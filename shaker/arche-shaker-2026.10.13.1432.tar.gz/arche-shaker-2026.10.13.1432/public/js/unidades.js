/* ═══ Unidades: conversiones fijas entre medidas (libra ↔ gramo, galón ↔ onza…) ═══
   Un insumo se guarda SIEMPRE en su unidad base (la que dice el insumo, ej. «gramo»). Antes, para
   comprar en libras había que definir «libra» como empaque en cada insumo; si no estaba, el cajero
   escribía «10» pensando en libras y el sistema entendía 10 gramos: el costo por gramo quedaba ~450
   veces más caro y las recetas salían con margen negativo. Ahora, si la unidad base es de peso o de
   volumen, se ofrecen solas las otras medidas de la misma familia, con la equivalencia escrita.
   Lo usan el navegador (window.Unidades) y el servidor (require), así la cuenta es la misma. */
(function (raiz) {
  'use strict';
  // factor = cuántas unidades de la base de la familia (gramo o mililitro) trae una.
  const MEDIDAS = [
    { clave: 'gramo', familia: 'peso', factor: 1, nombre: 'gramo', corto: 'g', alias: ['g', 'gr', 'grs', 'gramo', 'gramos'] },
    { clave: 'kilo', familia: 'peso', factor: 1000, nombre: 'kilo', corto: 'kg', alias: ['kg', 'kgs', 'kilo', 'kilos', 'kilogramo', 'kilogramos'] },
    { clave: 'libra', familia: 'peso', factor: 453.592, nombre: 'libra', corto: 'lb', alias: ['lb', 'lbs', 'libra', 'libras'] },
    { clave: 'onza', familia: 'peso', factor: 28.3495, nombre: 'onza', corto: 'oz', alias: ['oz', 'onza de peso'] },
    { clave: 'ml', familia: 'volumen', factor: 1, nombre: 'mililitro', corto: 'ml', alias: ['ml', 'mililitro', 'mililitros'] },
    { clave: 'litro', familia: 'volumen', factor: 1000, nombre: 'litro', corto: 'lt', alias: ['l', 'lt', 'lts', 'litro', 'litros'] },
    { clave: 'galon', familia: 'volumen', factor: 3785.41, nombre: 'galón', corto: 'gal', alias: ['gal', 'galon', 'galón', 'galones'] },
    // En los negocios de aquí «onza» casi siempre es de líquido (leche, pulpa): como unidad base se toma
    // como onza líquida. En un insumo de peso se ofrece la onza de peso (arriba), con su equivalencia.
    { clave: 'onza_liq', familia: 'volumen', factor: 29.5735, nombre: 'onza', corto: 'oz', alias: ['onza', 'onzas', 'onza liquida', 'onza líquida', 'oz fl', 'fl oz'] }
  ];

  const limpiar = t => String(t || '').trim().toLowerCase().replace(/\.$/, '');
  // La unidad base de un insumo, si es una medida conocida.
  function deUnidad(unidad) {
    const u = limpiar(unidad);
    if (!u) return null;
    // «onza» sola como base = líquida; «oz» también.
    if (u === 'oz') return MEDIDAS.find(m => m.clave === 'onza_liq');
    return MEDIDAS.find(m => m.alias.includes(u)) || null;
  }
  const porClave = clave => MEDIDAS.find(m => m.clave === clave) || null;

  // Cuántas unidades base del insumo trae UNA de la medida `clave`. null si no se pueden convertir.
  function factor(unidadBase, clave) {
    const b = deUnidad(unidadBase), m = porClave(clave);
    if (!b || !m || b.familia !== m.familia) return null;
    return m.factor / b.factor;
  }

  const redondear = (n, d) => { const p = Math.pow(10, d); return Math.round(n * p) / p; };
  const numero = n => Number(n).toLocaleString('es-DO', { maximumFractionDigits: n >= 1000 ? 0 : n >= 10 ? 1 : 2 });

  // Las otras medidas de la familia de la unidad base, con su equivalencia escrita:
  // [{ clave, nombre, factor, etiqueta: 'libra (453.6 gramo)' }]
  function opciones(unidadBase) {
    const b = deUnidad(unidadBase);
    if (!b) return [];
    return MEDIDAS.filter(m => m.familia === b.familia && m.clave !== b.clave)
      .map(m => {
        const f = m.factor / b.factor;
        return { clave: m.clave, nombre: m.nombre, corto: m.corto, factor: f, etiqueta: `${m.nombre} (${numero(f)} ${unidadBase})` };
      });
  }

  // Para mostrar una cantidad en base con una ayuda legible: 2159.136 gramo → «2,159 gramo (4.8 lb)».
  function ayuda(cantidad, unidadBase) {
    const b = deUnidad(unidadBase);
    const q = Number(cantidad);
    if (!b || !isFinite(q) || q === 0) return '';
    const grande = b.familia === 'peso' ? porClave('libra') : porClave('galon');
    if (b.clave === grande.clave) return '';
    const enGrande = q * b.factor / grande.factor;
    return enGrande >= 0.5 ? `${numero(enGrande)} ${grande.corto}` : '';
  }

  const api = { MEDIDAS, deUnidad, factor, opciones, ayuda, redondear };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else raiz.Unidades = api;
})(typeof window !== 'undefined' ? window : globalThis);
