-- Sistema de factura global — esquema v1
-- Recrea todo desde cero. Solo corre en una instalación NUEVA (asistente de
-- primer uso, routes/setup.js) — nunca como migración de una base con datos.

DROP TABLE IF EXISTS web_orders CASCADE;
DROP TABLE IF EXISTS cash_movements CASCADE;
DROP TABLE IF EXISTS cash_sessions CASCADE;
DROP TABLE IF EXISTS expenses CASCADE;
DROP TABLE IF EXISTS production_runs CASCADE;
DROP TABLE IF EXISTS preparation_inputs CASCADE;
DROP TABLE IF EXISTS preparations CASCADE;
DROP TABLE IF EXISTS supply_lots CASCADE;
DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS dining_tables CASCADE;
DROP TABLE IF EXISTS inventory_check_items CASCADE;
DROP TABLE IF EXISTS inventory_checks CASCADE;
DROP TABLE IF EXISTS employee_shifts CASCADE;
DROP TABLE IF EXISTS transfer_items CASCADE;
DROP TABLE IF EXISTS transfers CASCADE;
DROP TABLE IF EXISTS inventory_movements CASCADE;
DROP TABLE IF EXISTS sale_items CASCADE;
DROP TABLE IF EXISTS sales CASCADE;
DROP TABLE IF EXISTS customers CASCADE;
DROP TABLE IF EXISTS offer_locations CASCADE;
DROP TABLE IF EXISTS offer_items CASCADE;
DROP TABLE IF EXISTS offers CASCADE;
DROP TABLE IF EXISTS product_modifier_groups CASCADE;
DROP TABLE IF EXISTS modifier_options CASCADE;
DROP TABLE IF EXISTS modifier_groups CASCADE;
DROP TABLE IF EXISTS product_supplies CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS menu_categories CASCADE;
DROP TABLE IF EXISTS menu_schedules CASCADE;
DROP TABLE IF EXISTS audit_log CASCADE;
DROP TABLE IF EXISTS location_supply_stock CASCADE;
DROP TABLE IF EXISTS supplies CASCADE;
DROP TABLE IF EXISTS employees CASCADE;
DROP TABLE IF EXISTS locations CASCADE;
DROP TABLE IF EXISTS app_settings CASCADE;

-- ── Configuración general (nombre, logo, contraseña de dueño, impuestos) ──
-- Fila única (id=1). Pública sin login solo en nombre/logo: la pantalla de
-- entrada los necesita antes de autenticar. La contraseña se guarda hasheada
-- (scrypt, services/authService.js) y session_secret firma los tokens de
-- sesión — ambos se generan solos en el primer arranque.
CREATE TABLE app_settings (
  id                    SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  business_name         TEXT NOT NULL DEFAULT 'Mi negocio',
  logo_data_url         TEXT,
  owner_password_hash   TEXT,
  session_secret        TEXT,
  -- ITBIS y propina legal: apagados por defecto; el dueño los activa desde
  -- Configuración según lo que su negocio necesite. Los porcentajes son
  -- editables (RD: ITBIS 18%, propina legal 10% — ver salesService.js).
  itbis_enabled         BOOLEAN NOT NULL DEFAULT false,
  itbis_rate            NUMERIC(5,2) NOT NULL DEFAULT 18 CHECK (itbis_rate >= 0 AND itbis_rate <= 100),
  tip_enabled           BOOLEAN NOT NULL DEFAULT false,
  tip_rate              NUMERIC(5,2) NOT NULL DEFAULT 10 CHECK (tip_rate >= 0 AND tip_rate <= 100),
  -- Aviso de stock bajo por WhatsApp (services/lowStockAlertService.js).
  -- Throttle: se manda una vez y no se repite hasta que pase el tiempo mínimo.
  owner_whatsapp_number       TEXT,
  whatsapp_last_low_stock_alert_at TIMESTAMPTZ,
  whatsapp_last_reminder_alert_at  TIMESTAMPTZ,
  -- Página web de pedidos (routes/public.js): interruptor general, pausa
  -- temporal, qué punto de venta recibe los pedidos, costo de delivery, pedido
  -- mínimo, mensaje para el cliente, dominios autorizados a llamar a la API y
  -- el WhatsApp de respaldo que la página usa si esta API no responde.
  web_orders_enabled    BOOLEAN NOT NULL DEFAULT false,
  web_orders_paused     BOOLEAN NOT NULL DEFAULT false,
  web_location_id       INTEGER,
  web_delivery_fee      NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (web_delivery_fee >= 0),
  web_min_order         NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (web_min_order >= 0),
  web_prep_minutes      SMALLINT NOT NULL DEFAULT 30 CHECK (web_prep_minutes >= 0 AND web_prep_minutes <= 240),
  web_message           TEXT,
  web_allowed_origins   TEXT,
  web_whatsapp_number   TEXT,
  web_auto_send         BOOLEAN NOT NULL DEFAULT false,
  web_notify_customers  BOOLEAN NOT NULL DEFAULT false,
  -- Textos de la página (portada, contacto, aviso, pie) y su dirección pública.
  -- Colores de la marca (NULL = paleta por defecto). Ver public/js/brand.js.
  brand_accent          TEXT CHECK (brand_accent    IS NULL OR brand_accent    ~ '^#[0-9a-fA-F]{6}$'),
  brand_ink             TEXT CHECK (brand_ink       IS NULL OR brand_ink       ~ '^#[0-9a-fA-F]{6}$'),
  brand_paper           TEXT CHECK (brand_paper     IS NULL OR brand_paper     ~ '^#[0-9a-fA-F]{6}$'),
  brand_highlight       TEXT CHECK (brand_highlight IS NULL OR brand_highlight ~ '^#[0-9a-fA-F]{6}$'),
  -- Módulos encendidos/apagados ({} = todo encendido). Ver services/modules.js.
  modules               JSONB NOT NULL DEFAULT '{}'::jsonb,
  -- Tipo de negocio (vocabulario y plantilla), moneda y medios de pago.
  activity              TEXT NOT NULL DEFAULT 'restaurante' CHECK (activity IN ('restaurante', 'cafeteria', 'tienda', 'servicios', 'otro')),
  currency_symbol       TEXT NOT NULL DEFAULT 'RD$' CHECK (char_length(currency_symbol) BETWEEN 1 AND 6),
  payment_methods       JSONB NOT NULL DEFAULT '["Efectivo", "Transferencia", "Tarjeta"]'::jsonb,
  -- Pedidos de la página: vencimiento (min), horario de la tienda, zonas de delivery, bloqueos.
  web_expire_minutes    SMALLINT NOT NULL DEFAULT 15 CHECK (web_expire_minutes >= 0 AND web_expire_minutes <= 240),
  web_hours             JSONB NOT NULL DEFAULT '[]'::jsonb,
  web_delivery_zones    JSONB NOT NULL DEFAULT '[]'::jsonb,
  web_blocked_phones    TEXT,
  web_require_payment_confirmation BOOLEAN NOT NULL DEFAULT false,
  web_content           JSONB NOT NULL DEFAULT '{}'::jsonb,
  web_site_url          TEXT,
  -- Dominio propio de la tienda generada (opcional; sin http ni ruta).
  web_store_domain      TEXT CHECK (web_store_domain IS NULL OR web_store_domain ~ '^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$'),
  -- Tope de descuento (%) que puede dar un empleado; el dueño no tiene tope.
  discount_max_pct      NUMERIC(5,2) NOT NULL DEFAULT 10 CHECK (discount_max_pct >= 0 AND discount_max_pct <= 100),
  -- Correo del dueño (recuperar la contraseña).
  owner_email           TEXT,
  -- Última vez que la página pidió sus datos (¿está conectada?).
  web_last_site_fetch   TIMESTAMPTZ,
  web_last_site_origin  TEXT,
  -- Con cuántos días de anticipación se avisa que un lote está por vencer.
  expiry_alert_days     SMALLINT NOT NULL DEFAULT 3 CHECK (expiry_alert_days >= 0 AND expiry_alert_days <= 60),
  -- Respaldo automático cada 15 días (services/backupService.js).
  last_auto_backup_at   TIMESTAMPTZ,
  -- Última vez que el respaldo automático se copió con éxito fuera del servidor.
  last_offsite_backup_at TIMESTAMPTZ,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO app_settings (id, business_name) VALUES (1, 'Mi negocio');

-- ── Ubicaciones: almacén central + puntos de venta ───────────────────
-- 'kind' conserva sus valores internos heredados ('central' = almacén,
-- 'carrito' = punto de venta) — la interfaz los muestra con los nombres
-- de un restaurante ("Almacén", "Punto de venta").
CREATE TABLE locations (
  id                 SERIAL PRIMARY KEY,
  name               TEXT NOT NULL,
  kind               TEXT NOT NULL CHECK (kind IN ('central', 'carrito')),
  address            TEXT,
  pin                TEXT,
  active             BOOLEAN NOT NULL DEFAULT true,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO locations (name, kind) VALUES ('Almacén', 'central');

-- ── Empleados: el PIN identifica a la PERSONA, no a la ubicación ─────
-- Un empleado se asigna a UNA ubicación; el `kind` de esa ubicación decide
-- si ve la interfaz de punto de venta o la de almacén. Nunca se borra
-- (solo active=false) para no perder su historial.
CREATE TABLE employees (
  id           SERIAL PRIMARY KEY,
  name         TEXT NOT NULL,
  pin          TEXT NOT NULL,
  location_id  INTEGER NOT NULL REFERENCES locations(id),
  active       BOOLEAN NOT NULL DEFAULT true,
  -- cajero (vende), cocina (solo la pantalla de cocina), gerente (sin tope de descuento ni límite de día).
  role         TEXT NOT NULL DEFAULT 'cajero' CHECK (role IN ('cajero', 'cocina', 'gerente')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Único solo entre los ACTIVOS: el PIN de un empleado despedido se puede reutilizar.
CREATE UNIQUE INDEX idx_employees_pin_active ON employees(pin) WHERE active = true;

-- ── Turnos: llegada y salida de cada empleado ────────────────────────
-- ended_at NULL = turno abierto. El cierre real es que el empleado toque
-- "Salir" (services/shiftService.js).
CREATE TABLE employee_shifts (
  id           SERIAL PRIMARY KEY,
  employee_id  INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  location_id  INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  started_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at     TIMESTAMPTZ,
  close_type   TEXT CHECK (close_type IN ('manual', 'reported_next_login', 'auto_timeout')),
  reported_at  TIMESTAMPTZ
);
CREATE UNIQUE INDEX idx_employee_shifts_open ON employee_shifts(employee_id) WHERE ended_at IS NULL;
CREATE INDEX idx_employee_shifts_location ON employee_shifts(location_id, started_at DESC);

-- ── Insumos: catálogo (sin cantidad) + stock por ubicación ───────────
CREATE TABLE supplies (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  unit        TEXT NOT NULL,
  unit_cost   NUMERIC(12,4) NOT NULL DEFAULT 0,
  -- Empaque de COMPRA (como lo vende el proveedor) y de REPARTO (como se
  -- maneja al transferir) — independientes y opcionales.
  pack_name   TEXT,
  pack_size   NUMERIC(10,3),
  transfer_pack_name   TEXT,
  transfer_pack_size   NUMERIC(10,3),
  -- Qué insumos entran al conteo periódico de un punto de venta, y cómo:
  -- 'package' = confirmar paquetes cerrados; 'exact' = cantidad exacta, a ciegas.
  count_in_inventory_check  BOOLEAN NOT NULL DEFAULT false,
  count_mode  TEXT NOT NULL DEFAULT 'package' CHECK (count_mode IN ('package', 'exact')),
  -- Control de vencimiento (opcional, por insumo): si está activo, cada compra
  -- o entrada puede llevar la fecha en que vence, y las ventas gastan primero
  -- lo que vence antes (ver supply_lots y services/inventoryService.js).
  track_expiry  BOOLEAN NOT NULL DEFAULT false,
  active      BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE location_supply_stock (
  location_id          INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  supply_id            INTEGER NOT NULL REFERENCES supplies(id) ON DELETE CASCADE,
  stock                NUMERIC(10,3) NOT NULL DEFAULT 0,
  low_stock_threshold  NUMERIC(10,3) NOT NULL DEFAULT 0,
  PRIMARY KEY (location_id, supply_id)
);

-- ── Conteos de inventario de un punto de venta ───────────────────────
-- Un conteo físico una vez por semana y cada vez que cambia quién abre
-- (services/inventoryCheckService.js). `expected` se guarda junto a
-- `reported` para que el "debería haber" quede fijo en el tiempo.
CREATE TABLE inventory_checks (
  id           SERIAL PRIMARY KEY,
  location_id  INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  employee_id  INTEGER NOT NULL REFERENCES employees(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  trigger      TEXT NOT NULL CHECK (trigger IN ('semanal', 'cambio_empleado', 'semanal_y_cambio')),
  note         TEXT
);
CREATE INDEX idx_inventory_checks_location ON inventory_checks(location_id, created_at DESC);

CREATE TABLE inventory_check_items (
  id            SERIAL PRIMARY KEY,
  check_id      INTEGER NOT NULL REFERENCES inventory_checks(id) ON DELETE CASCADE,
  supply_id     INTEGER NOT NULL REFERENCES supplies(id),
  expected_qty  NUMERIC(12,4) NOT NULL,
  reported_qty  NUMERIC(12,4) NOT NULL
);
CREATE INDEX idx_inventory_check_items_check_id ON inventory_check_items(check_id);

-- ── Menú: categorías y subcategorías ─────────────────────────────────
-- Dos niveles: una categoría ("Almuerzos") con subcategorías ("Wraps
-- medianos"). Un producto cuelga de la más específica que tenga.
-- Horarios de venta (desayuno, almuerzo, cena): días de la semana (1 = lunes …
-- 7 = domingo) y franja horaria en hora de Santo Domingo. Una franja que
-- termina antes de empezar (ej. 18:00–02:00) cruza la medianoche. Se asignan a
-- categorías o a productos sueltos; solo afectan a la PÁGINA WEB (en el
-- local se vende lo que haya, a la hora que sea).
CREATE TABLE menu_schedules (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  days        SMALLINT[] NOT NULL DEFAULT '{1,2,3,4,5,6,7}',
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  active      BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE menu_categories (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  parent_id   INTEGER REFERENCES menu_categories(id) ON DELETE CASCADE,
  icon        TEXT,
  image_url   TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  active      BOOLEAN NOT NULL DEFAULT true,
  web_visible  BOOLEAN NOT NULL DEFAULT true,
  schedule_id  INTEGER REFERENCES menu_schedules(id) ON DELETE SET NULL,
  -- Frase corta que la página muestra bajo el nombre de la categoría.
  tagline      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_menu_categories_parent ON menu_categories(parent_id);

-- ── Productos (lo que se vende) ──────────────────────────────────────
-- Plato, batida o producto de reventa: todos se venden igual y descuentan
-- insumos por receta (product_supplies). Un producto de reventa (agua,
-- refresco) es simplemente un insumo + un producto con receta de 1 unidad.
CREATE TABLE products (
  id           SERIAL PRIMARY KEY,
  name         TEXT NOT NULL,
  category_id  INTEGER REFERENCES menu_categories(id) ON DELETE SET NULL,
  description  TEXT,
  image_url    TEXT,
  sale_price   NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (sale_price >= 0),
  sort_order   INTEGER NOT NULL DEFAULT 0,
  active       BOOLEAN NOT NULL DEFAULT true,
  -- Página web: ¿sale en la página? y, si tiene horario propio, cuál (si no,
  -- hereda el de su categoría).
  web_visible  BOOLEAN NOT NULL DEFAULT true,
  schedule_id  INTEGER REFERENCES menu_schedules(id) ON DELETE SET NULL,
  -- Ficha para la página: etiqueta (Nuevo, Popular…), calorías, proteína, y
  -- "agotado por hoy" (la fecha del día en que se marcó; vence sola).
  badge        TEXT,
  calories     INTEGER CHECK (calories IS NULL OR (calories >= 0 AND calories <= 5000)),
  protein_g    NUMERIC(6,1) CHECK (protein_g IS NULL OR (protein_g >= 0 AND protein_g <= 500)),
  sold_out_on  DATE,
  -- Tienda: código de barras (único entre los activos), SKU y ITBIS propio (NULL = el general; 0 = exento).
  barcode      TEXT,
  sku          TEXT,
  itbis_rate   NUMERIC(5,2) CHECK (itbis_rate IS NULL OR (itbis_rate >= 0 AND itbis_rate <= 100)),
  -- Mayoreo: a partir de esta cantidad en una línea, se cobra este precio en vez del de venta normal.
  wholesale_price     NUMERIC(10,2) CHECK (wholesale_price IS NULL OR wholesale_price >= 0),
  wholesale_min_qty   INTEGER CHECK (wholesale_min_qty IS NULL OR wholesale_min_qty > 0),
  -- Solo un gerente lo ve/vende en el punto de venta (ej. ventas al por
  -- mayor que en la práctica hace quien administra, no cualquier cajero).
  manager_only        BOOLEAN NOT NULL DEFAULT false,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_products_category ON products(category_id);
CREATE UNIQUE INDEX idx_products_barcode_active ON products(barcode) WHERE barcode IS NOT NULL AND active = true;

CREATE TABLE product_supplies (
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  supply_id   INTEGER NOT NULL REFERENCES supplies(id) ON DELETE RESTRICT,
  quantity    NUMERIC(10,3) NOT NULL CHECK (quantity > 0),
  unidad      TEXT,   -- medida en que se escribió (ej. «libra»); quantity siempre en la unidad base
  PRIMARY KEY (product_id, supply_id)
);

-- ── Modificadores: opciones que el cliente elige sobre un producto ───
-- Un grupo es "Elige tu acompañante" (una opción, obligatoria) o "Extras"
-- (varias, opcional). Cada opción puede sumar precio y, si consume un
-- insumo (ej. aguacate, bacon), descuenta stock y suma costo.
CREATE TABLE modifier_groups (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  selection   TEXT NOT NULL DEFAULT 'single' CHECK (selection IN ('single', 'multi')),
  required    BOOLEAN NOT NULL DEFAULT false,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  active      BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE modifier_options (
  id           SERIAL PRIMARY KEY,
  group_id     INTEGER NOT NULL REFERENCES modifier_groups(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  price_delta  NUMERIC(10,2) NOT NULL DEFAULT 0,
  supply_id    INTEGER REFERENCES supplies(id) ON DELETE RESTRICT,
  supply_qty   NUMERIC(10,3) CHECK (supply_qty IS NULL OR supply_qty > 0),
  sort_order   INTEGER NOT NULL DEFAULT 0,
  active       BOOLEAN NOT NULL DEFAULT true,
  CHECK ((supply_id IS NULL) = (supply_qty IS NULL))
);
CREATE INDEX idx_modifier_options_group ON modifier_options(group_id);

CREATE TABLE product_modifier_groups (
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  group_id    INTEGER NOT NULL REFERENCES modifier_groups(id) ON DELETE CASCADE,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (product_id, group_id)
);

-- ── Ofertas: un combo de productos a un precio fijo total ────────────
-- Cada producto del combo sigue siendo un sale_item normal (mismo costeo
-- real, mismo descuento de insumos); solo cambia cómo se reparte el precio
-- fijo entre esas líneas (services/salesService.js).
CREATE TABLE offers (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  price       NUMERIC(10,2) NOT NULL CHECK (price > 0),
  -- Apagador general, separado de EN QUÉ puntos de venta corre (offer_locations).
  active      BOOLEAN NOT NULL DEFAULT true,
  -- Lo que la página muestra de la oferta.
  label        TEXT,
  description  TEXT,
  image_url    TEXT,
  web_visible  BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE offer_items (
  offer_id    INTEGER NOT NULL REFERENCES offers(id) ON DELETE CASCADE,
  product_id  INTEGER NOT NULL REFERENCES products(id),
  quantity    NUMERIC(10,3) NOT NULL CHECK (quantity > 0),
  PRIMARY KEY (offer_id, product_id)
);

CREATE TABLE offer_locations (
  offer_id     INTEGER NOT NULL REFERENCES offers(id) ON DELETE CASCADE,
  location_id  INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  PRIMARY KEY (offer_id, location_id)
);

-- ── Clientes: se crean solos desde una venta con teléfono ────────────
-- El teléfono es el identificador (único). El nombre de un teléfono ya
-- existente no se pisa desde una venta nueva (services/customerService.js).
CREATE TABLE customers (
  id          SERIAL PRIMARY KEY,
  phone       TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  last_address TEXT,
  -- Fiado: tope de deuda (NULL = sin tope).
  credit_limit NUMERIC(10,2) CHECK (credit_limit IS NULL OR credit_limit >= 0),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Ventas ────────────────────────────────────────────────────────────
-- `total` es la venta NETA (sin ITBIS ni propina): es lo que suman los
-- reportes y de lo que sale la ganancia. `amount_due` es lo que de verdad
-- paga el cliente (neto + ITBIS + propina) — columna generada, no puede
-- desalinearse de sus componentes.
CREATE TABLE sales (
  id              SERIAL PRIMARY KEY,
  location_id     INTEGER NOT NULL REFERENCES locations(id),
  status          TEXT NOT NULL DEFAULT 'completada' CHECK (status IN ('completada', 'anulada')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  voided_at       TIMESTAMPTZ,
  void_reason     TEXT,
  customer_name   TEXT,
  payment_method  TEXT,
  notes           TEXT,
  total           NUMERIC(10,2) NOT NULL,
  itbis_amount    NUMERIC(10,2) NOT NULL DEFAULT 0,
  tip_amount      NUMERIC(10,2) NOT NULL DEFAULT 0,
  -- Delivery: se cobra aparte, no es venta del negocio (no entra a `total` ni a la ganancia).
  delivery_fee    NUMERIC(10,2) NOT NULL DEFAULT 0,
  amount_due      NUMERIC(10,2) GENERATED ALWAYS AS (total + itbis_amount + tip_amount + delivery_fee) STORED,
  -- Por dónde se vendió: mostrador (venta rápida), mesa, llevar o web.
  channel         TEXT NOT NULL DEFAULT 'mostrador' CHECK (channel IN ('mostrador', 'mesa', 'llevar', 'web', 'telefono')),
  -- Descuento sobre la venta (ya restado de `total`) y, si es una devolución (nota de crédito), la venta original.
  discount_amount NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
  discount_note   TEXT,
  return_of       INTEGER REFERENCES sales(id),
  total_cost      NUMERIC(10,2) NOT NULL,
  profit          NUMERIC(10,2) NOT NULL,
  -- UUID generado por el dispositivo ANTES de mandar la venta (modo sin
  -- conexión): un reintento con el mismo id no duplica la venta.
  client_id       TEXT,
  customer_id     INTEGER REFERENCES customers(id),
  employee_id     INTEGER REFERENCES employees(id) ON DELETE SET NULL
);
CREATE UNIQUE INDEX idx_sales_client_id ON sales(client_id) WHERE client_id IS NOT NULL;

CREATE TABLE sale_items (
  id            SERIAL PRIMARY KEY,
  sale_id       INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id    INTEGER REFERENCES products(id) ON DELETE SET NULL,
  -- Si no es NULL, la línea se vendió como parte de una oferta (el precio
  -- salió del combo). SET NULL: borrar la definición de una oferta no debe
  -- borrar el historial de ventas hechas con ella.
  offer_id      INTEGER REFERENCES offers(id) ON DELETE SET NULL,
  product_name  TEXT NOT NULL,
  quantity      NUMERIC(10,3) NOT NULL,
  unit_price    NUMERIC(10,2) NOT NULL,
  unit_cost     NUMERIC(10,2) NOT NULL,
  subtotal      NUMERIC(10,2) NOT NULL,
  -- Foto de las opciones elegidas al momento de la venta:
  -- [{ group, option, price_delta, cost }] — no depende de que el menú
  -- cambie después.
  modifiers     JSONB NOT NULL DEFAULT '[]'::jsonb,
  note          TEXT,
  -- ITBIS aplicado a la línea (foto del momento), parte del descuento que le tocó, y la línea original si es devolución.
  itbis_rate    NUMERIC(5,2),
  discount_share NUMERIC(10,2) NOT NULL DEFAULT 0,
  return_of_item INTEGER REFERENCES sale_items(id),
  -- Esta línea se cobró al precio de mayoreo (ver products.wholesale_price).
  is_wholesale  BOOLEAN NOT NULL DEFAULT false
);

-- ── Movimientos de inventario (bitácora, por ubicación) ──────────────
CREATE TABLE inventory_movements (
  id             SERIAL PRIMARY KEY,
  location_id    INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  supply_id      INTEGER NOT NULL REFERENCES supplies(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  type           TEXT NOT NULL CHECK (type IN ('compra', 'venta', 'ajuste', 'transferencia_salida', 'transferencia_entrada', 'merma', 'produccion')),
  quantity       NUMERIC(12,4) NOT NULL,
  note           TEXT,
  sale_id        INTEGER REFERENCES sales(id) ON DELETE SET NULL,
  transfer_id    INTEGER,
  -- Merma: por qué se perdió ('vencimiento', 'preparacion', 'derrame',
  -- 'devolucion', 'otro') y cuánto costaba cada unidad EN ESE MOMENTO (el
  -- costo del insumo puede cambiar después; la pérdida ya ocurrida no).
  reason         TEXT,
  unit_cost      NUMERIC(12,4),
  -- De qué lotes (por fecha de vencimiento) salió lo consumido:
  -- [{lot_id, expires_on, quantity}] — para poder devolverlos exactos al
  -- anular una venta.
  lots           JSONB
);

-- ── Preparaciones (insumos elaborados) ───────────────────────────────
-- Un insumo "preparado" se hace a partir de otros: pollo cocido y desmenuzado,
-- carne porcionada de 6 oz, salsa de la casa, base de batida. Su receta dice
-- cuánto de cada insumo entra en UNA tanda y cuánto rinde esa tanda (en la
-- unidad del insumo preparado). Al preparar, se gastan los ingredientes, se
-- suma lo preparado y su costo por unidad se calcula solo (lo que costaron los
-- ingredientes ÷ lo que salió de verdad). Después se usa en las recetas de los
-- platos como cualquier otro insumo.
CREATE TABLE preparations (
  supply_id    INTEGER PRIMARY KEY REFERENCES supplies(id) ON DELETE CASCADE,
  batch_yield  NUMERIC(12,3) NOT NULL CHECK (batch_yield > 0)
);
CREATE TABLE preparation_inputs (
  supply_id        INTEGER NOT NULL REFERENCES preparations(supply_id) ON DELETE CASCADE,
  input_supply_id  INTEGER NOT NULL REFERENCES supplies(id) ON DELETE RESTRICT,
  quantity         NUMERIC(12,3) NOT NULL CHECK (quantity > 0),
  PRIMARY KEY (supply_id, input_supply_id)
);
-- Cada vez que se prepara algo: qué se esperaba y qué salió de verdad (el
-- rendimiento real: la carne pierde peso al cocinarse, las verduras al limpiarse).
CREATE TABLE production_runs (
  id                SERIAL PRIMARY KEY,
  location_id       INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  supply_id         INTEGER NOT NULL REFERENCES supplies(id) ON DELETE CASCADE,
  batches           NUMERIC(10,3) NOT NULL CHECK (batches > 0),
  expected_output   NUMERIC(12,3) NOT NULL,
  actual_output     NUMERIC(12,3) NOT NULL CHECK (actual_output > 0),
  input_cost        NUMERIC(12,2) NOT NULL,
  unit_cost         NUMERIC(12,4) NOT NULL,
  note              TEXT,
  employee_id       INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_production_runs_created ON production_runs(created_at);

-- ── Gastos del negocio ───────────────────────────────────────────────
-- Lo que NO es mercancía (esa ya cuenta en el costo de cada venta): alquiler,
-- nómina, luz, transporte… Con esto Ganancias puede mostrar la ganancia real
-- del negocio y no solo "venta − costo de insumos". location_id NULL = gasto
-- general del negocio.
CREATE TABLE expenses (
  id            SERIAL PRIMARY KEY,
  location_id   INTEGER REFERENCES locations(id) ON DELETE SET NULL,
  category      TEXT NOT NULL CHECK (category IN ('alquiler', 'nomina', 'servicios', 'transporte', 'mantenimiento', 'impuestos', 'publicidad', 'otros')),
  description   TEXT NOT NULL,
  amount        NUMERIC(12,2) NOT NULL CHECK (amount > 0),
  expense_date  DATE NOT NULL DEFAULT ((now() AT TIME ZONE 'America/Santo_Domingo')::date),
  note          TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_expenses_date ON expenses(expense_date);

-- ── Cierre de caja (por punto de venta) ──────────────────────────────
-- Se abre con un fondo, se anotan entradas/salidas de efectivo que no son
-- ventas (pagar al del hielo, cambio), y al cerrar se cuenta lo que hay: el
-- sistema calcula cuánto DEBERÍA haber y muestra la diferencia.
CREATE TABLE cash_sessions (
  id               SERIAL PRIMARY KEY,
  location_id      INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  opened_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  opened_by        INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  opening_amount   NUMERIC(12,2) NOT NULL CHECK (opening_amount >= 0),
  closed_at        TIMESTAMPTZ,
  closed_by        INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  counted_amount   NUMERIC(12,2),
  expected_amount  NUMERIC(12,2),
  difference       NUMERIC(12,2),
  close_note       TEXT
);
-- Una sola caja abierta por punto de venta.
CREATE UNIQUE INDEX idx_cash_one_open ON cash_sessions(location_id) WHERE closed_at IS NULL;

CREATE TABLE cash_movements (
  id          SERIAL PRIMARY KEY,
  session_id  INTEGER NOT NULL REFERENCES cash_sessions(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL CHECK (kind IN ('entrada', 'salida')),
  amount      NUMERIC(12,2) NOT NULL CHECK (amount > 0),
  reason      TEXT NOT NULL,
  employee_id INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Lotes con fecha de vencimiento (solo insumos con track_expiry) ─────
-- Un lote = una entrada de un insumo con su fecha de vencimiento. NO
-- reemplaza a location_supply_stock (que sigue siendo el stock real): es un
-- registro paralelo para saber qué vence y cuándo. Si la suma de lotes es
-- menor al stock, la diferencia es stock "sin fecha" (cargado antes de activar
-- el control, o por un ajuste sin fecha).
CREATE TABLE supply_lots (
  id                  SERIAL PRIMARY KEY,
  location_id         INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  supply_id           INTEGER NOT NULL REFERENCES supplies(id) ON DELETE CASCADE,
  quantity_remaining  NUMERIC(12,4) NOT NULL CHECK (quantity_remaining >= 0),
  expires_on          DATE NOT NULL,
  received_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  source              TEXT NOT NULL DEFAULT 'compra',
  note                TEXT
);
CREATE INDEX idx_supply_lots_fefo ON supply_lots(location_id, supply_id, expires_on) WHERE quantity_remaining > 0;

-- ── Mesas y comandas ─────────────────────────────────────────────────
-- Una mesa pertenece a un punto de venta. Una comanda (order) es la cuenta
-- abierta de una mesa (o un pedido "para llevar" sin mesa) MIENTRAS se
-- atiende: se le van agregando platos, se manda a cocina por rondas, y al
-- cobrar se convierte en una venta normal (sales) — por eso el inventario,
-- los impuestos y los reportes siguen saliendo de un solo lugar.
CREATE TABLE dining_tables (
  id           SERIAL PRIMARY KEY,
  location_id  INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  seats        INTEGER CHECK (seats IS NULL OR seats > 0),
  sort_order   INTEGER NOT NULL DEFAULT 0,
  active       BOOLEAN NOT NULL DEFAULT true,
  UNIQUE (location_id, name)
);

CREATE TABLE orders (
  id             SERIAL PRIMARY KEY,
  location_id    INTEGER NOT NULL REFERENCES locations(id),
  table_id       INTEGER REFERENCES dining_tables(id) ON DELETE SET NULL,
  order_type     TEXT NOT NULL DEFAULT 'mesa' CHECK (order_type IN ('mesa', 'llevar')),
  -- Cómo se llama en pantalla y en el recibo ("Mesa 4", "Para llevar · Ana"):
  -- se guarda como texto para que renombrar o borrar la mesa no cambie el
  -- historial.
  label          TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'abierta' CHECK (status IN ('abierta', 'cobrada', 'cancelada')),
  customer_name  TEXT,
  note           TEXT,
  employee_id    INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  -- Pedidos que llegan de la página web (web_orders): de dónde vino, cómo se
  -- entrega y a quién.
  source         TEXT NOT NULL DEFAULT 'local' CHECK (source IN ('local', 'web')),
  fulfillment    TEXT CHECK (fulfillment IN ('retiro', 'delivery')),
  customer_phone TEXT,
  delivery_address TEXT,
  delivery_fee   NUMERIC(10,2) NOT NULL DEFAULT 0,
  payment_method TEXT,
  payment_status TEXT NOT NULL DEFAULT 'contra_entrega' CHECK (payment_status IN ('pendiente', 'contra_entrega', 'pagado')),
  dispatched_at  TIMESTAMPTZ,
  ready_notified BOOLEAN NOT NULL DEFAULT false,
  opened_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at      TIMESTAMPTZ,
  sale_id        INTEGER REFERENCES sales(id) ON DELETE SET NULL,
  cancel_reason  TEXT
);
-- Una mesa no puede tener dos cuentas abiertas a la vez.
CREATE UNIQUE INDEX idx_orders_one_open_per_table ON orders(table_id) WHERE status = 'abierta' AND table_id IS NOT NULL;
CREATE INDEX idx_orders_open ON orders(location_id) WHERE status = 'abierta';

-- Estados de un plato: 'pendiente' = anotado pero todavía no mandado a cocina
-- (se puede quitar sin rastro); 'nuevo' = ya en cocina; luego 'preparando' →
-- 'listo' → 'servido'. 'anulado' queda registrado con su motivo.
CREATE TABLE order_items (
  id            SERIAL PRIMARY KEY,
  order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id    INTEGER REFERENCES products(id) ON DELETE SET NULL,
  product_name  TEXT NOT NULL,
  quantity      INTEGER NOT NULL CHECK (quantity > 0),
  unit_price    NUMERIC(10,2) NOT NULL,
  -- Opciones elegidas: [{option_id, group, option, price_delta}]
  modifiers     JSONB NOT NULL DEFAULT '[]'::jsonb,
  note          TEXT,
  status        TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente', 'nuevo', 'preparando', 'listo', 'servido', 'anulado')),
  round         INTEGER,
  sent_at       TIMESTAMPTZ,
  started_at    TIMESTAMPTZ,
  ready_at      TIMESTAMPTZ,
  served_at     TIMESTAMPTZ,
  void_reason   TEXT,
  -- Venta en la que se cobró este plato (cuenta dividida: cada comensal paga lo suyo).
  sale_id       INTEGER REFERENCES sales(id) ON DELETE SET NULL,
  -- Plato que vino dentro de una oferta de la página (se cobra como combo).
  offer_id      INTEGER REFERENCES offers(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_kitchen ON order_items(status) WHERE status IN ('nuevo', 'preparando', 'listo');

-- ── Pedidos de la página web (bandeja de entrada) ────────────────────
-- La página los manda a /api/public/orders; el punto de venta los revisa y, al
-- aceptarlos, se convierten en una comanda normal (orders) que va a cocina.
-- `items` guarda lo pedido con los precios recalculados por el servidor.
CREATE TABLE web_orders (
  id              SERIAL PRIMARY KEY,
  public_token    TEXT NOT NULL UNIQUE,
  status          TEXT NOT NULL DEFAULT 'nuevo' CHECK (status IN ('nuevo', 'aceptado', 'rechazado', 'vencido', 'cancelado')),
  customer_name   TEXT NOT NULL,
  customer_phone  TEXT NOT NULL,
  fulfillment     TEXT NOT NULL CHECK (fulfillment IN ('retiro', 'delivery')),
  address         TEXT,
  payment_method  TEXT,
  note            TEXT,
  items           JSONB NOT NULL,
  net_total       NUMERIC(10,2) NOT NULL,
  delivery_fee    NUMERIC(10,2) NOT NULL DEFAULT 0,
  location_id     INTEGER REFERENCES locations(id) ON DELETE SET NULL,
  order_id        INTEGER REFERENCES orders(id) ON DELETE SET NULL,
  reject_reason   TEXT,
  cancel_reason   TEXT,
  -- 'pendiente' (transferencia por confirmar), 'contra_entrega' o 'pagado'.
  payment_status  TEXT NOT NULL DEFAULT 'contra_entrega' CHECK (payment_status IN ('pendiente', 'contra_entrega', 'pagado')),
  -- Clave que manda la página para que un reintento no duplique el pedido.
  client_key      TEXT,
  zone            TEXT,
  customer_id     INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  client_ip       TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at      TIMESTAMPTZ,
  decided_by      INTEGER REFERENCES employees(id) ON DELETE SET NULL
);
CREATE INDEX idx_web_orders_status ON web_orders(status, created_at);
CREATE UNIQUE INDEX idx_web_orders_client_key ON web_orders(client_key) WHERE client_key IS NOT NULL;
CREATE INDEX idx_web_orders_phone ON web_orders(customer_phone, created_at);

-- ── Transferencias entre ubicaciones ─────────────────────────────────
-- Lo que el origen ANOTA que envió no siempre es lo que el destino recibe.
-- 'pendiente': el origen se descuenta al instante, el destino no se acredita
-- hasta que confirme la cantidad REAL recibida. 'cancelada' repone el origen.
CREATE TABLE transfers (
  id                SERIAL PRIMARY KEY,
  from_location_id  INTEGER NOT NULL REFERENCES locations(id),
  to_location_id    INTEGER NOT NULL REFERENCES locations(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  status            TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente', 'confirmada', 'con_discrepancia', 'cancelada')),
  confirmed_at      TIMESTAMPTZ,
  cancelled_at      TIMESTAMPTZ,
  cancel_reason     TEXT,
  note              TEXT,
  created_by_employee_id    INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  confirmed_by_employee_id  INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  cancelled_by_employee_id  INTEGER REFERENCES employees(id) ON DELETE SET NULL
);

CREATE TABLE transfer_items (
  id                 SERIAL PRIMARY KEY,
  transfer_id        INTEGER NOT NULL REFERENCES transfers(id) ON DELETE CASCADE,
  supply_id          INTEGER NOT NULL REFERENCES supplies(id),
  quantity           NUMERIC(12,4) NOT NULL,
  -- NULL hasta que el destino confirma.
  received_quantity  NUMERIC(12,4),
  -- Lotes con vencimiento que salieron del origen: [{expires_on, quantity}].
  -- El destino los recibe con la misma fecha (ver inventoryService).
  lots               JSONB
);

ALTER TABLE inventory_movements
  ADD CONSTRAINT fk_inventory_movements_transfer
  FOREIGN KEY (transfer_id) REFERENCES transfers(id) ON DELETE SET NULL;

-- ── Bitácora de cambios de precio/costo ──────────────────────────────
-- Solo lo que mueve la ganancia reportada: products.sale_price y
-- supplies.unit_cost. entity_name guarda el nombre al momento del cambio.
CREATE TABLE audit_log (
  id            SERIAL PRIMARY KEY,
  entity_type   TEXT NOT NULL CHECK (entity_type IN ('product', 'supply')),
  entity_id     INTEGER,
  entity_name   TEXT,
  field         TEXT NOT NULL,
  old_value     NUMERIC(12,4),
  new_value     NUMERIC(12,4),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_log_entity ON audit_log(entity_type, entity_id);

-- ── Índices ──────────────────────────────────────────────────────────
CREATE INDEX idx_sale_items_sale_id ON sale_items(sale_id);
CREATE INDEX idx_sale_items_offer_id ON sale_items(offer_id) WHERE offer_id IS NOT NULL;
CREATE INDEX idx_inventory_movements_location_id ON inventory_movements(location_id);
CREATE INDEX idx_inventory_movements_created_at ON inventory_movements(created_at);
CREATE INDEX idx_inventory_movements_sale_id ON inventory_movements(sale_id);
CREATE INDEX idx_sales_created_at ON sales(created_at);
CREATE INDEX idx_sales_location_id ON sales(location_id);
CREATE INDEX idx_location_supply_stock_supply_id ON location_supply_stock(supply_id);
CREATE INDEX idx_product_supplies_supply_id ON product_supplies(supply_id);
CREATE INDEX idx_transfer_items_transfer_id ON transfer_items(transfer_id);

-- ── Fotos subidas desde el administrativo (página web) ───────────────
-- Se guardan como data URL (texto) para que entren en los respaldos.
DROP TABLE IF EXISTS media CASCADE;
CREATE TABLE media (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  mime        TEXT NOT NULL,
  data_url    TEXT NOT NULL,
  size_bytes  INTEGER NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── Recuperación de contraseña del dueño ─────────────────────────────
DROP TABLE IF EXISTS password_resets CASCADE;
CREATE TABLE password_resets (
  id          SERIAL PRIMARY KEY,
  code_hash   TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  attempts    INTEGER NOT NULL DEFAULT 0,
  used_at     TIMESTAMPTZ,
  ip          TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Crédito a clientes (fiado): cada cargo es una venta a crédito; cada abono, un pago
DROP TABLE IF EXISTS customer_ledger CASCADE;
CREATE TABLE customer_ledger (
  id           SERIAL PRIMARY KEY,
  customer_id  INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  kind         TEXT NOT NULL CHECK (kind IN ('cargo', 'abono')),
  amount       NUMERIC(10,2) NOT NULL CHECK (amount > 0),
  sale_id      INTEGER REFERENCES sales(id) ON DELETE SET NULL,
  method       TEXT,
  note         TEXT,
  employee_id  INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  location_id  INTEGER REFERENCES locations(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_customer_ledger_customer ON customer_ledger(customer_id);

-- Proveedores y órdenes de compra
DROP TABLE IF EXISTS vendors CASCADE;
CREATE TABLE vendors (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  phone       TEXT,
  email       TEXT,
  rnc         TEXT,
  notes       TEXT,
  active      BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE supplies ADD COLUMN vendor_id INTEGER REFERENCES vendors(id) ON DELETE SET NULL;
DROP TABLE IF EXISTS purchase_orders CASCADE;
CREATE TABLE purchase_orders (
  id          SERIAL PRIMARY KEY,
  vendor_id   INTEGER REFERENCES vendors(id) ON DELETE SET NULL,
  location_id INTEGER REFERENCES locations(id),
  status      TEXT NOT NULL DEFAULT 'borrador' CHECK (status IN ('borrador', 'enviada', 'recibida', 'cancelada')),
  notes       TEXT,
  expected_on DATE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  sent_at     TIMESTAMPTZ,
  received_at TIMESTAMPTZ
);
DROP TABLE IF EXISTS purchase_order_items CASCADE;
CREATE TABLE purchase_order_items (
  id          SERIAL PRIMARY KEY,
  po_id       INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  supply_id   INTEGER NOT NULL REFERENCES supplies(id),
  quantity    NUMERIC(12,3) NOT NULL CHECK (quantity > 0),
  unit_cost   NUMERIC(12,4) NOT NULL DEFAULT 0 CHECK (unit_cost >= 0)
);
CREATE INDEX idx_po_items_po ON purchase_order_items(po_id);

-- ── Solicitudes de reposición (el carrito pide, el almacén aprueba o rechaza) ──────
DROP TABLE IF EXISTS restock_request_items CASCADE;
DROP TABLE IF EXISTS restock_requests CASCADE;
CREATE TABLE restock_requests (
  id                       SERIAL PRIMARY KEY,
  location_id              INTEGER NOT NULL REFERENCES locations(id),
  requested_by_employee_id INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  status                   TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente', 'aprobada', 'rechazada', 'cancelada')),
  note                     TEXT,
  transfer_id              INTEGER REFERENCES transfers(id),
  reject_reason            TEXT,
  resolved_at              TIMESTAMPTZ,
  resolved_by_employee_id  INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_restock_requests_location ON restock_requests(location_id);
CREATE INDEX idx_restock_requests_status ON restock_requests(status);

CREATE TABLE restock_request_items (
  id          SERIAL PRIMARY KEY,
  request_id  INTEGER NOT NULL REFERENCES restock_requests(id) ON DELETE CASCADE,
  supply_id   INTEGER NOT NULL REFERENCES supplies(id),
  quantity    NUMERIC(12,3) NOT NULL CHECK (quantity > 0)
);
CREATE INDEX idx_restock_request_items_request ON restock_request_items(request_id);
