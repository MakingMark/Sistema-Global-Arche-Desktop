'use strict';
/* ═══ Celular: barra de pestañas + hoja «Más» (v3.2 administrativo, v3.3 facturación) ═══
   Antes el menú del dueño en el celular era un panel lateral con 4 grupos
   plegados (Inventario, Análisis, Catálogo, Negocio): quedaba medio vacío y
   cada sección costaba dos toques. Ahora sigue el mismo patrón que la
   facturación y que Chicheros: abajo, las 4 secciones de todos los días + «Más»,
   que abre una hoja con TODAS las secciones a la vista, agrupadas.
   Se arma desde el menú de escritorio (#owner-tabs), así respeta solo los
   módulos apagados (Modules.viewOff) y los íconos de siempre. Solo se ve por
   debajo de 820 px (ver app.css, «Administrativo en el celular»).
   v3.3: lo mismo para la facturación (fase 1 de ANALISIS-SISTEMA-COMPLETO.md):
   Vender · Mesas · Caja · Historial · Más (Cocina, Pedidos web, Reposición,
   Ayuda, Salir). El rol «cocina» solo ve Cocina. Los avisos con número
   (mesas listas, pedidos web) se copian a su pestaña, o a «Más» si están ahí. */
function setupMobileNav({ appId, navId, tabs, kicker, helpRole, allowed, short = {} }) {
  const app = document.getElementById(appId);
  const nav = document.getElementById(navId);
  if (!app || !nav) return;
  const TABS_FOR = () => (typeof tabs === 'function' ? tabs() : tabs);
  const off = view => {
    const it = itemFor(view);
    return !it || it.hidden || !!(window.Modules && Modules.viewOff(view)) || (allowed ? !allowed(view) : false);
  };
  const itemFor = view => nav.querySelector(`.nav-item[data-view="${view}"]`);
  const iconOf = item => { const svg = item.querySelector('svg'); return svg ? svg.outerHTML : ''; };
  const labelOf = item => (item.querySelector('.nav-label') || item).textContent.trim();
  const MORE_ICON = '<svg class="nav-icon" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="4" cy="9" r="1.4"/><circle cx="9" cy="9" r="1.4"/><circle cx="14" cy="9" r="1.4"/></svg>';

  /* ── Barra de abajo ── */
  const bar = document.createElement('nav');
  bar.className = 'owner-tabbar';
  bar.setAttribute('aria-label', 'Secciones principales');
  app.appendChild(bar);

  const badgeOf = item => { const b = item && item.querySelector('.nav-badge'); return b && !b.hidden && b.textContent.trim() !== '0' ? b.textContent.trim() : ''; };
  function paintBar() {
    const TABS = TABS_FOR();
    const tabs = TABS.filter(v => itemFor(v) && !off(v));
    const moreBadge = Array.from(nav.querySelectorAll('.nav-item[data-view]')).some(it => !tabs.includes(it.dataset.view) && !off(it.dataset.view) && badgeOf(it));
    bar.innerHTML = tabs.map(v => {
      const it = itemFor(v); const n = badgeOf(it);
      return `<button type="button" class="owner-tab" data-view="${v}">${iconOf(it)}<span>${short[v] || labelOf(it)}</span>${n ? `<i class="owner-tab-badge">${n}</i>` : ''}</button>`;
    }).join('') + `<button type="button" class="owner-tab" data-more aria-haspopup="dialog">${MORE_ICON}<span>Más</span>${moreBadge ? '<i class="owner-tab-badge is-dot"></i>' : ''}</button>`;
    markActive(currentView);
  }

  /* ── Hoja «Más» ── */
  const sheet = document.createElement('div');
  sheet.className = 'owner-more';
  sheet.hidden = true;
  sheet.innerHTML = `
    <div class="owner-more-backdrop" data-close></div>
    <section class="owner-more-panel" role="dialog" aria-modal="true" aria-label="Todas las secciones">
      <div class="owner-more-handle" aria-hidden="true"></div>
      <div class="owner-more-head">
        <div><p class="owner-more-kicker">${kicker}</p><h2 class="owner-more-title"></h2></div>
        <button type="button" class="owner-more-close" data-close aria-label="Cerrar">✕</button>
      </div>
      <div class="owner-more-body"></div>
      <div class="owner-more-foot">
        <a class="btn btn-sm" href="ayuda.html?role=${helpRole}" target="shaker-ayuda">Ayuda</a>
        <button type="button" class="btn btn-sm" data-logout>Salir</button>
        <span class="owner-more-arche" role="img" aria-label="Arche"></span>
      </div>
    </section>`;
  document.body.appendChild(sheet);
  const body = sheet.querySelector('.owner-more-body');

  function paintSheet() {
    const name = app.querySelector('.brand-name');
    sheet.querySelector('.owner-more-title').textContent = name ? name.textContent.trim() : '';
    const groups = nav.querySelectorAll('.nav-group').length ? Array.from(nav.querySelectorAll('.nav-group')) : [nav];
    body.innerHTML = groups.map(g => {
      const lbl = g.querySelector('.nav-group-label');
      const items = Array.from(g.querySelectorAll('.nav-item[data-view]')).filter(it => !off(it.dataset.view));
      if (!items.length) return '';
      return `<div class="owner-more-group">
        ${groups.length > 1 ? `<p class="owner-more-label">${lbl ? lbl.childNodes[0].textContent.trim() : 'Día a día'}</p>` : ''}
        <div class="owner-more-grid">${items.map(it => `<button type="button" class="owner-more-item${it.dataset.view === currentView ? ' is-active' : ''}" data-view="${it.dataset.view}">${iconOf(it)}<span>${labelOf(it)}</span>${badgeOf(it) ? `<i class="owner-tab-badge">${badgeOf(it)}</i>` : ''}</button>`).join('')}</div>
      </div>`;
    }).join('');
  }

  let lastFocus = null;
  function openSheet() {
    paintSheet();
    lastFocus = document.activeElement;
    sheet.hidden = false;
    requestAnimationFrame(() => sheet.classList.add('is-open'));
    document.documentElement.classList.add('owner-more-lock');
    const first = sheet.querySelector('.owner-more-item');
    if (first) first.focus({ preventScroll: true });
  }
  function closeSheet() {
    if (sheet.hidden) return;
    sheet.classList.remove('is-open');
    document.documentElement.classList.remove('owner-more-lock');
    setTimeout(() => { sheet.hidden = true; }, 260);
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }

  bar.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.hasAttribute('data-more')) { openSheet(); return; }
    window.showView(b.dataset.view);
    window.scrollTo({ top: 0 });
  });
  sheet.addEventListener('click', e => {
    if (e.target.closest('[data-close]')) { closeSheet(); return; }
    const it = e.target.closest('.owner-more-item');
    if (it) { window.showView(it.dataset.view); window.scrollTo({ top: 0 }); closeSheet(); }
    if (e.target.closest('[data-logout]')) closeSheet();
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

  // Deslizar hacia abajo desde el asa o el encabezado cierra la hoja.
  const panel = sheet.querySelector('.owner-more-panel');
  let y0 = null;
  panel.addEventListener('touchstart', e => { if (e.target.closest('.owner-more-handle, .owner-more-head')) y0 = e.touches[0].clientY; }, { passive: true });
  panel.addEventListener('touchmove', e => { if (y0 === null) return; const dy = Math.max(0, e.touches[0].clientY - y0); panel.style.transform = `translateY(${dy}px)`; }, { passive: true });
  panel.addEventListener('touchend', e => {
    if (y0 === null) return;
    const dy = e.changedTouches[0].clientY - y0; y0 = null; panel.style.transform = '';
    if (dy > 80) closeSheet();
  });

  /* ── Pestaña activa ── */
  let currentView = TABS_FOR()[0];
  function markActive(view) {
    const inBar = bar.querySelector(`[data-view="${view}"]`);
    bar.querySelectorAll('.owner-tab').forEach(b => {
      const on = inBar ? b.dataset.view === view : b.hasAttribute('data-more');
      b.classList.toggle('is-active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
  }
  window.addEventListener('view:show', e => { currentView = e.detail.view; markActive(currentView); });

  // Los módulos llegan después (appSettings.js) y los avisos cambian solos: se
  // rearma cuando cambian las clases, lo oculto o los números del menú.
  let raf = null;
  const repaint = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = null; paintBar(); }); };
  new MutationObserver(repaint).observe(nav, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['class', 'hidden'] });
  new MutationObserver(repaint).observe(app, { attributes: true, attributeFilter: ['data-emp-role', 'hidden'] });
  paintBar();
}

setupMobileNav({ appId: 'owner-app', navId: 'owner-tabs', kicker: 'Administrativo', helpRole: 'owner',
  tabs: ['panel', 'historial', 'inv-existencias', 'reportes'] });
setupMobileNav({ appId: 'cart-app', navId: 'cart-tabs', kicker: 'Facturación', helpRole: 'cart',
  allowed: v => document.getElementById('cart-app').dataset.empRole !== 'cocina' || v === 'pos-cocina',
  short: { 'pos-venta': 'Vender' },
  tabs: () => (document.getElementById('cart-app').dataset.empRole === 'cocina' ? ['pos-cocina'] : ['pos-venta', 'pos-mesas', 'pos-caja', 'pos-historial']) });
