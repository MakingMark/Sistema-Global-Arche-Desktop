/* ═══ Menú del punto de venta (compartido) ═══
   Todo lo que hace falta para ELEGIR productos en pantalla táctil: las
   categorías, la grilla de platos, la búsqueda y la hoja de opciones
   (acompañante, extras, nota). Lo usan la venta rápida (pos.js) y la cuenta
   de una mesa (mesas.js) — cada una decide qué pasa al elegir (onProduct).
   El menú, la configuración (¿cobra ITBIS/propina?) y el stock vienen del
   servidor y se cachean en el dispositivo (ver api.js), así que la selección
   funciona sin señal. */
const PosMenu = (function () {
  'use strict';
  let menu = { categories: [], products: [] };
  let settings = { itbis_enabled: false, itbis_rate: 18, tip_enabled: false, tip_rate: 10 };
  let stockBySupply = new Map();   // supply_id -> stock actual (solo para avisar "agotado")

  const esc = UI.escapeHtml;
  const round2 = n => Math.round(n * 100) / 100;
  const productById = id => menu.products.find(p => p.id === id);

  function optionById(product, optionId) {
    for (const g of product.modifier_groups) {
      const o = g.options.find(x => x.id === optionId);
      if (o) return { group: g, option: o };
    }
    return null;
  }
  const optionsDelta = (product, ids) => round2(ids.reduce((s, id) => {
    const f = optionById(product, id);
    return s + (f ? Number(f.option.price_delta) : 0);
  }, 0));

  // ITBIS y propina (opcionales, los prende el dueño): mismo cálculo que el
  // servidor (salesService.computeTaxes), sobre el neto.
  function computeTaxes(net) {
    return {
      itbis: settings.itbis_enabled ? round2(net * Number(settings.itbis_rate) / 100) : 0,
      tip: settings.tip_enabled ? round2(net * Number(settings.tip_rate) / 100) : 0
    };
  }

  // Descuento + ITBIS por producto + propina: el MISMO cálculo que el servidor (taxCore.js).
  // lines: [{ subtotal, rate }]  ·  discount: { type: 'percent'|'amount', value } | null
  const computeAmounts = (lines, discount) => TaxCore.compute({ lines, discount, tax: settings });
  const rateOf = productId => { const p = productById(productId); return p && p.itbis_rate !== undefined ? p.itbis_rate : null; };

  // Mayoreo: a partir de wholesale_min_qty EN ESA LÍNEA se cobra wholesale_price — mismo cálculo que el servidor.
  const isWholesale = (product, quantity) => !!(product && product.wholesale_price !== null && product.wholesale_price !== undefined && product.wholesale_min_qty && quantity >= Number(product.wholesale_min_qty));
  const unitPriceFor = (product, quantity) => Number(isWholesale(product, quantity) ? product.wholesale_price : product.sale_price);

  // Ventana para pedir un descuento. Resuelve { type, value, reason } o null si se cancela.
  function askDiscount(current) {
    return new Promise(resolve => {
      let done = false;
      const finish = v => { if (!done) { done = true; resolve(v); } };
      const m = UI.showModal('Descuento', `
        <div class="field"><label for="dc-type">Tipo</label><select id="dc-type"><option value="percent">Porcentaje (%)</option><option value="amount">Monto fijo</option></select></div>
        <div class="field"><label for="dc-value">Valor</label><input id="dc-value" type="number" min="0" step="0.01" inputmode="decimal" value="${current ? Number(current.value) : ''}"></div>
        <div class="field"><label for="dc-reason">Motivo (obligatorio)</label><input id="dc-reason" maxlength="120" placeholder="ej. cliente frecuente" value="${current ? esc(current.reason || '') : ''}"></div>
        <div id="dc-err" class="error" role="alert" hidden></div>
        <div class="modal-actions"><button class="btn btn-primary" id="dc-ok">Aplicar</button><button class="btn" id="dc-cancel">Cancelar</button></div>`, { onClose: () => finish(null) });
      const el = m.el;
      if (current) el.querySelector('#dc-type').value = current.type;
      el.querySelector('#dc-cancel').addEventListener('click', () => { m.close(); finish(null); });
      el.querySelector('#dc-ok').addEventListener('click', () => {
        const value = Number(el.querySelector('#dc-value').value), reason = el.querySelector('#dc-reason').value.trim(), type = el.querySelector('#dc-type').value;
        const err = el.querySelector('#dc-err');
        if (!(value > 0)) { err.textContent = 'Escribe cuánto se descuenta'; err.hidden = false; return; }
        if (type === 'percent' && value > 100) { err.textContent = 'El porcentaje no puede pasar de 100'; err.hidden = false; return; }
        if (!reason) { err.textContent = 'Escribe el motivo del descuento'; err.hidden = false; return; }
        m.close(); finish({ type, value, reason });
      });
    });
  }

  // Disponibilidad estimada: avisa, nunca bloquea (el stock cacheado puede
  // estar atrasado; el servidor es quien decide de verdad).
  function maxServings(product) {
    if (!product.supplies.length) return Infinity;
    let min = Infinity;
    for (const r of product.supplies) {
      if (!stockBySupply.has(r.supply_id)) return Infinity;
      min = Math.min(min, Math.floor(stockBySupply.get(r.supply_id) / Number(r.quantity) + 1e-9));
    }
    return min;
  }

  // Cada fuente es independiente: si una falla (sin señal Y sin caché), las
  // otras siguen sirviendo. El menú es la única imprescindible.
  async function load() {
    const [m, s, st] = await Promise.all([
      Api.pos.menu(),
      Api.settings.get().catch(() => null),
      Api.pos.stock().catch(() => null)
    ]);
    menu = m;
    if (s) settings = s;
    stockBySupply = new Map(st ? st.supplies.map(x => [x.supply_id, Number(x.stock)]) : []);
  }
  function refreshStock() {
    return Api.pos.stock()
      .then(st => { stockBySupply = new Map(st.supplies.map(x => [x.supply_id, Number(x.stock)])); })
      .catch(() => {});
  }

  /* ── Grilla + categorías + búsqueda ── */
  // opts: { tabsEl, subTabsEl, gridEl, searchEl, onProduct(p), counts() → Map(productId → n) }
  function mount(opts) {
    const { tabsEl, subTabsEl, gridEl, searchEl } = opts;
    let activeRoot = null;   // id de categoría principal elegida (null = todo, 0 = sin categoría)
    let activeSub = null;

    const rootCategories = () => menu.categories.filter(c => !c.parent_id);
    const childCategories = rootId => menu.categories.filter(c => c.parent_id === rootId);
    const categoryIdsFor = (rootId, subId) => subId ? [subId] : [rootId, ...childCategories(rootId).map(c => c.id)];

    function renderTabs() {
      const roots = rootCategories().filter(r => menu.products.some(p => categoryIdsFor(r.id, null).includes(p.category_id)));
      const uncategorized = menu.products.some(p => !p.category_id);
      const chip = (label, active, attrs) => `<button type="button" class="chip${active ? ' active' : ''}" role="tab" aria-selected="${active}" ${attrs}>${label}</button>`;
      // «★ Más vendidos» (v3.4): solo si ya hay suficientes ventas para que diga algo.
      const top = (menu.top_product_ids || []).filter(id => productById(id));
      tabsEl.innerHTML = chip('Todo', activeRoot === null, 'data-root=""') +
        (top.length >= 3 ? chip('★ Más vendidos', activeRoot === 'top', 'data-root="top"') : '') +
        roots.map(r => chip(`${esc(r.icon || '')} ${esc(r.name)}`.trim(), activeRoot === r.id, `data-root="${r.id}"`)).join('') +
        (uncategorized ? chip('Otros', activeRoot === 0, 'data-root="0"') : '');
      const subs = activeRoot ? childCategories(activeRoot).filter(c => menu.products.some(p => p.category_id === c.id)) : [];
      subTabsEl.hidden = !subs.length;
      subTabsEl.innerHTML = subs.length
        ? chip('Todos', activeSub === null, 'data-sub=""') + subs.map(c => chip(esc(c.name), activeSub === c.id, `data-sub="${c.id}"`)).join('')
        : '';
    }
    tabsEl.addEventListener('click', e => {
      const b = e.target.closest('[data-root]');
      if (!b) return;
      activeRoot = b.dataset.root === '' ? null : b.dataset.root === 'top' ? 'top' : Number(b.dataset.root);
      activeSub = null;
      render();
    });
    subTabsEl.addEventListener('click', e => {
      const b = e.target.closest('[data-sub]');
      if (!b) return;
      activeSub = b.dataset.sub === '' ? null : Number(b.dataset.sub);
      render();
    });
    searchEl.addEventListener('input', render);
    // Lector de código de barras: escribe el código y manda Enter. Si coincide exacto con un producto, se agrega solo.
    searchEl.addEventListener('keydown', e => {
      if (e.key !== 'Enter') return;
      const q = searchEl.value.trim().toLowerCase();
      if (!q) return;
      const hit = menu.products.find(p => (p.barcode && String(p.barcode).toLowerCase() === q) || (p.sku && String(p.sku).toLowerCase() === q));
      e.preventDefault();
      if (hit) { searchEl.value = ''; opts.onProduct(hit); render(); }
      else UI.toast('Ningún producto tiene ese código', 'error');
    });

    function visibleProducts() {
      const q = searchEl.value.trim().toLowerCase();
      if (q) return menu.products.filter(p => p.name.toLowerCase().includes(q) || (p.barcode && String(p.barcode).toLowerCase().includes(q)) || (p.sku && String(p.sku).toLowerCase().includes(q)));
      if (activeRoot === null) return menu.products;
      if (activeRoot === 'top') return (menu.top_product_ids || []).map(productById).filter(Boolean);
      if (activeRoot === 0) return menu.products.filter(p => !p.category_id);
      const ids = categoryIdsFor(activeRoot, activeSub);
      return menu.products.filter(p => ids.includes(p.category_id));
    }

    // El servidor manda las categorías en el orden del menú (principal, luego
    // sus subcategorías); los productos siguen ese mismo orden.
    function sortedByMenuOrder(list) {
      const pos = new Map(menu.categories.map((c, i) => [c.id, i]));
      return [...list].sort((a, b) => (pos.get(a.category_id) ?? 1e6) - (pos.get(b.category_id) ?? 1e6) || a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'es'));
    }

    // v3.1: los productos entran escalonados SOLO al cambiar de categoría o de
    // búsqueda (render() también corre con cada producto agregado, y ahí no
    // debe repetirse); el contador del producto que se acaba de sumar salta.
    let lastSig = null, prevCounts = new Map(), lastRect = null;
    function render() {
      renderTabs();
      const list = activeRoot === 'top' && !searchEl.value.trim() ? visibleProducts() : sortedByMenuOrder(visibleProducts());
      const counts = opts.counts ? opts.counts() : new Map();
      const sig = `${activeRoot}|${activeSub}|${searchEl.value.trim()}`;
      const entering = sig !== lastSig;
      lastSig = sig;
      gridEl.classList.toggle('is-entering', entering && !(window.Motion && Motion.reduce));
      // Sin ninguna foto en lo que se ve, tarjetas altas con medio cuadro vacío no
      // sirven: se muestran como lista compacta (más productos por pantalla).
      gridEl.classList.toggle('is-list', list.length > 0 && !list.some(p => p.image_url));
      gridEl.innerHTML = '';
      if (!list.length) {
        gridEl.innerHTML = `<p class="muted">${menu.products.length ? 'Nada coincide con esa búsqueda.' : 'Todavía no hay productos en el menú.'}</p>`;
        return;
      }
      list.forEach((p, idx) => {
        const n = counts.get(p.id) || 0;
        const servings = maxServings(p);
        const out = servings <= 0;
        const tile = document.createElement('button');
        tile.type = 'button';
        tile.className = 'pos-tile' + (out ? ' is-out' : '') + (n > (prevCounts.get(p.id) || 0) ? ' is-added' : '');
        if (entering) tile.style.setProperty('--i', Math.min(idx, 18));
        tile.innerHTML = `
          ${p.image_url ? `<img class="pos-tile-img" src="${esc(p.image_url)}" alt="" loading="lazy">` : ''}
          <span class="pos-tile-name">${esc(p.name)}</span>
          <span class="pos-tile-price">${fmt(p.sale_price)}${p.modifier_groups.length ? ' <span class="pos-tile-opt" title="Tiene opciones">＋</span>' : ''}</span>
          ${p.wholesale_price !== null && p.wholesale_price !== undefined && p.wholesale_min_qty ? `<span class="pos-tile-wholesale">Mayoreo: ${fmt(p.wholesale_price)} c/u desde ${p.wholesale_min_qty}</span>` : ''}
          ${out ? '<span class="pos-tile-flag">Agotado</span>' : (servings <= 3 && servings !== Infinity ? `<span class="pos-tile-flag is-low">Quedan ${servings}</span>` : '')}
          ${n ? `<span class="pos-tile-count" aria-label="${n} en la cuenta">${n}</span>` : ''}
        `;
        tile.addEventListener('click', async () => {
          lastRect = tile.getBoundingClientRect();
          if (out && !(await UI.confirmDialog(`El stock cargado dice que "${p.name}" está agotado. ¿Agregarlo igual?`))) return;
          opts.onProduct(p);
        });
        gridEl.appendChild(tile);
      });
      prevCounts = counts;
    }
    return { render, lastRect: () => lastRect };
  }

  /* ── Hoja de opciones: elegir acompañante/extras y nota antes de agregar ── */
  // `onConfirm({modifiers, note, quantity})` — la usan tanto un producto suelto
  // como cada producto de una oferta que tiene opciones.
  function openOptionsSheet(p, { title, showQty = true, initial, onConfirm } = {}) {
    const chosen = new Set(initial ? initial.modifiers : []);
    const state = { note: initial ? initial.note || '' : '', qty: 1 };
    const body = `
      <div class="opts-sheet">
        ${p.description ? `<p class="muted" style="margin-top:-4px">${esc(p.description)}</p>` : ''}
        ${p.modifier_groups.map(g => `
          <fieldset class="opts-group" data-group="${g.id}" data-single="${g.selection === 'single' ? 1 : 0}" data-required="${g.required ? 1 : 0}">
            <legend>${esc(g.name)} <span class="opts-hint">${g.selection === 'single' ? 'elige una' : 'elige las que quieras'}${g.required ? ' · obligatorio' : ''}</span><span class="opts-done" aria-hidden="true">✓</span></legend>
            <div class="opts-grid">
            ${g.options.map(o => `
              <label class="opts-option">
                <input type="${g.selection === 'single' ? 'radio' : 'checkbox'}" name="g${g.id}" value="${o.id}" ${chosen.has(o.id) ? 'checked' : ''}>
                <span class="opts-option-name">${esc(o.name)}</span>
                <span class="opts-option-price">${Number(o.price_delta) ? (Number(o.price_delta) > 0 ? '+' : '') + fmt(o.price_delta) : ''}</span>
              </label>`).join('')}
            </div>
          </fieldset>`).join('')}
        <label class="f" style="max-width:none"><span>Nota para cocina (opcional)</span><input type="text" id="opts-note" maxlength="200" placeholder="ej. sin cebolla" value="${esc(state.note)}"></label>
        <div class="opts-footer">
          ${showQty ? `<div class="qty-controls"><button type="button" data-a="dec" aria-label="Menos">−</button><span id="opts-qty">1</span><button type="button" data-a="inc" aria-label="Más">+</button></div>` : '<span></span>'}
          <button type="button" class="btn btn-primary" id="opts-add">Agregar</button>
        </div>
        <div class="error" id="opts-error" role="alert" hidden></div>
      </div>`;
    const modal = UI.showModal(esc(title || p.name), body);
    const el = modal.el;
    const errorEl = el.querySelector('#opts-error');
    const addBtn = el.querySelector('#opts-add');

    const selected = () => Array.from(el.querySelectorAll('.opts-group input:checked')).map(i => Number(i.value));
    function refresh() {
      const delta = optionsDelta(p, selected());
      addBtn.textContent = `Agregar · ${fmt((Number(p.sale_price) + delta) * state.qty)}`;
    }
    // Los cambios de esta hoja no son "datos sin guardar" (no hay nada que
    // perder al cerrarla): se frena el evento para que el modal no pida
    // confirmar al cerrar.
    // v3.4 (fase 2): opciones en botones; al elegir en un grupo de «elige una»,
    // la hoja baja sola al siguiente grupo obligatorio que falte.
    el.classList.add('opts-modal');
    function markGroups() {
      el.querySelectorAll('.opts-group').forEach(fs => fs.classList.toggle('is-done', !!fs.querySelector('input:checked')));
    }
    el.querySelector('.opts-sheet').addEventListener('change', e => {
      refresh(); markGroups(); errorEl.hidden = true; e.stopPropagation();
      const fs = e.target.closest('.opts-group');
      if (!fs || fs.dataset.single !== '1') return;
      const groups = Array.from(el.querySelectorAll('.opts-group'));
      const next = groups.slice(groups.indexOf(fs) + 1).find(g => g.dataset.required === '1' && !g.classList.contains('is-done'));
      const target = next || el.querySelector('#opts-add');
      setTimeout(() => target.scrollIntoView({ behavior: window.Motion && Motion.reduce ? 'auto' : 'smooth', block: next ? 'start' : 'nearest' }), 120);
    });
    markGroups();
    el.querySelector('.opts-sheet').addEventListener('input', e => { e.stopPropagation(); });
    el.querySelectorAll('[data-a]').forEach(b => b.addEventListener('click', () => {
      state.qty = Math.max(1, state.qty + (b.dataset.a === 'inc' ? 1 : -1));
      el.querySelector('#opts-qty').textContent = state.qty;
      refresh();
    }));
    addBtn.addEventListener('click', () => {
      const picked = selected();
      // Misma validación que hará el servidor, pero avisando ya mismo.
      for (const g of p.modifier_groups) {
        const n = g.options.filter(o => picked.includes(o.id)).length;
        if (g.required && !n) {
          errorEl.textContent = `Falta elegir: ${g.name}`;
          errorEl.hidden = false;
          el.querySelector(`[data-group="${g.id}"]`).scrollIntoView({ block: 'center' });
          return;
        }
      }
      const note = el.querySelector('#opts-note').value.trim() || null;
      modal.close();
      if (onConfirm) onConfirm({ modifiers: picked, note, quantity: state.qty });
    });
    refresh();
  }

  // Elegir un producto: si tiene opciones abre la hoja; si no, lo entrega directo.
  function pick(p, onConfirm) {
    if (p.modifier_groups.length) openOptionsSheet(p, { onConfirm });
    else onConfirm({ modifiers: [], note: null, quantity: 1 });
  }

  return {
    load, refreshStock, mount, openOptionsSheet, pick,
    productById, optionById, optionsDelta, computeTaxes, computeAmounts, rateOf, isWholesale, unitPriceFor, askDiscount,
    data: () => ({ menu, settings, stockBySupply }),
    getSettings: () => settings
  };
})();
