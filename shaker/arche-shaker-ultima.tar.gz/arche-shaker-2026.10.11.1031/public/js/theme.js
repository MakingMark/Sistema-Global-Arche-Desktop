/* ═══ Modo claro/oscuro — preferencia del NAVEGADOR (localStorage), no de la
   sesión: cerrar sesión no debería resetear el tema que alguien ya eligió en
   esa pantalla. El tema en sí ya se aplica antes de esto (script inline al
   principio de <head>, para no parpadear al tema guardado al cargar) — este
   archivo solo dibuja el switch de Configuración y responde a tocarlo. ═══ */
(function () {
  'use strict';
  const KEY = 'shaker_theme';
  const btnLight = document.getElementById('theme-btn-light');
  if (!btnLight) return; // Vista de carrito no tiene este switch — nada que hacer.
  const btnDark = document.getElementById('theme-btn-dark');
  const btnSystem = document.getElementById('theme-btn-system');
  const buttons = { light: btnLight, dark: btnDark, system: btnSystem };

  function current() {
    try { return localStorage.getItem(KEY) || 'system'; } catch (_) { return 'system'; }
  }

  function apply(mode) {
    if (mode === 'system') {
      delete document.documentElement.dataset.theme;
      try { localStorage.removeItem(KEY); } catch (_) {}
    } else {
      document.documentElement.dataset.theme = mode;
      try { localStorage.setItem(KEY, mode); } catch (_) {}
    }
    Object.entries(buttons).forEach(([m, btn]) => {
      const active = m === mode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }

  Object.entries(buttons).forEach(([mode, btn]) => btn.addEventListener('click', () => apply(mode)));
  apply(current());
})();
