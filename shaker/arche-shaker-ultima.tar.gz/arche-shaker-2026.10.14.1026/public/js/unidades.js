/* ═══ Unidades: conversiones fijas entre medidas (libra ↔ gramo, galón ↔ onza…) ═══
   Un insumo se guarda SIEMPRE en su unidad base (la que dice el insumo, ej. «gramo»). Antes, para
   comprar en libras había que definir «libra» como empaque en cada insumo; si no estaba, el cajero
   escribía «10» pensando en libras y el sistema entendía 10 gramos: el costo por gramo quedaba ~450
   veces más caro y las recetas salían con margen negativo. Ahora, si la unidad base es de peso o de
   volumen, se ofrecen solas las otras medidas de la misma familia, con la equivalencia escrita.
   Lo usan el navegador (window.Unidades) y el servidor (require), así la cuenta es la misma. */
(function (raiz) {
  'use strict';
  // factor = cuántas unidades de la base de la familia (gramo o mililitro) trae una.
  const MEDIDAS = [
    { clave: 'gramo', familia: 'peso', factor: 1, nombre: 'gramo', corto: 'g', alias: ['g', 'gr', 'grs', 'gramo', 'gramos'] },
    { clave: 'kilo', familia: 'peso', factor: 1000, nombre: 'kilo', corto: 'kg', alias: ['kg', 'kgs', 'kilo', 'kilos', 'kilogramo', 'kilogramos'] },
    { clave: 'libra', familia: 'peso', factor: 453.592, nombre: 'libra', corto: 'lb', alias: ['lb', 'lbs', 'libra', 'libras'] },
    { clave: 'onza', familia: 'peso', factor: 28.3495, nombre: 'onza', corto: 'oz', alias: ['oz', 'onza de peso'] },
    { clave: 'ml', familia: 'volumen', factor: 1, nombre: 'mililitro', corto: 'ml', alias: ['ml', 'mililitro', 'mililitros'] },
    { clave: 'litro', familia: 'volumen', factor: 1000, nombre: 'litro', corto: 'lt', alias: ['l', 'lt', 'lts', 'litro', 'litros'] },
    { clave: 'galon', familia: 'volumen', factor: 3785.41, nombre: 'galón', corto: 'gal', alias: ['gal', 'galon', 'galón', 'galones'] },
    // En los negocios de aquí «onza» casi siempre es de líquido (leche, pulpa): como unidad base se toma
    // como onza líquida. En un insumo de peso se ofrece la onza de peso (arriba), con su equivalencia.
    { clave: 'onza_liq', familia: 'volumen', factor: 29.5735, nombre: 'onza', corto: 'oz', alias: ['onza', 'onzas', 'onza liquida', 'onza líquida', 'oz fl', 'fl oz'] }
  ];

  const limpiar = t => String(t || '').trim().toLowerCase().replace(/\.$/, '');
  // La unidad base de un insumo, si es una medida conocida.
  function deUnidad(unidad) {
    const u = limpiar(unidad);
    if (!u) return null;
    // «onza» sola como base = líquida; «oz» también.
    if (u === 'oz') return MEDIDAS.find(m => m.clave === 'onza_liq');
    return MEDIDAS.find(m => m.alias.includes(u)) || null;
  }
  const porClave = clave => MEDIDAS.find(m => m.clave === clave) || null;

  // Cuántas unidades base del insumo trae UNA de la medida `clave`. null si no se pueden convertir.
  function factor(unidadBase, clave) {
    const b = deUnidad(unidadBase), m = porClave(clave);
    if (!b || !m || b.familia !== m.familia) return null;
    return m.factor / b.factor;
  }

  const redondear = (n, d) => { const p = Math.pow(10, d); return Math.round(n * p) / p; };
  // Números legibles: sin decimales de más, pero sin volver «0» una cantidad chica (0.0022 → 0.0022).
  const numero = n => { n = Number(n); return n !== 0 && Math.abs(n) < 0.1
    ? n.toLocaleString('es-DO', { maximumSignificantDigits: 2 })
    : n.toLocaleString('es-DO', { maximumFractionDigits: Math.abs(n) >= 1000 ? 0 : Math.abs(n) >= 10 ? 1 : 2 }); };

  // Las otras medidas de la familia de la unidad base, con su equivalencia escrita:
  // [{ clave, nombre, factor, etiqueta: 'libra (453.6 gramo)' }]
  function opciones(unidadBase) {
    const b = deUnidad(unidadBase);
    if (!b) return [];
    return MEDIDAS.filter(m => m.familia === b.familia && m.clave !== b.clave)
      .map(m => {
        const f = m.factor / b.factor;
        // Una medida más chica que la base se explica al revés: «gramo (1 lb = 453.6 gramo)», no «(0 lb)».
        const etiqueta = f >= 1 ? `${m.nombre} (${numero(f)} ${unidadBase})` : `${m.nombre} (1 ${unidadBase} = ${numero(1 / f)} ${m.nombre})`;
        return { clave: m.clave, nombre: m.nombre, corto: m.corto, factor: f, etiqueta };
      });
  }

  // Para mostrar una cantidad en base con una ayuda legible: 2159.136 gramo → «2,159 gramo (4.8 lb)».
  function ayuda(cantidad, unidadBase) {
    const b = deUnidad(unidadBase);
    const q = Number(cantidad);
    if (!b || !isFinite(q) || q === 0) return '';
    const grande = b.familia === 'peso' ? porClave('libra') : porClave('galon');
    if (b.clave === grande.clave) return '';
    const enGrande = q * b.factor / grande.factor;
    return enGrande >= 0.5 ? `${numero(enGrande)} ${grande.corto}` : '';
  }

  // La lista para ESCOGER «Se cuenta en» (antes era texto libre y se colaban «lb», «150 gramos», «ketchp mayonesa»).
  // Peso y líquidos se convierten solos entre sí; las piezas no se convierten (se usan con empaque: «paquete de 8»).
  const LISTA = [
    { grupo: 'Por peso', items: [['gramo', 'gramo (recomendado para carnes, vegetales, harinas…)'], ['libra', 'libra'], ['kilo', 'kilo']] },
    { grupo: 'Líquidos', items: [['onza', 'onza (líquida)'], ['mililitro', 'mililitro'], ['litro', 'litro'], ['galón', 'galón']] },
    { grupo: 'Por pieza', items: [['unidad', 'unidad'], ['lonja', 'lonja'], ['rebanada', 'rebanada'], ['rodaja', 'rodaja'], ['hoja', 'hoja'], ['porción', 'porción'], ['scoop', 'scoop'], ['taza', 'taza'], ['cucharada', 'cucharada'], ['paquete', 'paquete'], ['botella', 'botella'], ['lata', 'lata'], ['sobre', 'sobre'], ['caja', 'caja']] }
  ];
  const CANONICA = { gramo: 'gramo', kilo: 'kilo', libra: 'libra', ml: 'mililitro', litro: 'litro', galon: 'galón', onza_liq: 'onza', onza: 'onza de peso' };
  // El nombre oficial de una unidad escrita de cualquier forma («lb», «Libras», «gr» → «libra», «gramo»); las piezas
  // conocidas se dejan en singular y minúscula; lo desconocido se devuelve limpio (para no perder datos viejos).
  function canonica(u) {
    const t = limpiar(u).replace(/\s+/g, ' ');
    if (!t) return '';
    const m = deUnidad(t);
    if (m) return CANONICA[m.clave];
    if (/^(u|ud|und|unid|uds|unids|unidades?)$/.test(t)) return 'unidad';
    const piezas = LISTA[2].items.map(i => i[0]);
    const sing = piezas.find(pz => t === pz || t === pz + 's' || t === pz + 'es' || (pz.endsWith('ón') && t === pz.slice(0, -2) + 'ones') || t === pz.normalize('NFD').replace(/[\u0300-\u036f]/g, ''));
    return sing || t;
  }
  const enLista = u => LISTA.some(g => g.items.some(i => i[0] === canonica(u)));

  // Las <option> de «Se cuenta en». Si el insumo ya tenía una unidad que no está en la lista, se conserva arriba.
  function opcionesHtml(actual) {
    const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const c = actual ? canonica(actual) : '';
    const fuera = c && !enLista(c) ? `<option value="${esc(c)}" selected>${esc(c)} (la que tiene ahora)</option>` : '';
    return (c ? '' : '<option value="" selected disabled>Escoge…</option>') + fuera + LISTA.map(g => `<optgroup label="${g.grupo}">${g.items.map(([v, t]) => `<option value="${v}"${v === c ? ' selected' : ''}>${t}</option>`).join('')}</optgroup>`).join('');
  }

  const api = { MEDIDAS, deUnidad, factor, opciones, ayuda, redondear, numero, LISTA, canonica, enLista, opcionesHtml };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else raiz.Unidades = api;
})(typeof window !== 'undefined' ? window : globalThis);
