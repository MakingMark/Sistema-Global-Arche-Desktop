/* ═══ Compras: proveedores y órdenes de compra ═══ */
(function () {
  'use strict';
  const ordersEl = document.getElementById('compras-ordenes');
  if (!ordersEl) return;
  const vendorsEl = document.getElementById('compras-proveedores');
  const estadoSel = document.getElementById('compras-estado');
  const esc = UI.escapeHtml;
  const STATE = { borrador: ['Borrador', 'badge-muted'], enviada: ['Enviada', 'badge-warn'], recibida: ['Recibida', 'badge-ok'], cancelada: ['Cancelada', 'badge-voided'] };
  let vendors = [], supplies = [];

  async function loadBase() {
    [vendors, supplies] = await Promise.all([Api.vendors.list(), Api.supplies.list()]);
    supplies = supplies.filter(s => s.active !== false);
  }
  const vendorName = id => (vendors.find(v => v.id === id) || {}).name || 'Sin proveedor';

  /* ── Órdenes ── (v4: filas como Insumos; tocar abre la orden, «⋯» trae Enviar, Recibir y Cancelar) */
  const MAS = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/></svg>';
  const PILL = { borrador: 'g', enviada: 'am', recibida: 'ok', cancelada: 'g' };
  let ordenes = [];
  async function renderOrders() {
    ordenes = await Api.purchaseOrders.list(estadoSel.value);
    if (!ordenes.length) {
      ordersEl.innerHTML = estadoSel.value ? '<p class="muted">No hay órdenes en ese estado.</p>'
        : '<div class="hv-vacio"><b>Todavía no hay órdenes</b><span class="muted">Crea la primera con «+ Nueva orden»: Arche sugiere lo que se está acabando.</span></div>';
      return;
    }
    ordersEl.innerHTML = `<div class="in-lista" role="list">${ordenes.map(po => {
      const [label] = STATE[po.status] || [po.status];
      const n = po.items.length;
      return `<div class="in-fila${po.status === 'cancelada' ? ' row-inactive' : ''}" role="listitem" tabindex="0" data-po="${po.id}">
        <span class="ex-ini co-num">#${po.id}</span>
        <span class="in-n"><b>${esc(po.vendor_name || 'Sin proveedor')}</b><small>${fmtDate(po.created_at)} · ${n} ${n === 1 ? 'insumo' : 'insumos'}${po.expected_on ? ' · llega el ' + esc(po.expected_on) : ''}</small></span>
        <span class="in-c"><b>${fmt(po.total)}</b><small><span class="pend ${PILL[po.status] || 'g'}">${label}</span></small></span>
        <button type="button" class="hv-mas" aria-label="Acciones de la orden ${po.id}" aria-haspopup="menu">${MAS}</button>
      </div>`;
    }).join('')}</div>`;
  }
  ordersEl.addEventListener('click', async ev => {
    const f = ev.target.closest('[data-po]'); if (!f) return;
    const po = ordenes.find(x => String(x.id) === f.dataset.po); if (!po) return;
    const mas = ev.target.closest('.hv-mas');
    if (!mas) { editOrder(po.id); return; }
    const open = po.status === 'borrador' || po.status === 'enviada';
    const a = await UI.rowMenu(mas, `Orden #${po.id}`, open
      ? [{ a: 'ver', t: 'Editar' }, { a: 'wa', t: 'Enviar por WhatsApp' }, { a: 'recibir', t: 'Recibir mercancía…' }, { a: 'cancelar', t: 'Cancelar orden…', peligro: true, sep: true }]
      : [{ a: 'ver', t: 'Ver' }]);
    if (a === 'ver') editOrder(po.id);
    if (a === 'wa') sendOrder(po.id);
    if (a === 'recibir') receiveOrder(po.id);
    if (a === 'cancelar' && await UI.confirmDialog(`¿Cancelar la orden #${po.id}?`)) { try { await Api.purchaseOrders.cancel(po.id); renderOrders(); } catch (e) { UI.toast(e.message, 'error'); } }
  });
  ordersEl.addEventListener('keydown', ev => { const f = ev.target.closest('.in-fila'); if (f && ev.key === 'Enter' && ev.target === f) f.click(); });
  document.getElementById('compras-filtro').addEventListener('click', ev => {
    const b = ev.target.closest('[data-estado]'); if (!b) return;
    estadoSel.value = b.dataset.estado;
    document.querySelectorAll('#compras-filtro [data-estado]').forEach(x => { const on = x === b; x.classList.toggle('is-active', on); x.setAttribute('aria-selected', String(on)); });
    renderOrders();
  });

  async function sendOrder(id) {
    try {
      const po = await Api.purchaseOrders.get(id);
      if (!po.whatsapp_url) { UI.toast('Este proveedor no tiene teléfono: agrégalo en Proveedores', 'error'); return; }
      window.open(po.whatsapp_url, '_blank', 'noopener');
      if (po.status === 'borrador') await Api.purchaseOrders.send(id);
      renderOrders();
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function editOrder(id) {
    let po = { id: null, vendor_id: null, expected_on: '', notes: '', items: [], status: 'borrador' };
    if (id) { try { po = await Api.purchaseOrders.get(id); } catch (e) { UI.toast(e.message, 'error'); return; } }
    const closed = po.status === 'recibida' || po.status === 'cancelada';
    let lines = po.items.map(i => ({ supply_id: i.supply_id, quantity: i.quantity, unit_cost: i.unit_cost, unidad: '' }));
    // Cada línea se puede escribir en otra medida (ej. libras de un insumo que se cuenta en gramos):
    // cantidad y costo se muestran en esa medida y se guardan convertidos a la unidad base.
    const supplyOf = l => supplies.find(x => x.id === l.supply_id) || {};
    const factorOf = l => (l.unidad ? Unidades.factor(supplyOf(l).unit, l.unidad) || 1 : 1);
    const unidadOpts = l => { const s = supplyOf(l); if (!s.id) return ''; const ops = Unidades.opciones(s.unit);
      return ops.length ? `<option value="">${esc(s.unit)}</option>` + ops.map(o => `<option value="${o.clave}" ${o.clave === l.unidad ? 'selected' : ''}>${esc(o.nombre)}</option>`).join('') : ''; };
    const medida = l => { const s = supplyOf(l); const m = l.unidad && Unidades.MEDIDAS.find(x => x.clave === l.unidad); return m ? m.nombre : (s.unit || 'unidad'); };
    const supplyOpts = sel => '<option value="">Elige un insumo…</option>' + supplies.map(s => `<option value="${s.id}" ${s.id === sel ? 'selected' : ''}>${esc(s.name)} (${esc(s.unit)})</option>`).join('');
    const modal = UI.showModal(id ? `Orden #${id}` : 'Nueva orden de compra', `<div class="pf">
      <div class="pf-grupo">
        <label class="pf-fila"><span>Proveedor</span><select id="po-vendor" ${closed ? 'disabled' : ''}><option value="">Sin proveedor</option>${vendors.filter(v => v.active || v.id === po.vendor_id).map(v => `<option value="${v.id}" ${v.id === po.vendor_id ? 'selected' : ''}>${esc(v.name)}</option>`).join('')}</select></label>
        <label class="pf-fila"><span>Llega el<small>Opcional</small></span><input type="date" id="po-date" value="${esc(po.expected_on || '')}" ${closed ? 'disabled' : ''}></label>
        <label class="pf-fila pf-col"><span>Nota</span><input id="po-notes" maxlength="500" value="${esc(po.notes || '')}" placeholder="Opcional" ${closed ? 'disabled' : ''}></label>
      </div>
      <p class="pf-sec po-sec">Qué se pide${closed ? '' : '<button type="button" class="po-sugerir" id="po-suggest">Sugerir lo que falta</button>'}</p>
      <div class="pf-grupo">
        <div id="po-lines"></div>
        ${closed ? '' : '<button type="button" class="pf-fila pf-add" id="po-add">+ Agregar insumo</button>'}
        <div class="pf-resumen" id="po-total" role="status"></div>
      </div>
      <div class="error" id="po-error" role="alert" hidden></div>
      ${closed ? '' : '<div class="pf-acciones"><button type="button" class="btn" id="po-cancel">Cancelar</button><button type="button" class="btn btn-primary" id="po-save">Guardar orden</button></div>'}
    </div>`);
    const el = modal.el;
    const paint = () => {
      el.querySelector('#po-lines').innerHTML = lines.length ? lines.map((l, i) => `
        <div class="po-line po-l" data-i="${i}">
          <select data-f="supply_id" class="po-insumo" aria-label="Insumo" ${closed ? 'disabled' : ''}>${supplyOpts(l.supply_id)}</select>
          <span class="po-cant"><input data-f="quantity" type="number" min="0.001" step="any" inputmode="decimal" value="${Unidades.redondear(Number(l.quantity), 3)}" aria-label="Cantidad" ${closed ? 'disabled' : ''}>${unidadOpts(l) && !closed ? `<select data-f="unidad" aria-label="Medida">${unidadOpts(l)}</select>` : `<em>${esc(medida(l))}</em>`}</span>
          <span class="po-costo"><em>a ${esc(AppLocale.currency())}</em><input data-f="unit_cost" type="number" min="0" step="any" inputmode="decimal" value="${Unidades.redondear(Number(l.unit_cost), 4)}" aria-label="Costo por ${esc(medida(l))}" ${closed ? 'disabled' : ''}><em>c/${esc(medida(l))}</em></span>
          ${closed ? '' : '<button type="button" class="of-quitar" data-rm aria-label="Quitar insumo">✕</button>'}
        </div>`).join('') : '<div class="pf-fila pf-nota">Agrega los insumos que vas a pedir, o toca «Sugerir lo que falta».</div>';
      const total = lines.reduce((a, l) => a + (Number(l.quantity) || 0) * (Number(l.unit_cost) || 0), 0);
      el.querySelector('#po-total').innerHTML = lines.length ? `<span>Total estimado: <b>${fmtDec(total)}</b></span>` : '';
      el.querySelector('#po-total').hidden = !lines.length;
    };
    paint();
    el.addEventListener('change', e => {
      const row = e.target.closest('.po-line'); if (!row) return;
      const l = lines[Number(row.dataset.i)], f = e.target.dataset.f;
      if (f === 'unidad') {
        // Cambia la medida sin cambiar lo pedido: 4536 gramo a RD$0.30 = 10 libra a RD$135.
        const antes = factorOf(l); l.unidad = e.target.value; const ahora = factorOf(l);
        l.quantity = Unidades.redondear(Number(l.quantity) * antes / ahora, 3);
        l.unit_cost = Unidades.redondear(Number(l.unit_cost) * ahora / antes, 4);
        paint(); return;
      }
      if (f === 'supply_id') l.unidad = '';
      l[f] = f === 'supply_id' ? Number(e.target.value) || null : e.target.value;
      if (f === 'supply_id' && l.supply_id && !Number(l.unit_cost)) { const s = supplies.find(x => x.id === l.supply_id); if (s) l.unit_cost = Number(s.unit_cost) || 0; }
      paint();
    });
    el.addEventListener('input', e => { const row = e.target.closest('.po-line'); if (row && e.target.dataset.f !== 'supply_id' && e.target.dataset.f !== 'unidad') { lines[Number(row.dataset.i)][e.target.dataset.f] = e.target.value; const total = lines.reduce((a, l) => a + (Number(l.quantity) || 0) * (Number(l.unit_cost) || 0), 0); el.querySelector('#po-total').innerHTML = `<span>Total estimado: <b>${fmtDec(total)}</b></span>`; } });
    el.addEventListener('click', e => { const rm = e.target.closest('[data-rm]'); if (rm) { lines.splice(Number(rm.closest('.po-line').dataset.i), 1); paint(); } });
    if (closed) return;
    el.querySelector('#po-add').addEventListener('click', () => { lines.push({ supply_id: null, quantity: 1, unit_cost: 0, unidad: '' }); paint(); });
    el.querySelector('#po-suggest').addEventListener('click', async () => {
      try {
        const vid = el.querySelector('#po-vendor').value;
        const sug = await Api.purchaseOrders.suggest(vid || null);
        if (!sug.length) { UI.toast(vid ? 'Nada que pedir a este proveedor por ahora' : 'Nada se está acabando por ahora'); return; }
        sug.forEach(s => { if (!lines.some(l => l.supply_id === s.supply_id)) lines.push({ supply_id: s.supply_id, quantity: s.suggested, unit_cost: s.unit_cost, unidad: '' }); });
        paint();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
    el.querySelector('#po-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#po-save').addEventListener('click', async ev => {
      const err = el.querySelector('#po-error'); err.hidden = true; ev.currentTarget.disabled = true;
      try {
        await Api.purchaseOrders.save(id, {
          vendor_id: el.querySelector('#po-vendor').value ? Number(el.querySelector('#po-vendor').value) : null,
          expected_on: el.querySelector('#po-date').value || null, notes: el.querySelector('#po-notes').value,
          items: lines.map(l => ({ supply_id: l.supply_id, quantity: Unidades.redondear(Number(l.quantity) * factorOf(l), 3), unit_cost: Unidades.redondear((Number(l.unit_cost) || 0) / factorOf(l), 4) }))
        });
        modal.close(); UI.toast('Orden guardada'); renderOrders();
      } catch (e) { err.textContent = e.message; err.hidden = false; ev.currentTarget.disabled = false; }
    });
  }

  async function receiveOrder(id) {
    let po; try { po = await Api.purchaseOrders.get(id); } catch (e) { UI.toast(e.message, 'error'); return; }
    const modal = UI.showModal(`Recibir orden #${id}`, `<div class="pf">
      <p class="pf-nota" style="margin:0 14px 10px">Anota lo que llegó de verdad. Al confirmar, entra al inventario y el costo se promedia con lo que ya había.</p>
      <div class="pf-grupo">
      ${po.items.map(i => { const ops = Unidades.opciones(i.supply_unit); const ay = Unidades.ayuda(i.quantity, i.supply_unit); return `<div class="po-line po-l po-receive" data-item="${i.id}" data-unit="${esc(i.supply_unit)}" data-supply="${i.supply_id}">
        <span class="po-insumo po-nom"><b>${esc(i.supply_name)}</b><small>pedido: ${fmtNum(Unidades.redondear(Number(i.quantity), 2))} ${esc(i.supply_unit)}${ay ? ` (${ay})` : ''}</small></span>
        <span class="po-cant"><em>llegó</em><input data-f="quantity" type="number" min="0" step="any" inputmode="decimal" value="${Unidades.redondear(Number(i.quantity), 3)}" aria-label="Cantidad que llegó">${ops.length ? `<select data-f="unidad" aria-label="Medida"><option value="">${esc(i.supply_unit)}</option>${ops.map(o => `<option value="${o.clave}">${esc(o.nombre)}</option>`).join('')}</select>` : `<em>${esc(i.supply_unit)}</em>`}</span>
        <span class="po-costo"><em>a ${esc(AppLocale.currency())}</em><input data-f="unit_cost" type="number" min="0" step="any" inputmode="decimal" value="${Unidades.redondear(Number(i.unit_cost), 4)}" aria-label="Costo"><em data-costo-label>c/${esc(i.supply_unit)}</em></span></div>`; }).join('')}
      </div>
      <div class="error" id="rc-error" role="alert" hidden></div>
      <div class="pf-acciones"><button type="button" class="btn" id="rc-cancel">Cancelar</button><button type="button" class="btn btn-primary" id="rc-ok">Confirmar recepción</button></div>
    </div>`);
    const el = modal.el;
    // Cambiar la medida de una línea convierte lo que ya está escrito (no cambia lo que llegó).
    const fac = (row, clave) => (clave ? Unidades.factor(row.dataset.unit, clave) || 1 : 1);
    el.querySelectorAll('[data-item]').forEach(row => { row.dataset.prev = ''; });
    el.addEventListener('change', e => {
      if (e.target.dataset.f !== 'unidad') return;
      const row = e.target.closest('[data-item]');
      const antes = fac(row, row.dataset.prev), ahora = fac(row, e.target.value);
      const q = row.querySelector('[data-f="quantity"]'), c = row.querySelector('[data-f="unit_cost"]');
      q.value = Unidades.redondear(Number(q.value) * antes / ahora, 3);
      c.value = Unidades.redondear(Number(c.value) * ahora / antes, 4);
      const m = Unidades.MEDIDAS.find(x => x.clave === e.target.value);
      row.querySelector('[data-costo-label]').textContent = `c/${m ? m.nombre : row.dataset.unit}`;
      row.dataset.prev = e.target.value;
    });
    el.querySelector('#rc-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#rc-ok').addEventListener('click', async ev => {
      const btnOk = ev.currentTarget;
      const items = Array.from(el.querySelectorAll('[data-item]')).map(r => {
        const f = fac(r, r.dataset.prev);
        return { item_id: Number(r.dataset.item), supply_id: Number(r.dataset.supply), unit: r.dataset.unit,
          quantity: Unidades.redondear(Number(r.querySelector('[data-f="quantity"]').value) * f, 3),
          unit_cost: Unidades.redondear(Number(r.querySelector('[data-f="unit_cost"]').value) / f, 4) };
      });
      // Igual que en «Registrar compra»: un costo 4 veces distinto al de antes casi siempre es la medida.
      const raros = items.filter(it => { const s = supplies.find(x => x.id === it.supply_id); const a = s ? Number(s.unit_cost) : 0;
        return a > 0 && it.unit_cost > 0 && (it.unit_cost / a > 4 || a / it.unit_cost > 4); });
      if (raros.length && !(await UI.confirmDialog(`El costo de ${raros.map(r => (supplies.find(x => x.id === r.supply_id) || {}).name).join(', ')} es muy distinto al de antes. Revisa que la cantidad y el costo estén en la medida correcta (por ejemplo, libras y no gramos). ¿Recibir así?`))) return;
      btnOk.disabled = true;
      try { await Api.purchaseOrders.receive(id, { items: items.map(({ item_id, quantity, unit_cost }) => ({ item_id, quantity, unit_cost })) }); modal.close(); UI.toast('Mercancía recibida: ya está en el inventario'); renderOrders(); }
      catch (e) { const err = el.querySelector('#rc-error'); err.textContent = e.message; err.hidden = false; btnOk.disabled = false; }
    });
  }

  /* ── Proveedores ── (v4: filas; tocar edita en una hoja agrupada) */
  function renderVendors() {
    if (!vendors.length) { vendorsEl.innerHTML = '<div class="hv-vacio"><b>Todavía no hay proveedores</b><span class="muted">Agrega a quien le compras con «+ Proveedor»: con su WhatsApp, las órdenes se le mandan de un toque.</span></div>'; return; }
    vendorsEl.innerHTML = `<div class="in-lista" role="list">${vendors.map(v => {
      const ini = v.name.trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
      return `<div class="in-fila${v.active ? '' : ' row-inactive'}" role="listitem" tabindex="0" data-v="${v.id}">
        <span class="ex-ini">${esc(ini)}</span>
        <span class="in-n"><b>${esc(v.name)}${v.active ? '' : ' <span class="pend g">Inactivo</span>'}</b><small>${esc(v.phone || 'sin teléfono')}${v.rnc ? ' · RNC ' + esc(v.rnc) : ''}</small></span>
        <span class="in-c"><b>${v.supplies_count} ${v.supplies_count === 1 ? 'insumo' : 'insumos'}</b><small>${v.orders_count} ${v.orders_count === 1 ? 'orden' : 'órdenes'}</small></span>
        <button type="button" class="hv-mas" aria-label="Acciones de ${esc(v.name)}" aria-haspopup="menu">${MAS}</button>
      </div>`;
    }).join('')}</div>`;
  }
  vendorsEl.addEventListener('click', async ev => {
    const f = ev.target.closest('[data-v]'); if (!f) return;
    const v = vendors.find(x => String(x.id) === f.dataset.v); if (!v) return;
    const mas = ev.target.closest('.hv-mas');
    if (!mas) { editVendor(v); return; }
    const a = await UI.rowMenu(mas, v.name, [{ a: 'editar', t: 'Editar' }, { a: 'insumos', t: 'Sus insumos…' }, { a: 'toggle', t: v.active ? 'Desactivar' : 'Reactivar', sep: true, peligro: v.active }]);
    if (a === 'editar') editVendor(v);
    if (a === 'insumos') vendorSupplies(v);
    if (a === 'toggle') { try { await Api.vendors.update(v.id, { ...v, active: !v.active }); await refreshVendors(); } catch (e) { UI.toast(e.message, 'error'); } }
  });
  vendorsEl.addEventListener('keydown', ev => { const f = ev.target.closest('.in-fila'); if (f && ev.key === 'Enter' && ev.target === f) f.click(); });
  async function refreshVendors() { vendors = await Api.vendors.list(); renderVendors(); }

  // Hoja agrupada para crear (v = null) o editar un proveedor.
  function editVendor(v) {
    const ed = !!v;
    const modal = UI.showModal(ed ? esc(v.name) : 'Proveedor nuevo', `<div class="pf">
      <div class="pf-grupo">
        <label class="pf-fila"><span>Nombre</span><input id="ev-name" maxlength="100" autocomplete="off" value="${ed ? esc(v.name) : ''}" placeholder="ej. Distribuidora del Este"></label>
        <label class="pf-fila"><span>WhatsApp<small>Para mandarle las órdenes</small></span><input id="ev-phone" inputmode="tel" maxlength="30" value="${ed ? esc(v.phone || '') : ''}" placeholder="809 555 1234"></label>
        <label class="pf-fila"><span>RNC</span><input id="ev-rnc" maxlength="30" value="${ed ? esc(v.rnc || '') : ''}" placeholder="Opcional"></label>
        <label class="pf-fila"><span>Correo</span><input id="ev-email" type="email" maxlength="120" value="${ed ? esc(v.email || '') : ''}" placeholder="Opcional"></label>
        <label class="pf-fila pf-col"><span>Notas</span><input id="ev-notes" maxlength="500" value="${ed ? esc(v.notes || '') : ''}" placeholder="Opcional · ej. entrega martes y viernes"></label>
      </div>
      <div class="error" id="ev-error" role="alert" hidden></div>
      <div class="pf-acciones"><button type="button" class="btn" id="ev-cancel">Cancelar</button><button type="button" class="btn btn-primary" id="ev-ok">${ed ? 'Guardar' : 'Agregar proveedor'}</button></div>
    </div>`);
    const el = modal.el;
    el.querySelector('#ev-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#ev-ok').addEventListener('click', async () => {
      const data = { name: el.querySelector('#ev-name').value.trim(), phone: el.querySelector('#ev-phone').value.trim(), rnc: el.querySelector('#ev-rnc').value.trim(), email: el.querySelector('#ev-email').value.trim(), notes: el.querySelector('#ev-notes').value.trim() };
      const err = el.querySelector('#ev-error');
      if (!data.name) { err.textContent = 'Escribe el nombre del proveedor'; err.hidden = false; return; }
      try {
        if (ed) await Api.vendors.update(v.id, { ...v, ...data }); else await Api.vendors.create(data);
        modal.close(); UI.toast(ed ? 'Proveedor actualizado' : 'Proveedor agregado'); refreshVendors();
      } catch (e) { err.textContent = e.message; err.hidden = false; }
    });
    setTimeout(() => el.querySelector('#ev-name').focus(), 50);
  }

  // Qué insumos le compras a este proveedor (para sugerir pedidos).
  function vendorSupplies(v) {
    const modal = UI.showModal(`Insumos de ${esc(v.name)}`, `
      <p class="muted" style="margin-top:0">Marca los insumos que le compras a este proveedor. Así «Sugerir lo que falta» arma el pedido correcto.</p>
      <div class="checklist" style="max-height:50vh;overflow:auto">${supplies.map(s => `<label><input type="checkbox" value="${s.id}" ${s.vendor_id === v.id ? 'checked' : ''}> ${esc(s.name)}${s.vendor_id && s.vendor_id !== v.id ? ` <span class="muted">(hoy: ${esc(vendorName(s.vendor_id))})</span>` : ''}</label>`).join('') || '<p class="muted">Todavía no hay insumos.</p>'}</div>
      <div class="modal-actions" style="margin-top:14px"><button class="btn" id="vs-cancel">Cancelar</button><button class="btn btn-primary" id="vs-ok">Guardar</button></div>`);
    const el = modal.el;
    el.querySelector('#vs-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#vs-ok').addEventListener('click', async () => {
      try {
        for (const s of supplies) {
          const on = el.querySelector(`input[value="${s.id}"]`).checked;
          if (on && s.vendor_id !== v.id) await Api.vendors.setSupplyVendor(s.id, v.id);
          else if (!on && s.vendor_id === v.id) await Api.vendors.setSupplyVendor(s.id, null);
        }
        modal.close(); UI.toast('Guardado'); await loadBase(); renderVendors();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  document.getElementById('compras-proveedor-nuevo').addEventListener('click', () => editVendor(null));
  document.getElementById('compras-nueva').addEventListener('click', () => editOrder(null));

  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'compras') return;
    try { await loadBase(); renderVendors(); await renderOrders(); } catch (err) { UI.toast(err.message, 'error'); }
  });
})();
