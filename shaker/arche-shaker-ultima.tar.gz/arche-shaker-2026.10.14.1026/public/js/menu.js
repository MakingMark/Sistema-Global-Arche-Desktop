/* ═══ Menú: productos, categorías y opciones (dueño) ═══
   Productos = platos, batidas y reventa. Cada uno tiene una RECETA (insumos
   que descuenta y de donde sale su costo real) y puede ofrecer GRUPOS DE
   OPCIONES (acompañante, extras) que el cliente elige al pedir. Las
   categorías tienen dos niveles. Servidor: routes/products.js y routes/menu.js. */
(function () {
  'use strict';
  const grid = document.getElementById('menu-grid');
  if (!grid) return;

  const esc = UI.escapeHtml;
  const searchInput = document.getElementById('menu-search');
  const filterSelect = document.getElementById('menu-filter-category');
  const summaryEl = document.getElementById('menu-summary');
  const categoriasEl = document.getElementById('menu-categorias');
  const gruposEl = document.getElementById('menu-grupos');

  let supplies = [];
  let products = [];
  let categories = [];
  let groups = [];
  let schedules = [];
  let vendidos = new Map(), existencia = new Map(), escogido = null;

  /* ── Categorías: utilidades ── */
  const rootCats = () => categories.filter(c => !c.parent_id);
  const childrenOf = id => categories.filter(c => c.parent_id === id);
  function catLabel(id) {
    const c = categories.find(x => x.id === id);
    if (!c) return 'Sin categoría';
    const parent = c.parent_id ? categories.find(x => x.id === c.parent_id) : null;
    return parent ? `${parent.name} › ${c.name}` : c.name;
  }
  // <option>s con las subcategorías agrupadas bajo su madre. Una madre que
  // tiene hijas también se puede elegir ("general") — un plato puede colgar
  // directo de "Desayunos" aunque existan "Omelettes" y "Waffles" dentro.
  function categoryOptions(selectedId, { first } = {}) {
    const sel = v => (String(v) === String(selectedId) ? ' selected' : '');
    let html = first || '';
    for (const root of rootCats()) {
      const kids = childrenOf(root.id);
      if (!kids.length) {
        html += `<option value="${root.id}"${sel(root.id)}>${esc(root.icon || '')} ${esc(root.name)}</option>`;
      } else {
        html += `<optgroup label="${esc(root.icon || '')} ${esc(root.name)}">`
          + `<option value="${root.id}"${sel(root.id)}>${esc(root.name)} (general)</option>`
          + kids.map(k => `<option value="${k.id}"${sel(k.id)}>${esc(k.name)}</option>`).join('')
          + '</optgroup>';
      }
    }
    return html;
  }
  function withDescendants(id) {
    return [id, ...childrenOf(id).map(c => c.id)];
  }

  const scheduleOptions = (selectedId, first) => `<option value="">${first}</option>` + schedules.filter(x => x.active).map(x => `<option value="${x.id}" ${x.id === selectedId ? 'selected' : ''}>${esc(x.name)} (${x.start_time}–${x.end_time})</option>`).join('');

  /* ── Costo de una receta ── */
  const recipeCost = p => (p.supplies || []).reduce((sum, s) => sum + Number(s.unit_cost) * Number(s.quantity), 0);

  async function load() {
    [supplies, products, categories, groups, schedules] = await Promise.all([
      Api.supplies.list(), Api.products.list(), Api.menu.categories(), Api.menu.groups(), Api.menu.schedules()
    ]);
    window.dispatchEvent(new CustomEvent('menu:loaded', { detail: { schedules, categories, products } }));
    // v4: para la ficha del producto (vendidos en 30 días y para cuántos más alcanza la receta).
    try {
      const d = new Date(); d.setDate(d.getDate() - 29);
      const [vend, ov] = await Promise.all([Api.reports.byProduct({ from: localIsoDate(d) }).catch(() => []), Api.reports.stockOverview().catch(() => null)]);
      vendidos = new Map((vend || []).map(r => [r.product_name, Number(r.quantity)]));
      existencia = new Map();
      if (ov) { const locs = Modules.visibleLocations(ov.locations).map(l => String(l.id)); for (const r of ov.rows) existencia.set(r.id, Object.entries(r.cells).filter(([k]) => locs.includes(k)).reduce((t, [, c]) => t + Number(c.value), 0)); }
    } catch (_) {}
    renderFilter();
    renderProducts();
    renderCategories();
    renderGroups();
  }

  /* ═══════════════ PRODUCTOS ═══════════════ */
  function renderFilter() {
    const current = filterSelect.value;
    filterSelect.innerHTML = categoryOptions(current, {
      first: '<option value="">Todas las categorías</option><option value="none">Sin categoría</option>'
    });
    filterSelect.value = current || '';
  }

  /* v4 (DISENO-ARCHE.md, propuesta 2 · «Producto»): lista con precio, costo, margen y «Disponible» al instante; al
     escoger uno, su ficha a la derecha (en el celular sube como hoja): foto, precio/costo/margen, disponible, en la
     página web, agotado hoy, opciones y la receta con para cuántos más alcanza. Editar, Desglose y Eliminar ahí. */
  const ini = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
  const margenDe = p => { const c = recipeCost(p), pr = Number(p.sale_price); return (p.supplies || []).length && pr > 0 ? Math.round(((pr - c) / pr) * 100) : null; };
  const alcanza = p => { const sup = p.supplies || []; if (!sup.length) return null; let m = Infinity; for (const s of sup) { const q = Number(s.quantity); if (q > 0) m = Math.min(m, Math.floor((existencia.get(s.supply_id) || 0) / q)); } return m === Infinity ? null : Math.max(0, m); };
  const sw = (on, attrs, label) => `<button type="button" class="ct-sw${on ? ' on' : ''}" role="switch" aria-checked="${!!on}" aria-label="${esc(label)}" ${attrs}></button>`;
  const hoy = () => localIsoDate(new Date());
  function ficha(p) {
    if (!p) return '<p class="muted ct-vacio">Escoge un producto para ver su ficha.</p>';
    const cost = recipeCost(p), price = Number(p.sale_price), mg = margenDe(p), al = alcanza(p), v = vendidos.get(p.name) || 0;
    const agotado = p.sold_out_on && String(p.sold_out_on).slice(0, 10) === hoy();
    return `<div class="ct-foto"${p.image_url ? ` style="background-image:url('${esc(p.image_url)}')"` : ''}>${p.image_url ? '' : `<span>${esc(ini(p.name))}</span>`}</div>
      <div class="ct-cab"><h2>${esc(p.name)}</h2><p class="muted">${esc(catLabel(p.category_id))} · ${v ? `${fmtNum(v)} vendidos en 30 días` : 'sin ventas en 30 días'}</p>
        <div class="ct-num"><div><small>Precio</small><b>${fmt(price)}</b></div><div><small>Costo</small><b>${(p.supplies || []).length ? fmtDec(cost) : '—'}</b></div><div><small>Margen</small><b class="${mg === null ? '' : mg < 0 ? 'ct-mal' : 'ct-bien'}">${mg === null ? '—' : mg + ' %'}</b></div></div></div>
      <div class="ct-grupo">
        <div class="ct-fila"><div class="t"><b>Disponible para vender</b><small>Caja y página web</small></div>${sw(p.active, `data-ct="activo" data-id="${p.id}"`, 'Disponible para vender')}</div>
        <div class="ct-fila"><div class="t"><b>Mostrar en la página web</b></div>${sw(p.web_visible, `data-ct="web" data-id="${p.id}"`, 'Mostrar en la página web')}</div>
        <div class="ct-fila"><div class="t"><b>Agotado hoy</b><small>Se oculta de la caja y la página hasta mañana</small></div>${sw(agotado, `data-ct="agotado" data-id="${p.id}"`, 'Agotado hoy')}</div>
        ${p.modifier_group_ids.length ? `<div class="ct-fila"><div class="t"><b>Opciones</b><small>${esc(p.modifier_group_ids.map(id => (groups.find(g => g.id === id) || {}).name).filter(Boolean).join(', '))}</small></div></div>` : ''}
      </div>
      <p class="ct-t">Receta${al === null ? '' : ` · alcanza para ${fmtNum(al)} más`}</p>
      <div class="ct-grupo">${(p.supplies || []).length ? p.supplies.map(s => { const c = Number(s.unit_cost) * Number(s.quantity); return `<div class="ct-fila ct-ing"><div class="t"><b>${esc(s.supply_name)}</b><small>${fmtNum(Number(s.quantity))} ${esc(s.supply_unit || '')}</small><span class="ct-b2"><i style="width:${price > 0 ? Math.max(2, Math.min(100, (c / price) * 100)) : 0}%"></i></span></div><span class="ct-c">${fmtDec(c)}</span></div>`; }).join('')
        + `<div class="ct-fila ct-tot"><div class="t"><b>Costo de la receta</b></div><span class="ct-c">${fmtDec(cost)}</span></div><div class="ct-fila ct-tot"><div class="t"><b>Te queda por cada venta</b></div><span class="ct-c ${price - cost < 0 ? 'ct-mal' : 'ct-bien'}">${fmtDec(price - cost)}</span></div>`
        : '<div class="ct-fila"><div class="t"><b>Sin receta</b><small>Su costo cuenta como RD$0 y no descuenta insumos</small></div></div>'}</div>
      <div class="ct-historial" data-hist="${p.id}"></div>
      <div class="ct-btns ct-btns-1"><button type="button" class="btn btn-primary" data-ct="editar" data-id="${p.id}">Editar producto</button></div>
      <button type="button" class="btn ct-borrar" data-ct="eliminar" data-id="${p.id}">Eliminar producto…</button>`;
  }
  function renderProducts() {
    const q = searchInput.value.trim().toLowerCase();
    const f = filterSelect.value;
    const ids = f && f !== 'none' ? withDescendants(Number(f)) : null;
    const pos = new Map(categories.map((c, i) => [c.id, i]));
    const list = products.filter(p =>
      (!q || p.name.toLowerCase().includes(q)) &&
      (!f || (f === 'none' ? !p.category_id : ids.includes(p.category_id)))
    ).sort((a, b) => (pos.get(a.category_id) ?? 1e6) - (pos.get(b.category_id) ?? 1e6) || a.sort_order - b.sort_order || a.name.localeCompare(b.name, 'es'));
    const noRecipe = list.filter(p => p.active && !(p.supplies || []).length).length;
    summaryEl.textContent = `${list.length} ${list.length === 1 ? 'producto' : 'productos'}`
      + (noRecipe ? ` · ${noRecipe} sin receta (su costo cuenta como $0 y no descuentan insumos)` : '');
    if (!list.length) {
      grid.innerHTML = products.length
        ? '<p class="muted">Ningún producto coincide con ese filtro.</p>'
        : '<p class="muted">Todavía no hay productos. Crea el primero con <strong>+ Producto</strong>.</p>';
      return;
    }
    if (!escogido || !list.some(p => p.id === escogido)) escogido = list[0].id;
    let catAnt = undefined;
    const filas = list.map(p => {
      const mg = margenDe(p), price = Number(p.sale_price), cost = recipeCost(p), hasRecipe = (p.supplies || []).length > 0;
      const cab = p.category_id !== catAnt ? `<div class="ct-grupo-cab">${esc(catLabel((catAnt = p.category_id)))}</div>` : '';
      return `${cab}<div role="button" tabindex="0" class="ct-row${p.id === escogido ? ' sel' : ''}${p.active ? '' : ' off'}" data-ct-row="${p.id}">
        <span class="ct-n"><span class="ct-th"${p.image_url ? ` style="background-image:url('${esc(p.image_url)}')"` : ''}>${p.image_url ? '' : esc(ini(p.name))}</span><span><b>${esc(p.name)}</b><small>${p.active ? '' : 'No disponible · '}${hasRecipe ? `${p.supplies.length} insumo${p.supplies.length === 1 ? '' : 's'}` : 'Sin receta'}${(vendidos.get(p.name) || 0) ? ` · ${fmtNum(vendidos.get(p.name))} vendidos` : ''}</small></span></span>
        <span class="ct-v">${fmt(price)}</span><span class="ct-v muted">${hasRecipe ? fmtDec(cost) : '—'}</span>
        <span class="ct-mg">${mg === null ? '<span class="pend am">Sin receta</span>' : `<span class="ct-b"><i class="${mg < 0 ? 'r' : mg < 30 ? 'am' : ''}" style="width:${Math.max(4, Math.min(100, mg))}%"></i></span><span class="muted">${mg} %</span>`}</span>
        <span class="ct-d">${sw(p.active, `data-ct="activo" data-id="${p.id}"`, 'Disponible')}</span></div>`;
    }).join('');
    const sel = products.find(p => p.id === escogido);
    setTimeout(() => { const f = grid.querySelector('.ct-ficha'); if (f && sel) cargarHistorial(sel, f); }, 0);
    grid.innerHTML = `<div class="ct-split"><div class="ct-tabla"><div class="ct-cabecera" aria-hidden="true"><span>Producto</span><span class="r">Precio</span><span class="r">Costo</span><span>Margen</span><span>Disponible</span></div>${filas}</div><aside class="card ct-ficha">${ficha(sel)}</aside></div>`;
  }
  // Historial de cambios de precio (antes vivía en «Desglose»).
  async function cargarHistorial(p, raiz) {
    const caja = raiz && raiz.querySelector(`[data-hist="${p.id}"]`); if (!caja) return;
    const log = await Api.auditLog.list('product', p.id).catch(() => []);
    if (!log.length || !caja.isConnected) return;
    caja.innerHTML = `<p class="ct-t">Cambios de precio</p><div class="ct-grupo">${log.slice(0, 6).map(l => `<div class="ct-fila"><div class="t"><b>${fmtDec(l.old_value)} → ${fmtDec(l.new_value)}</b></div><span class="muted">${fmtDate(l.created_at)}</span></div>`).join('')}</div>`;
  }
  async function accionCatalogo(b, enHoja) {
    const p = products.find(x => String(x.id) === b.dataset.id); if (!p) return;
    const a = b.dataset.ct;
    if (a === 'editar') { if (enHoja) enHoja.close(); showProductModal(p); return; }
    if (a === 'desglose') { if (enHoja) enHoja.close(); showBreakdown(p); return; }
    if (a === 'eliminar') { if (enHoja) enHoja.close(); removeProduct(p); return; }
    // Interruptores: responde al instante y vuelve atrás si el servidor falla.
    const on = !b.classList.contains('on');
    document.querySelectorAll(`[data-ct="${a}"][data-id="${p.id}"]`).forEach(x => { x.classList.toggle('on', on); x.setAttribute('aria-checked', String(on)); });
    try {
      if (a === 'activo') { await Api.products.update(p.id, { active: on }); p.active = on; UI.toast(on ? `${p.name}: disponible` : `${p.name}: ya no se vende`); }
      if (a === 'web') { await Api.products.webFlags(p.id, { web_visible: on }); p.web_visible = on; }
      if (a === 'agotado') { const r = await Api.products.webFlags(p.id, { sold_out_today: on }); p.sold_out_on = r.sold_out_on; UI.toast(on ? `${p.name}: agotado por hoy` : `${p.name}: vuelve a estar a la venta`); }
      if (a === 'activo') { const row = grid.querySelector(`[data-ct-row="${p.id}"]`); if (row) row.classList.toggle('off', !on); }
    } catch (err) {
      document.querySelectorAll(`[data-ct="${a}"][data-id="${p.id}"]`).forEach(x => { x.classList.toggle('on', !on); x.setAttribute('aria-checked', String(!on)); });
      UI.toast(err.message, 'error');
    }
  }
  grid.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('[data-ct-row]')) e.target.click(); });
  grid.addEventListener('click', e => {
    const b = e.target.closest('[data-ct]');
    if (b) { e.stopPropagation(); accionCatalogo(b); return; }
    const row = e.target.closest('[data-ct-row]'); if (!row) return;
    escogido = Number(row.dataset.ctRow);
    const p = products.find(x => x.id === escogido);
    if (matchMedia('(max-width:820px)').matches) {
      const m = UI.showModal(esc(p.name), `<div class="ct-ficha ct-hoja">${ficha(p)}</div>`);
      m.el.addEventListener('click', ev => { const bb = ev.target.closest('[data-ct]'); if (bb) accionCatalogo(bb, m); });
      cargarHistorial(p, m.el);
      return;
    }
    grid.querySelectorAll('.ct-row').forEach(r => r.classList.toggle('sel', r === row));
    grid.querySelector('.ct-ficha').innerHTML = ficha(p);
    cargarHistorial(p, grid.querySelector('.ct-ficha'));
  });

  async function removeProduct(p) {
    if (!(await UI.confirmDialog(`¿Eliminar "${esc(p.name)}"?`))) return;
    try {
      await Api.products.remove(p.id);
      UI.toast('Producto eliminado');
      load();
    } catch (err) {
      UI.toast('No se pudo eliminar: ' + err.message, 'error');
    }
  }

  async function showBreakdown(p) {
    const log = await Api.auditLog.list('product', p.id).catch(() => []);
    const rows = (p.supplies || []).map(s => ({ label: `${esc(s.supply_name)} (${fmtNum(s.quantity)} ${esc(s.supply_unit)})`, cost: Number(s.unit_cost) * Number(s.quantity) }));
    const cost = rows.reduce((t, r) => t + r.cost, 0);
    const price = Number(p.sale_price);
    const profit = price - cost;
    const maxBar = Math.max(price, cost, 1);
    const body = `
      <p class="muted" style="margin-bottom:14px">Precio de venta <strong>${fmtDec(price)}</strong> — de qué está hecho el costo de <strong>${esc(p.name)}</strong>:</p>
      <div class="cost-bars">
        ${rows.map(r => `
          <div class="cost-bar-row"><span>${r.label}</span>
            <div class="cost-bar-track"><div class="cost-bar-fill" style="width:${Math.max(2, r.cost / maxBar * 100)}%"></div></div>
            <span class="cost-bar-value">${fmtDec(r.cost)}</span></div>`).join('') || '<p class="muted">Este producto no tiene receta cargada: su costo cuenta como RD$0.</p>'}
        <div class="cost-bar-row" style="border-top:1px dashed var(--line);padding-top:10px;font-weight:700"><span>Costo total</span>
          <div class="cost-bar-track"><div class="cost-bar-fill" style="width:${Math.max(2, cost / maxBar * 100)}%"></div></div>
          <span class="cost-bar-value">${fmtDec(cost)}</span></div>
        <div class="cost-bar-row" style="font-weight:700"><span>Ganancia</span>
          <div class="cost-bar-track"><div class="cost-bar-fill is-profit" style="width:${Math.max(2, Math.max(profit, 0) / maxBar * 100)}%"></div></div>
          <span class="cost-bar-value ${profit < 0 ? 'low-stock' : ''}">${fmtDec(profit)}</span></div>
      </div>
      <div class="breakdown-totals">
        <div class="stat"><div class="label">Costo</div><div class="value">${fmtDec(cost)}</div></div>
        <div class="stat"><div class="label">Precio</div><div class="value">${fmtDec(price)}</div></div>
        <div class="stat"><div class="label">Margen</div><div class="value">${price ? Math.round(profit / price * 100) : 0}%</div></div>
      </div>
      ${log.length ? `<div style="margin-top:18px;padding-top:14px;border-top:1px dashed var(--line)">
        <div style="font-weight:700;font-size:.9em;margin-bottom:8px">Historial de precio</div>
        ${log.map(l => `<div class="muted" style="font-size:.85em;margin-bottom:4px">${fmtDate(l.created_at)} — ${fmtDec(l.old_value)} → <strong>${fmtDec(l.new_value)}</strong></div>`).join('')}
      </div>` : ''}`;
    UI.showModal(`Desglose · ${esc(p.name)}`, body);
  }

  const supplyOptions = selectedId => supplies.filter(s => s.active || String(s.id) === String(selectedId))
    .map(s => `<option value="${s.id}" ${String(s.id) === String(selectedId) ? 'selected' : ''}>${esc(s.name)} (${esc(s.unit)})</option>`).join('');

  // Crear / editar un producto (mismo formulario).
  function showProductModal(p) {
    const editing = !!p;
    const chosenGroups = new Set(editing ? p.modifier_group_ids : []);
    const activeGroups = groups.filter(g => g.active || chosenGroups.has(g.id));
    // v4 (DISENO-ARCHE.md): hoja al estilo de Ajustes del iPhone — grupos con filas, interruptores, la receta con el
    // costo de cada insumo en vivo y lo poco usado plegado en «Más opciones». Mismos campos e ids que antes.
    const tasa = editing && p.itbis_rate !== null && p.itbis_rate !== undefined ? Number(p.itbis_rate) : null;
    const swc = (id, on) => `<input type="checkbox" class="pf-sw" id="${id}" ${on ? 'checked' : ''}>`;
    const body = `<div class="pf">
      <p class="pf-sec">Producto</p>
      <div class="pf-grupo">
        <label class="pf-fila"><span>Nombre</span><input id="mp-name" value="${esc(editing ? p.name : '')}" placeholder="ej. Wrap de pollo" autocomplete="off"></label>
        <label class="pf-fila"><span>Categoría</span><select id="mp-category">${categoryOptions(editing ? p.category_id : '', { first: '<option value="">Sin categoría</option>' })}</select></label>
        <label class="pf-fila"><span>Precio</span><span class="pf-pre">${esc(AppLocale.currency())}</span><input id="mp-price" type="number" step="0.01" min="0" inputmode="decimal" value="${editing ? Number(p.sale_price) : ''}" placeholder="0"></label>
        <label class="pf-fila pf-col"><span>Descripción</span><input id="mp-desc" value="${esc(editing ? p.description || '' : '')}" placeholder="Opcional · ej. Con vegetales salteados"></label>
        ${editing ? `<label class="pf-fila"><span>Disponible para vender</span>${swc('mp-active', p.active)}</label>` : ''}
      </div>

      <p class="pf-sec">Receta <small>· insumos que descuenta al venderse</small></p>
      <div class="pf-grupo">
        <div id="mp-recipe" class="pf-receta"></div>
        <button type="button" class="pf-fila pf-add" id="mp-add-supply">+ Agregar insumo</button>
        <div class="pf-resumen" id="mp-preview" role="status"></div>
      </div>

      <p class="pf-sec">Opciones que ofrece</p>
      <div class="pf-grupo">
        ${activeGroups.length ? `<div id="mp-groups">${activeGroups.map(g => `<label class="pf-fila"><span>${esc(g.name)}<small>${g.selection === 'single' ? 'Elige una' : 'Elige varias'}${g.required ? ' · obligatoria' : ''}</small></span><input type="checkbox" class="pf-check" value="${g.id}" ${chosenGroups.has(g.id) ? 'checked' : ''}></label>`).join('')}</div>`
          : '<div class="pf-fila pf-nota">Todavía no hay grupos de opciones; se crean en la pestaña «Opciones».</div>'}
      </div>

      <p class="pf-sec">En la página web</p>
      <div class="pf-grupo">
        <label class="pf-fila"><span>Se muestra en la página</span>${swc('mp-web', !editing || p.web_visible)}</label>
        <div class="pf-fila pf-col pf-foto">${Fotos.fieldHtml('mp-image', editing ? p.image_url : '', 'Foto del plato')}</div>
        <label class="pf-fila"><span>Etiqueta</span><input id="mp-badge" maxlength="24" value="${esc(editing ? p.badge || '' : '')}" placeholder="Nuevo, Popular…"></label>
        <label class="pf-fila"><span>Horario</span><select id="mp-sched">${scheduleOptions(editing ? p.schedule_id : null, 'El de su categoría')}</select></label>
        <label class="pf-fila"><span>Calorías</span><input id="mp-cal" type="number" min="0" max="5000" step="1" inputmode="numeric" value="${editing && p.calories ? p.calories : ''}" placeholder="Opcional"></label>
        <label class="pf-fila"><span>Proteína (g)</span><input id="mp-prot" type="number" min="0" max="500" step="0.1" inputmode="decimal" value="${editing && p.protein_g != null ? Number(p.protein_g) : ''}" placeholder="Opcional"></label>
      </div>

      <details class="pf-mas"${editing && (p.barcode || p.sku || tasa !== null || p.wholesale_price || p.manager_only) ? ' open' : ''}>
        <summary>Más opciones <small>código, impuesto, mayoreo</small></summary>
        <div class="pf-grupo">
          <label class="pf-fila"><span>Código de barras</span><input id="mp-barcode" maxlength="64" inputmode="numeric" value="${esc(editing ? p.barcode || '' : '')}" placeholder="Escanéalo o escríbelo"></label>
          <label class="pf-fila"><span>SKU / referencia</span><input id="mp-sku" maxlength="64" value="${esc(editing ? p.sku || '' : '')}" placeholder="Opcional"></label>
          <label class="pf-fila"><span>ITBIS</span><select id="mp-tax">
            <option value="">El general del negocio</option>
            <option value="0" ${tasa === 0 ? 'selected' : ''}>Exento (0 %)</option>
            <option value="16" ${tasa === 16 ? 'selected' : ''}>16 %</option>
            <option value="18" ${tasa === 18 ? 'selected' : ''}>18 %</option>
          </select></label>
          <label class="pf-fila"><span>Precio de mayoreo</span><span class="pf-pre">${esc(AppLocale.currency())}</span><input id="mp-wholesale-price" type="number" step="0.01" min="0" inputmode="decimal" value="${editing && p.wholesale_price !== null && p.wholesale_price !== undefined ? Number(p.wholesale_price) : ''}" placeholder="—"></label>
          <label class="pf-fila"><span>Desde cuántas unidades</span><input id="mp-wholesale-qty" type="number" step="1" min="1" inputmode="numeric" value="${editing && p.wholesale_min_qty ? p.wholesale_min_qty : ''}" placeholder="ej. 6"></label>
          <label class="pf-fila"><span>Solo lo vende un gerente<small>En la caja solo lo ve un gerente</small></span>${swc('mp-manager-only', editing && p.manager_only)}</label>
        </div>
      </details>

      <div class="pf-acciones">
        <button class="btn" id="mp-cancel">Cancelar</button>
        <button class="btn btn-primary" id="mp-save">${editing ? 'Guardar cambios' : 'Crear producto'}</button>
      </div></div>`;
    const modal = UI.showModal(editing ? `Editar · ${esc(p.name)}` : 'Producto nuevo', body);
    const el = modal.el;
    Fotos.bind(el);
    const recipeEl = el.querySelector('#mp-recipe');
    const previewEl = el.querySelector('#mp-preview');

    // La cantidad se puede escribir en otra medida de la misma familia (ej. «0.25 libra» en un insumo
    // que se cuenta en gramos): se guarda convertida a la unidad base y se recuerda la medida elegida.
    const supplyById = id => supplies.find(s => s.id === Number(id)) || {};
    const factorDe = (supply, clave) => (clave ? Unidades.factor(supply.unit, clave) || 1 : 1);
    const medidaDe = row => { const sel = row.querySelector('select[data-r="unidad"]'); return (sel && sel.value) || null; };
    function readRecipe() {
      return Array.from(recipeEl.querySelectorAll('.receta-row')).map(row => {
        const supply = supplyById(row.querySelector('select[data-r="insumo"]').value);
        const clave = medidaDe(row);
        const qty = Number(row.querySelector('input').value);
        return { supply_id: Number(supply.id), quantity: Unidades.redondear(qty * factorDe(supply, clave), 3), unidad: clave };
      }).filter(r => r.supply_id && r.quantity > 0);
    }
    function updatePreview() {
      const price = Number(el.querySelector('#mp-price').value) || 0;
      // Costo de cada insumo en su fila (y, si se escribió en otra medida, cuánto es en la base), y el resumen abajo.
      recipeEl.querySelectorAll('.receta-row').forEach(row => {
        const supply = supplyById(row.querySelector('select[data-r="insumo"]').value);
        const clave = medidaDe(row);
        const qty = Number(row.querySelector('input').value) || 0;
        const base = qty * factorDe(supply, clave);
        row.querySelector('.pf-costo').innerHTML = supply.id && qty
          ? `${fmtDec(base * Number(supply.unit_cost || 0))}${clave ? `<small>${Unidades.numero(base)} ${esc(supply.unit)}</small>` : ''}` : '—';
      });
      const rows = readRecipe();
      if (!rows.length) { previewEl.innerHTML = '<span>Sin receta: el costo cuenta como RD$0 y no descuenta insumos.</span>'; return; }
      const cost = rows.reduce((t, r) => t + r.quantity * Number(supplyById(r.supply_id).unit_cost || 0), 0);
      const mg = price > 0 ? Math.round((price - cost) / price * 100) : null;
      previewEl.innerHTML = `<span>Costo <b>${fmtDec(cost)}</b></span>${price > 0 ? `<span>Te queda <b class="${price - cost < 0 ? 'ct-mal' : 'ct-bien'}">${fmtDec(price - cost)}</b></span><span>Margen <b class="${mg < 0 ? 'ct-mal' : 'ct-bien'}">${mg} %</b></span>` : ''}`;
    }
    // Solo hay selector si el insumo se puede convertir (peso o volumen); si no, la unidad va como texto.
    function unidadCampo(supply, clave) {
      const ops = Unidades.opciones(supply.unit);
      if (!ops.length) return `<small class="pf-u">${esc(supply.unit || '')}</small>`;
      return `<select data-r="unidad" aria-label="Medida"><option value="">${esc(supply.unit)}</option>`
        + ops.map(o => `<option value="${o.clave}" ${o.clave === clave ? 'selected' : ''}>${esc(o.nombre)}</option>`).join('') + '</select>';
    }
    function addRow(supplyId, qtyBase, clave) {
      const row = document.createElement('div');
      row.className = 'receta-row';
      const supply = supplyById(supplyId);
      const f = factorDe(supply, clave);
      const qty = qtyBase ? Unidades.redondear(Number(qtyBase) / f, 3) : '';
      row.innerHTML = `<select data-r="insumo" aria-label="Insumo">${supplyOptions(supplyId)}</select>
        <span class="pf-cant"><input type="number" placeholder="Cant." step="any" min="0" inputmode="decimal" value="${qty}" aria-label="Cantidad"><span class="receta-medida">${unidadCampo(supply, clave)}</span></span>
        <span class="pf-costo"></span>
        <button type="button" class="pf-quitar" aria-label="Quitar insumo">−</button>`;
      row.querySelector('button').addEventListener('click', () => { row.remove(); updatePreview(); });
      row.querySelector('select[data-r="insumo"]').addEventListener('change', e => {
        row.querySelector('.receta-medida').innerHTML = unidadCampo(supplyById(e.target.value), null);
      });
      row.addEventListener('input', updatePreview);
      row.addEventListener('change', updatePreview);
      recipeEl.appendChild(row);
    }
    (editing ? p.supplies : []).forEach(s => addRow(s.supply_id, s.quantity, s.unidad));
    el.querySelector('#mp-add-supply').addEventListener('click', () => { addRow(); updatePreview(); });
    el.querySelector('#mp-price').addEventListener('input', updatePreview);
    updatePreview();

    el.querySelector('#mp-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#mp-save').addEventListener('click', async () => {
      const name = el.querySelector('#mp-name').value.trim();
      const sale_price = Number(el.querySelector('#mp-price').value);
      if (!name || !(sale_price >= 0) || el.querySelector('#mp-price').value === '') {
        UI.toast('El nombre y el precio (0 o más) son obligatorios', 'error');
        return;
      }
      const data = {
        name, sale_price,
        category_id: el.querySelector('#mp-category').value ? Number(el.querySelector('#mp-category').value) : null,
        description: el.querySelector('#mp-desc').value.trim() || null,
        supplies: readRecipe(),
        modifier_group_ids: Array.from(el.querySelectorAll('#mp-groups input:checked')).map(i => Number(i.value)),
        web_visible: el.querySelector('#mp-web').checked,
        schedule_id: el.querySelector('#mp-sched').value ? Number(el.querySelector('#mp-sched').value) : null,
        image_url: el.querySelector('#mp-image').value || null,
        badge: el.querySelector('#mp-badge').value.trim() || null,
        barcode: el.querySelector('#mp-barcode').value.trim() || null,
        sku: el.querySelector('#mp-sku').value.trim() || null,
        itbis_rate: el.querySelector('#mp-tax').value === '' ? null : Number(el.querySelector('#mp-tax').value),
        wholesale_price: el.querySelector('#mp-wholesale-price').value === '' ? null : Number(el.querySelector('#mp-wholesale-price').value),
        wholesale_min_qty: el.querySelector('#mp-wholesale-qty').value === '' ? null : Number(el.querySelector('#mp-wholesale-qty').value),
        manager_only: el.querySelector('#mp-manager-only').checked,
        calories: el.querySelector('#mp-cal').value === '' ? null : Number(el.querySelector('#mp-cal').value),
        protein_g: el.querySelector('#mp-prot').value === '' ? null : Number(el.querySelector('#mp-prot').value)
      };
      if (editing) data.active = el.querySelector('#mp-active').checked;
      try {
        if (editing) await Api.products.update(p.id, data); else await Api.products.create(data);
        modal.close();
        UI.toast(editing ? 'Producto actualizado' : 'Producto agregado');
        load();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  // Atajo de reventa: crea el insumo (unidad) + el producto con receta 1 a 1.
  function showResaleModal() {
    const body = `
      <p class="muted" style="margin-top:-4px">Para lo que se compra hecho y se vende tal cual (agua, refresco, barra de proteína). Crea el insumo y el producto de una vez — después carga el stock en <strong>Inventario → Entradas</strong>.</p>
      <div class="field-grid">
        <div class="f"><span>Nombre</span><input id="mr-name" placeholder="ej. Coca Cola"></div>
        <div class="f"><span>Categoría</span><select id="mr-category">${categoryOptions('', { first: '<option value="">Sin categoría</option>' })}</select></div>
        <div class="f"><span>Precio de venta (RD$)</span><input id="mr-price" type="number" step="0.01" min="0"></div>
        <div class="f"><span>Lo que te cuesta cada una (RD$)</span><input id="mr-cost" type="number" step="0.01" min="0"></div>
        <div class="f"><span>Empaque de compra (opcional)</span><input id="mr-pack-name" placeholder="ej. caja"></div>
        <div class="f"><span>Unidades por empaque</span><input id="mr-pack-size" type="number" step="1" min="0" placeholder="ej. 24"></div>
      </div>
      <div class="modal-actions" style="margin-top:20px">
        <button class="btn" id="mr-cancel">Cancelar</button>
        <button class="btn btn-primary" id="mr-save">Crear</button>
      </div>`;
    const modal = UI.showModal('Producto de reventa', body);
    const el = modal.el;
    el.querySelector('#mr-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#mr-save').addEventListener('click', async () => {
      const name = el.querySelector('#mr-name').value.trim();
      const priceRaw = el.querySelector('#mr-price').value;
      const costRaw = el.querySelector('#mr-cost').value;
      if (!name || priceRaw === '' || costRaw === '') {
        UI.toast('Nombre, precio de venta y costo son obligatorios', 'error');
        return;
      }
      try {
        await Api.products.resale({
          name, sale_price: Number(priceRaw), unit_cost: Number(costRaw),
          category_id: el.querySelector('#mr-category').value ? Number(el.querySelector('#mr-category').value) : null,
          pack_name: el.querySelector('#mr-pack-name').value.trim() || null,
          pack_size: el.querySelector('#mr-pack-size').value ? Number(el.querySelector('#mr-pack-size').value) : null
        });
        modal.close();
        UI.toast('Producto de reventa creado');
        load();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  /* ═══════════════ CATEGORÍAS ═══════════════ */
  // Las fotos que ya vienen con la app (public/img/menu/) — se elige una por
  // nombre; no hay subida de archivos.

  function renderCategories() {
    if (!categories.length) {
      categoriasEl.innerHTML = '<p class="muted">Todavía no hay categorías. Crea la primera con <strong>+ Categoría</strong>.</p>';
      return;
    }
    const row = (c, isChild) => `
      <div class="cat-row${isChild ? ' is-child' : ''}${c.active ? '' : ' row-inactive'}">
        <div class="cat-row-main">
          ${c.image_url ? `<img class="cat-thumb" src="${esc(c.image_url)}" alt="" loading="lazy">` : `<span class="cat-thumb cat-thumb-empty">${esc(c.icon || '•')}</span>`}
          <div>
            <strong>${esc(c.icon || '')} ${esc(c.name)}</strong>${c.active ? '' : ' <span class="badge badge-muted">Inactiva</span>'}
            <div class="muted" style="font-size:.85em">${c.product_count} ${c.product_count === 1 ? 'producto' : 'productos'}${!isChild && c.child_count ? ` · ${c.child_count} ${c.child_count === 1 ? 'subcategoría' : 'subcategorías'}` : ''}</div>
          </div>
        </div>
        <div class="cat-row-actions">
          <button class="btn btn-sm" data-edit="${c.id}">${UI.iconLabel('edit', 'Editar')}</button>
          ${isChild ? '' : `<button class="btn btn-sm" data-sub="${c.id}">+ Subcategoría</button>`}
          <button class="btn btn-sm" data-del="${c.id}">${UI.iconLabel('trash', 'Eliminar')}</button>
        </div>
      </div>`;
    categoriasEl.innerHTML = rootCats().map(root =>
      row(root, false) + childrenOf(root.id).map(k => row(k, true)).join('')
    ).join('');
    categoriasEl.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => showCategoryModal(categories.find(c => c.id === Number(b.dataset.edit)))));
    categoriasEl.querySelectorAll('[data-sub]').forEach(b => b.addEventListener('click', () => showCategoryModal(null, Number(b.dataset.sub))));
    categoriasEl.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
      const c = categories.find(x => x.id === Number(b.dataset.del));
      if (!(await UI.confirmDialog(`¿Eliminar la categoría "${esc(c.name)}"?`))) return;
      try {
        await Api.menu.removeCategory(c.id);
        UI.toast('Categoría eliminada');
        load();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    }));
  }

  function showCategoryModal(c, parentId) {
    const editing = !!c;
    const parent = editing ? c.parent_id : (parentId || null);
    const hasChildren = editing && childrenOf(c.id).length > 0;
    const body = `
      <div class="field-grid">
        <div class="f"><span>Nombre</span><input id="mc-name" value="${esc(editing ? c.name : '')}" placeholder="ej. Almuerzos"></div>
        <div class="f"><span>Ícono (un emoji, opcional)</span><input id="mc-icon" value="${esc(editing ? c.icon || '' : '')}" maxlength="4" placeholder="🥗"></div>
        <div class="f"><span>Está dentro de</span>
          <select id="mc-parent" ${hasChildren ? 'disabled' : ''}>
            <option value="">— Es una categoría principal —</option>
            ${rootCats().filter(r => !editing || r.id !== c.id).map(r => `<option value="${r.id}" ${r.id === parent ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}
          </select>
        </div>
        ${Fotos.fieldHtml('mc-image', editing ? c.image_url : '', 'Foto (opcional)')}
        <div class="f"><span>Orden (menor = primero)</span><input id="mc-order" type="number" step="1" value="${editing ? c.sort_order : 0}"></div>
      </div>
      <div style="margin:14px 0 6px;font-weight:700;font-size:.9em;color:var(--ink-soft)">En la página web</div>
      <label class="f-check"><input type="checkbox" id="mc-web" ${!editing || c.web_visible ? 'checked' : ''}><span>Se muestra en la página de pedidos</span></label>
      <label class="f" style="max-width:none;margin-top:8px"><span>Frase bajo el nombre (opcional)</span><input id="mc-tagline" maxlength="120" value="${esc(editing ? c.tagline || '' : '')}" placeholder="ej. Para arrancar el día con energía"></label>
      <label class="f" style="max-width:none;margin-top:8px"><span>Horario (desayuno, almuerzo, cena…)</span><select id="mc-sched">${scheduleOptions(editing ? c.schedule_id : null, 'Sin horario — siempre disponible')}</select></label>
      ${editing ? `<label class="f-check" style="margin-top:14px"><input type="checkbox" id="mc-active" ${c.active ? 'checked' : ''}><span>Activa (se ve en el punto de venta)</span></label>` : ''}
      ${hasChildren ? '<p class="muted" style="margin:10px 0 0">Tiene subcategorías, por eso no puede pasar a estar dentro de otra.</p>' : ''}
      <div class="modal-actions" style="margin-top:20px">
        <button class="btn" id="mc-cancel">Cancelar</button>
        <button class="btn btn-primary" id="mc-save">Guardar</button>
      </div>`;
    const modal = UI.showModal(editing ? `Editar · ${esc(c.name)}` : (parent ? 'Subcategoría nueva' : 'Categoría nueva'), body);
    const el = modal.el;
    Fotos.bind(el);
    el.querySelector('#mc-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#mc-save').addEventListener('click', async () => {
      const name = el.querySelector('#mc-name').value.trim();
      if (!name) { UI.toast('El nombre es obligatorio', 'error'); return; }
      const data = {
        name,
        icon: el.querySelector('#mc-icon').value.trim() || null,
        image_url: el.querySelector('#mc-image').value || null,
        sort_order: Number(el.querySelector('#mc-order').value) || 0,
        parent_id: el.querySelector('#mc-parent').value ? Number(el.querySelector('#mc-parent').value) : null,
        web_visible: el.querySelector('#mc-web').checked,
        tagline: el.querySelector('#mc-tagline').value.trim() || null,
        schedule_id: el.querySelector('#mc-sched').value ? Number(el.querySelector('#mc-sched').value) : null
      };
      if (editing) data.active = el.querySelector('#mc-active').checked;
      try {
        if (editing) await Api.menu.updateCategory(c.id, data); else await Api.menu.createCategory(data);
        modal.close();
        UI.toast(editing ? 'Categoría actualizada' : 'Categoría creada');
        load();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  /* ═══════════════ OPCIONES (modificadores) ═══════════════ */
  function renderGroups() {
    if (!groups.length) {
      gruposEl.innerHTML = '<div class="card"><p class="muted" style="margin:0">Todavía no hay grupos de opciones. Ejemplos: <em>Elige tu acompañante</em>, <em>Extras</em>, <em>Punto de la carne</em>.</p></div>';
      return;
    }
    gruposEl.innerHTML = groups.map(g => `
      <div class="card group-card${g.active ? '' : ' row-inactive'}" data-group="${g.id}">
        <div class="card-header-row">
          <div>
            <h2 style="margin:0">${esc(g.name)}</h2>
            <div class="group-badges">
              <span class="badge badge-ok">${g.selection === 'single' ? 'Elige una' : 'Elige varias'}</span>
              <span class="badge ${g.required ? 'badge-warn' : 'badge-muted'}">${g.required ? 'Obligatoria' : 'Opcional'}</span>
              ${g.active ? '' : '<span class="badge badge-muted">Inactivo</span>'}
              <span class="muted" style="font-size:.85em">usado en ${g.product_count} ${g.product_count === 1 ? 'producto' : 'productos'}</span>
            </div>
          </div>
          <div class="cat-row-actions">
            <button class="btn btn-sm" data-gedit="${g.id}">${UI.iconLabel('edit', 'Editar')}</button>
            <button class="btn btn-sm" data-gdel="${g.id}">${UI.iconLabel('trash', 'Eliminar')}</button>
          </div>
        </div>
        <div class="option-list">
          ${g.options.length ? g.options.map(o => `
            <div class="option-row${o.active ? '' : ' row-inactive'}">
              <span class="option-name">${esc(o.name)}${o.active ? '' : ' <span class="badge badge-muted">Inactiva</span>'}</span>
              <span class="option-price">${Number(o.price_delta) ? (Number(o.price_delta) > 0 ? '+' : '') + fmt(o.price_delta) : 'sin costo'}</span>
              <span class="option-supply muted">${o.supply_id ? `gasta ${fmtNum(o.supply_qty)} ${esc(o.supply_unit)} de ${esc(o.supply_name)}` : ''}</span>
              <span class="option-actions">
                <button class="btn btn-sm" data-oedit="${o.id}">${UI.iconLabel('edit', 'Editar')}</button>
                <button class="btn btn-sm" data-odel="${o.id}">${UI.iconLabel('trash', 'Quitar')}</button>
              </span>
            </div>`).join('') : '<p class="muted" style="margin:6px 0">Sin opciones todavía.</p>'}
        </div>
        <button class="btn btn-sm" data-oadd="${g.id}" style="margin-top:10px">+ Opción</button>
      </div>`).join('');

    const groupOf = id => groups.find(g => g.id === Number(id));
    const optionOf = id => { for (const g of groups) { const o = g.options.find(x => x.id === Number(id)); if (o) return { g, o }; } return null; };
    gruposEl.querySelectorAll('[data-gedit]').forEach(b => b.addEventListener('click', () => showGroupModal(groupOf(b.dataset.gedit))));
    gruposEl.querySelectorAll('[data-gdel]').forEach(b => b.addEventListener('click', async () => {
      const g = groupOf(b.dataset.gdel);
      if (!(await UI.confirmDialog(`¿Eliminar el grupo "${esc(g.name)}" y todas sus opciones?`))) return;
      try { await Api.menu.removeGroup(g.id); UI.toast('Grupo eliminado'); load(); }
      catch (err) { UI.toast(err.message, 'error'); }
    }));
    gruposEl.querySelectorAll('[data-oadd]').forEach(b => b.addEventListener('click', () => showOptionModal(groupOf(b.dataset.oadd), null)));
    gruposEl.querySelectorAll('[data-oedit]').forEach(b => b.addEventListener('click', () => { const f = optionOf(b.dataset.oedit); showOptionModal(f.g, f.o); }));
    gruposEl.querySelectorAll('[data-odel]').forEach(b => b.addEventListener('click', async () => {
      const f = optionOf(b.dataset.odel);
      if (!(await UI.confirmDialog(`¿Quitar la opción "${esc(f.o.name)}"?`))) return;
      try { await Api.menu.removeOption(f.o.id); UI.toast('Opción quitada'); load(); }
      catch (err) { UI.toast(err.message, 'error'); }
    }));
  }

  function showGroupModal(g) {
    const editing = !!g;
    const body = `
      <div class="field-grid">
        <div class="f"><span>Nombre del grupo</span><input id="mg-name" value="${esc(editing ? g.name : '')}" placeholder="ej. Elige tu acompañante"></div>
        <div class="f"><span>El cliente elige</span>
          <select id="mg-selection">
            <option value="single" ${!editing || g.selection === 'single' ? 'selected' : ''}>Una sola opción</option>
            <option value="multi" ${editing && g.selection === 'multi' ? 'selected' : ''}>Varias opciones</option>
          </select></div>
      </div>
      <label class="f-check" style="margin-top:14px"><input type="checkbox" id="mg-required" ${editing && g.required ? 'checked' : ''}><span>Es obligatorio elegir (no se puede facturar sin esto)</span></label>
      ${editing ? `<label class="f-check" style="margin-top:10px"><input type="checkbox" id="mg-active" ${g.active ? 'checked' : ''}><span>Activo</span></label>` : ''}
      <div class="modal-actions" style="margin-top:20px">
        <button class="btn" id="mg-cancel">Cancelar</button>
        <button class="btn btn-primary" id="mg-save">Guardar</button>
      </div>`;
    const modal = UI.showModal(editing ? `Editar · ${esc(g.name)}` : 'Grupo de opciones nuevo', body);
    const el = modal.el;
    el.querySelector('#mg-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#mg-save').addEventListener('click', async () => {
      const name = el.querySelector('#mg-name').value.trim();
      if (!name) { UI.toast('El nombre es obligatorio', 'error'); return; }
      const data = { name, selection: el.querySelector('#mg-selection').value, required: el.querySelector('#mg-required').checked };
      if (editing) data.active = el.querySelector('#mg-active').checked;
      try {
        if (editing) await Api.menu.updateGroup(g.id, data); else await Api.menu.createGroup(data);
        modal.close();
        UI.toast(editing ? 'Grupo actualizado' : 'Grupo creado — agregale opciones');
        load();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  function showOptionModal(g, o) {
    const editing = !!o;
    const body = `
      <p class="muted" style="margin-top:-4px">Opción de <strong>${esc(g.name)}</strong>.</p>
      <div class="field-grid">
        <div class="f"><span>Nombre</span><input id="mo-name" value="${esc(editing ? o.name : '')}" placeholder="ej. Aguacate"></div>
        <div class="f"><span>Suma al precio (RD$, 0 = sin costo)</span><input id="mo-price" type="number" step="0.01" value="${editing ? Number(o.price_delta) : 0}"></div>
        <div class="f"><span>Gasta un insumo (opcional)</span>
          <select id="mo-supply"><option value="">— Ninguno —</option>${supplies.filter(s => s.active || (editing && s.id === o.supply_id)).map(s => `<option value="${s.id}" ${editing && o.supply_id === s.id ? 'selected' : ''}>${esc(s.name)} (${esc(s.unit)})</option>`).join('')}</select></div>
        <div class="f" id="mo-qty-wrap"><span>Cantidad que gasta</span><input id="mo-qty" type="number" step="0.001" min="0" value="${editing && o.supply_qty ? Number(o.supply_qty) : ''}"></div>
      </div>
      ${editing ? `<label class="f-check" style="margin-top:14px"><input type="checkbox" id="mo-active" ${o.active ? 'checked' : ''}><span>Activa</span></label>` : ''}
      <div class="modal-actions" style="margin-top:20px">
        <button class="btn" id="mo-cancel">Cancelar</button>
        <button class="btn btn-primary" id="mo-save">Guardar</button>
      </div>`;
    const modal = UI.showModal(editing ? `Editar · ${esc(o.name)}` : 'Opción nueva', body);
    const el = modal.el;
    const supplySel = el.querySelector('#mo-supply');
    const qtyWrap = el.querySelector('#mo-qty-wrap');
    const syncQty = () => { qtyWrap.style.display = supplySel.value ? '' : 'none'; };
    supplySel.addEventListener('change', syncQty);
    syncQty();
    el.querySelector('#mo-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#mo-save').addEventListener('click', async () => {
      const name = el.querySelector('#mo-name').value.trim();
      if (!name) { UI.toast('El nombre es obligatorio', 'error'); return; }
      const supply_id = supplySel.value ? Number(supplySel.value) : null;
      const qty = Number(el.querySelector('#mo-qty').value);
      if (supply_id && !(qty > 0)) { UI.toast('Si gasta un insumo, pon cuánto (mayor a 0)', 'error'); return; }
      const data = { name, price_delta: Number(el.querySelector('#mo-price').value) || 0, supply_id, supply_qty: supply_id ? qty : null };
      if (editing) data.active = el.querySelector('#mo-active').checked;
      try {
        if (editing) await Api.menu.updateOption(o.id, data); else await Api.menu.createOption(g.id, data);
        modal.close();
        UI.toast(editing ? 'Opción actualizada' : 'Opción agregada');
        load();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  /* ── Eventos ── */
  document.getElementById('btn-menu-producto').addEventListener('click', () => showProductModal(null));
  document.getElementById('btn-menu-reventa').addEventListener('click', showResaleModal);
  document.getElementById('btn-menu-categoria').addEventListener('click', () => showCategoryModal(null, null));
  document.getElementById('btn-menu-grupo').addEventListener('click', () => showGroupModal(null));
  searchInput.addEventListener('input', renderProducts);
  filterSelect.addEventListener('change', renderProducts);

  // Lo usa Página web → Qué sale para editar un plato sin salir de esa pantalla.
  window.MenuAdmin = {
    editProduct: async id => { await load(); const p = products.find(x => x.id === Number(id)); if (p) showProductModal(p); }
  };

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'menu') load().catch(err => UI.toast('No se pudo cargar el menú: ' + err.message, 'error'));
  });
})();
