/* ═══ Aproximados: cuánto rinde un empaque de lo que no se pesa (lonjas, porciones, rebanadas…) ═══
   Nadie cuenta las lonjas de un queso. Para los insumos que se cuentan en piezas, el sistema sugiere
   cuánto trae normalmente lo que se compra (ej. «1 libra de queso ≈ 30 lonjas») y el dueño lo acepta o
   lo cambia. Son valores típicos de aquí; cada negocio los ajusta a lo que le rinde de verdad.
   Lo usan la edición de insumos y «Registrar compra» (window.Aproximados). */
(function (raiz) {
  'use strict';
  // nombre: palabras del insumo · unidades: en qué se cuenta · empaque/trae: cómo se compra y cuánto rinde.
  const TABLA = [
    { nombre: /queso/, unidades: /^lonjas?$|^rebanadas?$/, empaque: 'libra', trae: 30 },
    { nombre: /jam[oó]n/, unidades: /^lonjas?$|^rebanadas?$/, empaque: 'libra', trae: 20 },
    { nombre: /salami|mortadela|pepperoni/, unidades: /^lonjas?$|^rebanadas?$|^ruedas?$/, empaque: 'libra', trae: 30 },
    { nombre: /tocineta|bacon|beicon/, unidades: /^lonjas?$|^tiras?$/, empaque: 'libra', trae: 14 },
    { nombre: /pan/, unidades: /^rebanadas?$|^tajadas?$/, empaque: 'funda', trae: 20 },
    { nombre: /pan de (hamburguesa|hot ?dog|perro)|bollo/, unidades: /^unidad(es)?$|^panes?$/, empaque: 'paquete', trae: 8 },
    { nombre: /tortilla/, unidades: /^unidad(es)?$/, empaque: 'paquete', trae: 10 },
    { nombre: /salchicha|hot ?dog/, unidades: /^unidad(es)?$/, empaque: 'paquete', trae: 8 },
    { nombre: /mayonesa|ketchup|kétchup|catsup|mostaza|aderezo|salsa|sirup|sirope|miel/, unidades: /^porci[oó]n(es)?$/, empaque: 'galón', trae: 128, nota: 'porción de 1 onza' },
    { nombre: /mantequilla|margarina/, unidades: /^porci[oó]n(es)?$/, empaque: 'libra', trae: 32, nota: 'porción de ½ onza' },
    { nombre: /hielo/, unidades: /^porci[oó]n(es)?$|^vasos?$/, empaque: 'funda', trae: 10 },
    { nombre: /tomate/, unidades: /^ruedas?$|^rodajas?$|^lonjas?$/, empaque: 'libra', trae: 15 },
    { nombre: /tomate|cebolla|papa|aj[ií] morr[oó]n|pimiento/, unidades: /^unidad(es)?$/, empaque: 'libra', trae: 3 },
    { nombre: /lim[oó]n/, unidades: /^unidad(es)?$/, empaque: 'libra', trae: 8 },
    { nombre: /lechuga|repollo/, unidades: /^hojas?$/, empaque: 'mata', trae: 15 },
    { nombre: /fresa/, unidades: /^unidad(es)?$/, empaque: 'libra', trae: 25 },
    { nombre: /huevo/, unidades: /^unidad(es)?$/, empaque: 'cartón', trae: 30 },
    { nombre: /pepinillo/, unidades: /^rodajas?$|^ruedas?$/, empaque: 'frasco', trae: 60 }
  ];
  const limpiar = t => String(t || '').trim().toLowerCase();
  // «lonja» → «lonjas», «unidad» → «unidades», «porción» → «porciones» (para leer «≈ 30 lonjas»).
  const plural = u => { u = limpiar(u); if (!u || /s$/.test(u)) return u; if (/ón$/.test(u)) return u.slice(0, -2) + 'ones'; return /[aeiou]$/.test(u) ? u + 's' : u + 'es'; };

  // La sugerencia para un insumo (o null): { empaque, trae, nota, etiqueta: 'libra ≈ 30 lonja' }.
  function sugerir(nombre, unidad) {
    const n = limpiar(nombre), u = limpiar(unidad);
    if (!n || !u) return null;
    const f = TABLA.find(t => t.nombre.test(n) && t.unidades.test(u));
    if (!f) return null;
    return { empaque: f.empaque, trae: f.trae, nota: f.nota || '', etiqueta: `${f.empaque} ≈ ${f.trae} ${plural(u)}${f.nota ? ` (${f.nota})` : ''}` };
  }

  const api = { TABLA, sugerir, plural };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else raiz.Aproximados = api;
})(typeof window !== 'undefined' ? window : globalThis);
