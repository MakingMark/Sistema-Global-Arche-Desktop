/* ═══ Insumos: catálogo + registrar compras (nuevas o de reposición) ═══ */
(function () {
  'use strict';
  const grid = document.getElementById('insumos-grid');
  if (!grid) return;

  const NEW = '__new__';
  const esc = UI.escapeHtml;

  const compraInsumo = document.getElementById('compra-insumo');
  const compraUbicacion = document.getElementById('compra-ubicacion');
  const compraUnidadTipo = document.getElementById('compra-unidad-tipo');
  const compraCantidad = document.getElementById('compra-cantidad');
  const compraPrecio = document.getElementById('compra-precio');
  const compraPreview = document.getElementById('compra-preview');
  const formCompra = document.getElementById('form-compra');
  formCompra.querySelectorAll('.pf-pre').forEach(el => { el.textContent = AppLocale.currency(); });
  const searchInput = document.getElementById('insumos-search');

  const nuevoFields = document.getElementById('compra-nuevo-fields');
  const nuevoNombre = document.getElementById('compra-nuevo-nombre');
  const nuevoUnidad = document.getElementById('compra-nuevo-unidad');
  const nuevoEmpaqueNombre = document.getElementById('compra-nuevo-empaque-nombre');
  const nuevoEmpaqueSize = document.getElementById('compra-nuevo-empaque-size');
  if (nuevoUnidad && nuevoUnidad.tagName === 'SELECT') nuevoUnidad.innerHTML = Unidades.opcionesHtml('');

  // fmt() redondea a pesos enteros — bien para un cobro real, pero acá
  // esconde insumos baratos: Canela o Servilleta se veían como "RD$0"
  // (parece gratis) cuando en realidad cuestan RD$0.39 y RD$0.23. Mismo
  // ajuste pedido por el dueño para el desglose de Productos, aplicado
  // acá porque es el mismo problema — un costo por unidad, no un cobro.
  // fmtDec ahora es global — ver api.js.

  let supplies = [];

  /* ── Existencias por ubicación (insumo × ubicación) ── */
  const existenciasGrid = document.getElementById('existencias-grid');
  const existenciasResumen = document.getElementById('existencias-resumen');
  const existenciasBuscar = document.getElementById('existencias-buscar');
  const soloBajos = document.getElementById('existencias-solo-bajos');
  let overview = null;

  function fmtQty(n) {
    return Number(n).toLocaleString('es-DO', { maximumFractionDigits: 3 });
  }

  // v4 (DISENO-ARCHE.md): una tabla (insumo × ubicación) y, a la derecha, el detalle del escogido como el
  // inspector de las apps de Mac: cuánto queda, HASTA CUÁNDO ALCANZA según el gasto de los últimos 14 días,
  // el gasto día por día, costo, valor, última compra y qué productos lo usan. En el celular el detalle sube
  // como hoja. Lo bajo y lo que se acaba pronto va primero.
  let escogido = null;   // 'insumo:ubicación'
  const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
  function alcanzaTexto(c) {
    if (c.value <= 0) return { t: 'Agotado', cls: 'b' };
    if (c.alcanza_dias == null) return { t: 'Sin gasto en 14 días', cls: 'g' };
    const d = c.alcanza_dias;
    if (d < 1) return { t: 'Se acaba hoy', cls: 'b' };
    if (d < 2) return { t: 'Alcanza hasta mañana', cls: 'b' };
    if (d < 7) { const f = new Date(); f.setDate(f.getDate() + Math.floor(d)); return { t: `Alcanza hasta el ${DIAS[f.getDay()]}`, cls: 'am' }; }
    return { t: d < 60 ? `Alcanza ~${Math.round(d)} días` : 'Alcanza más de 2 meses', cls: 'ok' };
  }
  function filas() {
    const locations = Modules.visibleLocations(overview.locations);
    const out = [];
    for (const r of overview.rows) for (const l of locations) { const c = r.cells[l.id]; if (c) out.push({ r, l, c, key: `${r.id}:${l.id}` }); }
    return out;
  }
  const urgencia = x => (x.c.low ? 0 : 1) * 1e6 + (x.c.alcanza_dias == null ? 9e5 : Math.min(x.c.alcanza_dias, 8e5));
  function barras(vals) {
    const max = Math.max(...vals, 0.0001), w = 292, h = 64, bw = (w - 13 * 4) / 14;
    return `<svg class="ex-barras" viewBox="0 0 ${w} ${h}" width="100%" height="${h}" aria-hidden="true">${vals.map((v, i) => { const bh = Math.max(v > 0 ? 3 : 1.5, (v / max) * (h - 4)); return `<rect x="${i * (bw + 4)}" y="${h - bh}" width="${bw}" height="${bh}" rx="2.5" class="${i === 13 ? 'hoy' : v > 0 ? 'on' : ''}"/>`; }).join('')}</svg>`;
  }
  function anillo(p, low) {
    const r = 34, c = 2 * Math.PI * r;
    return `<svg width="84" height="84" viewBox="0 0 84 84" aria-hidden="true"><circle cx="42" cy="42" r="${r}" fill="none" stroke="var(--fill)" stroke-width="9"/><circle cx="42" cy="42" r="${r}" fill="none" stroke="${low ? '#FF3B30' : p < 0.35 ? '#FF9500' : '#34C759'}" stroke-width="9" stroke-linecap="round" stroke-dasharray="${Math.max(0.02, p) * c} ${c}" transform="rotate(-90 42 42)"/></svg>`;
  }
  function inspector(x) {
    if (!x) return '<div class="ex-insp-vacio muted">Escoge un insumo para ver hasta cuándo alcanza.</div>';
    const { r, l, c } = x, a = alcanzaTexto(c);
    const ref = Math.max(c.value, c.threshold * 3, c.consumo14, 1);
    const compra = c.ultima_compra ? `${new Date(c.ultima_compra.fecha).toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'short' }).replace(/\./g, '')}, ${fmtQty(c.ultima_compra.cantidad)} ${UI.escapeHtml(r.unit)}` : '—';
    return `<div class="ex-insp-cab"><div><h2>${UI.escapeHtml(r.name)}</h2><p class="muted">Insumo · ${UI.escapeHtml(l.name)}</p></div></div>
      <div class="ex-anillo">${anillo(c.value / ref, c.low)}<div><b>${fmtQty(c.value)} ${UI.escapeHtml(r.unit)}</b><span class="muted">${c.threshold > 0 ? `aviso en ${fmtQty(c.threshold)}` : 'sin aviso de bajo'}</span><strong class="pend ${a.cls}">${a.t}</strong></div></div>
      <div><p class="ex-t">Gasto de los últimos 14 días</p>${barras(c.por_dia || [])}</div>
      <dl class="ex-kv"><dt>Gasto promedio</dt><dd>${c.gasto_dia ? `${fmtQty(Math.round(c.gasto_dia * 100) / 100)} ${UI.escapeHtml(r.unit)} al día` : '—'}</dd>
        <dt>Costo</dt><dd>${fmtDec(r.unit_cost)} / ${UI.escapeHtml(r.unit)}</dd><dt>Valor en existencia</dt><dd>${fmt(c.value * r.unit_cost)}</dd>
        <dt>Última compra</dt><dd>${compra}</dd><dt>Lo usan</dt><dd>${UI.escapeHtml(r.usado_en || '—')}</dd></dl>
      <div class="ex-btns"><button type="button" class="btn" data-aviso-row="${r.id}" data-aviso-loc="${l.id}">Cambiar aviso</button><button type="button" class="btn btn-primary" data-ex-entrada="${r.id}">Registrar entrada</button></div>`;
  }
  // Un solo local con el inventario repartido (ej. compras que entraron al almacén): se ofrece unirlo.
  let unir = null;
  async function revisarUnir() {
    try { unir = await Api.locations.unirEstado(); } catch (_) { unir = null; }
    const caja = document.getElementById('ex-unir') || (() => { const d = document.createElement('div'); d.id = 'ex-unir'; existenciasResumen.before(d); return d; })();
    const otras = unir && unir.un_solo_local && unir.principal ? unir.otras.filter(o => o.insumos > 0) : [];
    caja.hidden = !otras.length;
    if (!otras.length) return;
    const n = otras.reduce((t, o) => t + o.insumos, 0);
    caja.className = 'ex-unir';
    caja.innerHTML = `<span class="hoy-ic" style="background:#FF9500"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8l8-4 8 4v8l-8 4-8-4z"/><path d="M4 8l8 4 8-4M12 12v8"/></svg></span>
      <div class="t"><b>Tu negocio es un solo local, pero ${n} insumo${n === 1 ? '' : 's'} está${n === 1 ? '' : 'n'} en «${UI.escapeHtml(otras.map(o => o.name).join('», «'))}».</b>
      <span class="muted">Las ventas descuentan de «${UI.escapeHtml(unir.principal.name)}», así que ese inventario no se está usando. Al unirlo pasa todo a «${UI.escapeHtml(unir.principal.name)}» y queda un solo inventario. Antes se guarda un respaldo completo, y cada traspaso queda anotado.</span></div>
      <button type="button" class="btn btn-primary" id="ex-unir-btn">Unir en ${UI.escapeHtml(unir.principal.name)}</button>`;
    caja.querySelector('#ex-unir-btn').addEventListener('click', async () => {
      if (!(await UI.confirmDialog(`¿Unir todo el inventario en «${unir.principal.name}»? El almacén se da de baja y queda un solo inventario.`))) return;
      try { const r = await Api.locations.unir(); UI.toast(`Listo: ${r.insumos_movidos} insumos unidos en ${r.principal}`); escogido = null; overview = await Api.reports.stockOverview(); revisarUnir(); renderExistencias(); }
      catch (err) { UI.toast(err.message, 'error'); }
    });
  }
  window.addEventListener('view:show', e => { if (e.detail.view === 'inv-existencias') revisarUnir(); });

  function renderExistencias() {
    if (!overview) return;
    const q = existenciasBuscar.value.trim().toLowerCase();
    const todas = filas();
    const bajos = todas.filter(x => x.c.low);
    const valor = todas.reduce((t, x) => t + x.c.value * x.r.unit_cost, 0);
    const shown = todas.filter(x => (!soloBajos.checked || x.c.low) && (!q || x.r.name.toLowerCase().includes(q))).sort((a, b) => urgencia(a) - urgencia(b));
    existenciasResumen.innerHTML = `<span><small>Valor en existencia</small><b>${fmt(valor)}</b></span><span><small>Insumos</small><b>${overview.rows.length}</b></span><span><small>Bajos</small><b class="${bajos.length ? 'ex-rojo' : ''}">${bajos.length}</b></span>`;
    if (!escogido && shown.length) escogido = shown[0].key;
    const sel = todas.find(x => x.key === escogido) || null;
    const varias = Modules.visibleLocations(overview.locations).length > 1;
    existenciasGrid.innerHTML = shown.length ? `<div class="ex-split"><div class="ex-tabla" role="list">
        <div class="ex-cab" aria-hidden="true"><span>Insumo</span>${varias ? '<span>Ubicación</span>' : ''}<span>Existencia</span><span>Hasta cuándo</span><span class="r">Valor</span></div>
        ${shown.map((x, i) => { const pc = y => y.c.low || y.c.value <= 0 || (y.c.alcanza_dias != null && y.c.alcanza_dias < 3);
          const nPc = shown.filter(pc).length;
          const cab = i === 0 && nPc ? `<div class="ex-grupo">Para comprar · ${nPc}</div>` : (!pc(x) && (i === 0 || pc(shown[i - 1])) ? `<div class="ex-grupo">${nPc ? 'Todo bien' : 'Existencias'} · ${shown.length - nPc}</div>` : '');
          const a = alcanzaTexto(x.c), ref = Math.max(x.c.value, x.c.threshold * 3, x.c.consumo14, 1);
          // v4 (celular): cada fila se desliza a la izquierda y deja ver «Comprar» y «Aviso», como en el correo del iPhone.
          return `${cab}<div class="ex-desliza" role="listitem"><div class="ex-acc" aria-hidden="true"><button type="button" class="ex-acc-b ex-acc-comprar" tabindex="-1" data-ex-entrada="${x.r.id}">Comprar</button><button type="button" class="ex-acc-b ex-acc-aviso" tabindex="-1" data-aviso-row="${x.r.id}" data-aviso-loc="${x.l.id}">Aviso</button></div><button type="button" class="ex-fila${x.key === escogido ? ' sel' : ''}${varias ? '' : ' una'}" data-ex="${x.key}">
            <span class="ex-n"><span class="ex-ini">${UI.escapeHtml(x.r.name.slice(0, 2).toUpperCase())}</span>${UI.escapeHtml(x.r.name)}</span>${varias ? `<span class="muted">${UI.escapeHtml(x.l.name)}</span>` : ''}
            <span class="ex-niv"><span class="ex-b"><i class="${x.c.low || x.c.value <= 0 ? 'r' : a.cls === 'am' ? 'am' : ''}" style="width:${Math.max(x.c.value > 0 ? 4 : 0, Math.min(100, (x.c.value / ref) * 100))}%"></i></span><span class="muted">${fmtQty(x.c.value)} ${UI.escapeHtml(x.r.unit)}</span></span>
            <span><span class="pend ${a.cls}">${a.t}</span></span>
            <span class="r ex-v">${fmt(x.c.value * x.r.unit_cost)}</span></button></div>`; }).join('')}
      </div><aside class="card ex-insp" aria-live="polite">${inspector(sel)}</aside></div>`
      : `<p class="muted">${q || soloBajos.checked ? 'Nada coincide con este filtro.' : 'Todavía no hay insumos.'}</p>`;
  }
  /* Deslizar (solo celular): la fila sigue al dedo hasta 168 px; si pasa de la mitad, se queda abierta. */
  const ABRE = 168;
  let gesto = null, abierta = null;
  const cerrarFila = f => { if (!f) return; f.style.transform = ''; f.classList.remove('ex-abierta'); if (abierta === f) abierta = null; setTimeout(() => { if (!f.classList.contains('ex-abierta')) f.parentNode.classList.remove('ex-mov'); }, 300); };
  existenciasGrid.addEventListener('touchstart', e => {
    if (!matchMedia('(max-width:820px)').matches) return;
    const f = e.target.closest('.ex-fila'); if (!f) return;
    if (abierta && abierta !== f) cerrarFila(abierta);
    const t = e.touches[0];
    gesto = { f, x: t.clientX, y: t.clientY, base: f.classList.contains('ex-abierta') ? -ABRE : 0, dx: 0, eje: null };
  }, { passive: true });
  existenciasGrid.addEventListener('touchmove', e => {
    if (!gesto) return;
    const t = e.touches[0], dx = t.clientX - gesto.x, dy = t.clientY - gesto.y;
    if (!gesto.eje) { if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return; gesto.eje = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y'; }
    if (gesto.eje !== 'x') return;
    gesto.dx = dx; gesto.f.parentNode.classList.add('ex-mov');
    const pos = Math.max(-ABRE - 24, Math.min(0, gesto.base + dx));
    gesto.f.style.transition = 'none'; gesto.f.style.transform = `translateX(${pos}px)`;
  }, { passive: true });
  existenciasGrid.addEventListener('touchend', () => {
    if (!gesto) return;
    const g = gesto; gesto = null; g.f.style.transition = '';
    if (g.eje !== 'x') return;
    g.f.dataset.desliz = '1'; setTimeout(() => { delete g.f.dataset.desliz; }, 350);
    const fin = g.base + g.dx;
    if (fin < -ABRE / 2) { g.f.style.transform = `translateX(${-ABRE}px)`; g.f.classList.add('ex-abierta'); abierta = g.f; } else cerrarFila(g.f);
  });
  existenciasGrid.addEventListener('click', e => {
    const f = e.target.closest('[data-ex]');
    // Tocar una fila deslizada (o justo después de deslizar) solo la cierra.
    if (f && (f.dataset.desliz || f.classList.contains('ex-abierta'))) { e.preventDefault(); cerrarFila(f); return; }
    if (e.target.closest('.ex-acc') && abierta) setTimeout(() => cerrarFila(abierta), 200);
    if (f) {
      escogido = f.dataset.ex;
      if (matchMedia('(max-width:820px)').matches) {
        const x = filas().find(y => y.key === escogido);
        const m = UI.showModal(x ? x.r.name : '', `<div class="ex-insp ex-hoja">${inspector(x)}</div>`);
        m.el.addEventListener('click', ev => { const b = ev.target.closest('[data-aviso-row],[data-ex-entrada]'); if (b) { m.close(); setTimeout(() => existenciasGrid.dispatchEvent(new CustomEvent('ex:accion', { detail: b.dataset })), 220); } });
        return;
      }
      existenciasGrid.querySelectorAll('.ex-fila').forEach(b => b.classList.toggle('sel', b === f));
      const x = filas().find(y => y.key === escogido);
      existenciasGrid.querySelector('.ex-insp').innerHTML = inspector(x);
      return;
    }
    const ent = e.target.closest('[data-ex-entrada]');
    if (ent) irAEntrada(ent.dataset.exEntrada);
  });
  function irAEntrada(supplyId) {
    window.showView('inv-entradas');
    setTimeout(() => { if (compraInsumo) { compraInsumo.value = String(supplyId); compraInsumo.dispatchEvent(new Event('change')); if (compraCantidad) compraCantidad.focus(); } }, 400);
  }
  existenciasGrid.addEventListener('ex:accion', e => {
    if (e.detail.exEntrada) { irAEntrada(e.detail.exEntrada); return; }
    // «Cambiar aviso» desde la hoja: se reusa el mismo diálogo de la tabla.
    const tmp = document.createElement('button'); tmp.dataset.avisoRow = e.detail.avisoRow; tmp.dataset.avisoLoc = e.detail.avisoLoc; tmp.hidden = true;
    existenciasGrid.appendChild(tmp); tmp.click(); tmp.remove();
  });

  // El nivel de aviso (cuánto es "poco") se cambia acá mismo, en la celda
  // donde se ve el stock. 0 = no avisar para ese insumo.
  existenciasGrid.addEventListener('click', e => {
    const btn = e.target.closest('[data-aviso-row]');
    if (!btn || !overview) return;
    const row = overview.rows.find(r => String(r.id) === btn.dataset.avisoRow);
    const loc = overview.locations.find(l => String(l.id) === btn.dataset.avisoLoc);
    const cell = row && row.cells[loc.id];
    if (!row || !loc || !cell) return;
    const modal = UI.showModal('Nivel de aviso', `
      <p>Avisar cuando queden <strong>${UI.escapeHtml(row.name)}</strong> en <strong>${UI.escapeHtml(loc.name)}</strong> esta cantidad o menos (${UI.escapeHtml(row.unit)}). Con 0 no se avisa.</p>
      <label class="f" style="max-width:none"><span>Cantidad</span><input id="aviso-valor" type="number" min="0" step="1" value="${cell.threshold}"></label>
      <div class="modal-actions" style="margin-top:16px">
        <button class="btn" id="aviso-cancel">Cancelar</button>
        <button class="btn btn-primary" id="aviso-save">Guardar</button>
      </div>`);
    modal.el.querySelector('#aviso-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#aviso-save').addEventListener('click', async () => {
      const value = Number(modal.el.querySelector('#aviso-valor').value);
      if (!(value >= 0)) { UI.toast('Escribe 0 o un número positivo', 'error'); return; }
      try {
        await Api.supplies.setThreshold(row.id, loc.id, value);
        modal.close();
        UI.toast('Nivel de aviso guardado');
        loadExistencias();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  });

  async function loadExistencias() {
    try {
      overview = await Api.reports.stockOverview();
      renderExistencias();
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  }
  soloBajos.addEventListener('change', renderExistencias);
  existenciasBuscar.addEventListener('input', renderExistencias);

  // Lo usa el aviso del Panel: abre Existencias ya filtrado a lo bajo.
  window.showExistencias = function (onlyLow) {
    soloBajos.checked = !!onlyLow;
    window.showView('inv-existencias');
    const card = document.getElementById('existencias-card');
    card.scrollIntoView({ block: 'start' });
    // El alto de la página cambia al cargar la tabla; reafirmar la posición.
    setTimeout(() => card.scrollIntoView({ block: 'start' }), 300);
  };

  async function render() {
    supplies = await Api.supplies.list();
    renderTable();

    const selected = compraInsumo.value;
    compraInsumo.innerHTML = supplies.map(s => `<option value="${s.id}">${UI.escapeHtml(s.name)}</option>`).join('')
      + `<option value="${NEW}">+ Insumo nuevo…</option>`;
    // Preservar la selección al re-renderizar (ej. después de guardar una
    // compra) — sin esto, cada render() volvía siempre al primer insumo de
    // la lista en vez de quedarse donde el dueño estaba parado.
    if (supplies.some(s => String(s.id) === selected) || selected === NEW) {
      compraInsumo.value = selected;
    }
    toggleNuevoFields();

    const locations = await Api.locations.list();
    // Solo activas: no tiene sentido registrar una compra nueva con destino
    // a un punto de venta ya dado de baja.
    compraUbicacion.innerHTML = Modules.visibleLocations(locations.filter(l => l.active)).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');

    window.dispatchEvent(new CustomEvent('supplies:updated', { detail: supplies }));
  }

  // Antes esto era una <table> de 5 columnas + acciones — mismo problema
  // estructural que ya tenía Productos (y Reportes): a un ancho intermedio
  // (~1042px) la columna de acciones fija tapaba "Costo del empaque" y hacía
  // falta un punto de quiebre medido a mano solo para esta tabla. Se pasa al
  // mismo componente de tarjetas ya probado en Productos — fase 3 de la
  // propuesta de rediseño: "un solo componente de datos, no una tabla
  // distinta por pantalla".
  function renderTable() {
    const q = searchInput.value.trim().toLowerCase();
    const filtered = q ? supplies.filter(s => s.name.toLowerCase().includes(q)) : supplies;
    grid.innerHTML = '';
    if (!filtered.length) {
      grid.innerHTML = `<p class="muted">Sin resultados para "${q}".</p>`;
      return;
    }
    // v4: una lista como la de Existencias, no tarjetas. Tocar la fila edita; «⋯» trae Editar y Eliminar.
    const lista = document.createElement('div');
    lista.className = 'in-lista'; lista.setAttribute('role', 'list');
    filtered.forEach(s => {
      // "Costo del empaque": el número que el dueño reconoce de la compra real (derivado del costo por unidad).
      const packCost = s.pack_name && s.pack_size ? `${fmt(Number(s.unit_cost) * Number(s.pack_size))} el ${UI.escapeHtml(s.pack_name)}` : '';
      const packs = [s.pack_name ? `${UI.escapeHtml(s.pack_name)} de ${fmtNum(s.pack_size)}` : '', s.transfer_pack_name ? `reparto: ${UI.escapeHtml(s.transfer_pack_name)} de ${fmtNum(s.transfer_pack_size)}` : ''].filter(Boolean).join(' · ');
      const fila = document.createElement('div');
      fila.className = 'in-fila' + (s.active ? '' : ' row-inactive'); fila.setAttribute('role', 'listitem'); fila.tabIndex = 0;
      fila.innerHTML = `<span class="ex-ini">${UI.escapeHtml(s.name.slice(0, 2).toUpperCase())}</span>
        <span class="in-n"><b>${UI.escapeHtml(s.name)}</b>${s.active ? '' : ' <span class="pend g">Inactivo</span>'}<small>${UI.escapeHtml(s.unit)}${packs ? ' · ' + packs : ''}${s.recetas ? ` · en ${s.recetas} receta${s.recetas === 1 ? '' : 's'}` : ''}</small></span>
        <span class="in-c"><b>${Number(s.unit_cost) > 0 ? fmtCost(s.unit_cost) : '<span class="pend am">Sin costo</span>'}</b><small>${Number(s.unit_cost) > 0 ? `por ${UI.escapeHtml(s.unit)}${packCost ? ' · ' + packCost : ''}` : ''}</small></span>
        <button type="button" class="hv-mas" aria-label="Acciones de ${UI.escapeHtml(s.name)}" aria-haspopup="menu"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/></svg></button>`;
      fila.addEventListener('click', e => {
        const mas = e.target.closest('.hv-mas');
        if (!mas) { showEditSupplyModal(s); return; }
        e.stopPropagation();
        document.querySelectorAll('.v4-menu.in-menu').forEach(m => m.remove());
        const menu = document.createElement('div'); menu.className = 'v4-menu in-menu'; menu.setAttribute('role', 'menu');
        menu.innerHTML = `<div class="v4-menu-cab">${UI.escapeHtml(s.name)}</div><button type="button" role="menuitem" data-a="editar">Editar</button><button type="button" role="menuitem" data-a="comprar">Registrar compra</button><hr><button type="button" role="menuitem" class="is-peligro" data-a="eliminar">Eliminar…</button>`;
        document.body.appendChild(menu);
        const r = mas.getBoundingClientRect(), mw = menu.offsetWidth, mh = menu.offsetHeight;
        menu.style.left = Math.max(8, Math.min(window.innerWidth - mw - 8, r.right - mw)) + 'px';
        menu.style.top = (r.bottom + mh + 8 > window.innerHeight ? r.top - mh - 6 : r.bottom + 6) + 'px';
        const fuera = ev => { if (!menu.contains(ev.target)) { menu.remove(); document.removeEventListener('click', fuera); } };
        setTimeout(() => document.addEventListener('click', fuera), 0);
        menu.addEventListener('click', async ev => {
          const a = ev.target.closest('[data-a]'); if (!a) return;
          menu.remove(); document.removeEventListener('click', fuera);
          if (a.dataset.a === 'editar') showEditSupplyModal(s);
          if (a.dataset.a === 'comprar') irAEntrada(s.id);
          if (a.dataset.a === 'eliminar') {
            if (!(await UI.confirmDialog(`¿Eliminar "${UI.escapeHtml(s.name)}"? Si se usa en alguna receta, primero hay que quitarlo de ahí.`))) return;
            try { await Api.supplies.remove(s.id); render(); } catch (err) { UI.toast('No se pudo eliminar: ' + err.message, 'error'); }
          }
        });
      });
      fila.addEventListener('keydown', e => { if (e.key === 'Enter') showEditSupplyModal(s); });
      lista.appendChild(fila);
    });
    grid.appendChild(lista);
  }

  // Un insumo usado en la receta de algún producto no se puede borrar (el
  // esquema lo protege a propósito — ver product_supplies ON DELETE
  // RESTRICT), y hasta ahora tampoco había forma de editarlo: un typo en el
  // nombre de "Leche condensada" quedaba ahí para siempre. PUT /supplies/:id
  // ya existía en el backend, solo faltaba esta parte.
  // Solo aparecen acá las correcciones manuales de costo (Editar) — las que
  // ya deja "Registrar compra" viven en la bitácora de movimientos de
  // inventario (la nota "Compra: X..."), no hace falta duplicarlas.
  function costHistoryRows(log) {
    if (!log.length) return '';
    return `
      <div style="margin:-4px 0 16px;padding-top:10px;border-top:1px dashed var(--line)">
        <div style="font-weight:700;font-size:.85em;margin-bottom:6px">Correcciones manuales de costo</div>
        ${log.map(l => `
          <div class="muted" style="font-size:.82em;margin-bottom:3px">
            ${fmtDate(l.created_at)} — ${fmtDec(l.old_value)} → <strong>${fmtDec(l.new_value)}</strong>
          </div>
        `).join('')}
      </div>
    `;
  }

  async function showEditSupplyModal(s) {
    const log = await Api.auditLog.list('supply', s.id).catch(() => []);
    const body = `
      <div class="f" style="margin-bottom:12px"><span>Nombre</span><input id="edit-sup-name" value="${UI.escapeHtml(s.name)}"></div>
      <div class="f" style="margin-bottom:6px"><span>Se cuenta en</span><select id="edit-sup-unit">${Unidades.opcionesHtml(s.unit)}</select></div>
      <p class="muted" id="edit-sup-unit-ayuda" style="margin:0 0 12px;font-size:.82em">La medida en que están sus recetas y su existencia.</p>
      <div class="f" style="margin-bottom:12px"><span>Costo (RD$)</span><div class="costo-en"><input id="edit-sup-cost" type="number" step="any" min="0" inputmode="decimal" value="${Number(s.unit_cost)}">${costoEnOpciones(s).length > 1 ? `<select id="edit-sup-cost-en" aria-label="Costo por">${costoEnOpciones(s).map(o => `<option value="${o.v}">${UI.escapeHtml(o.t)}</option>`).join('')}</select>` : `<span class="muted">por ${UI.escapeHtml(s.unit)}</span>`}</div></div>
      <p class="muted" id="edit-sup-cost-ayuda" style="margin:-6px 0 12px;font-size:.82em">Es lo que cuesta <strong>un(a) ${UI.escapeHtml(s.unit)}</strong>, la misma medida en que están las recetas. Si sabes el precio del paquete, del galón o de la libra, escógelo al lado y el sistema hace la cuenta (por eso conviene llenar abajo «Empaque de compra» y cuánto trae). Normalmente el costo se actualiza solo con «Registrar compra».</p>
      ${costHistoryRows(log)}
      <p class="muted" style="margin:0 0 4px;font-size:.82em">Empaque de compra — cómo lo vende el proveedor (ej. "caja" de 1000).</p>
      <div class="f" style="margin-bottom:12px"><span>Empaque de compra (opcional)</span><input id="edit-sup-pack-name" value="${UI.escapeHtml(s.pack_name || '')}" placeholder="ej. caja"></div>
      <div class="f" style="margin-bottom:12px"><span>Unidades por empaque de compra</span><input id="edit-sup-pack-size" type="number" step="0.001" min="0" value="${s.pack_size ? Number(s.pack_size) : ''}"></div>
      <p class="aprox-sug" id="edit-sup-sug" hidden></p>
      <p class="muted" style="margin:0 0 4px;font-size:.82em">Empaque de reparto — cómo se maneja al transferir entre almacén y puntos de venta, si es distinto al de compra (ej. "paquete" de 50, dentro de una caja de 1000).</p>
      <div class="f" style="margin-bottom:12px"><span>Empaque de reparto (opcional)</span><input id="edit-sup-transfer-pack-name" value="${UI.escapeHtml(s.transfer_pack_name || '')}" placeholder="ej. paquete"></div>
      <div class="f" style="margin-bottom:12px"><span>Unidades por empaque de reparto</span><input id="edit-sup-transfer-pack-size" type="number" step="0.001" min="0" value="${s.transfer_pack_size ? Number(s.transfer_pack_size) : ''}"></div>
      <label class="f-check" style="margin-bottom:4px"><input type="checkbox" id="edit-sup-is-prep" ${s.preparation ? 'checked' : ''}><span>Es un insumo preparado (se hace a partir de otros)</span></label>
      <p class="muted" style="margin:0 0 8px;font-size:.82em">Ej. pollo cocido y desmenuzado, carne porcionada, salsa de la casa. Se prepara desde <strong>Inventario → Preparar</strong>: gasta los ingredientes, suma lo preparado y calcula su costo solo. Después lo usas en las recetas de los platos.</p>
      <div id="edit-sup-prep-body" style="margin-bottom:14px;${s.preparation ? '' : 'display:none'}">
        <div class="f" style="margin-bottom:8px"><span>Una tanda rinde (${UI.escapeHtml(s.unit)})</span><input id="edit-sup-prep-yield" type="number" step="0.001" min="0" value="${s.preparation ? s.preparation.batch_yield : ''}" placeholder="ej. 700"></div>
        <div style="font-size:.85em;font-weight:700;color:var(--ink-soft);margin-bottom:6px">Ingredientes de UNA tanda</div>
        <div id="edit-sup-prep-rows" class="receta-builder"></div>
        <button type="button" class="btn btn-sm" id="edit-sup-prep-add" style="margin-top:6px">+ Ingrediente</button>
      </div>
      <label class="f-check" style="margin-bottom:4px"><input type="checkbox" id="edit-sup-expiry" ${s.track_expiry ? 'checked' : ''}><span>Controlar fecha de vencimiento</span></label>
      <p class="muted" style="margin:0 0 12px;font-size:.82em">Para lo perecedero (carnes, lácteos, vegetales): cada compra o entrada lleva su fecha, las ventas gastan primero lo que vence antes y el sistema avisa lo que está por vencer.</p>
      <label class="f-check" style="margin-bottom:16px"><input type="checkbox" id="edit-sup-active" ${s.active ? 'checked' : ''}><span>Activo (visible para comprar/recetas nuevas)</span></label>
      <div class="modal-actions" style="margin-top:20px">
        <button class="btn" id="edit-sup-cancel">Cancelar</button>
        <button class="btn btn-primary" id="edit-sup-save">Guardar</button>
      </div>
    `;
    const modal = UI.showModal(`Editar · ${UI.escapeHtml(s.name)}`, body);
    // Aproximado (ej. «libra ≈ 30 lonjas»): se sugiere si el insumo se cuenta en piezas y no tiene ese
    // empaque; «Usar» llena el empaque de compra. Se recalcula si cambian el nombre o la unidad.
    const sugEl = modal.el.querySelector('#edit-sup-sug');
    const pintarSug = () => {
      const g = Aproximados.sugerir(modal.el.querySelector('#edit-sup-name').value, modal.el.querySelector('#edit-sup-unit').value);
      const packN = modal.el.querySelector('#edit-sup-pack-name').value.trim(), packS = Number(modal.el.querySelector('#edit-sup-pack-size').value);
      const ya = g && packS === g.trae && packN.toLowerCase().startsWith(g.empaque);
      sugEl.hidden = !g || ya;
      if (!g || ya) return;
      sugEl.innerHTML = `Aproximado: <strong>1 ${UI.escapeHtml(g.etiqueta)}</strong>. Así no hay que contar al comprar. <button type="button" class="btn btn-sm">Usar</button>`;
      sugEl.querySelector('button').addEventListener('click', () => {
        modal.el.querySelector('#edit-sup-pack-name').value = `${g.empaque} (aprox.)`;
        modal.el.querySelector('#edit-sup-pack-size').value = g.trae;
        pintarSug();
      });
    };
    ['#edit-sup-name', '#edit-sup-unit', '#edit-sup-pack-name', '#edit-sup-pack-size'].forEach(q => modal.el.querySelector(q).addEventListener('input', pintarSug));
    // Al cambiar «Se cuenta en» se explica qué va a pasar (el servidor hace la conversión o la bloquea).
    const selU = modal.el.querySelector('#edit-sup-unit'), ayU = modal.el.querySelector('#edit-sup-unit-ayuda');
    const campoCosto = modal.el.querySelector('#edit-sup-cost'), campoPack = modal.el.querySelector('#edit-sup-pack-size');
    selU.addEventListener('change', () => {
      pintarSug();
      const de = Unidades.canonica(s.unit), a = selU.value, A = Unidades.deUnidad(de), B = Unidades.deUnidad(a);
      const convierte = de !== a && A && B && A.familia === B.familia;
      campoCosto.disabled = campoPack.disabled = !!convierte;
      ayU.classList.toggle('ex-aviso-unidad', de !== a);
      ayU.innerHTML = de === a ? 'La medida en que están sus recetas y su existencia.'
        : convierte ? `Al guardar, Arche <b>convierte</b> la existencia, las recetas, el costo y los empaques de «${UI.escapeHtml(de)}» a «${UI.escapeHtml(a)}». No hay que cambiar nada más.`
        : `«${UI.escapeHtml(de)}» y «${UI.escapeHtml(a)}» no se pueden convertir entre sí. Solo se puede si el insumo no tiene existencia ni se usa en recetas. Si lo compras en otra presentación, deja la unidad y usa «Empaque de compra».`;
    });
    pintarSug();
    modal.el.querySelector('#edit-sup-cancel').addEventListener('click', () => modal.close());
    const prepRows = modal.el.querySelector('#edit-sup-prep-rows');
    const ingredientOptions = selectedId => supplies.filter(x => x.id !== s.id && (x.active || x.id === selectedId))
      .map(x => `<option value="${x.id}" ${x.id === selectedId ? 'selected' : ''}>${UI.escapeHtml(x.name)} (${UI.escapeHtml(x.unit)})</option>`).join('');
    function addPrepRow(supplyId, qty) {
      const row = document.createElement('div');
      row.className = 'receta-row';
      row.innerHTML = `<select>${ingredientOptions(supplyId)}</select><input type="number" step="0.001" min="0" placeholder="Cantidad" value="${qty || ''}"><button type="button" class="btn btn-sm">Quitar</button>`;
      row.querySelector('button').addEventListener('click', () => row.remove());
      prepRows.appendChild(row);
    }
    if (s.preparation) s.preparation.inputs.forEach(i => addPrepRow(i.supply_id, i.quantity));
    modal.el.querySelector('#edit-sup-prep-add').addEventListener('click', () => addPrepRow());
    modal.el.querySelector('#edit-sup-is-prep').addEventListener('change', e => {
      modal.el.querySelector('#edit-sup-prep-body').style.display = e.target.checked ? '' : 'none';
      if (e.target.checked && !prepRows.children.length) addPrepRow();
    });
    modal.el.querySelector('#edit-sup-save').addEventListener('click', async () => {
      const name = modal.el.querySelector('#edit-sup-name').value.trim();
      const unit = modal.el.querySelector('#edit-sup-unit').value.trim();
      const costEn = modal.el.querySelector('#edit-sup-cost-en');
      const opEn = costEn ? costoEnOpciones(s).find(o => o.v === costEn.value) : null;
      const unit_cost = Unidades.redondear(Number(modal.el.querySelector('#edit-sup-cost').value) / ((opEn && opEn.f) || 1), 4);
      const pack_name = modal.el.querySelector('#edit-sup-pack-name').value.trim() || null;
      const pack_size = Number(modal.el.querySelector('#edit-sup-pack-size').value) || null;
      const transfer_pack_name = modal.el.querySelector('#edit-sup-transfer-pack-name').value.trim() || null;
      const transfer_pack_size = Number(modal.el.querySelector('#edit-sup-transfer-pack-size').value) || null;
      const active = modal.el.querySelector('#edit-sup-active').checked;
      const track_expiry = modal.el.querySelector('#edit-sup-expiry').checked;
      if (!name || !unit || !(unit_cost >= 0)) {
        UI.toast('Nombre, unidad y costo (0 o más) son obligatorios', 'error');
        return;
      }
      try {
        const guardado = await Api.supplies.update(s.id, { name, unit, unit_cost, pack_name, pack_size, transfer_pack_name, transfer_pack_size, active, track_expiry });
        if (guardado && guardado.convertido) UI.toast(`Listo: existencia, recetas y costo pasados de ${guardado.convertido.de} a ${guardado.convertido.a}`, 'success');
        if (modal.el.querySelector('#edit-sup-is-prep').checked) {
          const inputs = Array.from(prepRows.querySelectorAll('.receta-row')).map(r => ({ supply_id: Number(r.querySelector('select').value), quantity: Number(r.querySelector('input').value) })).filter(i => i.supply_id && i.quantity > 0);
          await Api.supplies.setPreparation(s.id, { batch_yield: Number(modal.el.querySelector('#edit-sup-prep-yield').value), inputs });
        } else if (s.preparation) {
          await Api.supplies.setPreparation(s.id, null);
        }
        modal.close();
        UI.toast('Insumo actualizado');
        render();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  // «Costo por…»: la unidad base, sus empaques (galón de 128 porciones, paquete de 8…) y las medidas
  // fijas (libra, kilo…). El costo se guarda siempre por unidad base: precio ÷ lo que trae.
  function costoEnOpciones(s) {
    const ops = [{ v: '', t: `por ${s.unit}`, f: 1 }];
    if (s.pack_name && Number(s.pack_size) > 0) ops.push({ v: 'pack', t: `por ${s.pack_name} (${fmtNum(Number(s.pack_size))} ${s.unit})`, f: Number(s.pack_size) });
    if (s.transfer_pack_name && Number(s.transfer_pack_size) > 0) ops.push({ v: 'transfer_pack', t: `por ${s.transfer_pack_name} (${fmtNum(Number(s.transfer_pack_size))} ${s.unit})`, f: Number(s.transfer_pack_size) });
    Unidades.opciones(s.unit).forEach(o => ops.push({ v: 'conv:' + o.clave, t: `por ${o.nombre}`, f: o.factor }));
    return ops;
  }

  function isNewSelected() {
    return compraInsumo.value === NEW;
  }

  function currentSupply() {
    return supplies.find(s => String(s.id) === compraInsumo.value);
  }

  // Ambos casos (insumo existente vs. "+ Insumo nuevo") arman el mismo tipo
  // de dato — { unit, packName, packSize } — solo que uno lo lee del insumo
  // ya guardado y el otro de lo que se va escribiendo en los campos nuevos.
  // Unificar esto es lo que permite que "Unidad de compra" y la vista previa
  // usen una sola lógica en vez de una copia para cada caso (que es como
  // terminaba desalineándose antes, entre "Agregar insumo" y "Registrar
  // compra" por separado).
  function currentUnitInfo() {
    if (isNewSelected()) {
      return {
        unit: nuevoUnidad.value.trim() || 'unidad',
        packName: nuevoEmpaqueNombre.value.trim(),
        packSize: Number(nuevoEmpaqueSize.value) || 0,
        transferPackName: '', transferPackSize: 0
      };
    }
    const s = currentSupply();
    return {
      unit: s ? s.unit : 'unidad',
      packName: s && s.pack_name ? s.pack_name : '',
      packSize: s && s.pack_size ? Number(s.pack_size) : 0,
      transferPackName: s && s.transfer_pack_name ? s.transfer_pack_name : '',
      transferPackSize: s && s.transfer_pack_size ? Number(s.transfer_pack_size) : 0
    };
  }

  function toggleNuevoFields() {
    nuevoFields.hidden = !isNewSelected();
    updateUnidadTipoOptions();
    updateVenceField();
  }

  // La fecha de vencimiento solo se pide si el insumo lo controla (o si se
  // está dando de alta uno nuevo con el control activado).
  const compraVenceWrap = document.getElementById('compra-vence-wrap');
  const compraNuevoVence = document.getElementById('compra-nuevo-vence');
  function updateVenceField() {
    const tracked = isNewSelected() ? compraNuevoVence.checked : !!(currentSupply() && currentSupply().track_expiry);
    compraVenceWrap.hidden = !tracked;
  }
  compraNuevoVence.addEventListener('change', updateVenceField);

  function updateUnidadTipoOptions() {
    const { unit, packName, packSize, transferPackName, transferPackSize } = currentUnitInfo();
    const opts = [`<option value="unit">${esc(unit)}</option>`];
    if (packName && packSize > 0) {
      // Si el nombre ya dice cuánto trae («libra (30 lonjas)»), no se repite.
      opts.push(`<option value="pack">${esc(packName)}${/\(/.test(packName) ? '' : ` (${fmtNum(packSize)} ${esc(unit)})`}</option>`);
    }
    // Empaque de reparto — un insumo comprado por caja también puede
    // comprarse ya contando por paquete si así llega la factura (ej. el
    // proveedor a veces vende sueltos por paquete, no siempre la caja
    // completa). Se ofrece como una opción MÁS, nunca reemplaza a la de compra.
    if (transferPackName && transferPackSize > 0) {
      opts.push(`<option value="transfer_pack">${esc(transferPackName)} (${fmtNum(transferPackSize)} ${esc(unit)})</option>`);
    }
    // Medidas fijas (libra, kilo, onza, galón…) cuando la unidad base es de peso o de volumen: así se
    // compra «10 libras» de un insumo que se cuenta en gramos sin tener que sacar la cuenta. Se salta la
    // que ya está como empaque con el mismo tamaño (ej. «libra» 453.6) para no repetirla.
    const repetida = f => [packSize, transferPackSize].some(t => t > 0 && Math.abs(t - f) / f < 0.01);
    Unidades.opciones(unit).filter(o => !repetida(o.factor))
      .forEach(o => opts.push(`<option value="conv:${o.clave}">${esc(o.etiqueta)}</option>`));
    // Aproximado de lo que no se pesa (ej. libra de queso ≈ 30 lonjas) si el insumo no tiene ya ese empaque.
    const g = sugerenciaCompra();
    if (g) opts.push(`<option value="aprox">${esc(g.empaque)} (≈ ${fmtNum(g.trae)} ${esc(Aproximados.plural(unit))}, aproximado)</option>`);
    compraUnidadTipo.innerHTML = opts.join('');
    updatePreview();
  }

  function sugerenciaCompra() {
    const { unit, packName, packSize } = currentUnitInfo();
    const nombre = isNewSelected() ? nuevoNombre.value : (currentSupply() || {}).name;
    const g = Aproximados.sugerir(nombre, unit);
    if (!g) return null;
    if (packSize > 0 && String(packName || '').toLowerCase().startsWith(g.empaque)) return null;   // ya lo tiene
    return g;
  }
  function tamanoEscogido() {
    const { packSize, transferPackSize, unit } = currentUnitInfo();
    const v = compraUnidadTipo.value;
    if (v === 'aprox') { const g = sugerenciaCompra(); return g ? g.trae : 1; }
    if (v === 'pack') return packSize;
    if (v === 'transfer_pack') return transferPackSize;
    if (v.startsWith('conv:')) return Unidades.factor(unit, v.slice(5)) || 1;
    return 1;
  }
  // Costo por unidad que quedaría con esta compra, y si se ve raro contra el de antes (más de 4 veces
  // más caro o más barato): casi siempre es la cantidad escrita en otra medida (libras en vez de gramos).
  function calculoCompra() {
    const { unit } = currentUnitInfo();
    const qty = Number(compraCantidad.value);
    const price = Number(compraPrecio.value);
    if (!qty || !price) return null;
    const size = tamanoEscogido();
    const totalUnits = size > 0 ? qty * size : qty;
    const nuevo = price / totalUnits;
    const s = isNewSelected() ? null : currentSupply();
    const antes = s ? Number(s.unit_cost) : 0;
    const raro = antes > 0 && (nuevo / antes > 4 || antes / nuevo > 4);
    return { unit, totalUnits, nuevo, antes, raro };
  }
  // v4: el resultado se ve como el resumen de la hoja de producto: lo que entra, el costo por unidad
  // (y por libra o galón si se cuenta en gramos u onzas) y cuánto cambió contra el de antes.
  function updatePreview() {
    const c = calculoCompra();
    if (!c) { compraPreview.innerHTML = ''; return; }
    const med = Unidades.deUnidad(c.unit);
    const grande = med ? (med.familia === 'peso' ? 'libra' : 'galon') : null;
    const fg = grande ? Unidades.factor(c.unit, grande) : null;
    const ayuda = fg && fg !== 1 ? `<span>${fmtCost(c.nuevo * fg)} ${grande === 'libra' ? 'la libra' : 'el galón'}</span>` : '';
    let cambio = '';
    if (c.antes > 0) {
      const pct = Math.round((c.nuevo - c.antes) / c.antes * 100);
      cambio = pct === 0 ? `<span>Igual que antes (${fmtCost(c.antes)})</span>`
        : `<span class="${pct > 0 ? 'pf-sube' : 'pf-baja'}">${pct > 0 ? '▲' : '▼'} ${Math.abs(pct)} % · antes ${fmtCost(c.antes)}</span>`;
    }
    compraPreview.innerHTML = `
      <div><small>Entra al inventario</small><b>${fmtNum(Unidades.redondear(c.totalUnits, 2))} ${esc(c.unit)}</b>${c.totalUnits && Unidades.ayuda(c.totalUnits, c.unit) ? `<span>${Unidades.ayuda(c.totalUnits, c.unit)}</span>` : ''}</div>
      <div><small>Costo por ${esc(c.unit)}</small><b>${fmtCost(c.nuevo)}</b>${ayuda}${cambio}</div>
      ${c.raro ? `<p class="pf-aviso">Es muy distinto al costo de antes. Revisa que «Viene en» tenga la medida correcta (por ejemplo «libra» y no «${esc(c.unit)}»).</p>` : ''}`;
  }

  compraInsumo.addEventListener('change', toggleNuevoFields);
  compraUnidadTipo.addEventListener('change', updatePreview);
  compraCantidad.addEventListener('input', updatePreview);
  compraPrecio.addEventListener('input', updatePreview);
  [nuevoNombre, nuevoUnidad, nuevoEmpaqueNombre, nuevoEmpaqueSize].forEach(el => {
    el.addEventListener('input', updateUnidadTipoOptions);
  });

  formCompra.addEventListener('submit', async e => {
    e.preventDefault();
    if (isNewSelected() && !nuevoNombre.value.trim()) {
      UI.toast('El insumo nuevo necesita un nombre', 'error');
      return;
    }
    if (isNewSelected() && !nuevoUnidad.value) { UI.toast('Escoge en qué se cuenta el insumo nuevo', 'error'); nuevoUnidad.focus(); return; }
    if (isNewSelected() && nuevoEmpaqueNombre.value.trim() && !(Number(nuevoEmpaqueSize.value) > 0)) { UI.toast('Di cuánto trae el empaque (ej. 24)', 'error'); nuevoEmpaqueSize.focus(); return; }
    // Sin esto, un doble toque mandaba la misma compra dos veces — duplica
    // el stock recibido de verdad y desvía el costo por unidad calculado,
    // no es solo un problema visual.
    const calc = calculoCompra();
    if (calc && calc.raro && !(await UI.confirmDialog(`El costo por ${calc.unit} pasaría de ${fmtCost(calc.antes)} a ${fmtCost(calc.nuevo)}. ¿Seguro que la cantidad y «Viene en» están bien?`))) return;
    const submitBtn = formCompra.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    try {
      let supplyId = compraInsumo.value;
      if (isNewSelected()) {
        const created = await Api.supplies.create({
          name: nuevoNombre.value.trim(),
          unit: nuevoUnidad.value || 'unidad',
          pack_name: nuevoEmpaqueNombre.value.trim() || null,
          pack_size: Number(nuevoEmpaqueSize.value) || null,
          track_expiry: compraNuevoVence.checked
        });
        supplyId = created.id;
      }
      const result = await Api.supplies.purchase(supplyId, {
        location_id: Number(compraUbicacion.value),
        // «aprox» no existe en el servidor: se manda ya convertido a la unidad base (ej. 2 libras ≈ 60 lonjas).
        quantity: compraUnidadTipo.value === 'aprox' ? Unidades.redondear(Number(compraCantidad.value) * tamanoEscogido(), 3) : Number(compraCantidad.value),
        quantity_unit: compraUnidadTipo.value === 'aprox' ? 'unit' : compraUnidadTipo.value,
        total_price: Number(compraPrecio.value),
        note: [compraUnidadTipo.value === 'aprox' ? `${compraCantidad.value} ${compraUnidadTipo.selectedOptions[0].textContent}` : '', document.getElementById('compra-nota').value].filter(Boolean).join(' — ') || null,
        expires_on: (!compraVenceWrap.hidden && document.getElementById('compra-vence').value) || null
      });
      UI.toast(`Compra registrada — costo por unidad: ${fmtCost(result.unit_cost)}`);
      formCompra.reset();
      updateVenceField();
      compraPreview.innerHTML = '';
      render();
    } catch (err) {
      UI.toast(err.message, 'error');
    } finally {
      submitBtn.disabled = false;
    }
  });

  searchInput.addEventListener('input', renderTable);

  // El catálogo (Insumos) y el formulario de compra (Entradas) comparten la
  // misma lista de insumos/ubicaciones, así que se cargan igual.
  document.getElementById('btn-insumo-nuevo').addEventListener('click', () => {
    window.showView('inv-entradas');
    compraInsumo.value = NEW;
    toggleNuevoFields();
    nuevoNombre.focus();
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'insumos' || e.detail.view === 'inv-entradas') render();
    if (e.detail.view === 'inv-existencias') loadExistencias();
  });
})();
