/* ═══ Carrusel del login: siempre 5 láminas ═══
   Presenta lo que hace el sistema con gráficos dibujados (sin capturas ni datos reales). Cada versión de
   novedades.json que traiga "carrusel": { titulo, texto, vis } entra de primera, marcada «Nuevo», y empuja a la
   lámina más vieja: las de BASE solo rellenan hasta llegar a 5. Se pausa con el mouse, el foco o el botón, y no
   gira solo si el equipo pide reducir el movimiento. */
(function () {
  'use strict';
  const caja = document.getElementById('l6-car');
  if (!caja) return;
  const TOTAL = 5, PASO = 6500;
  const BASE = [
    { vis: 'factura', titulo: 'Factura en segundos', texto: 'Vende, cobra y entrega el recibo sin enredos.' },
    { vis: 'inventario', titulo: 'Inventario al día', texto: 'Cada venta descuenta lo que usaste, con tus recetas.' },
    { vis: 'caja', titulo: 'Cierra la caja tranquilo', texto: 'Cuadra el turno y mira lo que entró por cada forma de pago.' },
    { vis: 'reportes', titulo: 'Tus números, claros', texto: 'Ventas y gastos explicados, para decidir con calma.' },
    { vis: 'mesas', titulo: 'Mesas, cocina y pedidos', texto: 'Todo el servicio en un solo lugar, sin papelitos.' }
  ];
  const linea = (w, c = '') => `<i class="c-l ${c}" style="width:${w}%"></i>`;
  const ok = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  const VIS = {
    factura: () => `<div class="c-card">${linea(46, 'f')}<div class="c-filas">${[72, 58, 66].map(w => `<div class="c-fila">${linea(w)}${linea(16)}</div>`).join('')}</div><div class="c-total">${linea(30, 'f')}${linea(26, 'a')}</div></div><b class="c-chip">${ok}Pagada</b>`,
    inventario: () => `<div class="c-card">${linea(40, 'f')}${[82, 54, 30].map((w, i) => `<div class="c-nivel">${linea(34 - i * 4)}<span class="c-barra"><u style="width:${w}%"></u></span></div>`).join('')}</div><b class="c-chip">${ok}Al día</b>`,
    caja: () => `<div class="c-card c-dona"><span class="c-anillo"></span><div class="c-ley">${[62, 48, 36].map((w, i) => `<div class="c-fila"><em class="p${i}"></em>${linea(w)}</div>`).join('')}</div></div><b class="c-chip">${ok}Cuadrada</b>`,
    reportes: () => `<div class="c-card">${linea(44, 'f')}<div class="c-barras">${[34, 52, 44, 68, 60, 90].map((h, i) => `<span class="${i === 5 ? 'a' : ''}" style="--h:${h}%;--i:${i}"></span>`).join('')}</div></div><b class="c-chip">${ok}Hoy</b>`,
    mesas: () => `<div class="c-card">${linea(38, 'f')}<div class="c-mesas">${[1, 0, 1, 1, 0, 1, 0, 1].map(o => `<span class="${o ? 'a' : ''}"></span>`).join('')}</div></div><b class="c-chip">${ok}En cocina</b>`,
    nuevo: () => `<div class="c-card c-nuevo"><span class="c-sol"><svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.2 6.8L21 11l-6.8 2.2L12 20l-2.2-6.8L3 11l6.8-2.2z"/></svg></span>${linea(62, 'f')}${linea(84)}${linea(70)}</div>`
  };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const pista = caja.querySelector('.l6-laminas'), puntos = caja.querySelector('.l6-puntos'), pausa = caja.querySelector('.l6-pausa');
  const quieto = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let actual = 0, reloj = null, enPausa = quieto, tocando = false;

  function pintar(laminas) {
    pista.innerHTML = laminas.map((l, i) => `<article class="l6-lam" role="group" aria-roledescription="lámina" aria-label="${i + 1} de ${laminas.length}">
      <div class="l6-vis" aria-hidden="true"><div class="c-esc">${(VIS[l.vis] || VIS.nuevo)()}</div></div>
      ${l.nuevo ? `<span class="l6-nuevo">Nuevo${l.version ? ' en ' + esc(l.version) : ''}</span>` : ''}
      <h2 class="l6-lam-t">${esc(l.titulo)}</h2><p class="l6-lam-x">${esc(l.texto)}</p></article>`).join('');
    puntos.innerHTML = laminas.map((_, i) => `<button type="button" class="l6-punto" aria-label="Ver lámina ${i + 1}"></button>`).join('');
    ir(0);
  }
  function ir(n) {
    const lam = pista.children, pts = puntos.children;
    actual = (n + lam.length) % lam.length;
    Array.from(lam).forEach((el, i) => { el.classList.toggle('activa', i === actual); el.setAttribute('aria-hidden', String(i !== actual)); });
    Array.from(pts).forEach((el, i) => { el.classList.toggle('activo', i === actual); if (i === actual) el.setAttribute('aria-current', 'true'); else el.removeAttribute('aria-current'); });
    programar();
  }
  function programar() {
    clearTimeout(reloj);
    const pantalla = document.getElementById('login-screen');
    if (enPausa || tocando || document.hidden || !pantalla || pantalla.hidden) return;
    reloj = setTimeout(() => ir(actual + 1), PASO);
  }
  function ponerPausa(si) {
    enPausa = si;
    pausa.setAttribute('aria-label', si ? 'Seguir presentación' : 'Pausar presentación');
    pausa.classList.toggle('en-pausa', si);
    programar();
  }
  puntos.addEventListener('click', e => { const b = e.target.closest('.l6-punto'); if (b) ir(Array.from(puntos.children).indexOf(b)); });
  pausa.addEventListener('click', () => ponerPausa(!enPausa));
  caja.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') { tocando = true; programar(); } });
  caja.addEventListener('pointerleave', () => { tocando = false; programar(); });
  caja.addEventListener('focusin', () => { tocando = true; programar(); });
  caja.addEventListener('focusout', () => { tocando = false; programar(); });
  document.addEventListener('visibilitychange', programar);
  new MutationObserver(programar).observe(document.getElementById('login-screen'), { attributes: true, attributeFilter: ['hidden'] });
  let x0 = null; // deslizar con el dedo
  pista.addEventListener('touchstart', e => { x0 = e.touches[0].clientX; }, { passive: true });
  pista.addEventListener('touchend', e => { if (x0 === null) return; const d = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(d) > 40) ir(actual + (d < 0 ? 1 : -1)); }, { passive: true });

  ponerPausa(enPausa);
  pintar(BASE);
  fetch('novedades.json', { cache: 'no-cache' }).then(r => r.ok ? r.json() : []).then(lista => {
    const nuevas = (Array.isArray(lista) ? lista : []).filter(n => n && n.carrusel && n.carrusel.titulo)
      .map(n => ({ vis: n.carrusel.vis || 'nuevo', titulo: n.carrusel.titulo, texto: n.carrusel.texto, version: n.version, nuevo: true }));
    if (nuevas.length) pintar(nuevas.concat(BASE).slice(0, TOTAL));
  }).catch(() => {});
})();
