/* ═══ Login v6 con el color del negocio (6-nov; antes «B», 13-oct) ═══
   Sin nombres de personas en pantalla: el código dice quién entra (como Toast o Shopify POS). Antes este login
   recordaba en cada equipo a quién había entrado y lo mostraba en círculos; eso se quitó y se borra lo guardado.
   Aquí: los textos de cada modo, el campo del PIN, el color del panel y el círculo de quien entra en la pantalla de
   carga. El formulario y la entrada siguen en auth.js. */
(function () {
  'use strict';
  const pantalla = document.getElementById('login-screen');
  if (!pantalla || typeof Auth === 'undefined') return;
  try { localStorage.removeItem('arche_personas_v1'); } catch (_) {}
  document.documentElement.classList.add('v4-login');
  const iniciales = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();

  // Pantalla de carga: el círculo de quien entra (solo lo ve esa persona, al entrar).
  const setOriginal = Auth.set;
  Auth.set = function (s) {
    try {
      const av = document.getElementById('v4-carga-av');
      if (av && s) {
        av.textContent = s.role === 'owner' ? '' : iniciales(s.employeeName || '');
        av.classList.toggle('es-dueno', s.role === 'owner');
        document.getElementById('access-loading').classList.add('v4-con-av');
      }
    } catch (_) {}
    return setOriginal.apply(this, arguments);
  };

  const pinpad = document.getElementById('login-pinpad');
  const tit = document.getElementById('ln-t-tit'), sub = document.getElementById('ln-t-sub');
  const dueno = document.getElementById('ln-dueno'), olvido = document.getElementById('ln-olvido');
  const neg = document.getElementById('brand-name-login');
  const cred = document.getElementById('login-credential'), pinIn = document.getElementById('login-pin-input');
  const puntos = document.getElementById('login-pin-dots'), entrar = document.getElementById('login-submit');
  const enPin = () => !pinpad.hidden;
  const modo = m => { const b = document.querySelector(`#login-mode [data-mode="${m}"]`); if (b && b.getAttribute('aria-checked') !== 'true') b.click(); };
  const negocio = () => { const n = neg ? neg.textContent.trim() : ''; return n && n !== 'Mi negocio' ? ' a ' + n : ''; };
  function textos() {
    const pin = enPin();
    tit.textContent = 'Hola de nuevo';
    sub.textContent = `Entra${negocio()} con tu ${pin ? 'PIN' : 'contraseña'}.`;
    dueno.textContent = pin ? 'Usar contraseña' : 'Usar PIN';
    olvido.hidden = pin; // la recuperación es por el correo del dueño: al empleado con PIN no le sirve
  }
  dueno.addEventListener('click', () => {
    modo(enPin() ? 'keyboard' : 'pin');
    if (!enPin()) setTimeout(() => cred.focus(), 40);
  });
  olvido.addEventListener('click', () => document.getElementById('login-forgot-link').click());
  new MutationObserver(textos).observe(pinpad, { attributes: true, attributeFilter: ['hidden'] });
  // Mientras se recupera la contraseña, los enlaces y las redes sobran.
  const forgot = document.getElementById('forgot-form');
  if (forgot) new MutationObserver(() => {
    pantalla.classList.toggle('ln-recuperando', !forgot.hidden);
    if (!forgot.hidden) { tit.textContent = 'Recuperar la contraseña'; sub.textContent = 'Te mandamos un código al correo del dueño.'; } else textos();
  }).observe(forgot, { attributes: true, attributeFilter: ['hidden'] });
  if (neg) new MutationObserver(textos).observe(neg, { childList: true, characterData: true, subtree: true });
  textos();

  // El campo del PIN: abre el teclado numérico del celular y pasa cada dígito al teclado de auth.js (oculto), que
  // entra solo al cuarto. En la PC también se escribe sin tocarlo (auth.js escucha el teclado).
  const tecla = d => pinpad.querySelector(d === null ? '#login-pin-backspace' : `[data-digit="${d}"]`).click();
  pinIn.addEventListener('input', () => {
    const v = pinIn.value.replace(/\D/g, '').slice(0, 4), antes = cred.value;
    if (v.length < antes.length) for (let i = antes.length; i > v.length; i--) tecla(null);
    else for (const d of v.slice(antes.length)) tecla(d);
    pinIn.value = cred.value;
  });
  new MutationObserver(() => { pinIn.value = cred.value; }).observe(puntos, { attributes: true, subtree: true, attributeFilter: ['class'] });
  // Con menos de 4 no se gasta un intento: se vuelve al campo.
  entrar.addEventListener('click', e => { if (enPin() && cred.value.length < 4) { e.preventDefault(); pinIn.focus(); } });

  // Celular: con el teclado abierto la A se guarda para que «Entrar» quede a la vista.
  const angosto = window.matchMedia('(max-width: 860px)');
  [pinIn, cred].forEach(el => {
    el.addEventListener('focus', () => pantalla.classList.toggle('l6-teclado', angosto.matches));
    el.addEventListener('blur', () => pantalla.classList.remove('l6-teclado'));
  });

  // Con logo del negocio (Configuración → Marca), el logo va en el lugar de la A; sin logo queda la A de Arche.
  const logo = document.getElementById('l6-logo');
  window.addEventListener('arche:marca', e => {
    const url = e.detail && e.detail.logo;
    logo.hidden = !url; pantalla.classList.toggle('l6-con-logo', !!url);
    const img = logo.querySelector('img');
    if (url) { img.src = url; img.alt = neg ? neg.textContent.trim() : ''; } else img.removeAttribute('src');
  });

  // El panel toma el acento, la tinta y el papel del negocio (Configuración → Marca).
  function colores(p) {
    if (!p) return;
    pantalla.style.setProperty('--l6-a', p.accent); pantalla.style.setProperty('--l6-k', p.ink); pantalla.style.setProperty('--l6-p', p.paper);
  }
  colores(window.Brand && Brand.normalize(Brand.saved() || Brand.DEFAULT));
  window.addEventListener('brand:applied', e => colores(e.detail));
})();

/* Facturación: subtítulo del título «Vender» con el punto de venta y la persona (en el celular). */
(function () {
  const h = document.getElementById('pos-venta-titulo'); if (!h) return;
  const poner = () => { try { const s = Auth.get(); if (s && s.role === 'cart') h.dataset.sub = [s.locationName, (s.employeeName || '').split(' ')[0]].filter(Boolean).join(' · '); } catch (_) {} };
  poner(); window.addEventListener('view:show', poner);
})();
