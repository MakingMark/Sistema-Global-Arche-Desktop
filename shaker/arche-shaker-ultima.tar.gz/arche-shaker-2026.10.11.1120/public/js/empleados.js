/* ═══ Empleados: quién trabaja en cada punto de venta/almacén ═══ */
(function () {
  'use strict';
  const form = document.getElementById('form-empleado');
  if (!form) return;

  const errorEl = document.getElementById('empleado-error');
  const tbody = document.querySelector('#tabla-empleados tbody');
  const locationSelect = document.getElementById('empleado-location-select');

  let employees = [];
  let locations = [];

  async function load() {
    [employees, locations] = await Promise.all([Api.employees.list(), Api.locations.list()]);
    locationSelect.innerHTML = locations.map(l =>
      `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`
    ).join('');
    render();
  }

  function render() {
    if (!employees.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="muted">Todavía no hay ningún empleado creado.</td></tr>';
      return;
    }
    tbody.innerHTML = employees.map(e => `
      <tr class="${e.active ? '' : 'row-inactive'}" data-id="${e.id}">
        <td>${UI.escapeHtml(e.name)}</td>
        <td data-th="Asignado a">
          <select class="reasignar-select">
            ${locations.map(l => `<option value="${l.id}" ${l.id === e.location_id ? 'selected' : ''}>${UI.escapeHtml(l.name)}</option>`).join('')}
          </select>
        </td>
        <td data-th="Rol"><select class="rol-select">${[['cajero', 'Cajero'], ['gerente', 'Gerente'], ['cocina', 'Cocina']].map(([v, t]) => `<option value="${v}" ${e.role === v ? 'selected' : ''}>${t}</option>`).join('')}</select></td>
        <td data-th="PIN">${UI.escapeHtml(e.pin)}</td>
        <td data-th="Estado">${e.active ? '<span class="badge badge-sage">Activo</span>' : '<span class="badge badge-voided">Desactivado</span>'}</td>
        <td data-th="Acciones">
          <button class="btn btn-sm" data-action="pin">Cambiar PIN</button>
          <button class="btn btn-sm" data-action="toggle">${e.active ? 'Desactivar' : 'Reactivar'}</button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.reasignar-select').forEach(sel => {
      sel.addEventListener('change', async () => {
        const id = sel.closest('[data-id]').dataset.id;
        try {
          await Api.employees.update(id, { location_id: Number(sel.value) });
          UI.toast('Empleado reasignado');
          load();
        } catch (err) {
          UI.toast(err.message, 'error');
          load();
        }
      });
    });

    tbody.querySelectorAll('.rol-select').forEach(sel => {
      sel.addEventListener('change', async () => {
        try { await Api.employees.update(sel.closest('[data-id]').dataset.id, { role: sel.value }); UI.toast('Rol actualizado'); load(); }
        catch (err) { UI.toast(err.message, 'error'); load(); }
      });
    });

    tbody.querySelectorAll('[data-action="pin"]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.closest('[data-id]').dataset.id;
        const pin = await UI.promptDialog('Nuevo PIN (4 dígitos) para este empleado:', 'ej. 4821');
        if (pin === null) return;
        try {
          await Api.employees.update(id, { pin });
          UI.toast('PIN actualizado');
          load();
        } catch (err) {
          UI.toast(err.message, 'error');
        }
      });
    });

    tbody.querySelectorAll('[data-action="toggle"]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const row = btn.closest('[data-id]');
        const id = row.dataset.id;
        const emp = employees.find(x => String(x.id) === id);
        if (emp.active) {
          const ok = await UI.confirmDialog(`¿Desactivar a ${UI.escapeHtml(emp.name)}? Ya no va a poder entrar con su PIN, pero su historial de ventas/solicitudes/transferencias queda intacto. Puedes reactivarlo cuando quieras.`);
          if (!ok) return;
        }
        try {
          await Api.employees.update(id, { active: !emp.active });
          UI.toast(emp.active ? 'Empleado desactivado' : 'Empleado reactivado');
          load();
        } catch (err) {
          UI.toast(err.message, 'error');
        }
      });
    });
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    errorEl.hidden = true;
    const fd = new FormData(form);
    try {
      await Api.employees.create({
        name: fd.get('name'),
        pin: fd.get('pin'),
        location_id: Number(fd.get('location_id')),
        role: fd.get('role')
      });
      form.reset();
      load();
      UI.toast('Empleado creado');
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
    }
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'empleados') load();
  });
})();
