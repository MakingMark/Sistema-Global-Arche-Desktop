/* ═══ Facturación — cliente HTTP + sesión ═══ */

const Auth = (function () {
  'use strict';
  const KEY = 'shaker_session';

  function get() {
    try { return JSON.parse(localStorage.getItem(KEY)); } catch (_) { return null; }
  }
  function set(session) { localStorage.setItem(KEY, JSON.stringify(session)); }
  function clear() { localStorage.removeItem(KEY); }

  function headers() {
    const s = get();
    if (!s) return {};
    if (s.role === 'owner') return { 'Authorization': 'Bearer ' + s.token };
    // El PIN es del EMPLEADO, no de la ubicación.
    if (s.role === 'cart') return { 'X-Employee-Id': String(s.employeeId), 'X-Employee-Pin': s.pin };
    return {};
  }

  return { get, set, clear, headers };
})();

const Api = (function () {
  'use strict';

  async function request(method, path, body) {
    const res = await fetch('/api' + path, {
      method,
      headers: Object.assign(
        { 'Content-Type': 'application/json' },
        Auth.headers()
      ),
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
    if (!res.ok) {
      let message = res.statusText, data = null;
      try { data = await res.json(); message = data.error || message; } catch (_) {}
      // Un 401 en medio del uso normal (no en el propio login) significa que
      // el token venció (30 días) o que la contraseña cambió desde otro
      // dispositivo — antes esto no podía pasar (la contraseña se revalidaba
      // completa en cada request), así que no había ningún manejo para ello:
      // cada pantalla mostraba su propio toast de error sin sacar a nadie de
      // una sesión que ya no es válida. Server de vuelta a la pantalla de
      // login en vez de dejar la app en un estado a medias. Mismo trato para
      // un carrito (antes solo cubría 'owner'): un PIN desactivado o
      // cambiado desde Ubicaciones mientras el carrito seguía "logueado"
      // dejaba cada pantalla mostrando su propio error suelto para siempre,
      // sin nunca mandarlo de vuelta al login para que entre con el PIN
      // correcto.
      // Arche Escritorio: sin licencia válida el servidor responde 402 a todo;
      // se va a la pantalla de licencia.
      if (res.status === 402 && data && data.licencia) { location.href = '/licencia.html'; }
      const session = Auth.get();
      const isLoginPath = path === '/auth/resolve';
      if (res.status === 401 && session && (session.role === 'owner' || session.role === 'cart') && !isLoginPath) {
        Auth.clear();
        location.reload();
      }
      const err = new Error(message);
      err.status = res.status;
      err.data = data;   // el cuerpo del error (ej. can_force en pedidos web)
      throw err;
    }
    if (res.status === 204) return null;
    return res.json();
  }

  return {
    auth: {
      resolve: credential => request('POST', '/auth/resolve', { credential }),
      changePassword: (current_password, new_password) => request('PUT', '/auth/password', { current_password, new_password }),
      account: () => request('GET', '/auth/account'),
      setEmail: (email, current_password) => request('PUT', '/auth/email', { email, current_password }),
      forgot: email => request('POST', '/auth/forgot', { email }),
      reset: (email, code, new_password) => request('POST', '/auth/reset', { email, code, new_password })
    },
    auditLog: {
      list: (entity_type, entity_id) => request('GET', `/audit-log?entity_type=${entity_type}` + (entity_id ? `&entity_id=${entity_id}` : ''))
    },
    setup: {
      status: () => request('GET', '/setup/status'),
      initDatabase: () => request('POST', '/setup/init-database'),
      complete: data => request('POST', '/setup/complete', data),
      restore: backup => request('POST', '/setup/restore', backup)
    },
    whatsapp: {
      status: () => request('GET', '/whatsapp/status'),
      pair: phone_number => request('POST', '/whatsapp/pair', { phone_number }),
      unlink: () => request('POST', '/whatsapp/unlink'),
      test: () => request('POST', '/whatsapp/test')
    },
    settings: {
      // Se guarda la última respuesta buena: sin señal, el punto de venta
      // igual sabe el nombre del negocio y si cobra ITBIS/propina (lo
      // necesita para armar el recibo local de una venta sin conexión).
      get: async () => {
        try {
          const data = await request('GET', '/settings');
          OfflineDb.cacheSet('settings', data);
          return data;
        } catch (err) {
          if (err.status !== undefined) throw err;
          const cached = await OfflineDb.cacheGet('settings');
          if (cached) return cached;
          throw err;
        }
      },
      update: data => request('PUT', '/settings', data),
      modules: () => request('GET', '/settings/modules'),
      saveModules: modules => request('PUT', '/settings/modules', { modules }),
      updateBusiness: data => request('PUT', '/settings', data),
      updateBrand: data => request('PUT', '/settings/brand', data),
      webContent: () => request('GET', '/settings/web-content'),
      updateWebContent: data => request('PUT', '/settings/web-content', data),
      web: () => request('GET', '/settings/web'),
      updateWeb: data => request('PUT', '/settings/web', data),
      removeLogo: () => request('DELETE', '/settings/logo')
    },
    backup: {
      status: () => request('GET', '/backup/status'),
      offsite: () => request('POST', '/backup/offsite'),
      // No usa request() de arriba porque la respuesta no es JSON — es el
      // archivo entero para descargar. Dispara la descarga acá mismo (mismo
      // truco que ya usan los "Exportar CSV" del resto de la app: un <a>
      // temporal con un blob), en vez de devolver el blob para que cada
      // pantalla lo maneje por separado.
      download: async () => {
        const res = await fetch('/api/backup/export', { headers: Auth.headers() });
        if (!res.ok) {
          let message = res.statusText;
          try { message = (await res.json()).error || message; } catch (_) {}
          throw Object.assign(new Error(message), { status: res.status });
        }
        const blob = await res.blob();
        const disposition = res.headers.get('Content-Disposition') || '';
        const match = disposition.match(/filename="([^"]+)"/);
        const filename = match ? match[1] : `respaldo-${new Date().toISOString().slice(0, 10)}.json`;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      },
      // El archivo ya viene leído como texto (FileReader, ver appSettings.js)
      // — JSON.parse puede tirar si el archivo no es JSON válido, a
      // propósito no se atrapa acá (el que llama decide cómo mostrarlo).
      restore: fileText => request('POST', '/backup/restore', JSON.parse(fileText))
    },
    unidades: {
      list: () => request('GET', '/unidades'),
      create: nombre => request('POST', '/unidades', { nombre }),
      remove: id => request('DELETE', `/unidades/${id}`)
    },
    supplies: {
      list: () => request('GET', '/supplies'),
      create: data => request('POST', '/supplies', data),
      update: (id, data) => request('PUT', `/supplies/${id}`, data),
      remove: id => request('DELETE', `/supplies/${id}`),
      adjustStock: (id, data) => request('POST', `/supplies/${id}/stock/adjust`, data),
      purchase: (id, data) => request('POST', `/supplies/${id}/purchase`, data),
      conteo: data => request('POST', '/supplies/conteo', data),
      waste: (id, data) => request('POST', `/supplies/${id}/waste`, data),
      setPreparation: (id, recipe) => request('PUT', `/supplies/${id}/preparation`, recipe || {}),
      produce: (id, data) => request('POST', `/supplies/${id}/produce`, data),
      setThreshold: (id, locationId, threshold) =>
        request('PUT', `/supplies/${id}/stock/${locationId}/threshold`, { low_stock_threshold: threshold })
    },
    // Menú: categorías (dos niveles), grupos de opciones y sus opciones.
    menu: {
      categories: () => request('GET', '/menu/categories'),
      createCategory: data => request('POST', '/menu/categories', data),
      updateCategory: (id, data) => request('PUT', `/menu/categories/${id}`, data),
      removeCategory: id => request('DELETE', `/menu/categories/${id}`),
      groups: () => request('GET', '/menu/modifier-groups'),
      createGroup: data => request('POST', '/menu/modifier-groups', data),
      updateGroup: (id, data) => request('PUT', `/menu/modifier-groups/${id}`, data),
      removeGroup: id => request('DELETE', `/menu/modifier-groups/${id}`),
      createOption: (groupId, data) => request('POST', `/menu/modifier-groups/${groupId}/options`, data),
      updateOption: (id, data) => request('PUT', `/menu/modifier-options/${id}`, data),
      removeOption: id => request('DELETE', `/menu/modifier-options/${id}`),
      schedules: () => request('GET', '/menu/schedules'),
      createSchedule: data => request('POST', '/menu/schedules', data),
      updateSchedule: (id, data) => request('PUT', `/menu/schedules/${id}`, data),
      removeSchedule: id => request('DELETE', `/menu/schedules/${id}`)
    },
    webOrders: {
      list: params => request('GET', '/web-orders' + (params ? '?' + new URLSearchParams(params) : '')),
      stats: params => request('GET', '/web-orders/stats' + (params ? '?' + new URLSearchParams(params) : ''))
    },
    media: {
      list: () => request('GET', '/media'),
      upload: data => request('POST', '/media', data),
      remove: id => request('DELETE', `/media/${id}`)
    },
    products: {
      list: () => request('GET', '/products'),
      create: data => request('POST', '/products', data),
      // Reventa (agua, refresco): crea el insumo y el producto 1 a 1 de una vez.
      resale: data => request('POST', '/products/resale', data),
      update: (id, data) => request('PUT', `/products/${id}`, data),
      webFlags: (id, data) => request('PUT', `/products/${id}/web`, data),
      remove: id => request('DELETE', `/products/${id}`)
    },
    sales: {
      list: params => request('GET', '/sales' + (params ? '?' + new URLSearchParams(params) : '')),
      get: id => request('GET', `/sales/${id}`),
      void: (id, reason) => request('POST', `/sales/${id}/void`, { reason }),
      returnItems: (id, data) => request('POST', `/sales/${id}/return`, data)
    },
    reports: {
      summary: params => request('GET', '/reports/summary' + (params ? '?' + new URLSearchParams(params) : '')),
      setupProgress: () => request('GET', '/reports/setup-progress'),
      byProduct: params => request('GET', '/reports/by-product' + (params ? '?' + new URLSearchParams(params) : '')),
      lowStock: scope => request('GET', '/reports/low-stock' + (scope ? `?scope=${scope}` : '')),
      stockOverview: () => request('GET', '/reports/stock-overview'),
      trends: params => request('GET', '/reports/trends?' + new URLSearchParams(params)),
      movements: params => request('GET', '/reports/movements' + (params ? '?' + new URLSearchParams(params) : '')),
      inventoryChecks: params => request('GET', '/reports/inventory-checks' + (params ? '?' + new URLSearchParams(params) : '')),
      supplyYield: () => request('GET', '/reports/supply-yield'),
      supplyYieldDetail: (locationId, supplyId) => request('GET', `/reports/supply-yield/detail?location_id=${locationId}&supply_id=${supplyId}`),
      analytics: params => request('GET', '/reports/analytics' + (params ? '?' + new URLSearchParams(params) : '')),
      waste: params => request('GET', '/reports/waste' + (params ? '?' + new URLSearchParams(params) : '')),
      profit: params => request('GET', '/reports/profit' + (params ? '?' + new URLSearchParams(params) : '')),
      cash: params => request('GET', '/reports/cash' + (params ? '?' + new URLSearchParams(params) : '')),
      production: params => request('GET', '/reports/production' + (params ? '?' + new URLSearchParams(params) : '')),
      expiry: params => request('GET', '/reports/expiry' + (params ? '?' + new URLSearchParams(params) : '')),
      suggestions: () => request('GET', '/reports/suggestions'),
      hoy: params => request('GET', '/reports/hoy' + (params && Object.keys(params).length ? '?' + new URLSearchParams(params) : ''))
    },
    locations: {
      list: () => request('GET', '/locations'),
      create: data => request('POST', '/locations', data),
      update: (id, data) => request('PUT', `/locations/${id}`, data),
      stock: id => request('GET', `/locations/${id}/stock`),
      movements: id => request('GET', `/locations/${id}/movements`),
      unirEstado: () => request('GET', '/locations/unir'),
      unir: () => request('POST', '/locations/unir')
    },
    employees: {
      list: () => request('GET', '/employees'),
      create: data => request('POST', '/employees', data),
      update: (id, data) => request('PUT', `/employees/${id}`, data),
      shifts: params => request('GET', '/employees/shifts' + (params ? '?' + new URLSearchParams(params) : ''))
    },
    // Turnos (llegada/salida) — compartido por carrito y almacén, ver
    // routes/shift.js. Se llama en cada login/desbloqueo; es idempotente.
    shift: {
      resume: () => request('POST', '/shift/resume'),
      report: (shiftId, reportedEndedAt) => request('POST', '/shift/report', { shift_id: shiftId, reported_ended_at: reportedEndedAt }),
      end: () => request('POST', '/shift/end')
    },
    transfers: {
      list: params => request('GET', '/transfers' + (params ? '?' + new URLSearchParams(params) : '')),
      create: data => request('POST', '/transfers', data),
      cancel: (id, reason) => request('POST', `/transfers/${id}/cancel`, { reason })
    },
    pos: {
      // menu/stock: se cachean en cada éxito y, si falla por RED (no por un
      // error real del servidor — ver el chequeo de err.status), se sirve la
      // última foto conocida — es lo que le permite a "Nueva venta" seguir
      // mostrando el menú (con sus opciones y recetas) y el stock aunque no
      // haya señal en absoluto, ni siquiera para abrir la pantalla por
      // primera vez tras un corte.
      menu: async () => {
        try {
          const data = await request('GET', '/pos/menu');
          OfflineDb.cacheSet('pos_menu', data);
          return data;
        } catch (err) {
          if (err.status !== undefined) throw err;
          const cached = await OfflineDb.cacheGet('pos_menu');
          if (cached) return cached;
          throw err;
        }
      },
      stock: async () => {
        try {
          const data = await request('GET', '/pos/stock');
          OfflineDb.cacheSet('pos_stock', data);
          return data;
        } catch (err) {
          if (err.status !== undefined) throw err;
          const cached = await OfflineDb.cacheGet('pos_stock');
          if (cached) return cached;
          throw err;
        }
      },
      // client_id viaja SIEMPRE (online y offline) — es lo que permite que un
      // reintento (offline que recién sincroniza, o un doble toque con mala
      // señal) nunca cree una segunda venta real. Ver salesService.js.
      createSale: async data => {
        const client_id = (crypto.randomUUID ? crypto.randomUUID() : 'cid-' + Date.now() + '-' + Math.random().toString(36).slice(2));
        const payload = Object.assign({}, data, { client_id });
        try {
          return await request('POST', '/pos/sales', payload);
        } catch (err) {
          // err.status definido = el SERVIDOR respondió y rechazó la venta
          // (ej. stock insuficiente, falta elegir una opción obligatoria) — es un rechazo real,
          // no un problema de conexión, así que no se debe encolar: el
          // vendedor tiene que verlo y corregirlo ya mismo, igual que siempre.
          if (err.status !== undefined) throw err;
          return await OfflineSync.queueSale(payload);
        }
      },
      sales: params => request('GET', '/pos/sales' + (params ? '?' + new URLSearchParams(params) : '')),
      saleDetail: id => request('GET', `/pos/sales/${id}`),
      voidSale: (id, reason) => request('POST', `/pos/sales/${id}/void`, { reason }),
      returnItems: (id, data) => request('POST', `/pos/sales/${id}/return`, data),
      customerPayment: (id, data) => request('POST', `/pos/customers/${id}/payments`, data),
      lookupCustomer: phone => request('GET', `/pos/customers/lookup?phone=${encodeURIComponent(phone)}`),
      restockRequests: () => request('GET', '/pos/restock-requests'),
      requestRestock: (items, note) => request('POST', '/pos/restock-requests', { items, note }),
      cancelRestockRequest: id => request('POST', `/pos/restock-requests/${id}/cancel`),
      // Mismo motivo que products/stock arriba: si se pide sin conexión (ej.
      // se reabrió "Nueva venta" ya sin señal), el recibo local de una oferta
      // (ver offlineSync.js buildLocalReceipt) necesita saber su precio de
      // combo — sin la foto cacheada, la mostraría al precio normal.
      offers: async () => {
        try {
          const data = await request('GET', '/pos/offers');
          OfflineDb.cacheSet('pos_offers', data);
          return data;
        } catch (err) {
          if (err.status !== undefined) throw err;
          const cached = await OfflineDb.cacheGet('pos_offers');
          if (cached) return cached;
          return [];
        }
      },
      // Confirmar un envío necesita conexión de verdad (es el momento en que
      // el stock del carrito se pone al día contra lo que llegó de verdad) —
      // a propósito sin caché/cola offline, a diferencia de products/stock.
      pendingTransfers: () => request('GET', '/pos/transfers/pending'),
      confirmTransfer: (id, data) => request('POST', `/pos/transfers/${id}/confirm`, data),
      // Mesas, comandas y cocina: necesitan el servidor (el mismo que mueve todo
      // el negocio — en un local con red propia, el servidor está DENTRO del
      // local y esto funciona aunque no haya internet).
      webOrders: status => request('GET', '/pos/web-orders' + (status ? `?status=${status}` : '')),
      webOrdersCount: () => request('GET', '/pos/web-orders/count'),
      acceptWebOrder: (id, force) => request('POST', `/pos/web-orders/${id}/accept`, force ? { force: true } : {}),
      confirmOrderPayment: id => request('POST', `/pos/orders/${id}/payment`, {}),
      dispatchOrder: id => request('POST', `/pos/orders/${id}/dispatch`, {}),
      requestBill: (id, requested) => request('POST', `/pos/orders/${id}/bill`, { requested }),
      rejectWebOrder: (id, reason) => request('POST', `/pos/web-orders/${id}/reject`, { reason }),
      waste: data => request('POST', '/pos/waste', data),
      preparations: () => request('GET', '/pos/preparations'),
      produce: data => request('POST', '/pos/produce', data),
      cash: () => request('GET', '/pos/cash'),
      openCash: opening_amount => request('POST', '/pos/cash/open', { opening_amount }),
      cashMovement: data => request('POST', '/pos/cash/movement', data),
      closeCash: data => request('POST', '/pos/cash/close', data),
      wasteToday: () => request('GET', '/pos/waste'),
      expiry: () => request('GET', '/pos/expiry'),
      tables: () => request('GET', '/pos/tables'),
      openOrder: data => request('POST', '/pos/orders', data),
      order: id => request('GET', `/pos/orders/${id}`),
      updateOrder: (id, data) => request('PUT', `/pos/orders/${id}`, data),
      addOrderItems: (id, items) => request('POST', `/pos/orders/${id}/items`, { items }),
      updateOrderItem: (id, itemId, data) => request('PUT', `/pos/orders/${id}/items/${itemId}`, data),
      removeOrderItem: (id, itemId, reason) => request('DELETE', `/pos/orders/${id}/items/${itemId}`, { reason }),
      sendOrder: id => request('POST', `/pos/orders/${id}/send`),
      setItemStatus: (itemId, status) => request('PUT', `/pos/order-items/${itemId}/status`, { status }),
      setRoundStatus: (id, round, status) => request('PUT', `/pos/orders/${id}/round-status`, { round, status }),
      kitchen: () => request('GET', '/pos/kitchen'),
      payOrder: (id, data) => request('POST', `/pos/orders/${id}/pay`, data),
      cancelOrder: (id, reason) => request('POST', `/pos/orders/${id}/cancel`, { reason }),
      inventoryCheckRequirement: () => request('GET', '/pos/inventory-check/requirement'),
      submitInventoryCheck: data => request('POST', '/pos/inventory-check', data)
    },
    expenses: {
      list: params => request('GET', '/expenses' + (params ? '?' + new URLSearchParams(params) : '')),
      create: data => request('POST', '/expenses', data),
      update: (id, data) => request('PUT', `/expenses/${id}`, data),
      remove: id => request('DELETE', `/expenses/${id}`)
    },
    tables: {
      list: locationId => request('GET', '/tables' + (locationId ? `?location_id=${locationId}` : '')),
      create: data => request('POST', '/tables', data),
      update: (id, data) => request('PUT', `/tables/${id}`, data),
      remove: id => request('DELETE', `/tables/${id}`)
    },
    offers: {
      list: () => request('GET', '/offers'),
      create: data => request('POST', '/offers', data),
      update: (id, data) => request('PUT', `/offers/${id}`, data),
      webStatus: () => request('GET', '/offers/web-status'),
      setLocations: (id, location_ids) => request('PUT', `/offers/${id}/locations`, { location_ids }),
      remove: id => request('DELETE', `/offers/${id}`)
    },
    customers: {
      lookup: phone => request('GET', `/customers/lookup?phone=${encodeURIComponent(phone)}`),
      list: () => request('GET', '/customers'),
      update: (id, name, credit_limit) => request('PUT', `/customers/${id}`, credit_limit === undefined ? { name } : { name, credit_limit }),
      statement: id => request('GET', `/customers/${id}/statement`),
      ficha: id => request('GET', `/customers/${id}/ficha`),
      payment: (id, data) => request('POST', `/customers/${id}/payments`, data)
    },
    vendors: {
      list: () => request('GET', '/vendors'),
      create: data => request('POST', '/vendors', data),
      update: (id, data) => request('PUT', `/vendors/${id}`, data),
      setSupplyVendor: (supplyId, vendor_id) => request('PUT', `/supplies/${supplyId}/vendor`, { vendor_id })
    },
    restockRequests: {
      list: status => request('GET', '/restock-requests' + (status ? `?status=${status}` : '')),
      approve: (id, data) => request('POST', `/restock-requests/${id}/approve`, data),
      reject: (id, reason) => request('POST', `/restock-requests/${id}/reject`, { reason })
    },
    purchaseOrders: {
      list: status => request('GET', '/purchase-orders' + (status ? `?status=${status}` : '')),
      get: id => request('GET', `/purchase-orders/${id}`),
      suggest: vendorId => request('GET', '/purchase-orders/suggest' + (vendorId ? `?vendor_id=${vendorId}` : '')),
      save: (id, data) => (id ? request('PUT', `/purchase-orders/${id}`, data) : request('POST', '/purchase-orders', data)),
      send: id => request('POST', `/purchase-orders/${id}/send`),
      cancel: id => request('POST', `/purchase-orders/${id}/cancel`),
      receive: (id, data) => request('POST', `/purchase-orders/${id}/receive`, data || {})
    }
  };
})();

// Moneda y medios de pago del negocio (Configuración → Tipo de negocio). Se guardan en el navegador para
// que las pantallas y el modo sin conexión formateen igual antes de que llegue la configuración.
window.AppLocale = (function () {
  const K = 'app_locale_v1';
  let st = { currency: 'RD$', payments: ['Efectivo', 'Transferencia', 'Tarjeta'], activity: 'restaurante' };
  try { Object.assign(st, JSON.parse(localStorage.getItem(K) || '{}')); } catch (_) {}
  return {
    currency: () => st.currency,
    // «Fiado» aparece solo si el negocio activó el crédito a clientes.
    payments: () => (window.Modules && Modules.enabled('fiado') && !st.payments.some(p => /^fiado$/i.test(p)) ? [...st.payments, 'Fiado'] : st.payments),
    activity: () => st.activity,
    set(s) {
      if (!s) return;
      if (s.currency_symbol) st.currency = s.currency_symbol;
      if (Array.isArray(s.payment_methods) && s.payment_methods.length) st.payments = s.payment_methods;
      if (s.activity) st.activity = s.activity;
      try { localStorage.setItem(K, JSON.stringify(st)); } catch (_) {}
      window.dispatchEvent(new CustomEvent('locale:changed', { detail: { ...st } }));
    }
  };
})();
const fmt = n => AppLocale.currency() + Math.round(Number(n) || 0).toLocaleString('es-DO');

// Igual que fmt, pero con centavos — para un costo por unidad (RD$0.39),
// donde redondear a peso entero lo esconde como "RD$0" (parece gratis).
// Antes copiado a mano en varias pantallas — unificado acá.
// Costo por unidad de un insumo: hasta 4 decimales (un gramo de algo puede
// costar RD$0.0345 — redondearlo a centavos falsea el costo de cada plato).
const fmtCost = n => AppLocale.currency() + Number(n || 0).toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 4 });

const fmtDec = n => AppLocale.currency() + Number(n || 0).toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Cantidades (no dinero): quita ceros decimales sobrantes — 453.600 -> "453,6",
// 1.000 -> "1" — para que las tablas no se llenen de decimales falsos.
// Cantidades para LEER: sin decimales de sobra (907.184 se lee como «novecientos mil»; mejor 907). Lo chico conserva sus decimales.
const fmtNum = n => { n = Number(n); const a = Math.abs(n); return n.toLocaleString('es-DO', { maximumFractionDigits: a >= 100 ? 0 : a >= 10 ? 1 : a >= 1 ? 2 : 3 }); };

// Fecha corta: solo hora si es de hoy, si no día/mes + hora — el detalle completo
// sigue disponible al abrir "Ver" en cada venta.
function fmtDate(iso) {
  const d = new Date(iso);
  const now = new Date();
  const time = d.toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit' });
  if (d.toDateString() === now.toDateString()) return time;
  return d.toLocaleDateString('es-DO', { day: 'numeric', month: 'short' }) + ' · ' + time;
}

// Componentes LOCALES de la fecha — nunca .toISOString().slice(0,10), que da
// la fecha en UTC y se adelanta un día entero entre las 8pm y la medianoche
// en Santo Domingo (UTC-4). Antes copiado a mano en pos.js/historial.js/
// historialInventario.js/turnos.js — unificado acá en la auditoría del 22
// sept (las cuatro copias eran byte por byte idénticas).
function localIsoDate(d = new Date()) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function daysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return localIsoDate(d);
}
