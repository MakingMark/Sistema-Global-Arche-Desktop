/* ═══ Marca: paleta de colores configurable ═══
   El dueño elige 4 colores (acento, tinta, papel y destacado) en Configuración
   → Marca; la matemática vive en brandCore.js. Este archivo corre en <head>,
   antes de pintar, con la última paleta guardada en este navegador, para que
   no parpadee. */
(function () {
  'use strict';
  const KEY = 'brand_css_v1';
  const { PRESETS, DEFAULT, normalize, tokens, css, checks, contrast } = BrandCore;

  /* ── Aplicar ── */
  let styleEl = null;
  function ensureStyle() {
    if (!styleEl) { styleEl = document.getElementById('brand-style'); }
    if (!styleEl) { styleEl = document.createElement('style'); styleEl.id = 'brand-style'; document.head.appendChild(styleEl); }
    return styleEl;
  }
  function apply(p, opts) {
    const norm = normalize(p);
    ensureStyle().textContent = css(norm);
    // v4: la barra del navegador toma el fondo del sistema (v4.js), no el color oscuro de la marca.
    if (opts && opts.persist) { try { localStorage.setItem(KEY, JSON.stringify(norm)); } catch (_) {} }
    window.dispatchEvent(new CustomEvent('brand:applied', { detail: norm }));
    return norm;
  }
  function saved() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (_) { return null; } }

  // Ícono de pestaña por defecto: la inicial del negocio sobre el acento.
  function faviconFor(name, p) {
    const n = normalize(p); const ch = (String(name || 'N').trim()[0] || 'N').toUpperCase().replace(/[<>&"']/g, '');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="${n.ink}"/><text x="32" y="44" font-family="Arial,sans-serif" font-weight="700" font-size="36" text-anchor="middle" fill="${n.accent}">${ch}</text></svg>`;
    return 'data:image/svg+xml,' + encodeURIComponent(svg);
  }

  window.Brand = { PRESETS, DEFAULT, normalize, apply, saved, css, tokens, checks, faviconFor, contrast };

  // Arranque inmediato (este script va en <head>): última paleta guardada o la de por defecto.
  apply(saved() || DEFAULT);
  const fav = document.getElementById('favicon');
  if (fav && !fav.getAttribute('data-custom')) { fav.href = faviconFor(document.title.split(' · ')[0], saved() || DEFAULT); fav.type = 'image/svg+xml'; }
})();
