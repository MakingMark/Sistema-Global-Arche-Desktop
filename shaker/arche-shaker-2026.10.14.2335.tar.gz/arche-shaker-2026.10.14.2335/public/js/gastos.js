/* ═══ Gastos (dueño): alquiler, nómina, servicios… ═══ */
(function () {
  'use strict';
  const form = document.getElementById('form-gastos-filtro');
  if (!form) return;
  const esc = UI.escapeHtml;
  const listaEl = document.getElementById('gastos-lista');
  const MAS = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/></svg>';
  const MES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const totalesEl = document.getElementById('gastos-totales');
  let categories = {};
  let locations = [];
  let data = null;

  const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const params = () => {
    const fd = new FormData(form);
    const p = {};
    ['from', 'to', 'category'].forEach(k => { if (fd.get(k)) p[k] = fd.get(k); });
    return p;
  };

  async function load() {
    data = await Api.expenses.list(params());
    categories = data.categories;
    const sel = form.querySelector('[name="category"]');
    if (sel.options.length <= 1) sel.innerHTML = '<option value="">Todas</option>' + Object.entries(categories).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('');
    const byCat = {};
    data.expenses.forEach(e => { byCat[e.category] = (byCat[e.category] || 0) + e.amount; });
    const top = Object.entries(byCat).sort((a, b) => b[1] - a[1])[0];
    totalesEl.innerHTML = `<div class="hv-resumen"><div><small>Total</small><b>${fmtDec(data.total)}</b></div><div><small>Registros</small><b>${data.expenses.length}</b></div><div><small>Mayor gasto</small><b>${top ? esc(categories[top[0]]) : '—'}</b></div></div>`;
    // v4: filas como Insumos; la fecha en un cuadrito (día y mes), tocar edita, «⋯» con Editar y Borrar.
    listaEl.innerHTML = data.expenses.length ? `<div class="in-lista" role="list">${data.expenses.map(e => {
      const [y, m, d] = e.expense_date.split('-');
      return `<div class="in-fila" role="listitem" tabindex="0" data-id="${e.id}">
        <span class="ex-ini gx-fecha"><b>${Number(d)}</b>${MES[Number(m) - 1]}</span>
        <span class="in-n"><b>${esc(e.description || e.category_label)}</b><small>${esc(e.category_label)} · ${esc(e.location_name || 'Todo el negocio')}${e.note ? ' · ' + esc(e.note) : ''}</small></span>
        <span class="in-c"><b>${fmtDec(e.amount)}</b></span>
        <button type="button" class="hv-mas" aria-label="Acciones del gasto" aria-haspopup="menu">${MAS}</button>
      </div>`;
    }).join('')}</div>` : '<div class="hv-vacio"><b>Sin gastos en estas fechas</b><span class="muted">Anota el alquiler, la nómina o la luz con «+ Gasto».</span></div>';
  }

  listaEl.addEventListener('click', async ev => {
    const f = ev.target.closest('[data-id]'); if (!f || !data) return;
    const e = data.expenses.find(x => x.id === Number(f.dataset.id)); if (!e) return;
    const mas = ev.target.closest('.hv-mas');
    if (!mas) { edit(e); return; }
    const a = await UI.rowMenu(mas, e.description || e.category_label, [{ a: 'editar', t: 'Editar' }, { a: 'borrar', t: 'Borrar…', peligro: true, sep: true }]);
    if (a === 'editar') edit(e);
    if (a === 'borrar') {
      if (!(await UI.confirmDialog('¿Borrar este gasto?'))) return;
      try { await Api.expenses.remove(e.id); UI.toast('Gasto borrado'); load(); } catch (err) { UI.toast(err.message, 'error'); }
    }
  });
  listaEl.addEventListener('keydown', ev => { const f = ev.target.closest('.in-fila'); if (f && ev.key === 'Enter' && ev.target === f) f.click(); });

  function edit(e) {
    const editing = !!e;
    const modal = UI.showModal(editing ? 'Editar gasto' : 'Gasto nuevo', `<div class="pf">
      <div class="pf-grupo">
        <label class="pf-fila"><span>Monto</span><span class="pf-pre">${esc(AppLocale.currency())}</span><input id="gx-amount" type="number" min="0" step="0.01" inputmode="decimal" value="${editing ? e.amount : ''}" placeholder="0"></label>
        <label class="pf-fila"><span>Categoría</span><select id="gx-cat">${Object.entries(categories).map(([k, v]) => `<option value="${k}" ${editing && e.category === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
        <label class="pf-fila pf-col"><span>Descripción</span><input id="gx-desc" maxlength="200" value="${esc(editing ? e.description : '')}" placeholder="ej. Alquiler de octubre"></label>
      </div>
      <div class="pf-grupo" style="margin-top:12px">
        <label class="pf-fila"><span>Fecha</span><input id="gx-date" type="date" value="${editing ? e.expense_date : iso(new Date())}"></label>
        <label class="pf-fila"><span>Dónde</span><select id="gx-loc"><option value="">Todo el negocio</option>${locations.filter(l => l.kind === 'carrito').map(l => `<option value="${l.id}" ${editing && e.location_id === l.id ? 'selected' : ''}>${esc(l.name)}</option>`).join('')}</select></label>
        <label class="pf-fila pf-col"><span>Nota</span><input id="gx-note" maxlength="300" value="${esc(editing ? e.note || '' : '')}" placeholder="Opcional"></label>
      </div>
      <div class="error" id="gx-error" role="alert" hidden></div>
      <div class="pf-acciones"><button type="button" class="btn" id="gx-cancel">Cancelar</button><button type="button" class="btn btn-primary" id="gx-save">${editing ? 'Guardar' : 'Anotar gasto'}</button></div>
    </div>`);
    setTimeout(() => modal.el.querySelector('#gx-amount').focus(), 50);
    modal.el.querySelector('#gx-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#gx-save').addEventListener('click', async () => {
      const body = {
        category: modal.el.querySelector('#gx-cat').value, amount: Number(modal.el.querySelector('#gx-amount').value),
        expense_date: modal.el.querySelector('#gx-date').value, location_id: modal.el.querySelector('#gx-loc').value || null,
        description: modal.el.querySelector('#gx-desc').value.trim(), note: modal.el.querySelector('#gx-note').value.trim() || null
      };
      const errEl = modal.el.querySelector('#gx-error');
      const fallo = m => { errEl.textContent = m; errEl.hidden = false; };
      if (!(body.amount > 0)) { fallo('Escribe el monto (mayor que 0)'); modal.el.querySelector('#gx-amount').focus(); return; }
      if (!body.expense_date) { fallo('Escoge la fecha'); return; }
      try {
        if (editing) await Api.expenses.update(e.id, body); else await Api.expenses.create(body);
        modal.close();
        UI.toast(editing ? 'Gasto actualizado' : 'Gasto registrado');
        load();
      } catch (err) { fallo(err.message); }
    });
  }

  document.getElementById('btn-gasto-nuevo').addEventListener('click', async () => {
    if (!locations.length) locations = await Api.locations.list();
    edit(null);
  });
  form.addEventListener('submit', ev => { ev.preventDefault(); load(); });
  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'gastos') return;
    locations = await Api.locations.list().catch(() => locations);
    const from = form.querySelector('[name="from"]'), to = form.querySelector('[name="to"]');
    if (!from.value && !to.value) { const n = new Date(); from.value = iso(new Date(n.getFullYear(), n.getMonth(), 1)); to.value = iso(n); }
    load().catch(err => UI.toast(err.message, 'error'));
  });
})();
