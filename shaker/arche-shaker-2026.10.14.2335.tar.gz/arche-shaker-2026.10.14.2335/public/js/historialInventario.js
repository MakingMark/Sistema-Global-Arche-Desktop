/* ═══ Historial › Envíos y Movimientos de inventario (dueño) ═══
   Junto con Ventas (historial.js) son las tres pestañas de "lo que ya
   pasó". Antes los envíos y la bitácora vivían escondidos dentro del detalle
   de cada ubicación, con un tope de 100 envíos en total y 20 movimientos
   por ubicación — acá se filtran por fecha/ubicación/estado/tipo. */
(function () {
  'use strict';
  const view = document.querySelector('section.view[data-view="historial"]');
  if (!view) return;

  const tabs = view.querySelectorAll('[data-htab]');
  const panels = view.querySelectorAll('[data-hpanel]');
  const enviosForm = document.getElementById('form-historial-envios');
  const movForm = document.getElementById('form-historial-mov');
  const enviosTbody = document.querySelector('#tabla-historial-envios tbody');
  const movTbody = document.querySelector('#tabla-historial-mov tbody');
  const enviosNota = document.getElementById('historial-envios-nota');
  const movNota = document.getElementById('historial-mov-nota');
  const LIMIT = 200;

  // localIsoDate/daysAgo ahora son globales — ver api.js.

  // BUG encontrado en vivo por el dueño ("los parámetros... no es
  // correcta"): renderEnvios/renderMovimientos llamaban a params(form) sin
  // que esta función existiera en ningún archivo — cada vez que se abría
  // "Envíos" o "Movimientos" tiraba `ReferenceError: params is not
  // defined` (atrapado por el try/catch de abajo y mostrado como un toast
  // de error), así que esas dos pestañas nunca llegaron a cargar nada.
  // Arma los filtros desde el <form> correspondiente: cada campo con valor
  // se manda tal cual (from/to/location_id en los dos formularios, más
  // status en Envíos o type en Movimientos — no hace falta nombrarlos
  // aparte, un campo vacío ya se omite solo).
  function params(form) {
    const fd = new FormData(form);
    const out = {};
    for (const [k, v] of fd.entries()) if (v) out[k] = v;
    return out;
  }

  const STATUS_LABEL = {
    pendiente: '<span class="badge badge-warn">Pendiente</span>',
    confirmada: '<span class="badge badge-sage">Confirmada</span>',
    con_discrepancia: '<span class="badge badge-voided">Con diferencia</span>',
    cancelada: '<span class="badge badge-voided">Cancelada</span>'
  };
  const TYPE_LABEL = {
    compra: 'Compra',
    venta: 'Venta',
    ajuste: 'Ajuste',
    transferencia_salida: 'Envío (salida)',
    transferencia_entrada: 'Recibido (entrada)',
    merma: 'Merma'
  };
  function fmtQty(n) {
    return fmtNum(n);   // sin decimales de sobra (907.184 se lee como 907)
  }

  function itemsSummary(t) {
    return t.items.map(i => {
      const name = UI.escapeHtml(i.supply_name || 'Insumo');
      const sent = fmtQty(i.quantity);
      const differs = i.received_quantity != null && Number(i.received_quantity) !== Number(i.quantity);
      return `${name}: ${sent}${differs ? ` <span class="low-stock">(recibido ${fmtQty(i.received_quantity)})</span>` : ''}`;
    }).join('<br>') || '—';
  }

  async function loadLocations() {
    const locations = await Api.locations.list();
    const opts = '<option value="">Todas</option>' +
      locations.filter(l => l.active).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');
    [enviosForm, movForm].forEach(f => {
      const sel = f.querySelector('[name="location_id"]');
      const keep = sel.value;
      sel.innerHTML = opts;
      sel.value = keep;
    });
  }

  async function renderEnvios() {
    let rows;
    try {
      rows = await Api.transfers.list(params(enviosForm));
    } catch (err) {
      UI.toast(err.message, 'error');
      return;
    }
    enviosTbody.innerHTML = rows.map(t => `
      <tr>
        <td data-th="Fecha">${fmtDate(t.created_at)}</td>
        <td data-th="Entre">${UI.escapeHtml(t.from_name)} → ${UI.escapeHtml(t.to_name)}</td>
        <td data-th="Qué se envió">${itemsSummary(t)}${t.note ? `<div class="muted">${UI.escapeHtml(t.note)}</div>` : ''}</td>
        <td data-th="Estado">${STATUS_LABEL[t.status] || t.status}${t.status === 'cancelada' && t.cancel_reason ? `<div class="muted">${UI.escapeHtml(t.cancel_reason)}</div>` : ''}</td>
        <td data-th="Quién">${t.created_by_employee_name ? UI.escapeHtml(t.created_by_employee_name) : 'Administrador'}${t.confirmed_by_employee_name ? ' → ' + UI.escapeHtml(t.confirmed_by_employee_name) : ''}</td>
        <td data-th="">${t.status === 'pendiente' ? `<button type="button" class="btn btn-sm" data-cancel="${t.id}">Cancelar</button>` : ''}</td>
      </tr>
    `).join('') || '<tr><td colspan="6" class="muted">Sin envíos para este filtro.</td></tr>';
    enviosNota.textContent = rows.length >= LIMIT ? `Se muestran los ${LIMIT} más recientes — acota las fechas para ver el resto.` : '';

    enviosTbody.querySelectorAll('[data-cancel]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const reason = await UI.promptDialog(
          '¿Cancelar esta transferencia? El stock que ya salió vuelve al origen. Escribe el motivo (ej. "duplicada por error").',
          'Motivo',
          { required: true }
        );
        if (reason === null) return;
        try {
          await Api.transfers.cancel(btn.dataset.cancel, reason);
          UI.toast('Transferencia cancelada — stock repuesto al origen');
        } catch (err) {
          UI.toast(err.message, 'error');
        }
        renderEnvios();
      });
    });
  }

  async function renderMovimientos() {
    let rows;
    try {
      rows = await Api.reports.movements(params(movForm));
    } catch (err) {
      UI.toast(err.message, 'error');
      return;
    }
    movTbody.innerHTML = rows.map(m => {
      const q = Number(m.quantity);
      const what = `${UI.escapeHtml(m.supply_name || '')}${m.supply_unit ? ` <span class="muted">(${UI.escapeHtml(m.supply_unit)})</span>` : ''}`;
      const ref = m.sale_id ? `Venta #${m.sale_id}` : m.transfer_id ? `Envío #${m.transfer_id}` : '';
      const note = [ref, m.note].filter(Boolean).map(UI.escapeHtml).join(' · ');
      return `
        <tr>
          <td data-th="Fecha">${fmtDate(m.created_at)}</td>
          <td data-th="Ubicación">${UI.escapeHtml(m.location_name)}</td>
          <td data-th="Tipo">${TYPE_LABEL[m.type] || m.type}</td>
          <td data-th="Qué">${what}</td>
          <td class="num ${q < 0 ? 'low-stock' : ''}" data-th="Cantidad">${q > 0 ? '+' : ''}${fmtQty(q)}</td>
          <td data-th="Nota">${note || '—'}</td>
        </tr>`;
    }).join('') || '<tr><td colspan="6" class="muted">Sin movimientos para este filtro.</td></tr>';
    movNota.textContent = rows.length >= LIMIT ? `Se muestran los ${LIMIT} más recientes — acota las fechas para ver el resto.` : '';
  }

  // Un insumo con paquetes cerrados que no coinciden con lo esperado — en
  // rojo, para verlo sin tener que leer cada línea. Solo "no cuadra" cuando
  // reported != expected (0 == 0, ej. sin paquete cerrado esa vez, no es
  // una diferencia).
  function showTab(name) {
    tabs.forEach(t => {
      const on = t.dataset.htab === name;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', String(on));
    });
    panels.forEach(p => { p.hidden = p.dataset.hpanel !== name; });
    if (name === 'envios') renderEnvios();
    if (name === 'movimientos') renderMovimientos();
  }
  tabs.forEach(t => t.addEventListener('click', () => showTab(t.dataset.htab)));

  // Lo usan otras pantallas para saltar directo a una pestaña ya filtrada
  // (ej. "Ver todos los envíos" desde el detalle de una ubicación).
  window.showHistorial = async function (tab, filters) {
    window.showView('historial');
    await locPromise; // las opciones de ubicación deben existir antes de elegir una
    const form = tab === 'envios' ? enviosForm : tab === 'movimientos' ? movForm : null;
    if (form && filters) {
      Object.entries(filters).forEach(([k, v]) => { if (form.elements[k]) form.elements[k].value = v; });
    }
    showTab(tab);
  };

  enviosForm.addEventListener('submit', e => { e.preventDefault(); renderEnvios(); });
  movForm.addEventListener('submit', e => { e.preventDefault(); renderMovimientos(); });
  document.getElementById('btn-historial-envios-limpiar').addEventListener('click', () => {
    enviosForm.reset();
    enviosForm.elements.from.value = daysAgo(30);
    enviosForm.elements.to.value = localIsoDate();
    renderEnvios();
  });
  document.getElementById('btn-historial-mov-limpiar').addEventListener('click', () => {
    movForm.reset();
    movForm.elements.from.value = daysAgo(7);
    movForm.elements.to.value = localIsoDate();
    renderMovimientos();
  });

  let locPromise = Promise.resolve();
  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'historial') return;
    locPromise = loadLocations();
    await locPromise;
    // Envíos: último mes (se manda poco); movimientos: última semana (las
    // ventas generan un movimiento cada una — un mes entero es demasiado).
    if (!enviosForm.elements.from.value && !enviosForm.elements.to.value) {
      enviosForm.elements.from.value = daysAgo(30);
      enviosForm.elements.to.value = localIsoDate();
    }
    if (!movForm.elements.from.value && !movForm.elements.to.value) {
      movForm.elements.from.value = daysAgo(7);
      movForm.elements.to.value = localIsoDate();
    }
    // Si ya estaba abierta otra pestaña (volviendo desde otra pantalla), se
    // refresca esa; si no, Ventas (historial.js) ya se encarga sola.
    const active = view.querySelector('.subtab.active');
    if (active && active.dataset.htab !== 'ventas') showTab(active.dataset.htab);
  });
})();
