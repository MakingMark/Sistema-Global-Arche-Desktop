'use strict';
/* ═══ Celular: barra de pestañas + hoja «Más» (v3.2 administrativo, v3.3 facturación) ═══
   Antes el menú del dueño en el celular era un panel lateral con 4 grupos
   plegados (Inventario, Análisis, Catálogo, Negocio): quedaba medio vacío y
   cada sección costaba dos toques. Ahora sigue el mismo patrón que la
   facturación y que Chicheros: abajo, las 4 secciones de todos los días + «Más»,
   que abre una hoja con TODAS las secciones a la vista, agrupadas.
   Se arma desde el menú de escritorio (#owner-tabs), así respeta solo los
   módulos apagados (Modules.viewOff) y los íconos de siempre. Solo se ve por
   debajo de 820 px (ver app.css, «Administrativo en el celular»).
   v3.3: lo mismo para la facturación (fase 1 de ANALISIS-SISTEMA-COMPLETO.md):
   Vender · Mesas · Caja · Historial · Más (Cocina, Pedidos web, Reposición,
   Ayuda, Salir). El rol «cocina» solo ve Cocina. Los avisos con número
   (mesas listas, pedidos web) se copian a su pestaña, o a «Más» si están ahí. */
function setupMobileNav({ appId, navId, tabs, kicker, helpRole, allowed, short = {}, soloExtras = false, alias = {}, v4 = false }) {
  const app = document.getElementById(appId);
  const nav = document.getElementById(navId);
  if (!app || !nav) return;
  const TABS_FOR = () => (typeof tabs === 'function' ? tabs() : tabs);
  const off = view => {
    const it = itemFor(view);
    return !it || it.hidden || !!(window.Modules && Modules.viewOff(view)) || (allowed ? !allowed(view) : false);
  };
  const itemFor = view => nav.querySelector(`.nav-item[data-view="${view}"]`);
  const iconOf = item => { const svg = item.querySelector('svg'); return svg ? svg.outerHTML : ''; };
  const labelOf = item => (item.querySelector('.nav-label') || item).textContent.trim();
  const MORE_ICON = '<svg class="nav-icon" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="4" cy="9" r="1.4"/><circle cx="9" cy="9" r="1.4"/><circle cx="14" cy="9" r="1.4"/></svg>';

  /* ── Barra de abajo ── */
  const bar = document.createElement('nav');
  bar.className = v4 ? 'owner-tabbar v4-tabbar' : 'owner-tabbar';
  bar.setAttribute('aria-label', 'Secciones principales');
  app.appendChild(bar);

  const badgeOf = item => { const b = item && item.querySelector('.nav-badge'); return b && !b.hidden && b.textContent.trim() !== '0' ? b.textContent.trim() : ''; };
  function paintBar() {
    const TABS = TABS_FOR();
    const tabs = TABS.filter(v => itemFor(v) && !off(v));
    const moreBadge = Array.from(nav.querySelectorAll('.nav-item[data-view]')).some(it => !tabs.includes(it.dataset.view) && !off(it.dataset.view) && badgeOf(it));
    bar.innerHTML = tabs.map(v => {
      const it = itemFor(v); const n = badgeOf(it);
      return `<button type="button" class="owner-tab" data-view="${v}">${iconOf(it)}<span>${short[v] || labelOf(it)}</span>${n ? `<i class="owner-tab-badge">${n}</i>` : ''}</button>`;
    }).join('') + (v4 ? '' : `<button type="button" class="owner-tab" data-more aria-haspopup="dialog">${MORE_ICON}<span>Más</span>${moreBadge ? '<i class="owner-tab-badge is-dot"></i>' : ''}</button>`);
    if (v4 && avatarBtn) avatarBtn.classList.toggle('has-dot', moreBadge);
    markActive(currentView);
  }

  /* ── Hoja «Más» ── */
  const sheet = document.createElement('div');
  sheet.className = 'owner-more';
  sheet.hidden = true;
  sheet.innerHTML = `
    <div class="owner-more-backdrop" data-close></div>
    <section class="owner-more-panel" role="dialog" aria-modal="true" aria-label="Todas las secciones">
      <div class="owner-more-handle" aria-hidden="true"></div>
      <div class="owner-more-head">
        <div><p class="owner-more-kicker">${kicker}</p><h2 class="owner-more-title"></h2></div>
        <button type="button" class="owner-more-close" data-close aria-label="Cerrar">✕</button>
      </div>
      <div class="owner-more-body"></div>
      <div class="owner-more-foot">
        <a class="btn btn-sm" href="ayuda.html?role=${helpRole}" target="shaker-ayuda">Ayuda</a>
        <button type="button" class="btn btn-sm" data-logout>Salir</button>
        <span class="owner-more-arche" role="img" aria-label="Arche"></span>
      </div>
    </section>`;
  document.body.appendChild(sheet);
  const body = sheet.querySelector('.owner-more-body');

  // v4 (DISENO-ARCHE.md): «Cuenta y negocio» como los Ajustes del iPhone — filas con ícono en un cuadrito de color.
  const COLOR = { panel: '#0A84FF', historial: '#FF9500', 'inv-existencias': '#FF9500', menu: '#FF9F0A', reportes: '#0A84FF', clientes: '#AF52DE', pagina: '#5AC8FA', empleados: '#34C759', configuracion: '#636366' };
  const CHEV = '<svg class="v4-chev" viewBox="0 0 8 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.5 1.5L6.5 7l-5 5.5"/></svg>';
  function paintSheetV4() {
    const name = (app.querySelector('.brand-name') || {}).textContent || '';
    sheet.querySelector('.owner-more-title').textContent = 'Cuenta y negocio';
    const ini = name.trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
    const enBarra = TABS_FOR();
    const items = Array.from(nav.querySelectorAll('.nav-item[data-view]')).filter(it => !off(it.dataset.view) && !enBarra.includes(it.dataset.view));
    const fila = (attrs, color, icono, texto, extra = '') => `<button type="button" class="v4-fila" ${attrs}><span class="v4-cuadro" style="background:${color}">${icono}</span><span class="v4-fila-t">${texto}</span>${extra}${CHEV}</button>`;
    body.innerHTML = `
      <div class="v4-grupo"><div class="v4-fila v4-quien"><span class="v4-logo">${UI.escapeHtml(ini)}</span><span class="v4-fila-t"><b>${UI.escapeHtml(name)}</b><small>Dueño · Administrativo</small></span></div></div>
      <div class="v4-grupo">${items.map(it => fila(`data-view="${it.dataset.view}"`, COLOR[it.dataset.view] || '#8E8E93', iconOf(it), UI.escapeHtml(labelOf(it)), badgeOf(it) ? `<i class="owner-tab-badge">${badgeOf(it)}</i>` : '')).join('')}</div>
      <div class="v4-grupo" data-v4-ubic hidden></div>
      <div class="v4-grupo">
        ${fila('data-v4="persona"', '#FF9500', '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3 19c0-3.2 2.7-5.5 6-5.5"/><path d="M15 13l3-3 3 3M18 10v9"/></svg>', 'Cambiar de persona')}
        ${fila('data-v4="tema"', '#5856D6', '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/></svg>', 'Tema claro u oscuro')}
        ${fila('data-v4="ayuda"', '#34C759', '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17h.01"/></svg>', 'Ayuda')}
      </div>
      <div class="v4-grupo"><button type="button" class="v4-fila v4-salir" data-logout>Cerrar sesión</button></div>`;
    // Ubicación (solo con más de un local): una fila con el selector del iPhone a la derecha.
    if (window.V4 && V4.ubicaciones) V4.ubicaciones().then(locs => {
      const g = body.querySelector('[data-v4-ubic]'); if (!g || locs.length < 2) return;
      const actual = V4.ubicacion();
      g.innerHTML = `<label class="v4-fila v4-fila-sel"><span class="v4-cuadro" style="background:#5AC8FA"><svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-6-5.3-6-10a6 6 0 0 1 12 0c0 4.7-6 10-6 10z"/><circle cx="12" cy="11" r="2.2"/></svg></span><span class="v4-fila-t">Ubicación</span>
        <select data-v4-loc aria-label="Ubicación">${[{ id: '', name: 'Todas' }, ...locs].map(l => `<option value="${l.id}"${String(l.id) === actual ? ' selected' : ''}>${UI.escapeHtml(l.name)}</option>`).join('')}</select></label>`;
      g.hidden = false;
      g.querySelector('[data-v4-loc]').addEventListener('change', e => V4.ponerUbicacion(e.target.value));
    });
  }
  function paintSheet() {
    if (v4) { paintSheetV4(); return; }
    const name = app.querySelector('.brand-name');
    sheet.querySelector('.owner-more-title').textContent = name ? name.textContent.trim() : '';
    const groups = nav.querySelectorAll('.nav-group').length ? Array.from(nav.querySelectorAll('.nav-group')) : [nav];
    body.innerHTML = groups.map(g => {
      const lbl = g.querySelector('.nav-group-label');
      const enBarra = soloExtras ? TABS_FOR() : [];
    const items = Array.from(g.querySelectorAll('.nav-item[data-view]')).filter(it => !off(it.dataset.view) && !enBarra.includes(it.dataset.view));
      if (!items.length) return '';
      return `<div class="owner-more-group">
        ${groups.length > 1 ? `<p class="owner-more-label">${lbl ? lbl.childNodes[0].textContent.trim() : 'Día a día'}</p>` : ''}
        <div class="owner-more-grid">${items.map(it => `<button type="button" class="owner-more-item${it.dataset.view === viaHub(currentView) ? ' is-active' : ''}" data-view="${it.dataset.view}">${iconOf(it)}<span>${labelOf(it)}</span>${badgeOf(it) ? `<i class="owner-tab-badge">${badgeOf(it)}</i>` : ''}</button>`).join('')}</div>
      </div>`;
    }).join('');
  }

  let lastFocus = null;
  function openSheet() {
    paintSheet();
    lastFocus = document.activeElement;
    sheet.hidden = false;
    requestAnimationFrame(() => sheet.classList.add('is-open'));
    document.documentElement.classList.add('owner-more-lock');
    const first = sheet.querySelector('.owner-more-item');
    if (first) first.focus({ preventScroll: true });
  }
  function closeSheet() {
    if (sheet.hidden) return;
    sheet.classList.remove('is-open');
    document.documentElement.classList.remove('owner-more-lock');
    setTimeout(() => { sheet.hidden = true; }, 260);
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }

  bar.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.hasAttribute('data-more')) { openSheet(); return; }
    window.showView(b.dataset.view);
    window.scrollTo({ top: 0 });
  });
  sheet.addEventListener('click', e => {
    if (e.target.closest('[data-close]')) { closeSheet(); return; }
    const v4b = e.target.closest('[data-v4]');
    if (v4b) {
      if (v4b.dataset.v4 === 'tema') { const t = app.querySelector('[data-theme-toggle]'); if (t) t.click(); }
      if (v4b.dataset.v4 === 'ayuda') window.open(`ayuda.html?role=${helpRole}`, 'shaker-ayuda');
      if (v4b.dataset.v4 === 'persona' && window.V4) { V4.cambiarPersona(); return; }
      closeSheet(); return;
    }
    const fila = e.target.closest('.v4-fila[data-view]');
    if (fila) { window.showView(fila.dataset.view); window.scrollTo({ top: 0 }); closeSheet(); return; }
    const it = e.target.closest('.owner-more-item');
    if (it) { window.showView(it.dataset.view); window.scrollTo({ top: 0 }); closeSheet(); }
    if (e.target.closest('[data-logout]')) closeSheet();
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

  // Deslizar hacia abajo desde el asa o el encabezado cierra la hoja.
  const panel = sheet.querySelector('.owner-more-panel');
  let y0 = null;
  panel.addEventListener('touchstart', e => { if (e.target.closest('.owner-more-handle, .owner-more-head')) y0 = e.touches[0].clientY; }, { passive: true });
  panel.addEventListener('touchmove', e => { if (y0 === null) return; const dy = Math.max(0, e.touches[0].clientY - y0); panel.style.transform = `translateY(${dy}px)`; }, { passive: true });
  panel.addEventListener('touchend', e => {
    if (y0 === null) return;
    const dy = e.changedTouches[0].clientY - y0; y0 = null; panel.style.transform = '';
    if (dy > 80) closeSheet();
  });

  /* ── v4: foto arriba a la derecha, búsqueda redonda y barra que se encoge al bajar ── */
  var avatarBtn = null;
  if (v4) {
    avatarBtn = document.createElement('button');
    avatarBtn.type = 'button'; avatarBtn.className = 'v4-avatar'; avatarBtn.setAttribute('aria-label', 'Cuenta y negocio'); avatarBtn.setAttribute('aria-haspopup', 'dialog');
    const pintaAv = () => { const n = (app.querySelector('.brand-name') || {}).textContent || ''; avatarBtn.textContent = n.trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase(); };
    pintaAv(); const bn = app.querySelector('.brand-name'); if (bn) new MutationObserver(pintaAv).observe(bn, { childList: true, characterData: true, subtree: true });
    avatarBtn.addEventListener('click', openSheet);
    // Título pequeño de la pantalla actual (aparece al desplazar, como en iOS).
    const tit = document.createElement('div'); tit.className = 'v4-titulo'; tit.setAttribute('aria-hidden', 'true');
    (app.querySelector('.sidebar') || app).appendChild(tit);
    window.addEventListener('view:show', e => setTimeout(() => {
      const sec = app.querySelector(`section.view[data-view="${e.detail.view}"]`);
      const h = sec && (sec.querySelector('h1.dash-title') || sec.querySelector('h1'));
      tit.textContent = h ? h.textContent.trim() : '';
    }, 120));
    (app.querySelector('.sidebar') || app).appendChild(avatarBtn);
    const lupa = document.createElement('button');
    lupa.type = 'button'; lupa.className = 'v4-gbus'; lupa.setAttribute('aria-label', 'Buscar');
    lupa.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>';
    lupa.addEventListener('click', () => { const b = document.getElementById('buscar-btn'); if (b) b.click(); });
    app.appendChild(lupa);
    const acc = document.createElement('button');
    acc.type = 'button'; acc.className = 'v4-acc'; acc.hidden = true;
    acc.addEventListener('click', () => { window.showView('panel'); window.scrollTo({ top: 0, behavior: 'smooth' }); });
    app.appendChild(acc);
    window.addEventListener('hoy:datos', e => {
      const d = e.detail, c = d && d.es_hoy && d.cajas && d.cajas[0];
      acc.hidden = !c;
      if (c) acc.innerHTML = `<i></i><span><b>Caja abierta · ${UI.escapeHtml(fmt(c.expected_now))}</b><small>${UI.escapeHtml(c.opened_by_name || c.location_name)} · ${d.hoy.facturas} venta${d.hoy.facturas === 1 ? '' : 's'} hoy</small></span>`;
    });
    let yAnt = 0;
    window.addEventListener('scroll', () => {
      const y = window.scrollY, abajo = y > yAnt + 4, arriba = y < yAnt - 4;
      // El rebote elástico del iPhone al llegar al final se ve como «subir»: ahí no se abre el menú.
      const fondo = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      if ((y >= fondo - 24 || yAnt >= fondo - 24) && y > 120) { yAnt = y; return; }
      if (abajo && y > 120) app.classList.add('v4-min');
      else if (arriba || y < 60) app.classList.remove('v4-min');
      app.classList.toggle('v4-scrolled', y > 8);
      yAnt = y;
    }, { passive: true });
  }

  /* ── Pestaña activa ── */
  let currentView = TABS_FOR()[0];
  // Fase 4: una pantalla interna de un grupo (ej. Compras) marca la pestaña de su grupo (Inventario).
  // Pantallas internas que pertenecen a una pestaña (ej. la cuenta de una mesa → Mesas).
  const viaHub = view => (alias[view] || (appId === 'owner-app' && window.Hubs ? Hubs.primaryOf(view) : view));
  function markActive(view) {
    const inBar = bar.querySelector(`[data-view="${viaHub(view)}"]`);
    bar.querySelectorAll('.owner-tab').forEach(b => {
      const on = inBar ? b.dataset.view === viaHub(view) : b.hasAttribute('data-more');
      b.classList.toggle('is-active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
  }
  window.addEventListener('view:show', e => { currentView = e.detail.view; markActive(currentView); });

  // Los módulos llegan después (appSettings.js) y los avisos cambian solos: se
  // rearma cuando cambian las clases, lo oculto o los números del menú.
  let raf = null;
  const repaint = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = null; paintBar(); }); };
  new MutationObserver(repaint).observe(nav, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['class', 'hidden'] });
  new MutationObserver(repaint).observe(app, { attributes: true, attributeFilter: ['data-emp-role', 'hidden'] });
  paintBar();
}

setupMobileNav({ appId: 'owner-app', navId: 'owner-tabs', kicker: 'Administrativo', helpRole: 'owner', v4: true,
  short: { panel: 'Hoy', historial: 'Ventas' },
  tabs: ['panel', 'historial', 'inv-existencias', 'reportes'] });
setupMobileNav({ appId: 'cart-app', navId: 'cart-tabs', kicker: 'Facturación', helpRole: 'cart',
  allowed: v => document.getElementById('cart-app').dataset.empRole !== 'cocina' || v === 'pos-cocina',
  short: { 'pos-venta': 'Vender' },
  soloExtras: true,   // en «Más» solo lo que no está ya en la barra de abajo
  alias: { 'pos-cuenta': 'pos-mesas' },
  tabs: () => (document.getElementById('cart-app').dataset.empRole === 'cocina' ? ['pos-cocina'] : ['pos-venta', 'pos-mesas', 'pos-caja', 'pos-historial']) });
