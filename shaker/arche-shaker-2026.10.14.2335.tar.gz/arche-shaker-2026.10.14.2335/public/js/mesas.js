/* ═══ Mesas, cuentas y cocina (punto de venta) ═══
   Mesas: el mapa del salón (libre / ocupada / plato listo para servir).
   Cuenta: lo anotado en una mesa — se manda a cocina por rondas, se sirve y se
   cobra (al cobrar se convierte en una venta normal).
   Cocina: la pantalla de la tablet de cocina, con las comandas en orden de
   llegada. Todo va contra el servidor del negocio (routes/orders.js); se
   actualiza solo cada pocos segundos. */
(function () {
  'use strict';
  const mesasGrid = document.getElementById('mesas-grid');
  if (!mesasGrid) return;

  const esc = UI.escapeHtml;
  const $ = id => document.getElementById(id);
  const llevarGrid = $('llevar-grid');
  const cuentaItemsEl = $('cuenta-items');
  const cuentaErrorEl = $('cuenta-error');
  const cocinaBoard = $('cocina-board');
  const cocinaListos = $('cocina-listos');

  let order = null;            // la cuenta abierta en pantalla
  let menuMounted = null;      // el selector de productos de la cuenta (posMenu.js)
  let currentView = null;
  let busy = false;

  const isPos = () => { const s = Auth.get(); return !!s && s.role === 'cart'; };
  const fmtTime = iso => new Date(iso).toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit' });
  const minutesSince = iso => Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60000));
  const showCuentaError = msg => { cuentaErrorEl.textContent = msg; cuentaErrorEl.hidden = !msg; };

  /* ═══════════ MESAS ═══════════ */
  // Cuánto lleva ocupada, fácil de leer: «45 min», «1 h 20 min», «más de un día».
  function duracion(iso) {
    const m = minutesSince(iso);
    if (m < 1) return '0 min';
    if (m < 60) return `${m} min`;
    if (m < 24 * 60) { const h = Math.floor(m / 60), r = m % 60; return r ? `${h} h ${r} min` : `${h} h`; }
    return 'más de un día';
  }
  const plural = (n, uno, varios) => `${n} ${n === 1 ? uno : varios}`;

  // Estado de una mesa, en orden de urgencia (el color del borde y la cápsula).
  function estadoMesa(t) {
    if (!t.order_id) return { cls: 'is-free', pill: 'Libre', meta: t.seats ? `${t.seats} lugares` : '' };
    const desde = `desde ${fmtTime(t.opened_at)} · ${duracion(t.opened_at)}`;
    if (t.ready > 0) return { cls: 'is-ready', pill: plural(t.ready, 'listo', 'listos') + ' para servir', meta: desde };
    if (t.bill_requested_at) return { cls: 'is-bill', pill: 'Por cobrar', meta: `pidió la cuenta · hace ${duracion(t.bill_requested_at)}` };
    if (t.in_kitchen > 0) return { cls: 'is-kitchen', pill: `${t.in_kitchen} en cocina`, meta: desde };
    if (t.pending > 0) return { cls: 'is-pending', pill: `${t.pending} sin mandar`, meta: desde };
    if (t.net_total > 0) return { cls: 'is-eating', pill: 'Comiendo', meta: desde };
    return { cls: 'is-open', pill: 'Abierta', meta: desde };
  }

  function tableTile(t, isTakeout) {
    const open = !!t.order_id;
    const e = estadoMesa(t);
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `table-tile ${e.cls}` + (open ? ' is-busy' : '');
    const extra = open && t.pending > 0 && e.cls !== 'is-pending' ? `<span class="table-extra">${t.pending} sin mandar</span>` : '';
    b.innerHTML = `
      <span class="table-name">${esc(isTakeout ? t.label : t.name)}</span>
      <span class="table-pill">${esc(e.pill)}</span>
      ${open ? `<span class="table-total">${fmt(t.net_total)}</span>` : ''}
      <span class="table-meta">${esc(e.meta)}</span>${extra}`;
    b.setAttribute('aria-label', [isTakeout ? t.label : t.name, e.pill, open ? fmt(t.net_total) : '', e.meta].filter(Boolean).join(', '));
    b.addEventListener('click', () => {
      if (isTakeout || open) openOrderScreen(t.order_id);
      else openNewTable(t);
    });
    return b;
  }

  let zonaActual = null;
  try { zonaActual = localStorage.getItem('arche_mesas_zona'); } catch (_) {}
  let ultimasMesas = null;

  function pintarMesas(data) {
    ultimasMesas = data;
    const zonas = [...new Set(data.tables.map(t => t.zone).filter(Boolean))];
    const seg = $('mesas-zonas');
    seg.hidden = zonas.length < 2;
    if (zonas.length < 2 || (zonaActual && !zonas.includes(zonaActual))) zonaActual = null;
    if (!seg.hidden) {
      seg.innerHTML = ['', ...zonas].map(z => `<button type="button" class="v4-seg-b${(zonaActual || '') === z ? ' is-active' : ''}" role="tab" aria-selected="${(zonaActual || '') === z}" data-zona="${esc(z)}">${z ? esc(z) : 'Todas'}</button>`).join('');
    }
    const visibles = zonaActual ? data.tables.filter(t => t.zone === zonaActual) : data.tables;
    mesasGrid.innerHTML = '';
    visibles.forEach(t => mesasGrid.appendChild(tableTile(t, false)));
    $('mesas-vacio').hidden = data.tables.length > 0;
    llevarGrid.innerHTML = '';
    data.takeouts.forEach(t => llevarGrid.appendChild(tableTile(t, true)));
    $('llevar-title').hidden = !data.takeouts.length;
    const abiertas = [...data.tables.filter(t => t.order_id), ...data.takeouts];
    const total = abiertas.reduce((s, t) => s + (Number(t.net_total) || 0), 0);
    const porCobrar = abiertas.filter(t => t.bill_requested_at).length;
    $('mesas-resumen').textContent = abiertas.length
      ? `${plural(data.tables.filter(t => t.order_id).length, 'ocupada', 'ocupadas')}${data.takeouts.length ? ` · ${data.takeouts.length} para llevar` : ''} · ${fmt(total)} abierto${porCobrar ? ` · ${porCobrar} por cobrar` : ''}`
      : (data.tables.length ? 'Todas libres' : '');
  }

  $('mesas-zonas').addEventListener('click', e => {
    const b = e.target.closest('[data-zona]');
    if (!b) return;
    zonaActual = b.dataset.zona || null;
    try { zonaActual ? localStorage.setItem('arche_mesas_zona', zonaActual) : localStorage.removeItem('arche_mesas_zona'); } catch (_) {}
    if (ultimasMesas) pintarMesas(ultimasMesas);
  });

  async function renderTables() {
    let data;
    try { data = await Api.pos.tables(); } catch (err) { showOffline(err); return; }
    pintarMesas(data);
  }

  function showOffline(err) {
    if (err && err.status === undefined) UI.toast('Sin conexión con el servidor — las mesas y la cocina lo necesitan (la Venta rápida sí funciona sin señal)', 'error');
    else if (err) UI.toast(err.message, 'error');
  }

  async function openNewTable(t) {
    try {
      const o = await Api.pos.openOrder({ table_id: t.id });
      await openOrderScreen(o.id, o);
    } catch (err) { showOffline(err); }
  }

  $('btn-nuevo-llevar').addEventListener('click', () => {
    const modal = UI.showModal('Pedido para llevar', `
      <label class="f" style="max-width:none"><span>Nombre del cliente (opcional)</span><input type="text" id="llevar-nombre" maxlength="80" placeholder="ej. Luis"></label>
      <div class="modal-actions" style="margin-top:16px">
        <button class="btn" id="llevar-cancel">Cancelar</button>
        <button class="btn btn-primary" id="llevar-ok">Abrir cuenta</button>
      </div>`);
    modal.el.querySelector('#llevar-nombre').focus();
    modal.el.querySelector('#llevar-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#llevar-ok').addEventListener('click', async () => {
      const name = modal.el.querySelector('#llevar-nombre').value.trim();
      try {
        const o = await Api.pos.openOrder({ order_type: 'llevar', customer_name: name || null });
        modal.close();
        await openOrderScreen(o.id, o);
      } catch (err) { showOffline(err); }
    });
  });

  /* ═══════════ CUENTA ═══════════ */
  async function openOrderScreen(orderId, preloaded) {
    try {
      order = preloaded || await Api.pos.order(orderId);
      await PosMenu.load().catch(() => {});
    } catch (err) { showOffline(err); return; }
    showCuentaError('');
    window.showView('pos-cuenta');
    // Celular: mesa nueva (vacía) abre en el menú; una con platos, en la cuenta.
    vistaCuenta(order.items.some(i => i.status !== 'anulado' && !i.sale_id) ? 'cuenta' : 'agregar');
    // La cuenta cuelga de "Mesas": se deja esa pestaña como activa.
    document.querySelectorAll('#cart-tabs .nav-item').forEach(t => t.classList.toggle('active', t.dataset.view === 'pos-mesas'));
    if (!menuMounted) {
      menuMounted = PosMenu.mount({
        tabsEl: $('cuenta-category-tabs'), subTabsEl: $('cuenta-subcategory-tabs'),
        gridEl: $('cuenta-product-grid'), searchEl: $('cuenta-search'),
        counts: () => {
          const m = new Map();
          (order ? order.items : []).filter(i => i.status !== 'anulado').forEach(i => m.set(i.product_id, (m.get(i.product_id) || 0) + i.quantity));
          return m;
        },
        onProduct: p => PosMenu.pick(p, ({ modifiers, note, quantity }) => addItem(p, modifiers, note, quantity))
      });
    }
    renderOrder();
  }

  // Lo usa la bandeja de pedidos web para saltar directo a la comanda recién aceptada.
  window.openOrderById = id => openOrderScreen(id);

  async function addItem(p, modifiers, note, quantity) {
    showCuentaError('');
    try {
      order = await Api.pos.addOrderItems(order.id, [{ product_id: p.id, quantity, modifiers, note }]);
      renderOrder();
    } catch (err) { showCuentaError(err.status === undefined ? 'Sin conexión con el servidor — no se pudo anotar' : err.message); }
  }

  const STATUS_LABEL = {
    pendiente: ['Sin mandar', 'is-pending'], nuevo: ['En cocina', 'is-kitchen'], preparando: ['Preparando', 'is-kitchen'],
    listo: ['¡Listo!', 'is-ready'], servido: ['Servido', 'is-served'], anulado: ['Anulado', 'is-void'], pagado: ['Pagado', 'is-served']
  };
  const STATUS_ORDER = { pendiente: 0, listo: 1, nuevo: 2, preparando: 2, servido: 3, anulado: 4 };
  const orderOf = i => (i.sale_id && i.status !== 'anulado') ? 5 : STATUS_ORDER[i.status];

  // Secciones de la cuenta, en el orden en que el mesero las necesita.
  const SECCIONES = [
    ['listo', 'Listo para servir'], ['pendiente', 'Sin mandar'], ['cocina', 'En cocina'],
    ['servido', 'Servido'], ['pagado', 'Ya pagado'], ['anulado', 'Anulado']
  ];
  const seccionDe = i => (i.sale_id && i.status !== 'anulado') ? 'pagado'
    : (i.status === 'nuevo' || i.status === 'preparando') ? 'cocina' : i.status;

  function lineaHtml(i) {
    const [label, cls] = STATUS_LABEL[i.sale_id && i.status !== 'anulado' ? 'pagado' : i.status];
    const mods = (i.modifiers || []).map(m => `${esc(m.option)}${Number(m.price_delta) ? ` (${Number(m.price_delta) > 0 ? '+' : ''}${fmt(m.price_delta)})` : ''}`);
    const sub = [...mods, i.note ? `“${esc(i.note)}”` : '', i.status === 'preparando' ? 'preparando' : '', i.status === 'anulado' && i.void_reason ? esc(i.void_reason) : ''].filter(Boolean).join(' · ');
    let actions = '';
    if (i.sale_id) actions = '';
    else if (i.status === 'pendiente') {
      actions = `<div class="qty-controls" role="group" aria-label="Cantidad"><button type="button" data-a="dec" aria-label="Uno menos">−</button><button type="button" data-a="inc" aria-label="Uno más">+</button></div>
                 <button type="button" class="btn btn-sm cl-quitar" data-a="del">Quitar</button>`;
    } else if (i.status === 'listo') {
      actions = `<button type="button" class="btn btn-sm btn-primary" data-a="served">Servido</button><button type="button" class="btn btn-sm cl-anular" data-a="void">Anular</button>`;
    } else if (i.status !== 'anulado') {
      actions = `<button type="button" class="btn btn-sm cl-anular" data-a="void">Anular</button>`;
    }
    return `<div class="cuenta-linea order-line ${cls}" data-item="${i.id}">
      <span class="cl-cant">${i.quantity}×</span>
      <div class="cl-txt"><b>${esc(i.product_name)}</b>${sub ? `<small>${sub}</small>` : ''}<span class="lx-sr">${label}</span></div>
      <span class="cl-precio">${fmt(Number(i.unit_price) * i.quantity)}</span>
      ${actions ? `<div class="cl-acc">${actions}</div>` : ''}
    </div>`;
  }

  function renderOrder() {
    if (!order) return;
    $('cuenta-title').textContent = order.label;
    const items = [...order.items].sort((a, b) => (orderOf(a) - orderOf(b)) || (a.id - b.id));
    const live = items.filter(i => i.status !== 'anulado' && !i.sale_id);
    cuentaItemsEl.innerHTML = items.length ? SECCIONES.map(([k, titulo]) => {
      const de = items.filter(i => seccionDe(i) === k);
      return de.length ? `<section class="cuenta-sec cuenta-sec-${k}"><h3>${titulo}</h3><div class="cuenta-grupo">${de.map(lineaHtml).join('')}</div></section>` : '';
    }).join('') : '<p class="muted cuenta-vacia">Todavía no hay nada anotado. Toca un plato del menú para agregarlo.</p>';
    $('cuenta-sub').textContent = [`Desde las ${fmtTime(order.opened_at)} · ${duracion(order.opened_at)}`, order.customer_name || '', order.bill_requested_at ? 'pidió la cuenta' : ''].filter(Boolean).join(' · ');
    $('cuenta-split').hidden = live.length < 2;
    $('cuenta-bill').hidden = !live.length;
    $('cuenta-bill').textContent = order.bill_requested_at ? 'Por cobrar ✓' : 'Pidió la cuenta';
    $('cuenta-bill').classList.toggle('is-on', !!order.bill_requested_at);
    $('cuenta-bill').setAttribute('aria-pressed', String(!!order.bill_requested_at));

    const amt0 = PosMenu.computeAmounts(live.map(i => ({ subtotal: Number(i.unit_price) * i.quantity, rate: PosMenu.rateOf(i.product_id) })), null);
    const net = amt0.net;
    const { itbis, tip } = amt0;
    const cfg = PosMenu.getSettings();
    $('cuenta-row-subtotal').hidden = !(cfg.itbis_enabled || cfg.tip_enabled);
    $('cuenta-row-itbis').hidden = !cfg.itbis_enabled;
    $('cuenta-row-tip').hidden = !cfg.tip_enabled;
    $('cuenta-subtotal').textContent = fmt(net);
    $('cuenta-itbis-label').textContent = `ITBIS (${Number(cfg.itbis_rate)}%)`;
    $('cuenta-itbis').textContent = fmt(itbis);
    $('cuenta-tip-label').textContent = `Propina legal (${Number(cfg.tip_rate)}%)`;
    $('cuenta-tip').textContent = fmt(tip);
    // Pedido web con delivery: el costo del domicilio se suma al final de la cuenta.
    const fee = (order.source === 'web' && Number(order.delivery_fee) > 0 && live.length) ? Number(order.delivery_fee) : 0;
    $('cuenta-row-fee').hidden = !fee;
    $('cuenta-fee').textContent = fmt(fee);
    $('cuenta-total').textContent = fmt(net + itbis + tip + fee);
    const info = [order.source === 'web' ? '🌐 Pedido de la página' : '', order.fulfillment === 'delivery' ? `📍 ${order.delivery_address || ''}` : (order.source === 'web' ? 'Retiro en el local' : ''), order.customer_phone ? `📞 ${String(order.customer_phone).replace(/^1/, '')}` : '', order.note ? `📝 ${order.note}` : ''].filter(Boolean).join('  ·  ');
    const extraInfo = [order.payment_status === 'pendiente' ? '💳 Transferencia por confirmar' : '', order.dispatched_at ? '🛵 En camino' : ''].filter(Boolean).join(' · ');
    $('cuenta-info').textContent = [info, extraInfo].filter(Boolean).join(' · ');
    $('cuenta-info').hidden = !(info || extraInfo);
    $('cuenta-paid').hidden = !(order.source === 'web' && order.payment_status === 'pendiente');
    $('cuenta-dispatch').hidden = !(order.fulfillment === 'delivery' && !order.dispatched_at && items.some(i => ['nuevo', 'preparando', 'listo', 'servido'].includes(i.status)));

    const pending = items.filter(i => i.status === 'pendiente').length;
    // Con algo sin mandar, lo principal es mandarlo a cocina; si no queda nada, lo principal es cobrar.
    $('cuenta-send').hidden = !pending;
    $('cuenta-send').textContent = `Mandar a cocina (${pending})`;
    $('cuenta-send').classList.toggle('btn-primary', !!pending);
    $('cuenta-pay').classList.toggle('btn-primary', !pending);
    $('cuenta-pay').disabled = !live.length;
    $('cuenta-pay').textContent = live.length ? `Cobrar ${fmt(net + itbis + tip + fee)}` : 'Cobrar';
    $('cuenta-vista-cuenta').textContent = live.length ? `Cuenta · ${fmt(net + itbis + tip + fee)}` : 'Cuenta';
    const bar = $('cuenta-mobile-bar');
    bar.hidden = !live.length;
    const units = live.reduce((s, i) => s + i.quantity, 0);
    $('cuenta-mobile-summary').textContent = `${units} ${units === 1 ? 'artículo' : 'artículos'} · ${fmt(net + itbis + tip)}`;
    if (menuMounted) menuMounted.render();
  }

  // Celular: la cuenta y el menú se alternan con el control «Cuenta / Agregar platos».
  function vistaCuenta(v) {
    document.querySelector('.view[data-view="pos-cuenta"]').dataset.vista = v;
    document.querySelectorAll('#cuenta-vista [data-vista]').forEach(b => { const on = b.dataset.vista === v; b.classList.toggle('is-active', on); b.setAttribute('aria-selected', String(on)); });
    window.scrollTo({ top: 0 });
  }
  $('cuenta-vista').addEventListener('click', e => { const b = e.target.closest('[data-vista]'); if (b) vistaCuenta(b.dataset.vista); });
  $('cuenta-mobile-bar').addEventListener('click', () => {
    if (window.matchMedia('(max-width: 760px)').matches) vistaCuenta('cuenta');
    else $('cuenta-pay').scrollIntoView({ behavior: 'smooth', block: 'center' });
  });

  $('cuenta-bill').addEventListener('click', async () => {
    try { order = await Api.pos.requestBill(order.id, !order.bill_requested_at); renderOrder(); if (order.bill_requested_at) UI.toast(`${order.label}: por cobrar`); }
    catch (err) { showCuentaError(err.status === undefined ? 'Sin conexión con el servidor' : err.message); }
  });
  $('cuenta-split').addEventListener('click', () => cobrar({ dividir: true }));

  let menuCuenta = null;
  const cerrarMenuCuenta = () => { if (menuCuenta) { menuCuenta.remove(); menuCuenta = null; } };
  document.addEventListener('click', e => { if (menuCuenta && !menuCuenta.contains(e.target) && !e.target.closest('#cuenta-mas')) cerrarMenuCuenta(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarMenuCuenta(); });
  $('cuenta-mas').addEventListener('click', e => {
    if (menuCuenta) { cerrarMenuCuenta(); return; }
    if (!order) return;
    menuCuenta = document.createElement('div'); menuCuenta.className = 'v4-menu'; menuCuenta.setAttribute('role', 'menu');
    menuCuenta.innerHTML = `<div class="v4-menu-cab">${esc(order.label)}</div>
      ${order.order_type === 'mesa' ? '<button type="button" role="menuitem" data-a="mover">Cambiar de mesa…</button>' : ''}
      <hr><button type="button" role="menuitem" class="is-peligro" data-a="cancelar">Cancelar cuenta…</button>`;
    document.body.appendChild(menuCuenta);
    const r = e.currentTarget.getBoundingClientRect(), mw = menuCuenta.offsetWidth;
    menuCuenta.style.left = Math.max(8, Math.min(window.innerWidth - mw - 8, r.right - mw)) + 'px';
    menuCuenta.style.top = (r.bottom + 6) + 'px';
    menuCuenta.style.transformOrigin = 'top right';
    menuCuenta.addEventListener('click', ev => {
      const a = ev.target.closest('[data-a]'); if (!a) return;
      cerrarMenuCuenta();
      if (a.dataset.a === 'mover') moverMesa();
      if (a.dataset.a === 'cancelar') cancelarCuenta();
    });
    menuCuenta.querySelector('button').focus();
  });

  cuentaItemsEl.addEventListener('click', async e => {
    const btn = e.target.closest('[data-a]');
    const row = btn && btn.closest('[data-item]');
    if (!btn || !row || !order || busy) return;
    const item = order.items.find(i => i.id === Number(row.dataset.item));
    if (!item) return;
    showCuentaError('');
    busy = true;
    try {
      if (btn.dataset.a === 'inc' || btn.dataset.a === 'dec') {
        const q = item.quantity + (btn.dataset.a === 'inc' ? 1 : -1);
        order = q <= 0 ? await Api.pos.removeOrderItem(order.id, item.id) : await Api.pos.updateOrderItem(order.id, item.id, { quantity: q });
      } else if (btn.dataset.a === 'del') {
        order = await Api.pos.removeOrderItem(order.id, item.id);
      } else if (btn.dataset.a === 'served') {
        await Api.pos.setItemStatus(item.id, 'servido');
        order = await Api.pos.order(order.id);
      } else if (btn.dataset.a === 'void') {
        busy = false;
        const reason = await UI.promptDialog(`¿Anular "${item.product_name}"? Ya se mandó a cocina.`, 'Motivo (obligatorio)');
        if (!reason) return;
        busy = true;
        order = await Api.pos.removeOrderItem(order.id, item.id, reason);
      }
      renderOrder();
    } catch (err) { showCuentaError(err.status === undefined ? 'Sin conexión con el servidor' : err.message); }
    finally { busy = false; }
  });

  $('cuenta-paid').addEventListener('click', async () => {
    try { order = await Api.pos.confirmOrderPayment(order.id); UI.toast('Transferencia confirmada'); renderOrder(); } catch (err) { UI.toast(err.message, 'error'); }
  });
  $('cuenta-dispatch').addEventListener('click', async () => {
    try { await Api.pos.dispatchOrder(order.id); order = await Api.pos.order(order.id); UI.toast('El cliente ve que va en camino'); renderOrder(); } catch (err) { UI.toast(err.message, 'error'); }
  });
  $('cuenta-send').addEventListener('click', async () => {
    showCuentaError('');
    try {
      const res = await Api.pos.sendOrder(order.id);
      order = res;
      UI.toast(`Ronda ${res.round} enviada a cocina (${res.sent} ${res.sent === 1 ? 'plato' : 'platos'})`);
      renderOrder();
    } catch (err) { showCuentaError(err.status === undefined ? 'Sin conexión con el servidor — no se pudo mandar a cocina' : err.message); }
  });

  $('cuenta-back').addEventListener('click', () => { order = null; window.showView('pos-mesas'); });

  async function cancelarCuenta() {
    const reason = await UI.promptDialog(`¿Cancelar la cuenta "${order.label}"? Se anula todo lo anotado y no se cobra.`, 'Motivo de la cancelación (obligatorio)');
    if (!reason) return;
    try {
      await Api.pos.cancelOrder(order.id, reason);
      UI.toast('Cuenta cancelada');
      order = null;
      window.showView('pos-mesas');
    } catch (err) { showCuentaError(err.message); }
  }

  async function moverMesa() {
    let data;
    try { data = await Api.pos.tables(); } catch (err) { showOffline(err); return; }
    const free = data.tables.filter(t => !t.order_id);
    if (!free.length) { UI.toast('No hay ninguna mesa libre', 'error'); return; }
    const modal = UI.showModal('Cambiar de mesa', `<div class="tables-grid">${free.map(t => `<button type="button" class="table-tile" data-table="${t.id}"><span class="table-name">${esc(t.name)}</span><span class="table-meta">libre</span></button>`).join('')}</div>`);
    modal.el.querySelectorAll('[data-table]').forEach(b => b.addEventListener('click', async () => {
      try {
        order = await Api.pos.updateOrder(order.id, { table_id: Number(b.dataset.table) });
        modal.close();
        renderOrder();
        UI.toast(`Ahora es ${order.label}`);
      } catch (err) { UI.toast(err.message, 'error'); }
    }));
  }

  /* Cobrar (toda la cuenta, o solo lo de un comensal) */
  $('cuenta-pay').addEventListener('click', () => cobrar());
  async function cobrar(opts = {}) {
    const pending = order.items.filter(i => i.status === 'pendiente').length;
    if (pending && !(await UI.confirmDialog(`Hay ${pending} ${pending === 1 ? 'plato' : 'platos'} sin mandar a cocina. ¿Cobrar igual?`))) return;
    const unpaid = order.items.filter(i => i.status !== 'anulado' && !i.sale_id);
    const lineNet = i => Number(i.unit_price) * i.quantity;
    let discount = null;
    let ultimoPago = null; try { ultimoPago = localStorage.getItem('arche_ultimo_pago'); } catch (_) {}
    const pagoInicial = order.payment_method || (AppLocale.payments().includes(ultimoPago) ? ultimoPago : AppLocale.payments()[0]);
    let recibido = null, totalActual = 0;
    const modal = UI.showModal(`Cobrar · ${esc(order.label)}`, `
      <div class="pay-total" id="pay-total"></div>
      <p class="muted" style="text-align:center;margin-top:-6px" id="pay-detail"></p>
      ${unpaid.length > 1 ? `<details class="pay-split"${opts.dividir ? ' open' : ''}><summary>Dividir la cuenta — cobrar solo algunos platos</summary>
        <p class="muted" style="margin:6px 0">Marca lo que paga esta persona; el resto queda abierto para los demás.</p>
        ${unpaid.map(i => `<label class="opts-option"><input type="checkbox" data-item="${i.id}"${opts.dividir ? '' : ' checked'}><span class="opts-option-name">${i.quantity} x ${esc(i.product_name)}${(i.modifiers || []).length ? ` <span class="muted">(+ ${i.modifiers.map(m => esc(m.option)).join(', ')})</span>` : ''}</span><span class="opts-option-price">${fmt(lineNet(i))}</span></label>`).join('')}
      </details>` : ''}
      <div class="row" style="justify-content:center;gap:8px;margin-bottom:8px"><button type="button" class="btn btn-sm" id="pay-discount">Descuento…</button><button type="button" class="btn btn-sm" id="pay-discount-clear" hidden>Quitar descuento</button></div>
      <!-- v3.13: mismo cobro que la venta rápida (pago en botones, vuelto, cliente plegado). -->
      <div class="cobro-block"><p class="cobro-label">Forma de pago</p><div class="pay-buttons" id="pay-btns" role="radiogroup"></div>
        <select id="pay-method" class="lx-sr" tabindex="-1" aria-hidden="true">${AppLocale.payments().map(m => `<option ${pagoInicial === m ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select></div>
      <div class="cobro-block" id="pay-efectivo"><p class="cobro-label">¿Con cuánto paga?</p><div class="cash-chips" id="pay-cash"></div>
        <input type="number" id="pay-recibido" class="cash-otro" inputmode="decimal" min="0" step="1" placeholder="Otro monto" hidden>
        <div class="vuelto" id="pay-vuelto" hidden><span id="pay-vuelto-l">Vuelto</span><strong id="pay-vuelto-m"></strong></div></div>
      <div class="cobro-extras"><button type="button" class="chip" id="pay-toggle-cliente">${order.customer_name ? '− Cliente' : '+ Cliente'}</button></div>
      <div id="pay-cliente" ${order.customer_name ? '' : 'hidden'}>
        <div class="field"><label for="pay-phone">Teléfono del cliente (opcional)</label><input type="text" id="pay-phone" inputmode="numeric" placeholder="ej. 8095551234"></div>
        <div class="field"><label for="pay-name">Cliente (opcional)</label><input type="text" id="pay-name" value="${esc(order.customer_name || '')}"></div>
      </div>
      <div class="error" id="pay-error" role="alert" hidden></div>
      <div class="modal-actions" style="margin-top:16px">
        <button class="btn" id="pay-cancel">Volver</button>
        <button class="btn btn-primary" id="pay-ok">Confirmar cobro</button>
      </div>`);
    const el = modal.el;
    const selected = () => unpaid.length > 1 ? Array.from(el.querySelectorAll('[data-item]:checked')).map(c => Number(c.dataset.item)) : unpaid.map(i => i.id);
    function refresh() {
      const ids = new Set(selected());
      const amt = PosMenu.computeAmounts(unpaid.filter(i => ids.has(i.id)).map(i => ({ subtotal: lineNet(i), rate: PosMenu.rateOf(i.product_id) })), discount);
      const { net, itbis, tip } = amt;
      const closes = ids.size === unpaid.length;
      const fee = closes && order.source === 'web' ? Number(order.delivery_fee) || 0 : 0;
      el.querySelector('#pay-total').textContent = fmt(net + itbis + tip + fee);
      el.querySelector('#pay-detail').textContent = itbis || tip || fee || amt.discount ? `Subtotal ${fmt(amt.gross)}${amt.discount ? ` · Descuento -${fmt(amt.discount)}` : ''}${itbis ? ` · ITBIS ${fmt(itbis)}` : ''}${tip ? ` · Propina ${fmt(tip)}` : ''}${fee ? ` · Delivery ${fmt(fee)}` : ''}` : 'Sin impuestos';
      el.querySelector('#pay-discount-clear').hidden = !discount;
      el.querySelector('#pay-ok').disabled = !ids.size;
      totalActual = net + itbis + tip + fee;
      el.querySelector('#pay-ok').textContent = ids.size ? `Cobrar ${fmt(totalActual)}` : 'Confirmar cobro';
      pintarPago();
    }
    // Pago en botones + «¿con cuánto paga?» (igual que pos.js).
    const esEfectivo = m => /efectivo|cash/i.test(m || '');
    const billetes = t => { const b = [50, 100, 200, 500, 1000, 2000].filter(x => x > t).slice(0, 3); for (let k = Math.ceil((t + 1) / 1000) * 1000; b.length < 3; k += 1000) if (!b.includes(k) && k > t) b.push(k); return b; };
    function pintarPago() {
      const metodo = el.querySelector('#pay-method').value;
      el.querySelector('#pay-btns').innerHTML = AppLocale.payments().map(m => `<button type="button" class="pay-btn${m === metodo ? ' is-active' : ''}" data-pay="${esc(m)}">${esc(m)}</button>`).join('');
      const efe = esEfectivo(metodo) && totalActual > 0;
      el.querySelector('#pay-efectivo').hidden = !efe;
      if (!efe) return;
      const ops = billetes(totalActual);
      el.querySelector('#pay-cash').innerHTML = `<button type="button" class="cash-chip${recibido === null ? ' is-active' : ''}" data-cash="exacto">Exacto</button>` +
        ops.map(v => `<button type="button" class="cash-chip${recibido === v ? ' is-active' : ''}" data-cash="${v}">${fmt(v)}</button>`).join('') +
        `<button type="button" class="cash-chip${recibido !== null && !ops.includes(recibido) ? ' is-active' : ''}" data-cash="otro">Otro</button>`;
      const vu = el.querySelector('#pay-vuelto');
      vu.hidden = recibido === null;
      if (recibido === null) return;
      const diff = Math.round((recibido - totalActual) * 100) / 100;
      vu.classList.toggle('is-short', diff < 0);
      el.querySelector('#pay-vuelto-l').textContent = diff < 0 ? 'Faltan' : 'Vuelto';
      el.querySelector('#pay-vuelto-m').textContent = fmt(Math.abs(diff));
    }
    el.querySelector('#pay-btns').addEventListener('click', e => {
      const b = e.target.closest('[data-pay]'); if (!b) return;
      el.querySelector('#pay-method').value = b.dataset.pay;
      try { localStorage.setItem('arche_ultimo_pago', b.dataset.pay); } catch (_) {}
      if (/fiado|cr[eé]dito/i.test(b.dataset.pay)) { el.querySelector('#pay-cliente').hidden = false; el.querySelector('#pay-toggle-cliente').textContent = '− Cliente'; }
      pintarPago();
    });
    el.querySelector('#pay-cash').addEventListener('click', e => {
      const b = e.target.closest('[data-cash]'); if (!b) return;
      const inp = el.querySelector('#pay-recibido');
      if (b.dataset.cash === 'otro') { inp.hidden = false; inp.focus(); recibido = Number(inp.value) > 0 ? Number(inp.value) : null; }
      else { inp.hidden = true; inp.value = ''; recibido = b.dataset.cash === 'exacto' ? null : Number(b.dataset.cash); }
      pintarPago();
    });
    el.querySelector('#pay-recibido').addEventListener('input', e => { recibido = Number(e.target.value) > 0 ? Number(e.target.value) : null; pintarPago(); e.stopPropagation(); });
    el.querySelector('#pay-toggle-cliente').addEventListener('click', ev => {
      const box = el.querySelector('#pay-cliente'); box.hidden = !box.hidden;
      ev.currentTarget.textContent = box.hidden ? '+ Cliente' : '− Cliente';
    });
    el.addEventListener('change', e => { if (e.target.matches('[data-item]')) refresh(); e.stopPropagation(); });
    refresh();
    el.querySelector('#pay-discount').addEventListener('click', async () => { const d = await PosMenu.askDiscount(discount); if (d) { discount = d; refresh(); } });
    el.querySelector('#pay-discount-clear').addEventListener('click', () => { discount = null; refresh(); });
    el.querySelector('#pay-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#pay-ok').addEventListener('click', async ev => {
      const btn = ev.currentTarget;
      const metodoCobro = el.querySelector('#pay-method').value;
      if (esEfectivo(metodoCobro) && recibido !== null && recibido < totalActual) {
        const box = el.querySelector('#pay-error');
        box.textContent = `Con ${fmt(recibido)} no alcanza: el total es ${fmt(totalActual)}. Elige otro monto o «Exacto».`;
        box.hidden = false;
        return;
      }
      const vueltoCobro = esEfectivo(metodoCobro) && recibido !== null ? { recibido, vuelto: Math.round((recibido - totalActual) * 100) / 100 } : null;
      const phone = el.querySelector('#pay-phone').value.replace(/\D/g, '');
      const ids = selected();
      const all = ids.length === unpaid.length;
      btn.disabled = true;
      try {
        const sale = await Api.pos.payOrder(order.id, {
          ...(all ? {} : { item_ids: ids }),
          ...(discount ? { discount } : {}),
          payment_method: el.querySelector('#pay-method').value,
          customer_name: el.querySelector('#pay-name').value.trim() || null,
          customer_phone: phone ? (phone.length === 11 && phone.startsWith('1') ? phone : `1${phone}`) : null
        });
        modal.close();
        if (sale.order_closed) { order = null; window.showView('pos-mesas'); }
        else { order = await Api.pos.order(order.id); renderOrder(); }
        const telWa = phone ? (phone.length === 11 && phone.startsWith('1') ? phone : `1${phone}`) : '';
        const done = UI.showModal(sale.order_closed ? 'Cuenta cobrada' : 'Cobrado — la cuenta sigue abierta', `${vueltoCobro ? `<p class="recibo-vuelto">Recibido ${fmt(vueltoCobro.recibido)} · <strong>Vuelto ${fmt(vueltoCobro.vuelto)}</strong></p>` : ''}<pre class="recibo-pre">${esc(sale.receipt || '')}</pre>
          ${sale.order_closed ? '' : `<p class="muted">Quedan ${sale.remaining_items} ${sale.remaining_items === 1 ? 'plato' : 'platos'} por cobrar en esta cuenta.</p>`}
          <div class="modal-actions"><button class="btn btn-primary" id="rc-close">Listo</button><button class="btn" id="rc-print">Imprimir</button><a class="btn btn-wa" href="https://wa.me/${telWa}?text=${encodeURIComponent(sale.receipt || '')}" target="_blank" rel="noopener">WhatsApp</a></div>`);
        done.el.querySelector('#rc-print').addEventListener('click', () => { const win = openReceiptWindow(true); fillReceiptWindow(win, sale.receipt); });
        done.el.querySelector('#rc-close').addEventListener('click', () => done.close());
      } catch (err) {
        const box = el.querySelector('#pay-error');
        box.textContent = err.status === undefined ? 'Sin conexión con el servidor — no se cobró. Prueba de nuevo.' : err.message;
        box.hidden = false;
        btn.disabled = false;
      }
    });
  }

  /* ═══════════ COCINA ═══════════ */
  let kitchenItems = [];
  let lastNewCount = null;
  let audioCtx = null;

  function beep() {
    if (!$('cocina-sonido').checked) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.4, audioCtx.currentTime + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.6);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(); o.stop(audioCtx.currentTime + 0.65);
    } catch (_) { /* el navegador bloqueó el audio hasta que alguien toque la pantalla */ }
  }

  function groupTickets(items) {
    const map = new Map();
    items.forEach(i => {
      const key = `${i.order_id}:${i.round}`;
      if (!map.has(key)) map.set(key, { key, order_id: i.order_id, round: i.round, label: i.label, sent_at: i.sent_at, employee: i.employee_name, items: [] });
      map.get(key).items.push(i);
    });
    return [...map.values()].sort((a, b) => new Date(a.sent_at) - new Date(b.sent_at));
  }

  function ticketHtml(t, ready) {
    const hasNew = t.items.some(i => i.status === 'nuevo');
    const estado = ready ? 'listo' : hasNew && !t.items.some(i => i.status === 'preparando' || i.status === 'listo') ? 'nueva' : 'preparando';
    const desdeListo = ready ? t.items.map(i => i.ready_at).filter(Boolean).sort().pop() : null;
    const mins = minutesSince(desdeListo || t.sent_at);
    const late = !ready && mins >= 15, slow = !ready && mins >= 8;
    const pill = { nueva: 'Nueva', preparando: 'Preparando', listo: 'Listo' }[estado];
    const boton = { nueva: '<button type="button" class="btn btn-primary" data-k="start">Empezar</button>',
      preparando: '<button type="button" class="btn" data-k="ready">Listo</button>',
      listo: '<button type="button" class="btn k-entregar" data-k="served">Entregado</button>' }[estado];
    return `<article class="kitchen-ticket k-${estado}${late ? ' is-late' : slow ? ' is-slow' : ''}" data-key="${t.key}" data-order="${t.order_id}" data-round="${t.round}">
      <header><strong>${esc(t.label)}</strong><span class="ticket-time" data-sent="${desdeListo || t.sent_at}" data-pill="${pill}">${pill} · ${duracion(desdeListo || t.sent_at)}</span></header>
      <div class="ticket-sub">Ronda ${t.round}${t.employee ? ` · ${esc(t.employee)}` : ''}</div>
      <ul>${t.items.map(i => `
        <li class="ticket-item is-${i.status}" data-id="${i.id}" data-status="${i.status}"${ready ? '' : ' role="button" tabindex="0" title="Tocar: cambia el estado de este plato"'}>
          <span class="ticket-qty">${i.quantity}×</span>
          <span class="ticket-name">${esc(i.product_name)}${[...(i.modifiers || []).map(m => esc(m.option)), i.note ? esc(i.note) : ''].filter(Boolean).length ? `<em>${[...(i.modifiers || []).map(m => esc(m.option)), i.note ? esc(i.note) : ''].filter(Boolean).join(' · ')}</em>` : ''}</span>
          ${ready ? '' : `<span class="ticket-state" aria-hidden="true">${i.status === 'listo' ? '✓' : ''}</span>`}
        </li>`).join('')}
      </ul>
      <footer>${boton}</footer>
    </article>`;
  }

  let filtroCocina = 'todas';
  function renderKitchen() {
    const active = kitchenItems.filter(i => i.status === 'nuevo' || i.status === 'preparando');
    const readyOnly = kitchenItems.filter(i => i.status === 'listo');
    // Una comanda sigue en el tablero mientras le quede algún plato por hacer;
    // sus platos ya listos se ven tachados adentro.
    const activeKeys = new Set(active.map(i => `${i.order_id}:${i.round}`));
    const boardItems = kitchenItems.filter(i => activeKeys.has(`${i.order_id}:${i.round}`));
    const readyItems = readyOnly.filter(i => !activeKeys.has(`${i.order_id}:${i.round}`));
    const enCurso = groupTickets(boardItems), listas = groupTickets(readyItems);
    cocinaBoard.innerHTML = [...(filtroCocina !== 'listas' ? enCurso.map(t => ticketHtml(t, false)) : []), ...(filtroCocina !== 'curso' ? listas.map(t => ticketHtml(t, true)) : [])].join('');
    cocinaListos.innerHTML = '';
    $('cocina-vacio').hidden = cocinaBoard.innerHTML !== '';
    $('cocina-vacio').textContent = filtroCocina === 'listas' ? 'No hay comandas listas esperando al mesero.' : 'No hay nada en preparación. Cuando manden una comanda, aparece acá sola.';
    $('cocina-listos-title').hidden = true;
    const vieja = enCurso.length ? duracion(enCurso[0].sent_at) : '';
    $('cocina-resumen').textContent = enCurso.length || listas.length
      ? [enCurso.length ? `${enCurso.length} ${enCurso.length === 1 ? 'comanda' : 'comandas'} en curso · la más vieja lleva ${vieja}` : 'Nada en preparación', listas.length ? `${listas.length} ${listas.length === 1 ? 'lista' : 'listas'} para entregar` : ''].filter(Boolean).join(' · ')
      : '';
  }
  $('cocina-filtro').addEventListener('click', e => {
    const b = e.target.closest('[data-f]'); if (!b) return;
    filtroCocina = b.dataset.f;
    $('cocina-filtro').querySelectorAll('[data-f]').forEach(x => { const on = x === b; x.classList.toggle('is-active', on); x.setAttribute('aria-selected', String(on)); });
    renderKitchen();
  });
  cocinaBoard.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.closest('.ticket-item[role="button"]')) { e.preventDefault(); e.target.click(); } });

  cocinaBoard.addEventListener('click', async e => {
    const ticket = e.target.closest('.kitchen-ticket');
    if (!ticket) return;
    const btn = e.target.closest('[data-k]');
    const li = e.target.closest('.ticket-item');
    try {
      if (btn) {
        await Api.pos.setRoundStatus(Number(ticket.dataset.order), Number(ticket.dataset.round), { start: 'preparando', ready: 'listo', served: 'servido' }[btn.dataset.k]);
      } else if (li && li.getAttribute('role') === 'button') {
        // Tocar un plato: nuevo → preparando → listo (y de listo, vuelve a preparando).
        const next = { nuevo: 'preparando', preparando: 'listo', listo: 'preparando' }[li.dataset.status];
        if (next) await Api.pos.setItemStatus(Number(li.dataset.id), next);
      } else return;
      await pollKitchen(true);
    } catch (err) { showOffline(err); }
  });

  /* ═══════════ Actualización automática y avisos ═══════════ */
  const badgeMesas = $('nav-badge-mesas');
  const badgeCocina = $('nav-badge-cocina');
  function setBadge(el, n, label) {
    el.textContent = String(n);
    el.hidden = n === 0;
    el.setAttribute('aria-label', `${n} ${label}`);
  }

  // `force`: al entrar a una pantalla se actualiza siempre; el intervalo
  // automático, en cambio, descansa cuando la pestaña no se está mirando.
  async function pollKitchen(force) {
    if (!isPos() || (document.hidden && force !== true) || $('cart-app').hidden) return;
    if (!Modules.enabled('cocina')) return;
    try {
      kitchenItems = await Api.pos.kitchen();
    } catch (_) { return; }   // sin señal/servidor: se queda con lo último que se vio
    const nuevos = kitchenItems.filter(i => i.status === 'nuevo').length;
    const listos = kitchenItems.filter(i => i.status === 'listo').length;
    setBadge(badgeCocina, nuevos, 'platos nuevos en cocina');
    setBadge(badgeMesas, listos, 'platos listos para servir');
    if (lastNewCount !== null && nuevos > lastNewCount) beep();
    lastNewCount = nuevos;
    if (currentView === 'pos-cocina') renderKitchen();
    if (currentView === 'pos-cuenta' && order && !busy) refreshOrderQuietly();
  }

  // La cuenta abierta se refresca sola para ver cuándo un plato queda listo,
  // sin pisar lo que el mesero está tocando en ese momento.
  async function refreshOrderQuietly() {
    try {
      const fresh = await Api.pos.order(order.id);
      if (JSON.stringify(fresh.items) !== JSON.stringify(order.items)) { order = fresh; renderOrder(); }
    } catch (_) { /* ignorar */ }
  }

  setInterval(pollKitchen, 5000);
  // Los minutos de cada comanda avanzan sin volver a pedir nada al servidor.
  setInterval(() => {
    document.querySelectorAll('.ticket-time').forEach(el => { el.textContent = `${el.dataset.pill} · ${duracion(el.dataset.sent)}`; });
  }, 20000);

  window.addEventListener('view:show', e => {
    currentView = e.detail.view;
    if (!isPos()) return;
    if (currentView === 'pos-mesas') { order = null; renderTables(); pollKitchen(true); }
    if (currentView === 'pos-cocina') { renderKitchen(); pollKitchen(true); }
  });
  // Mesas se refresca sola mientras se mira (otra tablet pudo abrir/cerrar cuentas).
  setInterval(() => { if (currentView === 'pos-mesas' && isPos() && !document.hidden) renderTables(); }, 8000);
  pollKitchen(true);
})();
