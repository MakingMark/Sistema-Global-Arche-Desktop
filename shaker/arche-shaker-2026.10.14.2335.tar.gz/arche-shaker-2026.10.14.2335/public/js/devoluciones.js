/* ═══ Devolución de una venta (nota de crédito) ═══
   La usan el Historial del dueño y el del punto de venta. `api` trae la venta y registra la devolución. */
const Devoluciones = (function () {
  'use strict';
  const esc = UI.escapeHtml;

  // api: { detail(id) → venta con items[].returned_quantity, submit(id, body) → nota de crédito }
  async function open(saleId, api, onDone) {
    let sale;
    try { sale = await api.detail(saleId); } catch (err) { UI.toast(err.message, 'error'); return; }
    if (sale.status === 'anulada') { UI.toast('La venta está anulada: no se puede devolver', 'error'); return; }
    if (sale.return_of) { UI.toast('Eso ya es una devolución', 'error'); return; }
    const lines = sale.items.map(i => ({ ...i, left: Number(i.quantity) - Number(i.returned_quantity || 0) })).filter(i => i.left > 1e-9);
    if (!lines.length) { UI.toast('Todo lo de esta venta ya fue devuelto', 'error'); return; }
    const methods = AppLocale.payments().filter(m => !/^fiado$/i.test(m));
    // v4: hoja agrupada. Cada producto con su círculo para marcar y la cantidad con − y +; motivos de un
    // toque; abajo, cuánto se devuelve más o menos (el monto exacto, con descuento e ITBIS, lo da el servidor).
    const porUnidad = i => (Number(i.quantity) > 0 ? Number(i.subtotal) / Number(i.quantity) : 0);
    const cuando = sale.created_at ? new Date(sale.created_at).toLocaleString('es-DO', { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }).replace(/([a-zé]{3})\.(?= )/g, '$1') : '';
    const modal = UI.showModal('Devolver productos', `<div class="pf dv">
      <div class="an-resumen"><span class="an-num">Venta #${sale.id}</span><b class="an-total">${fmt(sale.amount_due != null ? sale.amount_due : sale.total)}</b>
        <span class="an-meta">${esc(cuando)}${sale.payment_method ? ' · ' + esc(sale.payment_method) : ''}</span></div>
      <div class="pf-sec">Qué se devuelve</div>
      <div class="pf-grupo">${lines.map(i => `
        <div class="pf-fila dv-linea">
          <input type="checkbox" class="pf-check" data-line="${i.id}" aria-label="Devolver ${esc(i.product_name)}">
          <span class="dv-nombre"><b>${esc(i.product_name)}</b><small>${fmtNum(i.left)} vendido${i.left === 1 ? '' : 's'} · ${fmt(porUnidad(i))} c/u</small></span>
          <span class="dv-paso"><button type="button" data-menos="${i.id}" aria-label="Menos">−</button>
            <input type="number" class="return-qty" data-qty="${i.id}" min="0.001" max="${i.left}" step="any" value="${i.left}" inputmode="decimal" aria-label="Cantidad a devolver">
            <button type="button" data-mas="${i.id}" aria-label="Más">+</button></span>
        </div>`).join('')}</div>
      <div class="pf-sec">Motivo</div>
      <div class="an-chips" role="group" aria-label="Motivos rápidos">${['Llegó defectuoso', 'No le gustó', 'Producto equivocado', 'Se cobró de más'].map(m => `<button type="button" class="an-chip">${m}</button>`).join('')}</div>
      <div class="pf-grupo"><label class="pf-fila pf-col"><span>Escríbelo o toca uno de arriba</span><input id="ret-reason" maxlength="200" placeholder="ej. defectuoso, no le quedó"></label></div>
      <div class="pf-sec">Cómo queda</div>
      <div class="pf-grupo">
        <label class="pf-fila"><span>Se le devuelve en</span><select id="ret-method"><option value="">Igual que pagó${sale.payment_method ? ` (${esc(sale.payment_method)})` : ''}</option>${methods.map(m => `<option>${esc(m)}</option>`).join('')}</select></label>
        <label class="pf-fila"><span>Vuelve al inventario<small>Solo si se puede volver a vender</small></span><input type="checkbox" class="pf-sw" id="ret-restock"></label>
      </div>
      <div class="pf-calc" id="ret-calc"></div>
      <div class="error" id="ret-error" role="alert" hidden></div>
      <div class="pf-acciones"><button class="btn" id="ret-cancel">Cancelar</button><button class="btn btn-primary" id="ret-ok">Registrar devolución</button></div>
    </div>`);
    const el = modal.el;
    const calc = () => {
      const marcados = lines.filter(i => el.querySelector(`[data-line="${i.id}"]`).checked);
      const monto = marcados.reduce((t, i) => t + porUnidad(i) * (Number(el.querySelector(`[data-qty="${i.id}"]`).value) || 0), 0);
      el.querySelector('#ret-calc').innerHTML = marcados.length
        ? `<div><small>Productos</small><b>${marcados.length}</b></div><div><small>Se devuelve aprox.</small><b>${fmt(monto)}</b><span>con su descuento e ITBIS</span></div>` : '';
      el.querySelector('#ret-ok').textContent = marcados.length ? `Devolver ${fmt(monto)}` : 'Registrar devolución';
    };
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-menos],[data-mas]'); if (!b) return;
      const id = b.dataset.menos || b.dataset.mas, inp = el.querySelector(`[data-qty="${id}"]`), max = Number(inp.max);
      inp.value = Unidades.redondear(Math.min(max, Math.max(1, (Number(inp.value) || 0) + (b.dataset.mas ? 1 : -1))), 3);
      el.querySelector(`[data-line="${id}"]`).checked = true; calc();
    });
    el.addEventListener('input', e => { if (e.target.matches('.return-qty')) el.querySelector(`[data-line="${e.target.dataset.qty}"]`).checked = true; calc(); });
    el.addEventListener('change', calc);
    const motivo = el.querySelector('#ret-reason');
    el.querySelectorAll('.an-chip').forEach(c => c.addEventListener('click', () => { motivo.value = c.textContent; el.querySelectorAll('.an-chip').forEach(x => x.classList.toggle('is-on', x === c)); }));
    calc();
    el.querySelector('#ret-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#ret-ok').addEventListener('click', async ev => {
      const err = el.querySelector('#ret-error');
      err.hidden = true;
      const items = Array.from(el.querySelectorAll('[data-line]:checked')).map(c => ({ sale_item_id: Number(c.dataset.line), quantity: Number(el.querySelector(`[data-qty="${c.dataset.line}"]`).value) }));
      const reason = el.querySelector('#ret-reason').value.trim();
      if (!items.length) { err.textContent = 'Marca al menos un producto'; err.hidden = false; return; }
      if (items.some(i => !(i.quantity > 0))) { err.textContent = 'Revisa las cantidades'; err.hidden = false; return; }
      if (!reason) { err.textContent = 'Escribe el motivo de la devolución'; err.hidden = false; return; }
      const btn = ev.currentTarget; btn.disabled = true;
      try {
        const ret = await api.submit(saleId, { items, reason, refund_method: el.querySelector('#ret-method').value || undefined, restock: el.querySelector('#ret-restock').checked });
        modal.close();
        const done = UI.showModal('Devolución registrada', `<pre class="recibo-pre">${esc(ret.receipt || '')}</pre>
          <div class="modal-actions"><button class="btn btn-primary" id="rd-print">Imprimir</button><button class="btn" id="rd-close">Cerrar</button></div>`);
        done.el.querySelector('#rd-print').addEventListener('click', () => { const win = openReceiptWindow(true); fillReceiptWindow(win, ret.receipt); });
        done.el.querySelector('#rd-close').addEventListener('click', () => done.close());
        if (onDone) onDone(ret);
      } catch (e) {
        err.textContent = e.status === undefined ? 'Sin conexión — no se registró. Prueba de nuevo.' : e.message;
        err.hidden = false; btn.disabled = false;
      }
    });
  }
  return { open };
})();
