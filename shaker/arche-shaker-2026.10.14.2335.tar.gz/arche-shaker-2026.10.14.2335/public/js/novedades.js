/* ═══ Novedades: lo nuevo de cada actualización, contado como mejoras ═══
   Después de cada actualización el dueño ve, una sola vez, una hoja con las mejoras (cada una entra
   con una animación suave). En el login aparece «✨ Nuevas mejoras» mientras no las haya visto.
   El contenido vive en /novedades.json (la más nueva primero); se marca como vista por equipo
   (localStorage), así que no molesta de nuevo. Se puede volver a abrir con Novedades.abrir(). */
(function () {
  'use strict';
  const CLAVE = 'arche_novedades_vista';
  const leer = () => { try { return localStorage.getItem(CLAVE) || ''; } catch (_) { return ''; } };
  const marcar = id => { try { localStorage.setItem(CLAVE, id); } catch (_) {} };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const ICONOS = {
    balanza: '<path d="M12 3v18M7 21h10M5 7h14M5 7l-3 7a3 3 0 0 0 6 0L5 7zm14 0l-3 7a3 3 0 0 0 6 0l-3-7"/>',
    receta: '<path d="M6 3h9l3 3v15H6z"/><path d="M9 10h6M9 14h6M9 18h4"/>',
    lonjas: '<path d="M4 15l8-10 8 10z"/><circle cx="10" cy="12" r="1.2"/><circle cx="14" cy="13.5" r="1"/><path d="M4 15v3h16v-3"/>',
    escudo: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
    nube: '<path d="M7 18a4 4 0 0 1-.5-8 6 6 0 0 1 11.5 1.5A3.5 3.5 0 0 1 17.5 18z"/><path d="M12 11v5M9.5 13.5L12 16l2.5-2.5"/>',
    mesa: '<path d="M4 9h16M6 9v10M18 9v10M8 13h8"/><path d="M7 9l1.5-4h7L17 9"/>',
    caja: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18M7 15h3"/>',
    estrella: '<path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.4 6.7 19.4l1.2-6L3.4 9.3l6-.7z"/>'
  };
  const icono = n => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONOS[n] || ICONOS.estrella}</svg>`;

  let datos = null;
  async function cargar() {
    if (datos) return datos;
    try { const r = await fetch('/novedades.json', { cache: 'no-store' }); datos = r.ok ? await r.json() : []; } catch (_) { datos = []; }
    return datos;
  }
  const pendiente = lista => (lista[0] && lista[0].id !== leer() ? lista[0] : null);

  function abrir(n, noche) {
    const fecha = n.fecha ? new Date(n.fecha + 'T12:00:00').toLocaleDateString('es-DO', { day: 'numeric', month: 'short', year: 'numeric' }).replace('.', '') : '';
    const html = `<div class="nov">
      <div class="nov-cab"><span class="nov-chispa">${icono('estrella')}</span>
        <div><span class="nov-marca">Arche · Novedades${fecha ? ` · ${esc(fecha)}` : ''}</span><h3>${esc(n.titulo)}</h3></div></div>
      ${n.intro ? `<p class="nov-intro">${esc(n.intro)}</p>` : ''}
      <ul class="nov-lista">${n.puntos.map((p, i) => `<li style="--i:${i}"><span class="nov-ic">${icono(p.icono)}</span>
        <div><b>${esc(p.titulo)}</b><p>${esc(p.texto)}</p></div></li>`).join('')}</ul>
      <p class="nov-firma">${esc(n.firma || 'Arche crece con tu negocio.')}</p>
      <button type="button" class="btn btn-primary nov-ok">Entendido</button>
    </div>`;
    const modal = UI.showModal('Lo nuevo en Arche', html, { onClose: () => marcar(n.id) });
    modal.el.classList.add('nov-modal');
    if (noche) modal.el.classList.add('nov-modal--noche');
    modal.el.querySelector('.nov-ok').addEventListener('click', () => { marcar(n.id); modal.close(); });
    const pill = document.getElementById('nov-pill'); if (pill) pill.hidden = true;
  }

  // Login (propuesta B): en la computadora, la tarjeta «Lo nuevo en Arche» con las mejoras en lista y «Ver todo»;
  // en el celular, la cápsula «3 nuevas» arriba. Las dos abren la hoja.
  // El login las muestra mientras no se hayan visto Y, aunque ya se vieran, durante 14 días desde la fecha de la
  // versión (antes desaparecían en cuanto alguien tocaba «Entendido», y quien entraba después no se enteraba).
  const DIAS_EN_LOGIN = 14;
  const reciente = n => { const f = Date.parse(n.fecha + 'T12:00:00'); return !isNaN(f) && Date.now() - f < DIAS_EN_LOGIN * 864e5; };
  async function pillLogin() {
    const lista0 = await cargar();
    const n = pendiente(lista0) || (lista0[0] && reciente(lista0[0]) ? lista0[0] : null);
    if (!n) return;
    const nueva = !!pendiente(lista0);
    const tarjeta = document.getElementById('ln-nov'), cap = document.getElementById('ln-nov-cap');
    if (tarjeta && cap) {
      const abrirLogin = () => abrir(n);
      cap.querySelector('.ln-nov-cap-t').textContent = !nueva ? 'Novedades' : n.puntos.length === 1 ? '1 nueva' : `${n.puntos.length} nuevas`;
      cap.hidden = false; cap.onclick = abrirLogin;
      const lista = n.puntos.slice(0, 3);
      tarjeta.innerHTML = `<div class="ln-nov-cab"><b>Lo nuevo en Arche${n.version ? ` · <span class="ln-nov-ver">${esc(n.version)}</span>` : ''}</b><button type="button" class="ln-nov-todo">Ver todo</button></div>
        ${lista.map(p => `<div class="ln-nov-it"><span class="ln-nov-ic">${icono(p.icono)}</span><span class="ln-nov-tx"><b>${esc(p.titulo)}</b><span>${esc(p.texto)}</span></span></div>`).join('')}`;
      tarjeta.querySelector('.ln-nov-todo').onclick = abrirLogin;
      tarjeta.hidden = false;
      return;
    }
    const saludo = document.getElementById('login-greeting');
    if (!saludo || document.getElementById('nov-pill')) return;
    const b = document.createElement('button');
    b.type = 'button'; b.id = 'nov-pill'; b.className = 'nov-pill';
    b.innerHTML = `${icono('estrella')}<span>Nuevas mejoras</span>`;
    b.addEventListener('click', () => abrir(n));
    saludo.insertAdjacentElement('beforebegin', b);
  }

  // Dentro del sistema: el dueño la ve sola una vez, un momento después de entrar.
  async function alEntrar() {
    const s = typeof Auth !== 'undefined' && Auth.get ? Auth.get() : null;
    if (!s || s.role !== 'owner') return;
    const n = pendiente(await cargar());
    if (n) setTimeout(() => abrir(n), 1200);
  }

  window.Novedades = { abrir: async () => { const l = await cargar(); if (l[0]) abrir(l[0]); } };
  const iniciar = () => { pillLogin(); alEntrar(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
