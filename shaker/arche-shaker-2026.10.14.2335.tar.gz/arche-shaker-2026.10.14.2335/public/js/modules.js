/* ═══ Módulos: qué partes del sistema usa este negocio ═══
   Lista que viene del servidor (Configuración → Módulos). Lo apagado se
   esconde del menú y de las pantallas; el servidor además cierra sus rutas.
   Se guarda la última lista en el navegador para no parpadear al cargar. */
(function () {
  'use strict';
  const KEY = 'modules_v1';
  // Pantalla → módulo que la maneja (las que no aparecen son del núcleo).
  const VIEW_MODULE = {
    'pos-mesas': 'mesas', 'pos-cuenta': 'mesas', salon: 'mesas', 'pos-cocina': 'cocina', 'pos-web': 'pedidos_directos', 'pos-caja': 'caja', 'pos-restock': 'transferencias',
    'inv-existencias': 'insumos', 'inv-entradas': 'insumos', 'inv-ajustes': 'insumos', insumos: 'insumos',
    'inv-preparar': 'preparar', 'inv-transferir': 'transferencias',
    reportes: 'reportes', gastos: 'gastos', analitica: 'tendencias', ofertas: 'ofertas', pagina: 'pagina',
    ubicaciones: 'ubicaciones', turnos: 'turnos', clientes: 'clientes', compras: 'proveedores'
  };
  let map = {};
  try { map = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (_) {}

  const enabled = id => !id || map[id] !== false;
  const viewOff = view => !enabled(VIEW_MODULE[view]);
  const isSingleLocation = () => !enabled('ubicaciones');

  function applyTo(root) {
    (root || document).querySelectorAll('[data-module]').forEach(el => {
      el.classList.toggle('mod-off', !enabled(el.dataset.module));
    });
    // Menú lateral y barras de pestañas: por la pantalla a la que llevan.
    (root || document).querySelectorAll('.nav-item[data-view]').forEach(el => {
      el.classList.toggle('mod-off', viewOff(el.dataset.view));
    });
    // Un grupo del menú sin ninguna opción visible desaparece entero.
    (root || document).querySelectorAll('.nav-group').forEach(g => {
      const items = Array.from(g.querySelectorAll('.nav-item'));
      g.classList.toggle('mod-off', items.length > 0 && items.every(i => i.classList.contains('mod-off')));
    });
  }

  function set(next) {
    if (!next || typeof next !== 'object') return;
    map = next;
    try { localStorage.setItem(KEY, JSON.stringify(map)); } catch (_) {}
    applyTo(document);
    window.dispatchEvent(new CustomEvent('modules:changed', { detail: map }));
  }

  // Con un solo local, las listas de ubicaciones muestran solo el punto de venta.
  function visibleLocations(list) {
    if (!isSingleLocation()) return list;
    const pos = list.filter(l => l.kind === 'carrito' && l.active);
    return pos.length ? [pos[0]] : list;
  }

  window.Modules = { enabled, viewOff, isSingleLocation, set, applyTo, visibleLocations, VIEW_MODULE, get: () => ({ ...map }) };

  // Lo que se agregue después (ventanas, formularios armados por script) también se ajusta.
  if (window.MutationObserver) {
    new MutationObserver(muts => {
      for (const m of muts) m.addedNodes.forEach(n => { if (n.nodeType === 1 && (n.matches('[data-module]') || n.querySelector('[data-module]'))) applyTo(n.parentNode || document); });
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
  document.addEventListener('DOMContentLoaded', () => applyTo(document));
  applyTo(document);
})();
