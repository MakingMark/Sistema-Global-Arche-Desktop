/* ═══ Hoja de conteo (inventario inicial o conteo físico) ═══
   Una sola pantalla con todos los insumos: se escribe lo que se contó y en qué medida (libra, kilo, paquete…),
   tal como se contó en la tienda. Lo que se deja en blanco no se toca. Al guardar, la existencia QUEDA en lo
   contado (no se suma) y cada cambio se anota como «ajuste». Los insumos de «control simple» no salen aquí. */
(function () {
  'use strict';
  const esc = t => UI.escapeHtml(String(t == null ? '' : t));
  const fmt = n => Number(n).toLocaleString('es-DO', { maximumFractionDigits: 2 });

  // Las medidas en que se puede contar un insumo: su unidad, sus empaques y las medidas oficiales (libra, kilo, onza…).
  function medidas(s) {
    const ops = [{ v: 'unit', t: s.unit, f: 1 }];
    const pack = (v, nombre, tam) => { if (nombre && Number(tam) > 0) ops.push({ v, t: `${nombre}${/\(/.test(nombre) ? '' : ` (${fmt(tam)} ${s.unit})`}`, f: Number(tam) }); };
    pack('pack', s.pack_name, s.pack_size);
    pack('transfer_pack', s.transfer_pack_name, s.transfer_pack_size);
    const repetida = f => [s.pack_size, s.transfer_pack_size].some(t => Number(t) > 0 && Math.abs(Number(t) - f) / f < 0.01);
    Unidades.opciones(s).filter(o => !repetida(o.factor)).forEach(o => ops.push({ v: 'conv:' + o.clave, t: o.nombre, f: o.factor }));
    return ops;
  }

  async function abrir() {
    let insumos, hay = new Map();
    try {
      const [lista, ov] = await Promise.all([Api.supplies.list(), Api.reports.stockOverview()]);
      insumos = lista.filter(s => s.active && s.control_stock !== false);
      ov.rows.forEach(r => hay.set(r.id, Object.values(r.cells).reduce((t, c) => t + Number(c.value || 0), 0)));
    } catch (e) { UI.toast(e.message, 'error'); return; }
    const filas = insumos.map(s => {
      const ops = medidas(s);
      const unica = ops.length === 1;
      if (!Unidades.enLista(s.unit)) {
        // Medida que no es del sistema: no se puede contar hasta corregirla (el servidor tampoco lo deja).
        return `<div class="cnt-fila" data-id="${s.id}" data-nombre="${esc(s.name.toLowerCase())}" data-bloqueado="1">
          <span class="cnt-nom"><b>${esc(s.name)}</b><small class="muted">Su medida «${esc(s.unit)}» no es del sistema</small></span>
          <span class="pend am" style="grid-column:2 / -1;justify-self:start">Corregir medida primero (Catálogo → Insumos → Editar)</span>
        </div>`;
      }
      return `<div class="cnt-fila" data-id="${s.id}" data-nombre="${esc(s.name.toLowerCase())}">
        <span class="cnt-nom"><b>${esc(s.name)}</b><small class="muted">Hay ahora: ${esc(Unidades.texto(hay.get(s.id) || 0, s.unit))}</small></span>
        <input class="cnt-qty" type="number" step="any" min="0" inputmode="decimal" placeholder="—" aria-label="Cuánto contaste de ${esc(s.name)}">
        <select class="cnt-med" aria-label="Medida de ${esc(s.name)}">${unica ? '' : '<option value="" selected disabled>¿en qué?</option>'}${ops.map(o => `<option value="${esc(o.v)}" data-f="${o.f}">${esc(o.t)}</option>`).join('')}</select>
        <small class="cnt-eq muted"></small>
      </div>`;
    }).join('');
    const modal = UI.showModal('Contar el inventario', `
      <label class="f" style="margin:0 0 8px"><span>¿Qué es este conteo?</span><select id="cnt-motivo"><option value="Inventario inicial">Inventario inicial (la primera vez)</option><option value="Reconteo">Reconteo (corregir lo que hay)</option></select></label>
      <p class="muted" style="margin-top:0">Escribe lo que <b>contaste</b> y en qué medida lo contaste (libras, kilos, paquetes…). Lo que dejes en blanco <b>no se toca</b>. Al guardar, la existencia queda <b>exactamente</b> en lo que escribiste.</p>
      <p class="muted" style="font-size:.85em">La sal, los sazones, el recaíto y similares ("control simple") no salen aquí: no se cuentan.</p>
      <input type="search" id="cnt-buscar" class="cnt-buscar" placeholder="Buscar insumo…" aria-label="Buscar insumo">
      <div class="cnt-lista" id="cnt-lista">${filas || '<p class="muted">No hay insumos para contar.</p>'}</div>
      <div class="modal-actions" style="margin-top:14px">
        <span class="muted" id="cnt-resumen" style="margin-right:auto">Nada escrito todavía</span>
        <button type="button" class="btn" id="cnt-cancelar">Cancelar</button>
        <button type="button" class="btn btn-primary" id="cnt-guardar" disabled>Guardar conteo</button>
      </div>`);
    const el = modal.el, lista = el.querySelector('#cnt-lista');
    const btn = el.querySelector('#cnt-guardar'), resumen = el.querySelector('#cnt-resumen');

    function pintarFila(fila) {
      const qty = fila.querySelector('.cnt-qty').value, sel = fila.querySelector('.cnt-med'), eq = fila.querySelector('.cnt-eq');
      const s = insumos.find(x => x.id === Number(fila.dataset.id));
      const opt = sel.selectedOptions[0];
      const sinMedida = qty !== '' && !(opt && opt.value);
      sel.classList.toggle('cnt-falta', sinMedida);
      if (qty === '' || sinMedida) { eq.textContent = ''; return; }
      const base = Number(qty) * Number(opt.dataset.f);
      eq.textContent = opt.value === 'unit' ? '' : `= ${Unidades.cantidad(base, s.unit)} ${s.unit}`;
    }
    function pintarResumen() {
      const escritas = [...lista.querySelectorAll('.cnt-fila:not([data-bloqueado])')].filter(f => f.querySelector('.cnt-qty').value !== '');
      const faltan = escritas.filter(f => !f.querySelector('.cnt-med').value).length;
      resumen.textContent = !escritas.length ? 'Nada escrito todavía'
        : faltan ? `${escritas.length} escritos · a ${faltan} le falta la medida` : `${escritas.length} insumo${escritas.length === 1 ? '' : 's'} para guardar`;
      resumen.style.color = faltan ? 'var(--danger, #d33)' : '';
      btn.disabled = !escritas.length || faltan > 0;
    }
    lista.addEventListener('input', e => { const f = e.target.closest('.cnt-fila'); if (f) { pintarFila(f); pintarResumen(); } });
    lista.addEventListener('change', e => { const f = e.target.closest('.cnt-fila'); if (f) { pintarFila(f); pintarResumen(); } });
    el.querySelector('#cnt-buscar').addEventListener('input', e => {
      const q = e.target.value.trim().toLowerCase();
      lista.querySelectorAll('.cnt-fila').forEach(f => { f.hidden = !!q && !f.dataset.nombre.includes(q); });
    });
    el.querySelector('#cnt-cancelar').addEventListener('click', () => modal.close());
    btn.addEventListener('click', async () => {
      const items = [...lista.querySelectorAll('.cnt-fila:not([data-bloqueado])')].filter(f => f.querySelector('.cnt-qty').value !== '')
        .map(f => ({ supply_id: Number(f.dataset.id), quantity: Number(f.querySelector('.cnt-qty').value), quantity_unit: f.querySelector('.cnt-med').value }));
      const ok = await UI.confirmDialog(`¿Guardar el conteo de ${items.length} insumo${items.length === 1 ? '' : 's'}? La existencia de cada uno queda en lo que escribiste.`);
      if (!ok) return;
      btn.disabled = true;
      try {
        const r = await Api.supplies.conteo({ items, note: el.querySelector('#cnt-motivo').value });
        modal.close();
        UI.toast(`Conteo guardado: ${r.guardados} insumo${r.guardados === 1 ? '' : 's'}. Míralos en Inventario → Existencias.`);
      } catch (err) { UI.toast(err.message, 'error'); btn.disabled = false; }
    });
  }

  function montar() {
    const sec = document.querySelector('[data-view="inv-ajustes"]');
    if (!sec || sec.querySelector('#cnt-abrir')) return;
    const h1 = sec.querySelector('h1');
    const card = document.createElement('div');
    card.className = 'card-quiet';
    card.innerHTML = `<h2>Contar el inventario</h2>
      <p class="muted" style="margin-top:-6px">Para cargar el conteo de inicio o revisar todo: una hoja con todos tus insumos, escribes lo que contaste y la medida (libra, kilo, paquete…). Lo que dejes en blanco no se toca.</p>
      <button type="button" class="btn btn-primary" id="cnt-abrir">Abrir la hoja de conteo</button>`;
    h1.insertAdjacentElement('afterend', card);
    card.querySelector('#cnt-abrir').addEventListener('click', abrir);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', montar); else montar();
})();
