/* ═══ Panel «Hoy» (rediseño v4, DISENO-ARCHE.md · propuesta 2) ═══
   Una pantalla que cuenta cómo va el día: la cifra con su gráfica acumulada contra el mismo día de la
   semana pasada (se recorre con el mouse o el dedo), las tres cifras clave con su semana, lo que necesita
   atención con su acción, «Destacados» en palabras y «Ahora mismo» (caja, turnos, pedidos en línea).
   Datos: GET /api/reports/hoy (hoyService.js) + bajo stock. Se refresca solo cada minuto si es hoy. */
(function () {
  'use strict';
  const root = document.getElementById('hoy-v4');
  if (!root) return;
  const esc = s => UI.escapeHtml(String(s == null ? '' : s));
  const reducir = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
  const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const hora12 = h => (h === 0 ? '12 a. m.' : h < 12 ? `${h} a. m.` : h === 12 ? '12 p. m.' : `${h - 12} p. m.`);
  const pct = (a, b) => (b > 0 ? Math.round(((a - b) / b) * 100) : null);
  const fechaLarga = iso => { const [y, m, d] = iso.split('-').map(Number); const f = new Date(y, m - 1, d); const t = `${DIAS[f.getDay()]} ${d} de ${MESES[m - 1]}`; return t[0].toUpperCase() + t.slice(1); };
  const svgI = (p, extra = '') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${p}</svg>`;
  const IC = {
    alerta: '<path d="M12 4L2.5 20h19z"/><path d="M12 10v4.5M12 17.5v.01"/>',
    caja: '<path d="M4 8l8-4 8 4v8l-8 4-8-4z"/><path d="M4 8l8 4 8-4M12 12v8"/>',
    moto: '<circle cx="5.5" cy="17" r="3"/><circle cx="18.5" cy="17" r="3"/><path d="M8.5 17h6l3-6h-4l-2-3H8M14 6h3"/>',
    sube: '<path d="M4 16l6-6 4 4 6-7"/><path d="M15 7h5v5"/>',
    baja: '<path d="M4 8l6 6 4-4 6 7"/><path d="M15 17h5v-5"/>',
    producto: '<path d="M6 3h12l-1.4 15.5a2 2 0 01-2 1.8H9.4a2 2 0 01-2-1.8z"/><path d="M5 8h14"/>',
    calendario: '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    chispa: '<path d="M12 2.5l1.9 5.6 5.6 1.9-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.9z" fill="currentColor" stroke="none"/>'
  };
  let estado = { dia: null, rango: null, loc: (window.V4 && V4.ubicacion) ? V4.ubicacion() : '' }, datosR = null, locs = [], datos = null, bajos = [], cargando = false, reloj = null;

  /* ── Gráfica acumulada que se recorre ── */
  function grafica(d, w, h, compacta) {
    const hoyH = d.horas.hoy, antH = d.horas.semana_pasada;
    const conVenta = i => hoyH[i] > 0 || antH[i] > 0;
    let ini = 7, fin = 21;
    for (let i = 0; i < 24; i++) if (conVenta(i)) { ini = Math.min(ini, i); break; }
    for (let i = 23; i >= 0; i--) if (conVenta(i)) { fin = Math.max(fin, i); break; }
    const horas = []; for (let i = ini; i <= fin; i++) horas.push(i);
    const acum = a => horas.reduce((r, i) => (r.push((r.length ? r[r.length - 1] : 0) + a[i]), r), []);
    const H = acum(hoyH), A = acum(antH);
    const corte = d.es_hoy ? horas.filter(i => i <= d.hora_actual).length : horas.length;
    const Hv = H.slice(0, Math.max(corte, 1));
    const max = Math.max(1, ...H, ...A) * 1.1;
    const pl = compacta ? 4 : 46, pr = 12, pt = compacta ? 34 : 40, pb = compacta ? 6 : 24;
    const X = i => pl + (i * (w - pl - pr)) / Math.max(1, horas.length - 1), Y = v => pt + (h - pt - pb) * (1 - v / max);
    const path = a => a.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`).join(' ');
    let s = `<svg class="hoy-graf" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" role="img" aria-label="Ventas acumuladas por hora, comparadas con el mismo día de la semana pasada"><defs><linearGradient id="hoy-grad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--tint)" stop-opacity=".22"/><stop offset="1" stop-color="var(--tint)" stop-opacity="0"/></linearGradient></defs>`;
    if (!compacta) {
      const paso = max > 40000 ? 10000 : max > 16000 ? 5000 : max > 6000 ? 2000 : 1000;
      for (let v = 0; v < max; v += paso) s += `<line x1="${pl}" x2="${w - pr}" y1="${Y(v)}" y2="${Y(v)}" class="hoy-eje"/><text x="${pl - 8}" y="${Y(v) + 4}" text-anchor="end" class="hoy-et">${v ? (v >= 1000 ? v / 1000 + 'k' : v) : '0'}</text>`;
      let ultX = -99; horas.forEach((hh, i) => { const x = X(i); if ((i === 0 || i === horas.length - 1 || hh % 3 === 1) && x - ultX > 52 && (i === horas.length - 1 || X(horas.length - 1) - x > 52)) { s += `<text x="${x}" y="${h - 5}" text-anchor="middle" class="hoy-et">${hora12(hh)}</text>`; ultX = x; } });
    }
    s += `<path d="${path(Hv)} L${X(Hv.length - 1)} ${Y(0)} L${X(0)} ${Y(0)}Z" fill="url(#hoy-grad)"/><path d="${path(A)}" class="hoy-ant"/><path d="${path(Hv)}" class="hoy-lin"/>`;
    s += `<g class="hoy-cursor" hidden><line class="hoy-regla" y1="${pt - 6}" y2="${h - pb}"/><circle class="hoy-pa" r="4"/><circle class="hoy-ph" r="6"/><g class="hoy-tip"><rect rx="11" height="22" y="-16"/><text y="-1" text-anchor="middle"></text></g></g></svg>`;
    return { svg: s, horas, H: Hv, A, X, Y, pt, w };
  }
  function activarCursor(cont, g) {
    const svg = cont.querySelector('svg'), cur = svg.querySelector('.hoy-cursor');
    const pon = i => {
      i = Math.max(0, Math.min(g.H.length - 1, i));
      const x = g.X(i), a = g.A[i], hv = g.H[i], p = pct(hv, a);
      cur.removeAttribute('hidden');
      cur.querySelector('.hoy-regla').setAttribute('x1', x); cur.querySelector('.hoy-regla').setAttribute('x2', x);
      const pa = cur.querySelector('.hoy-pa'), ph = cur.querySelector('.hoy-ph');
      pa.setAttribute('cx', x); pa.setAttribute('cy', g.Y(a)); ph.setAttribute('cx', x); ph.setAttribute('cy', g.Y(hv));
      const t = `${hora12(g.horas[i] + 1).replace(' ', ' ')} · ${fmt(hv)}${p === null ? '' : ` · ${p >= 0 ? '+' : ''}${p} %`}`;
      const tip = cur.querySelector('.hoy-tip'), tx = tip.querySelector('text'), rc = tip.querySelector('rect');
      tx.textContent = t; const ancho = t.length * 6.6 + 22;
      const cx = Math.max(ancho / 2 + 2, Math.min(g.w - ancho / 2 - 2, x));
      rc.setAttribute('x', -ancho / 2); rc.setAttribute('width', ancho); tip.setAttribute('transform', `translate(${cx},${g.pt - 12})`);
    };
    const mover = e => { const r = svg.getBoundingClientRect(); const fx = ((e.clientX - r.left) / r.width) * g.w; let best = 0; g.H.forEach((_, i) => { if (Math.abs(g.X(i) - fx) < Math.abs(g.X(best) - fx)) best = i; }); pon(best); };
    svg.addEventListener('pointermove', mover);
    svg.addEventListener('pointerdown', mover);
    svg.addEventListener('pointerleave', () => pon(g.H.length - 1));
    svg.style.touchAction = 'pan-y';
    pon(g.H.length - 1);
  }
  function chispa(vals, w = 92, h = 30) {
    const max = Math.max(...vals), min = Math.min(...vals), n = vals.length;
    if (n < 2 || max === min) return `<svg width="${w}" height="${h}" aria-hidden="true"><path d="M0 ${h / 2}H${w}" class="hoy-chispa"/></svg>`;
    const d = vals.map((v, i) => `${i ? 'L' : 'M'}${((i * w) / (n - 1)).toFixed(1)} ${(h - 3 - ((h - 6) * (v - min)) / (max - min)).toFixed(1)}`).join(' ');
    return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true"><path d="${d}" class="hoy-chispa"/></svg>`;
  }

  /* ── Rangos 7 días / Mes / Año: el período contra el anterior, con barras por día (o por mes en «Año») ── */
  const isoL = f => `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, '0')}-${String(f.getDate()).padStart(2, '0')}`;
  const MESES_C = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  function periodo(r) {
    const hoy = new Date(); hoy.setHours(12, 0, 0, 0);
    const mas = (f, n) => { const x = new Date(f); x.setDate(x.getDate() + n); return x; };
    if (r === '7') return { from: isoL(mas(hoy, -6)), to: isoL(hoy), pFrom: isoL(mas(hoy, -13)), pTo: isoL(mas(hoy, -7)), titulo: 'Últimos 7 días', kick: 'Ventas de los últimos 7 días', ant: 'los 7 días anteriores', grupo: 'day', n: 7 };
    if (r === 'mes') {
      const ini = new Date(hoy.getFullYear(), hoy.getMonth(), 1, 12), pIni = new Date(hoy.getFullYear(), hoy.getMonth() - 1, 1, 12);
      const finPrev = new Date(hoy.getFullYear(), hoy.getMonth(), 0, 12); const pFin = new Date(pIni); pFin.setDate(Math.min(hoy.getDate(), finPrev.getDate()));
      return { from: isoL(ini), to: isoL(hoy), pFrom: isoL(pIni), pTo: isoL(pFin), titulo: 'Este mes', kick: `Ventas de ${new Date().toLocaleDateString('es-DO', { month: 'long' })}`, ant: 'el mes pasado a esta fecha', grupo: 'day', n: new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0).getDate() };
    }
    const ini = new Date(hoy.getFullYear(), 0, 1, 12), pIni = new Date(hoy.getFullYear() - 1, 0, 1, 12), pFin = new Date(hoy.getFullYear() - 1, hoy.getMonth(), hoy.getDate(), 12);
    return { from: isoL(ini), to: isoL(hoy), pFrom: isoL(pIni), pTo: isoL(pFin), titulo: 'Este año', kick: `Ventas de ${hoy.getFullYear()}`, ant: 'el año pasado a esta fecha', grupo: 'month', n: 12 };
  }
  function cubetas(r, per, filas, desde) {
    const val = new Map(filas.map(x => { const f = new Date(x.day); return [per.grupo === 'month' ? f.getMonth() : isoL(f), { total: Number(x.total) || 0, profit: Number(x.profit) || 0, n: Number(x.sales_count) || 0 }]; }));
    const out = [];
    for (let i = 0; i < per.n; i++) {
      if (per.grupo === 'month') { out.push({ et: MESES_C[i], ...(val.get(i) || { total: 0 }) }); continue; }
      const f = new Date(desde + 'T12:00'); f.setDate(f.getDate() + i);
      const et = r === '7' ? f.toLocaleDateString('es-DO', { weekday: 'short' }).replace('.', '') + ' ' + f.getDate() : String(f.getDate());
      out.push({ et, ...(val.get(isoL(f)) || { total: 0 }) });
    }
    return out;
  }
  function barras(act, ant, w, h, hasta) {
    const n = act.length, pl = 6, pr = 6, pt = 14, pb = 24, max = Math.max(1, ...act.map(b => b.total), ...ant.map(b => b.total)) * 1.08;
    const paso = (w - pl - pr) / n, bw = Math.max(3, Math.min(34, paso * 0.56));
    let svg = `<svg class="hoy-graf" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" role="img" aria-label="Ventas por ${n === 12 ? 'mes' : 'día'}, con el período anterior detrás">`;
    act.forEach((b, i) => {
      const x = pl + paso * i + paso / 2, Y = v => pt + (h - pt - pb) * (1 - v / max), a = ant[i] ? ant[i].total : 0;
      if (a) svg += `<rect x="${(x - bw / 2 + bw * 0.18).toFixed(1)}" y="${Y(a).toFixed(1)}" width="${(bw * 0.82).toFixed(1)}" height="${(h - pb - Y(a)).toFixed(1)}" rx="3" class="hoy-bar-ant"/>`;
      if (i <= hasta) svg += `<rect x="${(x - bw / 2).toFixed(1)}" y="${Y(b.total).toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(0, h - pb - Y(b.total)).toFixed(1)}" rx="3" class="hoy-bar"><title>${b.et}: ${fmt(b.total)}</title></rect>`;
      const cada = n > 20 ? 5 : 1;
      if (i % cada === 0 || i === n - 1) svg += `<text x="${x.toFixed(1)}" y="${h - 6}" text-anchor="middle" class="hoy-et">${b.et}</text>`;
    });
    return svg + '</svg>';
  }
  /* ── «Personalizar»: qué tarjetas se ven (se recuerda en este equipo) ── */
  const SECCIONES = [['avisos', 'Avisos', 'Insumos bajos y pedidos web'], ['metricas', 'Ganancia, facturas y ticket', ''], ['destacados', 'Destacados', ''], ['top', 'Más vendido', 'Y cómo te pagaron'], ['ahora', 'Ahora mismo', 'Caja, turnos y pedidos en línea']];
  const ocultas = () => { try { return JSON.parse(localStorage.getItem('arche_hoy_ocultar') || '[]'); } catch (_) { return []; } };
  function personalizar() {
    const oc = ocultas();
    const m = UI.showModal('Personalizar «Hoy»', `<div class="pf"><p class="pf-nota" style="margin:0 14px 10px">Escoge qué ver en tu pantalla de inicio. Se guarda en este equipo.</p><div class="pf-grupo">${SECCIONES.map(([k, t, sub]) => `<label class="pf-fila"><span>${t}${sub ? `<small>${sub}</small>` : ''}</span><input type="checkbox" class="pf-sw" data-sec="${k}" ${oc.includes(k) ? '' : 'checked'}></label>`).join('')}</div>
      <div class="pf-acciones"><button class="btn" data-a="todo">Mostrar todo</button><button class="btn btn-primary" data-a="listo">Listo</button></div></div>`);
    const guardar = () => { const o = [...m.el.querySelectorAll('[data-sec]')].filter(x => !x.checked).map(x => x.dataset.sec); try { localStorage.setItem('arche_hoy_ocultar', JSON.stringify(o)); } catch (_) {} pintar(); };
    m.el.addEventListener('change', guardar);
    m.el.querySelector('[data-a="todo"]').onclick = () => { m.el.querySelectorAll('[data-sec]').forEach(x => { x.checked = true; }); guardar(); };
    m.el.querySelector('[data-a="listo"]').onclick = () => m.close();
  }

  const capLoc = cls => (locs.length ? `<label class="${cls}">${locs.length > 1 ? `<select aria-label="Ubicación" data-loc>${['<option value="">Todas las ubicaciones</option>', ...locs.map(l => `<option value="${l.id}"${String(l.id) === String(estado.loc) ? ' selected' : ''}>${esc(l.name)}</option>`)].join('')}</select>` : `<span>${esc(locs[0].name)}</span>`}</label>` : '');
  /* ── Pintar ── */
  function pintar() {
    const d = datos; if (!d) return;
    const esHoy = d.es_hoy, nombreDia = esHoy ? 'Hoy' : (estado.dia === ayerISO() ? 'Ayer' : fechaLarga(d.dia));
    const comp = esHoy ? d.semana_pasada.a_esta_hora : d.semana_pasada.total;
    const p = pct(d.hoy.total, comp);
    const diaSem = DIAS[new Date(d.dia + 'T12:00').getDay()];
    const avisos = [];
    if (bajos.length) {
      const peor = bajos[0];
      avisos.push(`<button type="button" class="hoy-aviso" data-a="bajos"><span class="hoy-ic" style="background:#FF3B30">${svgI(IC.alerta)}</span><span class="t"><b>${esc(peor.supply_name)} ${bajos.length > 1 ? `y ${bajos.length - 1} más` : ''} bajo${bajos.length > 1 ? 's' : ''}</b> <small>· ${esc(peor.location_name)}: quedan ${fmtNum(peor.stock)}</small></span><span class="hoy-mini">Ver</span></button>`);
    }
    if (d.web && d.web.pendientes) avisos.push(`<button type="button" class="hoy-aviso" data-a="web"><span class="hoy-ic" style="background:#0A84FF">${svgI(IC.moto)}</span><span class="t"><b>${d.web.pendientes} pedido${d.web.pendientes > 1 ? 's' : ''} web</b> <small>· esperando confirmación</small></span><span class="hoy-mini">Ver</span></button>`);
    const g = grafica(d, 760, 240, false);
    const oc = ocultas(), R = estado.rango && datosR && datosR.r === estado.rango ? datosR : null;
    const dias = d.dias || [];
    const ticket = d.hoy.ticket, ticketAnt = d.semana_pasada.ticket;
    const cmp = (a, b, unidad) => { const q = pct(a, b); if (q === null || !b) return '<em class="hoy-gris">sin dato de la semana pasada</em>'; if (Math.abs(q) < 3) return `<em class="hoy-gris">igual que el ${diaSem} pasado</em>`; return `<em class="${q > 0 ? 'hoy-sube' : 'hoy-baja'}">${q > 0 ? '▲' : '▼'} ${Math.abs(q)} %</em> <em class="hoy-gris">vs. el ${diaSem} pasado${unidad || ''}</em>`; };
    const margen = d.hoy.total > 0 ? Math.round((d.hoy.profit / d.hoy.total) * 100) : null;
    const pagosT = d.pagos.reduce((s, x) => s + x.total, 0);
    const maxTop = Math.max(1, ...d.top.map(t => t.total));

    root.innerHTML = `
      ${capLoc('hoy-loc')}
      <div class="hoy-cab"><div><h1 class="dash-title">${esc(R ? R.per.titulo : nombreDia)}</h1><p class="hoy-sub">${R ? esc(rangoTexto(R.per)) : esc(fechaLarga(d.dia)) + (esHoy ? ' · se actualiza solo' : '')}</p></div>
        <div class="hoy-der"><div class="v4-seg" role="tablist" aria-label="Período">${[['', 'Hoy'], [ayerISO(), 'Ayer']].map(([v, t]) => { const on = !estado.rango && (estado.dia || '') === v; return `<button type="button" role="tab" class="v4-seg-b${on ? ' is-active' : ''}" data-dia="${v}" aria-selected="${on}">${t}</button>`; }).join('')}${[['7', '7 días'], ['mes', 'Mes'], ['ano', 'Año']].map(([v, t]) => `<button type="button" role="tab" class="v4-seg-b${estado.rango === v ? ' is-active' : ''}" data-rango="${v}" aria-selected="${estado.rango === v}">${t}</button>`).join('')}</div>
        ${capLoc('hoy-loc hoy-loc-esc')}<button type="button" class="btn" data-a="personalizar">Personalizar</button><button type="button" class="btn" data-goto-v4="reportes">Ver reportes</button></div></div>
      <div class="hoy-arranque-slot"></div>
      ${avisos.length && !oc.includes('avisos') ? `<div class="hoy-franja">${avisos.join('')}</div>` : ''}
      <div class="hoy-heroe${oc.includes('metricas') ? ' sin-metr' : ''}">
        ${R ? heroeRango(R) : `<section class="card hoy-g">
          <div class="hoy-kick">Ventas ${esHoy ? 'de hoy' : 'del día'}<span class="hoy-ley"><i></i>${esc(nombreDia)}</span><span class="hoy-ley"><i class="p"></i>${esc(diaSem[0].toUpperCase() + diaSem.slice(1))} pasado</span></div>
          <div class="hoy-cifra"><span class="hoy-big">${fmt(d.hoy.total)}</span>${p === null || !comp ? '' : `<span class="${p >= 0 ? 'hoy-sube' : 'hoy-baja'}">${p >= 0 ? '▲' : '▼'} ${Math.abs(p)} %</span>`}<span class="hoy-gris">${comp ? `vs. el ${diaSem} pasado${esHoy ? ' a esta hora' : ''} (${fmt(comp)})` : esHoy && d.semana_pasada.total ? `el ${diaSem} pasado a esta hora aún no había ventas` : `el ${diaSem} pasado no hubo ventas`}</span></div>
          ${d.hoy.total === 0 && esHoy ? `<p class="hoy-vacio">Todavía no hay ventas hoy. La línea punteada es cómo fue el ${diaSem} pasado.</p>` : ''}
          <div class="hoy-graf-c">${g.svg}</div><p class="hoy-pista">Mantén y desliza para ver cada hora</p>
        </section>`}
        ${oc.includes('metricas') ? '' : R ? metricasRango(R) : `<div class="hoy-metr">
          <section class="card"><div><small>Ganancia</small><b>${fmt(d.hoy.profit)}</b>${margen === null ? '<em class="hoy-gris">sin ventas</em>' : `<em class="hoy-sube">Margen ${margen} %</em>`}</div>${chispa(dias.map(x => x.profit))}</section>
          <section class="card"><div><small>Facturas</small><b>${d.hoy.facturas}</b>${cmp(d.hoy.facturas, esHoy ? null : d.semana_pasada.facturas)}</div>${chispa(dias.map(x => x.facturas))}</section>
          <section class="card"><div><small>Ticket<span class="hoy-esc"> promedio</span></small><b>${fmt(ticket)}</b>${d.hoy.facturas ? cmp(ticket, ticketAnt) : '<em class="hoy-gris">sin ventas</em>'}</div>${chispa(dias.map(x => (x.facturas ? x.total / x.facturas : 0)))}</section>
        </div>`}
      </div>
      <div class="hoy-tres">
        <section class="card" ${oc.includes('destacados') ? 'hidden' : ''}><h2 class="hoy-h">${svgI(IC.chispa)}Destacados</h2>
          ${d.destacados.length ? d.destacados.map(x => `<div class="hoy-dest"><span class="hoy-dic">${svgI(IC[x.tipo] || IC.chispa)}</span><span>${x.partes.map(pp => (pp.b ? `<b>${esc(pp.t)}</b>` : esc(pp.t))).join('')}</span></div>`).join('')
            : '<p class="hoy-gris hoy-nota">Con 4 semanas de ventas, aquí aparecen frases como «los martes son tu día más flojo».</p>'}</section>
        <section class="card" ${oc.includes('top') ? 'hidden' : ''}><h2 class="hoy-h">Más vendido${R ? `<small class="hoy-gris"> · ${esc(R.per.titulo.toLowerCase())}</small>` : ''}<button type="button" class="hoy-lnk" data-goto-v4="reportes">Ver todo</button></h2>
          ${R ? topRango(R) : d.top.length ? d.top.map((t, i) => `<div class="hoy-top"><span class="n">${i + 1}</span><span>${esc(t.nombre)} <span class="hoy-gris">· ${fmtNum(t.cantidad)}</span></span><b>${fmt(t.total)}</b><span class="bar"><i style="width:${Math.round((t.total / maxTop) * 100)}%"></i></span></div>`).join('') : '<p class="hoy-gris hoy-nota">Sin ventas todavía.</p>'}
          ${pagosT ? `<p class="hoy-gris hoy-pt">Cómo te pagaron</p><div class="hoy-pago">${d.pagos.slice(0, 3).map(x => `<i style="width:${(x.total / pagosT) * 100}%"></i>`).join('')}</div><div class="hoy-pley">${d.pagos.slice(0, 3).map(x => `<span><i></i>${esc(x.metodo)} ${Math.round((x.total / pagosT) * 100)} %</span>`).join('')}</div>` : ''}</section>
        <section class="card hoy-ahora" ${oc.includes('ahora') ? 'hidden' : ''}><h2 class="hoy-h">Ahora mismo</h2>
          ${d.cajas.length ? d.cajas.map(c => `<div class="hoy-caja"><small>Caja abierta · ${esc(c.location_name)}${c.opened_by_name ? ` · ${esc(c.opened_by_name)}` : ''}</small><b>${fmt(c.expected_now)}</b><small>Efectivo que debe haber en la gaveta</small></div>`).join('') : '<div class="hoy-fila"><div class="t">Caja<small>No hay caja abierta</small></div></div>'}
          <div class="hoy-fila"><div class="t">En turno<small>${d.en_turno.length ? d.en_turno.map(t => esc(t.name.split(' ')[0])).join(', ') : 'Nadie ha marcado entrada'}</small></div><div class="hoy-avs">${d.en_turno.slice(0, 4).map((t, i) => `<span class="hoy-av a${i % 4}">${esc(t.name[0])}</span>`).join('')}</div></div>
          ${d.web && d.web.habilitado ? `<div class="hoy-fila"><div class="t">Pedidos en línea<small>${d.web.pausado ? 'En pausa' : `Recibiendo · ${d.web.minutos} min de preparación`}</small></div><button type="button" class="hoy-sw${d.web.pausado ? '' : ' on'}" role="switch" aria-checked="${!d.web.pausado}" aria-label="Recibir pedidos en línea" data-a="web-pausa"></button></div>` : ''}
        </section>
      </div>
      <button type="button" class="hoy-pers-mov" data-a="personalizar">Personalizar «Hoy»</button>`;
    const tt = document.querySelector('.v4-titulo'); if (tt) tt.textContent = R ? R.per.titulo : nombreDia;
    // La lista de arranque (dashboard.js) sigue viva: se muestra aquí mientras falte algo.
    const arr = document.getElementById('panel-arranque');
    if (arr) root.querySelector('.hoy-arranque-slot').appendChild(arr);
    // La gráfica se dibuja al tamaño real de su caja (sin estirar letras ni líneas).
    const caja = root.querySelector('.hoy-graf-c');
    const gw = Math.round(caja.clientWidth) || 760, gh = Math.round(caja.clientHeight) || 240;
    if (R) caja.innerHTML = barras(R.act, R.ant, gw, gh, R.hasta);
    else { const g2 = grafica(d, gw, gh, gw < 420); caja.innerHTML = g2.svg; activarCursor(caja, g2); }
    if (!reducir) root.querySelectorAll('.hoy-heroe .card,.hoy-tres .card,.hoy-aviso').forEach((el, i) => el.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 280, delay: i * 30, easing: 'cubic-bezier(.2,.8,.2,1)', fill: 'backwards' }));
  }
  const rangoTexto = per => { const f = x => new Date(x + 'T12:00').toLocaleDateString('es-DO', { day: 'numeric', month: 'short' }).replace('.', ''); return `${f(per.from)} – ${f(per.to)} · comparado con ${per.ant}`; };
  const vs = (a, b, ant) => { const q = pct(a, b); if (q === null || !b) return `<em class="hoy-gris">sin datos ${ant.startsWith('el ') ? 'd' + ant : 'de ' + ant}</em>`; if (Math.abs(q) < 3) return `<em class="hoy-gris">igual que ${ant}</em>`; return `<em class="${q > 0 ? 'hoy-sube' : 'hoy-baja'}">${q > 0 ? '▲' : '▼'} ${Math.abs(q)} %</em> <em class="hoy-gris">vs. ${ant}</em>`; };
  function heroeRango(R) {
    const t = R.tot, ta = R.totAnt;
    return `<section class="card hoy-g"><div class="hoy-kick">${esc(R.per.kick)}<span class="hoy-ley"><i></i>Este período</span><span class="hoy-ley"><i class="p"></i>Período anterior</span></div>
      <div class="hoy-cifra"><span class="hoy-big">${fmt(t.total)}</span>${vs(t.total, ta.total, R.per.ant)}${ta.total ? `<span class="hoy-gris">(${fmt(ta.total)})</span>` : ''}</div>
      <div class="hoy-graf-c"></div><p class="hoy-pista">Pasa el dedo o el mouse sobre una barra para ver su total</p></section>`;
  }
  function metricasRango(R) {
    const t = R.tot, ta = R.totAnt, tk = t.n ? t.total / t.n : 0, tka = ta.n ? ta.total / ta.n : 0, mg = t.total > 0 ? Math.round((t.profit / t.total) * 100) : null;
    return `<div class="hoy-metr">
      <section class="card"><div><small>Ganancia</small><b>${fmt(t.profit)}</b>${mg === null ? '<em class="hoy-gris">sin ventas</em>' : `<em class="hoy-sube">Margen ${mg} %</em>`}</div>${chispa(R.act.slice(0, R.hasta + 1).map(b => b.profit || 0))}</section>
      <section class="card"><div><small>Facturas</small><b>${t.n}</b>${vs(t.n, ta.n, R.per.ant)}</div>${chispa(R.act.slice(0, R.hasta + 1).map(b => b.n || 0))}</section>
      <section class="card"><div><small>Ticket<span class="hoy-esc"> promedio</span></small><b>${fmt(tk)}</b>${t.n ? vs(tk, tka, R.per.ant) : '<em class="hoy-gris">sin ventas</em>'}</div>${chispa(R.act.slice(0, R.hasta + 1).map(b => (b.n ? b.total / b.n : 0)))}</section>
    </div>`;
  }
  function topRango(R) {
    const top = R.top.slice(0, 5), max = Math.max(1, ...top.map(x => Number(x.revenue)));
    return top.length ? top.map((x, i) => `<div class="hoy-top"><span class="n">${i + 1}</span><span>${esc(x.product_name)} <span class="hoy-gris">· ${fmtNum(Number(x.quantity))}</span></span><b>${fmt(Number(x.revenue))}</b><span class="bar"><i style="width:${Math.round((Number(x.revenue) / max) * 100)}%"></i></span></div>`).join('') : '<p class="hoy-gris hoy-nota">Sin ventas en este período.</p>';
  }
  async function cargarRango() {
    const r = estado.rango, per = periodo(r), loc = estado.loc ? { location_id: estado.loc } : {};
    const [a, b, top] = await Promise.all([
      Api.reports.summary({ from: per.from, to: per.to, group_by: per.grupo, ...loc }),
      Api.reports.summary({ from: per.pFrom, to: per.pTo, group_by: per.grupo, ...loc }),
      Api.reports.byProduct({ from: per.from, to: per.to, ...loc })
    ]);
    const tot = x => ({ total: Number(x.totals.total) || 0, profit: Number(x.totals.profit) || 0, n: Number(x.totals.sales_count) || 0 });
    const hoy = new Date();
    const hasta = per.grupo === 'month' ? hoy.getMonth() : r === '7' ? 6 : hoy.getDate() - 1;
    datosR = { r, per, tot: tot(a), totAnt: tot(b), act: cubetas(r, per, a.byDay, per.from), ant: cubetas(r, per, b.byDay, per.pFrom), top, hasta };
  }
  const ayerISO = () => { const f = new Date(); f.setDate(f.getDate() - 1); return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, '0')}-${String(f.getDate()).padStart(2, '0')}`; };

  async function cargar() {
    if (cargando) return; cargando = true;
    try {
      const q = { ...(estado.dia ? { dia: estado.dia } : {}), ...(estado.loc ? { location_id: estado.loc } : {}) };
      if (!locs.length) { try { locs = Modules.visibleLocations((await Api.locations.list()).filter(l => l.active && l.kind === 'carrito')); } catch (_) { locs = []; } }
      const [d, b] = await Promise.all([Api.reports.hoy(q), Api.reports.lowStock('all').catch(() => ({ supplies: [] })), estado.rango ? cargarRango() : null]);
      datos = d; bajos = b.supplies || []; pintar();
      window.dispatchEvent(new CustomEvent('hoy:datos', { detail: d }));
    } catch (e) { root.innerHTML = `<div class="card hoy-error"><b>No se pudo cargar el panel.</b><span class="hoy-gris">${esc(e.message)}</span> <button type="button" class="btn btn-sm" data-a="reintentar">Reintentar</button></div>`; }
    finally { cargando = false; }
  }

  root.addEventListener('change', e => { if (e.target.matches('[data-loc]')) { if (window.V4 && V4.ponerUbicacion) V4.ponerUbicacion(e.target.value); else { estado.loc = e.target.value; cargar(); } } });
  // La ubicación escogida en el menú de identidad o en la hoja del celular (v4.js) también manda aquí.
  window.addEventListener('v4:ubicacion', e => { estado.loc = e.detail || ''; cargar(); });
  root.addEventListener('click', async e => {
    const t = e.target.closest('[data-dia],[data-rango],[data-a],[data-goto-v4]'); if (!t) return;
    if (t.dataset.dia !== undefined) { estado.dia = t.dataset.dia || null; estado.rango = null; cargar(); return; }
    if (t.dataset.rango) { estado.rango = t.dataset.rango; estado.dia = null; cargar(); return; }
    if (t.dataset.gotoV4) { window.showView(t.dataset.gotoV4); return; }
    const a = t.dataset.a;
    if (a === 'reintentar') cargar();
    if (a === 'personalizar') personalizar();
    if (a === 'bajos' && window.showExistencias) window.showExistencias(true);
    if (a === 'web') window.showView('pagina');
    if (a === 'web-pausa') {
      const pausar = t.classList.contains('on');
      t.classList.toggle('on', !pausar); t.setAttribute('aria-checked', String(!pausar));   // responde primero…
      try { await Api.settings.updateWeb({ web_orders_paused: pausar }); UI.toast(pausar ? 'Pedidos en línea en pausa' : 'Recibiendo pedidos en línea'); datos.web.pausado = pausar; }
      catch (err) { t.classList.toggle('on', pausar); t.setAttribute('aria-checked', String(pausar)); UI.toast(err.message, 'error'); }   // …y vuelve atrás si falla
    }
  });

  window.addEventListener('view:show', e => {
    clearInterval(reloj);
    if (e.detail.view !== 'panel') return;
    cargar();
    reloj = setInterval(() => { if (!document.hidden && !estado.dia) cargar(); }, 60000);
  });
  window.HoyV4 = { recargar: cargar };
})();
