/* ═══ Caja del punto de venta: abrir, anotar entradas/salidas y cerrar ═══ */
(function () {
  'use strict';
  const closedCard = document.getElementById('caja-cerrada');
  if (!closedCard) return;
  const esc = UI.escapeHtml;
  const $ = id => document.getElementById(id);
  let session = null;

  const showError = msg => { $('caja-error').textContent = msg || ''; $('caja-error').hidden = !msg; };
  const isPos = () => { const s = Auth.get(); return !!s && s.role === 'cart'; };

  // v3.9: estado de la caja en la barra superior (sin entrar a Caja) y montos
  // rápidos para el fondo inicial (el último usado en este equipo primero).
  const pill = $('ux-caja');
  const FONDO_KEY = 'arche_ultimo_fondo';
  let estadoConocido = false;
  function pintarPill() {
    const on = !window.Modules || Modules.enabled('caja');
    pill.hidden = !on || !isPos() || !estadoConocido;
    if (pill.hidden) return;
    pill.classList.toggle('is-open', !!session);
    pill.innerHTML = session ? '<i></i>Caja abierta' : '<i></i>Caja cerrada';
    pill.title = session ? 'Ver la caja' : 'Abrir la caja';
  }
  pill.addEventListener('click', () => window.showView('pos-caja'));
  function pintarFondos() {
    let ultimo = null; try { ultimo = localStorage.getItem(FONDO_KEY); } catch (_) {}
    const montos = [...new Set([ultimo !== null ? Number(ultimo) : null, 0, 500, 1000, 2000].filter(v => v !== null && !isNaN(v)))].slice(0, 5);
    $('caja-fondo-chips').innerHTML = montos.map(v => `<button type="button" class="cash-chip" data-fondo="${v}">${v === Number(ultimo) && ultimo !== null ? '↺ ' : ''}${fmt(v)}</button>`).join('');
  }
  $('caja-fondo-chips').addEventListener('click', e => {
    const b = e.target.closest('[data-fondo]');
    if (!b) return;
    $('caja-fondo').value = b.dataset.fondo;
    $('caja-fondo-chips').querySelectorAll('.cash-chip').forEach(c => c.classList.toggle('is-active', c === b));
  });

  function render() {
    estadoConocido = true;
    pintarPill();
    if (!session) pintarFondos();
    closedCard.hidden = !!session;
    $('caja-abierta').hidden = !session;
    if (!session) { $('caja-desde').hidden = true; return; }
    const ventas = session.by_method.reduce((t, m) => t + (m.sales_count || 0), 0);
    $('caja-desde').hidden = false;
    $('caja-desde').textContent = `Abierta${session.opened_by_name ? ` por ${session.opened_by_name.split(' ')[0]}` : ''} ${fmtDate(session.opened_at)} · ${ventas} ${ventas === 1 ? 'venta' : 'ventas'}`;
    const fila = (l, v, cls = '') => `<div class="caja-fila${cls}"><span>${l}</span><b>${v}</b></div>`;
    $('caja-resumen').innerHTML = fila('Fondo inicial', fmtDec(session.opening_amount)) + fila('Ventas en efectivo', fmtDec(session.cash_sales)) +
      (Number(session.credit_payments) > 0 ? fila('Abonos de clientes', fmtDec(session.credit_payments)) : '') +
      (Number(session.entradas) > 0 ? fila('Entradas', '+ ' + fmtDec(session.entradas)) : '') +
      (Number(session.salidas) > 0 ? fila('Salidas', '− ' + fmtDec(session.salidas)) : '');
    $('caja-debe').textContent = fmtDec(session.expected_now);
    const other = session.by_method.filter(m => m.method !== 'efectivo' && m.total);
    $('caja-metodos-card').hidden = !other.length;
    $('caja-metodos').innerHTML = other.map(m => fila(`${esc(m.method.charAt(0).toUpperCase() + m.method.slice(1))} · ${m.sales_count}`, fmtDec(m.total))).join('');
    $('caja-movimientos').innerHTML = session.movements.length ? session.movements.map(m =>
      fila(`${esc(m.reason)} <small>${fmtDate(m.created_at)}</small>`, `${m.kind === 'entrada' ? '+' : '−'} ${fmtDec(m.amount)}`, m.kind === 'entrada' ? ' is-entrada' : '')).join('') : '<p class="caja-ayuda">Sin movimientos.</p>';
    updateDiff();
  }

  function updateDiff() {
    const el = $('caja-diff');
    const raw = $('caja-contado').value;
    if (!session || raw === '') { el.hidden = true; $('caja-nota-f').hidden = true; return; }
    const diff = Math.round((Number(raw) - session.expected_now) * 100) / 100;
    const ok = Math.abs(diff) < 0.005;
    el.hidden = false;
    el.className = 'caja-diff ' + (ok ? 'cuadra' : 'no-cuadra');
    el.innerHTML = ok
      ? `<span class="caja-diff-ic" aria-hidden="true">✓</span><div><b>Cuadra exacto</b><small>Contado ${fmtDec(Number(raw))}</small></div>`
      : `<span class="caja-diff-ic" aria-hidden="true">!</span><div><b>${diff > 0 ? 'Sobran' : 'Faltan'} ${fmtDec(Math.abs(diff))}</b><small>Contado ${fmtDec(Number(raw))} · debe haber ${fmtDec(session.expected_now)}. Escribe qué pasó en la nota.</small></div>`;
    $('caja-nota-f').hidden = ok;
    $('btn-caja-cerrar').textContent = ok ? 'Cerrar caja' : 'Cerrar caja con diferencia';
  }
  $('caja-contado').addEventListener('input', updateDiff);

  /* v4 (DISENO-ARCHE.md): contar billete por billete. Cada denominación con − y +; la suma llena «Efectivo que
     contaste» y dice al momento si cuadra. Solo con pesos dominicanos (RD$), que son las denominaciones que conoce. */
  const DENOM = [2000, 1000, 500, 200, 100, 50, 25, 10, 5, 1];
  const cuenta = {};
  const contadoEl = $('caja-contado');
  const conteo = document.createElement('div');
  conteo.className = 'conteo';
  const campo = contadoEl.closest('.field, label, .f') || contadoEl;
  campo.before(conteo);
  function pintarConteo() {
    if (!/^RD/i.test(AppLocale.currency())) { conteo.hidden = true; return; }
    conteo.hidden = false;
    conteo.innerHTML = `<div class="conteo-lista">${DENOM.map(d => `<div class="conteo-f"><span class="conteo-d">${fmt(d)}<small>${d >= 50 ? 'billete' : 'moneda'}</small></span>
      <span class="conteo-st"><button type="button" data-d="${d}" data-k="-1" aria-label="Uno menos de ${fmt(d)}">−</button><b>${cuenta[d] || 0}</b><button type="button" data-d="${d}" data-k="1" aria-label="Uno más de ${fmt(d)}">+</button></span>
      <span class="conteo-sub">${cuenta[d] ? fmt(d * cuenta[d]) : ''}</span></div>`).join('')}</div>`;
  }
  conteo.addEventListener('click', e => {
    const b = e.target.closest('[data-d]'); if (!b) return;
    const d = Number(b.dataset.d);
    cuenta[d] = Math.max(0, (cuenta[d] || 0) + Number(b.dataset.k));
    const total = DENOM.reduce((t, x) => t + x * (cuenta[x] || 0), 0);
    contadoEl.value = total ? String(total) : '';
    pintarConteo(); updateDiff();
  });
  pintarConteo();

  async function load() {
    if (!isPos()) return;
    try { session = await Api.pos.cash(); showError(''); } catch (err) { showError(err.status === undefined ? 'Sin conexión con el servidor — la caja lo necesita.' : err.message); return; }
    render();
  }

  const run = async fn => { try { showError(''); session = await fn(); render(); } catch (err) { showError(err.status === undefined ? 'Sin conexión con el servidor' : err.message); } };

  $('btn-caja-abrir').addEventListener('click', () => {
    const v = $('caja-fondo').value;
    if (v === '') { showError('Escribe el fondo inicial (puede ser 0)'); return; }
    try { localStorage.setItem(FONDO_KEY, String(Number(v))); } catch (_) {}
    run(() => Api.pos.openCash(Number(v))).then(() => { $('caja-fondo').value = ''; UI.toast('Caja abierta'); });
  });
  document.querySelector('.caja-mov-tipo').addEventListener('click', e => {
    const b = e.target.closest('[data-tipo]'); if (!b) return;
    $('caja-mov-tipo').value = b.dataset.tipo;
    document.querySelectorAll('.caja-mov-tipo [data-tipo]').forEach(x => { const on = x === b; x.classList.toggle('is-active', on); x.setAttribute('aria-checked', String(on)); });
  });
  $('btn-caja-mov').addEventListener('click', () => {
    run(() => Api.pos.cashMovement({ kind: $('caja-mov-tipo').value, amount: Number($('caja-mov-monto').value), reason: $('caja-mov-motivo').value })).then(() => {
      if (!$('caja-error').hidden) return;
      $('caja-mov-monto').value = ''; $('caja-mov-motivo').value = ''; UI.toast('Anotado');
    });
  });
  $('btn-caja-cerrar').addEventListener('click', async () => {
    showError('');
    if ($('caja-contado').value === '') { showError('Cuenta el efectivo y escribe cuánto hay'); return; }
    const descuadre = Math.abs(Number($('caja-contado').value) - session.expected_now) >= 0.005;
    if (descuadre && !$('caja-nota').value.trim()) { showError('No cuadra: escribe en la nota qué pasó'); $('caja-nota').focus(); return; }
    if (!(await UI.confirmDialog('¿Cerrar la caja? Después hay que abrir una nueva para seguir.'))) return;
    try {
      const closed = await Api.pos.closeCash({ counted_amount: Number($('caja-contado').value), note: $('caja-nota').value.trim() || null });
      UI.toast(Math.abs(closed.difference) < 0.005 ? 'Caja cerrada — cuadró' : `Caja cerrada — diferencia ${fmtDec(closed.difference)}`);
      $('caja-contado').value = ''; $('caja-nota').value = '';
      DENOM.forEach(d => { delete cuenta[d]; }); pintarConteo();
      session = null;
      render();
    } catch (err) { showError(err.status === undefined ? 'Sin conexión con el servidor' : err.message); }
  });

  window.addEventListener('view:show', e => { if (e.detail.view === 'pos-caja') load(); });
  // La píldora se pone al día al entrar a la facturación y cada 5 minutos.
  const cartApp = document.getElementById('cart-app');
  let pillTimer = null;
  const refrescar = () => { if (!cartApp.hidden && isPos() && (!window.Modules || Modules.enabled('caja'))) load(); };
  new MutationObserver(() => { clearInterval(pillTimer); if (!cartApp.hidden) { refrescar(); pillTimer = setInterval(refrescar, 5 * 60000); } })
    .observe(cartApp, { attributes: true, attributeFilter: ['hidden'] });
  if (!cartApp.hidden) { refrescar(); pillTimer = setInterval(refrescar, 5 * 60000); }
})();
