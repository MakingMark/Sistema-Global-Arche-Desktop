/* ═══ Reportes de ganancia (dueño) ═══ */
(function () {
  'use strict';
  const form = document.getElementById('form-reporte');
  if (!form) return;
  const totalesEl = document.getElementById('reporte-totales');
  const tbody = document.querySelector('#tabla-reportes tbody');
  const locTbody = document.querySelector('#tabla-reporte-ubicacion tbody');
  const prodTbody = document.querySelector('#tabla-reporte-producto tbody');
  const supplyYieldTbody = document.querySelector('#tabla-rendimiento-insumos tbody');
  const locationSelect = form.querySelector('[name="location_id"]');
  const fromInput = form.querySelector('[name="from"]');
  const toInput = form.querySelector('[name="to"]');
  const printMetaEl = document.getElementById('reporte-print-meta');
  const groupBySelect = document.getElementById('reporte-groupby');
  const periodoTh = document.getElementById('reporte-periodo-th');

  const PERIODO_LABEL = { day: 'Día', week: 'Semana', month: 'Mes' };

  function currentParams() {
    const params = { group_by: groupBySelect.value };
    if (fromInput.value) params.from = fromInput.value;
    if (toInput.value) params.to = toInput.value;
    if (locationSelect.value) params.location_id = locationSelect.value;
    return params;
  }

  // "Semana del 8/9" (el día en que empieza, no un rango — más corto y
  // suficiente para ubicarla) / "Septiembre 2026" / la fecha normal para
  // día — el mismo dato (`d.day`, siempre el INICIO del período que
  // devuelve date_trunc) se lee distinto según qué eligió el dueño arriba.
  function fmtPeriod(dateStr, groupBy) {
    const d = new Date(dateStr);
    if (groupBy === 'month') {
      const label = d.toLocaleDateString('es-DO', { month: 'long', year: 'numeric' });
      return label.charAt(0).toUpperCase() + label.slice(1);
    }
    if (groupBy === 'week') return `Semana del ${d.toLocaleDateString('es-DO')}`;
    return d.toLocaleDateString('es-DO');
  }

  function statCard(label, value, comp) {
    return `<div class="stat"><div class="label">${label}</div><div class="value">${value}</div>${comp || ''}</div>`;
  }
  // v4 (DISENO-ARCHE.md): cada cifra dice cómo va contra el período anterior del mismo largo, en palabras.
  function comparar(actual, antes) {
    const a = Number(actual) || 0, b = Number(antes) || 0;
    if (!b) return '<div class="rp-comp muted">sin datos del período anterior</div>';
    const p = Math.round(((a - b) / b) * 100);
    if (Math.abs(p) < 2) return '<div class="rp-comp muted">igual que el período anterior</div>';
    return `<div class="rp-comp"><span class="${p > 0 ? 'rp-sube' : 'rp-baja'}">${p > 0 ? '▲' : '▼'} ${Math.abs(p)} %</span> <span class="muted">vs. período anterior</span></div>`;
  }
  function periodoAnterior(params) {
    if (!params.from || !params.to) return null;
    const f = new Date(params.from + 'T00:00:00'), t = new Date(params.to + 'T00:00:00');
    const dias = Math.round((t - f) / 86400000) + 1;
    const pt = new Date(f); pt.setDate(pt.getDate() - 1);
    const pf = new Date(f); pf.setDate(pf.getDate() - dias);
    return { ...params, from: isoDate(pf), to: isoDate(pt) };
  }
  // Barras por día del rango: entre semana en gris, fin de semana en el tinte suave, el último día en el tinte.
  function barrasDias(byDay, params) {
    if (!params.from || !params.to || params.from === params.to) return '';
    const f = new Date(params.from + 'T00:00:00'), t = new Date(params.to + 'T00:00:00');
    const n = Math.round((t - f) / 86400000) + 1; if (n > 62) return '';
    const mapa = new Map(byDay.map(d => [isoDate(new Date(d.day)), Number(d.total)]));
    const dias = Array.from({ length: n }, (_, i) => { const d = new Date(f); d.setDate(d.getDate() + i); return { d, v: mapa.get(isoDate(d)) || 0 }; });
    const max = Math.max(1, ...dias.map(x => x.v)) * 1.1, W = 1000, H = 120, gap = n > 31 ? 2 : 5, bw = (W - gap * (n - 1)) / n;
    const corto = d => d.toLocaleDateString('es-DO', { day: 'numeric', month: 'short' }).replace(/\./g, '');
    return `<figure class="rp-barras"><svg viewBox="0 0 ${W} ${H + 22}" width="100%" role="img" aria-label="Ventas por día del rango">${dias.map((x, i) => { const h = Math.max(x.v ? 3 : 1, (x.v / max) * H); const fin = [0, 6].includes(x.d.getDay()); return `<rect x="${i * (bw + gap)}" y="${H - h}" width="${bw}" height="${h}" rx="${Math.min(4, bw / 3)}" class="${i === n - 1 ? 'ult' : fin ? 'fin' : ''}"><title>${corto(x.d)}: ${fmt(x.v)}</title></rect>`; }).join('')}
      <text x="0" y="${H + 16}" class="rp-et">${corto(dias[0].d)}</text><text x="${W}" y="${H + 16}" text-anchor="end" class="rp-et">${corto(dias[n - 1].d)}</text></svg>
      <figcaption class="rp-ley"><span><i></i>Entre semana</span><span><i class="fin"></i>Fin de semana</span><span><i class="ult"></i>Último día</span></figcaption></figure>`;
  }

  // Componentes LOCALES de la fecha, nunca .toISOString().slice(0,10) — esa
  // variante da la fecha en UTC, que se adelanta un día entero entre las
  // 8pm y la medianoche en Santo Domingo (UTC-4). Con fechas ya ancladas a
  // medianoche (ej. isoDate(new Date(y,m,1))) daba lo mismo, pero
  // isoDate(now) para "Hasta" (más abajo) sí quedaba mal en ese horario.
  function isoDate(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }

  // El filtro (fechas + ubicación) se ve bien en pantalla como formulario,
  // pero en papel un <input type="date"> vacío no dice nada — esta línea
  // en texto plano es lo que de verdad queda impreso, junto con cuándo se
  // generó el reporte (para que un papel viejo no se confunda con uno nuevo).
  function updatePrintMeta() {
    if (!printMetaEl) return;
    const businessName = document.getElementById('brand-name-owner')?.textContent || 'Mi negocio';
    const rango = fromInput.value && toInput.value
      ? `Del ${new Date(fromInput.value + 'T00:00:00').toLocaleDateString('es-DO')} al ${new Date(toInput.value + 'T00:00:00').toLocaleDateString('es-DO')}`
      : 'Todo el historial';
    const ubicacion = locationSelect.selectedOptions[0]?.textContent || 'Todas';
    const generado = new Date().toLocaleString('es-DO');
    printMetaEl.textContent = `${businessName} · ${rango} · Ubicación: ${ubicacion} · Generado el ${generado}`;
  }

  async function loadLocations() {
    const locations = await Api.locations.list();
    // Solo ubicaciones activas: un punto de venta dado de baja (o de prueba, nunca
    // limpiado) no debería quedar como opción eterna en el filtro — "Todas"
    // ya suma su historial igual, solo se pierde poder filtrar
    // específicamente por ella una vez retirada.
    locationSelect.innerHTML = '<option value="">Todas</option>' +
      locations.filter(l => l.active).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');
  }

  async function render(params) {
    updatePrintMeta();
    renderWaste(params);
    renderReal(params);
    renderCash(params);
    // Esqueleto mientras llegan los dos pedidos de abajo — un rango largo
    // (todo el año, todas las ubicaciones) puede tardar; antes las tablas
    // se quedaban en blanco ese rato, sin señal de que el filtro sí corrió.
    totalesEl.innerHTML = Array.from({ length: 3 }, () =>
      `<div class="stat"><div class="skeleton skeleton-text" style="width:60%;margin:0 auto 8px"></div><div class="skeleton skeleton-text" style="width:40%;height:1.3em;margin:0 auto"></div></div>`
    ).join('');
    locTbody.innerHTML = UI.skeletonRows(3, 4);
    prodTbody.innerHTML = UI.skeletonRows(4, 5);
    tbody.innerHTML = UI.skeletonRows(4, 5);
    const ant = periodoAnterior(params);
    const [{ totals, byDay, byLocation }, byProduct, prev] = await Promise.all([
      Api.reports.summary(params),
      Api.reports.byProduct(params),
      ant ? Api.reports.summary(ant).catch(() => null) : null
    ]);
    const pt = prev && prev.totals;

    // "Total" es la venta NETA (sin ITBIS ni propina): lo que de verdad es del
    // negocio. El ITBIS (se le paga al fisco) y la propina (es del personal)
    // se muestran aparte, solo si alguna vez se cobraron en el rango.
    totalesEl.innerHTML =
      statCard('Facturas', totals.sales_count, pt && comparar(totals.sales_count, pt.sales_count)) +
      statCard('Ventas (neto)', fmt(totals.total), pt && comparar(totals.total, pt.total)) +
      statCard('Ganancia', fmt(totals.profit), pt && comparar(totals.profit, pt.profit)) +
      (Number(totals.itbis_total) > 0 ? statCard('ITBIS cobrado', fmt(totals.itbis_total)) : '') +
      (Number(totals.tip_total) > 0 ? statCard('Propina cobrada', fmt(totals.tip_total)) : '') +
      barrasDias(byDay, params);

    // Quién vendió MÁS/MENOS dinero dentro del rango elegido arriba — "Desde"
    // y "Hasta" permiten cualquier rango (un día puntual, una semana...).
    const mejor = byLocation.length > 1 ? byLocation.reduce((best, l) => (!best || Number(l.total) > Number(best.total)) ? l : best, null) : null;
    const peor = byLocation.length > 1 ? byLocation.reduce((worst, l) => (!worst || Number(l.total) < Number(worst.total)) ? l : worst, null) : null;
    locTbody.innerHTML = byLocation.map(l => `
      <tr class="${l === mejor ? 'best-row' : ''} ${l === peor ? 'warn-row' : ''}">
        <td data-th="Ubicación">${UI.escapeHtml(l.location_name)}${l === mejor ? ' <span class="best-tag">vende más</span>' : ''}${l === peor ? ' <span class="warn-tag">vende menos</span>' : ''}</td>
        <td class="num" data-th="Facturas">${l.sales_count}</td>
        <td class="num" data-th="Ventas">${fmt(l.total)}</td>
        <td class="num" data-th="Ganancia">${fmt(l.profit)}</td>
      </tr>
    `).join('') || '<tr><td colspan="4" class="muted">Sin ventas.</td></tr>';

    prodTbody.innerHTML = byProduct.map(p => `
      <tr>
        <td data-th="Producto">${UI.escapeHtml(p.product_name)}</td>
        <td class="num" data-th="Cantidad">${Number(p.quantity).toLocaleString('es-DO')}</td>
        <td class="num" data-th="Ingreso">${fmt(p.revenue)}</td>
        <td class="num" data-th="Costo">${fmt(p.cost)}</td>
        <td class="num" data-th="Ganancia">${fmt(p.profit)}</td>
      </tr>
    `).join('') || '<tr><td colspan="5" class="muted">Sin ventas.</td></tr>';

    const groupBy = groupBySelect.value;
    periodoTh.textContent = PERIODO_LABEL[groupBy] || 'Día';
    tbody.innerHTML = byDay.map(d => `
      <tr>
        <td data-th="${PERIODO_LABEL[groupBy] || 'Día'}">${fmtPeriod(d.day, groupBy)}</td>
        <td class="num" data-th="Facturas">${d.sales_count}</td>
        <td class="num" data-th="Total">${fmt(d.total)}</td>
        <td class="num" data-th="Costo">${fmt(d.total_cost)}</td>
        <td class="num" data-th="Ganancia">${fmt(d.profit)}</td>
      </tr>
    `).join('') || '<tr><td colspan="5" class="muted">Sin ventas en este rango.</td></tr>';
  }

  // Nombre distinto a propósito (no `fmtDate`, que ya existe global en
  // api.js con otro comportamiento — mostrar solo la hora si es de hoy):
  // acá siempre hace falta el día completo, la entrega casi nunca es de
  // hoy. Encontrado en la auditoría del 22 sept: tener las dos con el
  // mismo nombre las tapaba (shadowing) sin que se notara, un riesgo real
  // si alguien agregaba otro uso de `fmtDate` más abajo en este archivo
  // esperando el comportamiento global.
  function fmtDeliveryDate(d) { return new Date(d).toLocaleDateString('es-DO'); }
  // Pluraliza la unidad real del insumo (unidad → unidades, vaso → vasos).
  // "unidad" + "s" da "unidads" — mal en español (un error gramatical real
  // que el dueño encontró en pantalla). Una palabra que termina en consonante
  // pluraliza con "-es" ("unidad" → "unidades"); en vocal, con "-s" ("vaso" →
  // "vasos", "botella" → "botellas") — cubre las unidades reales que usa
  // este reporte sin necesitar una lista de excepciones a mano.
  function unitLabel(unit, n) {
    if (Number(n) === 1) return unit;
    return /[aeiou]$/i.test(unit) ? unit + 's' : unit + 'es';
  }

  async function renderSupplyYield() {
    if (!supplyYieldTbody) return;
    supplyYieldTbody.innerHTML = UI.skeletonRows(3, 2);
    const rows = await Api.reports.supplyYield();
    supplyYieldTbody.innerHTML = rows.map(r => {
      const quedan = r.depleted
        ? '<span class="tag-neutral">agotado</span>'
        : `${Number(r.remaining_stock).toLocaleString('es-DO')} ${unitLabel(r.unit, r.remaining_stock)} quedan`;
      // Lo entregado tiene que repartirse entre lo vendido y lo que queda —
      // si sobra algo sin vender NI en stock, no se fue en ventas reales
      // (merma, derrame, mal manejo).
      const unaccounted = Number(r.unaccounted) > 0.01
        ? `<div class="cell-subtitle"><span class="warn-tag" title="Entregado ${Number(r.delivered_qty).toLocaleString('es-DO')} — vendido ${Number(r.sold_since_delivery).toLocaleString('es-DO')} — queda ${Number(r.remaining_stock).toLocaleString('es-DO')}">Faltan ${fmtNum(r.unaccounted)} ${unitLabel(r.unit, r.unaccounted)} sin explicar</span></div>`
        : '';
      // Rediseñado dos veces tras feedback real viendo la tabla en pantalla.
      // Primero: "Entrega" era una frase completa (fecha + cantidad + la
      // fórmula del paquete) — se resolvió con jerarquía tipográfica en vez
      // de más columnas. Segundo ("se ve tirado, nada estético"): una
      // columna "Aviso" que queda vacía en la mayoría de las filas se ve
      // como un hueco sin terminar, y pintar de rosado CADA fila agotada
      // (una condición normal, no un problema) le restaba peso justo a la
      // única fila que sí hace falta resaltar. Ahora "Aviso" es una
      // tercera línea DENTRO de "Rendimiento" — solo aparece si hay algo
      // real que avisar — y el tinte de fila queda reservado para eso,
      // no para "agotado" (que se sigue viendo, con su propia etiqueta,
      // pero en un gris neutro — es información, no una alarma).
      const rindeTitle = r.pack_size
        ? `1 ${UI.escapeHtml(r.pack_name)} rinde ${Number(r.pack_size).toLocaleString('es-DO')} ${unitLabel(r.unit, r.pack_size)}`
        : '';
      // En la vida real nunca se entrega "12 unidades sueltas" de un insumo
      // — se entrega el empaque completo (1 pote, 4 botellas...). Cuando lo
      // entregado es un múltiplo exacto del empaque (el caso normal), se
      // muestra así — que es como el dueño de verdad lo piensa — con el
      // total en unidades entre paréntesis solo como referencia.
      const deliveredQty = Number(r.delivered_qty);
      const packSize = Number(r.pack_size);
      const packs = packSize > 0 ? deliveredQty / packSize : 0;
      const deliveredLabel = (r.pack_name && Number.isInteger(Math.round(packs * 1000) / 1000))
        ? `${Math.round(packs)} ${UI.escapeHtml(unitLabel(r.pack_name, packs))} (${deliveredQty.toLocaleString('es-DO')} ${unitLabel(r.unit, deliveredQty)})`
        : `${deliveredQty.toLocaleString('es-DO')} ${unitLabel(r.unit, deliveredQty)}`;
      return `
      <tr class="row-clickable ${Number(r.unaccounted) > 0.01 ? 'warn-row' : ''}" data-location-id="${r.location_id}" data-supply-id="${r.supply_id}" tabindex="0" role="button" aria-label="Ver desglose de ${UI.escapeHtml(r.location_name)} — ${UI.escapeHtml(r.supply_name)}">
        <td data-th="Punto de venta · Insumo">
          <strong>${UI.escapeHtml(r.location_name)} — ${UI.escapeHtml(r.supply_name)}</strong>
          <div class="cell-subtitle muted">Entregado ${deliveredLabel} · ${fmtDeliveryDate(r.delivered_at)} · <span class="row-clickable-hint">ver desglose ›</span></div>
        </td>
        <td class="num" data-th="Rendimiento"${rindeTitle ? ` title="${rindeTitle}"` : ''}>
          <strong>${Number(r.sold_since_delivery).toLocaleString('es-DO')} ${unitLabel(r.unit, r.sold_since_delivery)} vendidos</strong>
          <div class="cell-subtitle">${quedan}</div>
          ${unaccounted}
        </td>
      </tr>
    `;
    }).join('') || '<tr><td colspan="2" class="muted">Todavía no se ha transferido ningún insumo a un punto de venta.</td></tr>';

    supplyYieldTbody.querySelectorAll('tr.row-clickable').forEach(tr => {
      const open = () => showSupplyYieldDetail(tr.dataset.locationId, tr.dataset.supplyId);
      tr.addEventListener('click', open);
      tr.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });
  }

  // Desglose real detrás de "entregado/vendido" — pedido explícito del dueño:
  // "si le doy clic me debería dejar desglosar, no entiendo esa información".
  // Muestra la entrega (transferencia) y cada venta real que consumió desde
  // ahí, para poder verificarlo a mano en vez de confiar en el resumen.
  async function showSupplyYieldDetail(locationId, supplyId) {
    const d = await Api.reports.supplyYieldDetail(locationId, supplyId);
    const rows = d.sales.map(s => `
      <tr>
        <td data-th="Fecha">${new Date(s.created_at).toLocaleString('es-DO')}</td>
        <td data-th="Venta">#${s.sale_id}${s.customer_name ? ` · ${UI.escapeHtml(s.customer_name)}` : ''}</td>
        <td class="num" data-th="Cantidad">${Number(s.quantity).toLocaleString('es-DO')}</td>
      </tr>
    `).join('') || '<tr><td colspan="3" class="muted">Todavía no se vendió nada desde esa entrega.</td></tr>';
    const body = `
      <p class="muted" style="margin-top:-4px">Entregado <strong>${Number(d.delivered_qty).toLocaleString('es-DO')}</strong> el ${fmtDeliveryDate(d.delivered_at)}. Desde ahí, cada venta real que consumió de este insumo:</p>
      <div class="table-scroll"><table class="table">
        <thead><tr><th>Fecha</th><th>Venta</th><th class="num">Cantidad</th></tr></thead>
        <tbody>${rows}</tbody>
      </table></div>
      <p class="muted" style="margin-top:10px;margin-bottom:0">Total vendido: <strong>${Number(d.sales.reduce((sum, s) => sum + Number(s.quantity), 0)).toLocaleString('es-DO')}</strong> · Quedan ahora: <strong>${Number(d.remaining_stock).toLocaleString('es-DO')}</strong></p>
    `;
    UI.showModal('Desglose de entrega y ventas', body);
  }

  /* ── Ganancia real (bruta − merma − gastos) ── */
  async function renderReal(params) {
    const { from, to, location_id } = params;
    let d;
    try { d = await Api.reports.profit({ ...(from ? { from } : {}), ...(to ? { to } : {}), ...(location_id ? { location_id } : {}) }); } catch (_) { return; }
    document.getElementById('reporte-real-card').hidden = false;
    document.getElementById('reporte-real').innerHTML =
      statCard('Ganancia bruta', fmt(d.gross_profit)) + statCard('Merma', '− ' + fmt(d.waste_cost)) + statCard('Gastos', '− ' + fmt(d.expenses_total)) +
      `<div class="stat"><div class="label">Ganancia neta</div><div class="value ${d.net_profit < 0 ? 'low-stock' : ''}">${fmt(d.net_profit)}</div></div>`;
  }

  /* ── Cierres de caja ── */
  async function renderCash(params) {
    const { from, to, location_id } = params;
    let rows;
    try { rows = await Api.reports.cash({ ...(from ? { from } : {}), ...(to ? { to } : {}), ...(location_id ? { location_id } : {}) }); } catch (_) { return; }
    document.querySelector('#tabla-caja tbody').innerHTML = rows.map(c => `<tr>
      <td data-th="Apertura">${fmtDate(c.opened_at)}</td><td data-th="Punto">${UI.escapeHtml(c.location_name)}</td>
      <td data-th="Abrió">${UI.escapeHtml(c.opened_by_name || '—')}</td><td data-th="Cerró">${c.closed_at ? UI.escapeHtml(c.closed_by_name || '—') : '<span class="badge badge-warn">Abierta</span>'}</td>
      <td class="num" data-th="Fondo">${fmtDec(c.opening_amount)}</td>
      <td class="num" data-th="Debía haber">${c.expected_amount === null ? '—' : fmtDec(c.expected_amount)}</td>
      <td class="num" data-th="Contado">${c.counted_amount === null ? '—' : fmtDec(c.counted_amount)}</td>
      <td class="num ${c.difference && Math.abs(c.difference) > 0.005 ? 'low-stock' : ''}" data-th="Diferencia">${c.difference === null ? '—' : (c.difference > 0 ? '+' : '') + fmtDec(c.difference)}</td>
      <td data-th="Nota">${UI.escapeHtml(c.close_note || '—')}</td></tr>`).join('') || '<tr><td colspan="9" class="muted">Sin cierres de caja en este rango.</td></tr>';
  }

  /* ── Merma ── */
  async function renderWaste(params) {
    const { from, to, location_id } = params;
    let data;
    try { data = await Api.reports.waste({ ...(from ? { from } : {}), ...(to ? { to } : {}), ...(location_id ? { location_id } : {}) }); } catch (_) { return; }
    document.getElementById('merma-totales').innerHTML =
      statCard('Registros', data.totals.events) + statCard('Costo de lo perdido', fmt(data.totals.cost));
    const empty = cols => `<tr><td colspan="${cols}" class="muted">Sin merma en este rango.</td></tr>`;
    document.querySelector('#tabla-merma-motivo tbody').innerHTML = data.byReason.map(x =>
      `<tr><td data-th="Motivo">${UI.escapeHtml(x.label)}</td><td class="num" data-th="Veces">${x.events}</td><td class="num" data-th="Costo">${fmtDec(x.cost)}</td></tr>`).join('') || empty(3);
    document.querySelector('#tabla-merma-insumo tbody').innerHTML = data.bySupply.map(x =>
      `<tr><td data-th="Insumo">${UI.escapeHtml(x.supply_name)}</td><td class="num" data-th="Cantidad">${fmtNum(x.quantity)} ${UI.escapeHtml(x.supply_unit)}</td><td class="num" data-th="Costo">${fmtDec(x.cost)}</td></tr>`).join('') || empty(3);
    document.querySelector('#tabla-merma-recientes tbody').innerHTML = data.recent.map(x =>
      `<tr><td data-th="Fecha">${fmtDate(x.created_at)}</td><td data-th="Ubicación">${UI.escapeHtml(x.location_name)}</td><td data-th="Insumo">${UI.escapeHtml(x.supply_name)}</td><td class="num" data-th="Cantidad">${fmtNum(x.quantity)} ${UI.escapeHtml(x.supply_unit)}</td><td data-th="Motivo">${UI.escapeHtml(x.reason_label)}</td><td data-th="Nota">${UI.escapeHtml(x.note || '—')}</td><td class="num" data-th="Costo">${fmtDec(x.cost)}</td></tr>`).join('') || empty(7);
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    render(currentParams());
  });

  // Cambiar Día/Semana/Mes no debería exigir tocar "Filtrar" de nuevo — es
  // otra forma de MIRAR el mismo rango ya elegido, no un filtro nuevo.
  groupBySelect.addEventListener('change', () => render(currentParams()));

  document.getElementById('btn-imprimir-reporte').addEventListener('click', () => window.print());

  // Exportar a CSV/Excel — pedido de la auditoría ("nuevos módulos"): un
  // dueño que quiera llevarle números a un contador o cruzarlos en una hoja
  // de cálculo no tenía más opción que "Imprimir" (una vista de papel). Lee
  // la tabla YA RENDERIZADA en pantalla (respeta el filtro de fecha/ubicación
  // aplicado) en vez de pedir los datos de nuevo — "lo que ves es lo que
  // exportas", sin otro llamado a la API.
  function tableToCsv(table) {
    // Una celda "compuesta" (ej. Rendimiento de insumos: título + línea de
    // detalle + "ver desglose ›") viene de varias líneas en el HTML fuente —
    // textContent trae eso tal cual, con saltos de línea y la sangría del
    // propio template adentro. Acá se aplana a una sola línea legible y se
    // saca "ver desglose ›" (es una pista de interacción de la pantalla, no
    // un dato) para que el CSV quede prolijo en vez de una celda con 3
    // renglones pegados.
    const cellText = el => el.textContent
      .replace(/\s*ver desglose\s*›\s*/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
    const esc = s => {
      const v = String(s ?? '');
      return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
    };
    const rows = [];
    table.querySelectorAll('thead tr').forEach(tr => {
      rows.push(Array.from(tr.children).map(th => esc(cellText(th))).join(','));
    });
    table.querySelectorAll('tbody tr').forEach(tr => {
      // Fila de "sin datos" (colspan) no aporta nada a un CSV — se salta.
      if (tr.children.length === 1 && tr.children[0].hasAttribute('colspan')) return;
      rows.push(Array.from(tr.children).map(td => esc(cellText(td))).join(','));
    });
    return rows.join('\r\n');
  }

  document.querySelectorAll('[data-csv]').forEach(btn => {
    btn.addEventListener('click', () => {
      const table = document.getElementById(btn.dataset.csv);
      const csv = tableToCsv(table);
      // BOM (﻿) al principio — sin esto, Excel abre un CSV con acentos
      // (ubicación, día, ganancía) mal decodificado como si fuera otra
      // codificación de caracteres. Google Sheets y los demás lo ignoran sin
      // problema, así que no hay costo por agregarlo.
      const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const today = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `${btn.dataset.csvName}-${today}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });
  });

  window.addEventListener('view:show', async e => {
    if (e.detail.view === 'reportes') {
      await loadLocations();
      // Sin filtro, esto mostraba TODO el historial desde siempre — el
      // dueño casi siempre quiere ver "este mes" (como ya hace el Panel),
      // así que se precargan Desde/Hasta la primera vez que se abre esta
      // vista. Si ya había un rango propio puesto (volviendo de otra
      // sección), no se pisa — solo se completa cuando ambos están vacíos.
      if (!fromInput.value && !toInput.value) {
        const now = new Date();
        fromInput.value = isoDate(new Date(now.getFullYear(), now.getMonth(), 1));
        toInput.value = isoDate(now);
      }
      render(currentParams());
      renderSupplyYield();
    }
  });
})();
