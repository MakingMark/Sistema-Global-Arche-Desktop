/* ═══ Ofertas: combos de productos MIXTOS a un precio fijo, habilitables
   por punto de venta (dueño) ═══ Cada producto del combo, al venderse, sigue
   costando lo real (receta); solo el PRECIO base se reparte proporcional
   entre las líneas, y las opciones con costo extra se cobran encima — ver
   salesService.js.
   v4: lista como Insumos; una sola hoja agrupada para crear o editar (productos, precio,
   puntos de venta y página web juntos); «⋯» con Editar, Pausar y Eliminar. */
(function () {
  'use strict';
  const gridEl = document.getElementById('ofertas-grid');
  if (!gridEl) return;
  const esc = UI.escapeHtml;
  const MAS = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/></svg>';

  let vasos = []; // productos activos del menú — cualquiera puede ir en un combo
  let locations = [];
  let offers = [];

  async function loadOptions() {
    const [products, locs] = await Promise.all([Api.products.list(), Api.locations.list()]);
    vasos = products.filter(p => p.active);
    locations = locs.filter(l => l.kind === 'carrito' && l.active);
  }

  const normal = items => items.reduce((sum, it) => sum + Number(it.product_sale_price != null ? it.product_sale_price : ((vasos.find(p => p.id === Number(it.product_id)) || {}).sale_price || 0)) * Number(it.quantity), 0);

  function renderGrid() {
    if (!offers.length) {
      gridEl.innerHTML = '<div class="hv-vacio"><b>Todavía no hay ofertas</b><span class="muted">Crea un combo con «+ Oferta»: por ejemplo, almuerzo + bebida a un precio especial.</span></div>';
      return;
    }
    const fila = o => {
      const ahorro = normal(o.items) - Number(o.price);
      const locs = o.location_ids.map(id => locations.find(l => l.id === id)).filter(Boolean).map(l => l.name);
      const items = o.items.map(it => `${Number(it.quantity)}× ${esc(it.product_name)}`).join(' + ');
      const donde = locs.length ? `en ${locs.map(esc).join(', ')}` : '<span class="of-falta">sin punto de venta</span>';
      const perf = o.performance || { times_sold: 0 };
      return `<div class="in-fila${o.active ? '' : ' row-inactive'}" role="listitem" tabindex="0" data-id="${o.id}">
        <span class="ex-ini of-ini" aria-hidden="true">%</span>
        <span class="in-n"><b>${esc(o.name)}${o.active ? '' : ' <span class="pend g">Pausada</span>'}${o.web_visible ? ' <span class="pend ok">En la página</span>' : ''}</b><small>${items}</small><small>${donde} · vendida ${perf.times_sold} ${perf.times_sold === 1 ? 'vez' : 'veces'}</small></span>
        <span class="in-c"><b>${fmt(o.price)}</b><small>${ahorro > 0 ? `ahorra ${fmt(ahorro)}` : ''}</small></span>
        <button type="button" class="hv-mas" aria-label="Acciones de ${esc(o.name)}" aria-haspopup="menu">${MAS}</button>
      </div>`;
    };
    gridEl.innerHTML = `<div class="in-lista of-lista" role="list">${offers.map(fila).join('')}</div>`;
  }

  gridEl.addEventListener('click', async ev => {
    const f = ev.target.closest('[data-id]'); if (!f) return;
    const o = offers.find(x => String(x.id) === f.dataset.id); if (!o) return;
    const mas = ev.target.closest('.hv-mas');
    if (!mas) { hoja(o); return; }
    const a = await UI.rowMenu(mas, o.name, [{ a: 'editar', t: 'Editar' }, { a: 'pausa', t: o.active ? 'Pausar' : 'Activar' }, { a: 'borrar', t: 'Eliminar…', peligro: true, sep: true }]);
    if (a === 'editar') hoja(o);
    if (a === 'pausa') { try { await Api.offers.update(o.id, { active: !o.active }); UI.toast(o.active ? 'Oferta pausada' : 'Oferta activa'); render(); } catch (err) { UI.toast(err.message, 'error'); } }
    if (a === 'borrar') {
      if (!(await UI.confirmDialog(`¿Eliminar "${esc(o.name)}"? Las ventas ya hechas con esta oferta quedan intactas en el historial.`))) return;
      try { await Api.offers.remove(o.id); UI.toast('Oferta eliminada'); render(); } catch (err) { UI.toast(err.message, 'error'); }
    }
  });
  gridEl.addEventListener('keydown', ev => { const f = ev.target.closest('.in-fila'); if (f && ev.key === 'Enter' && ev.target === f) f.click(); });

  // Hoja agrupada para crear o editar un combo.
  function hoja(o) {
    if (!vasos.length) { UI.toast('Primero crea productos en el Menú', 'error'); return; }
    const editando = !!o;
    const opts = sel => vasos.map(p => `<option value="${p.id}" ${String(p.id) === String(sel) ? 'selected' : ''}>${esc(p.name)} · ${fmt(p.sale_price)}</option>`).join('');
    const filaProd = (pid, q) => `<div class="of-prod"><select aria-label="Producto">${opts(pid)}</select>
      <span class="of-cant"><button type="button" data-k="-1" aria-label="Uno menos">−</button><input type="number" min="1" step="1" inputmode="numeric" value="${q || 1}" aria-label="Cantidad"><button type="button" data-k="1" aria-label="Uno más">+</button></span>
      <button type="button" class="of-quitar" aria-label="Quitar producto">✕</button></div>`;
    const modal = UI.showModal(editando ? esc(o.name) : 'Oferta nueva', `<div class="pf">
      <div class="pf-grupo">
        <label class="pf-fila"><span>Nombre</span><input id="of-nombre" maxlength="80" autocomplete="off" value="${editando ? esc(o.name) : ''}" placeholder="ej. Almuerzo + batida"></label>
        <label class="pf-fila"><span>Precio del combo</span><span class="pf-pre">${esc(AppLocale.currency())}</span><input id="of-precio" type="number" min="0" step="0.01" inputmode="decimal" value="${editando ? Number(o.price) : ''}" placeholder="0"></label>
        ${editando ? `<label class="pf-fila"><span>Activa<small>Pausada no sale en la caja ni en la página</small></span><input type="checkbox" class="pf-sw" id="of-activa" ${o.active ? 'checked' : ''}></label>` : ''}
      </div>
      <p class="pf-sec">Productos del combo</p>
      <div class="pf-grupo">
        <div id="of-prods">${(editando ? o.items : [{ product_id: vasos[0].id, quantity: 1 }]).map(it => filaProd(it.product_id, Number(it.quantity))).join('')}</div>
        <button type="button" class="pf-fila pf-add" id="of-add">+ Agregar producto</button>
        <div class="pf-resumen" id="of-resumen" role="status"></div>
      </div>
      <p class="pf-sec">Dónde se vende</p>
      <div class="pf-grupo">
        ${locations.length ? locations.map(l => `<label class="pf-fila"><span>${esc(l.name)}</span><input type="checkbox" class="pf-check" data-loc="${l.id}" ${editando ? (o.location_ids.includes(l.id) ? 'checked' : '') : (locations.length === 1 ? 'checked' : '')}></label>`).join('') : '<div class="pf-fila pf-nota">Todavía no hay ningún punto de venta activo.</div>'}
      </div>
      <p class="pf-sec">En la página web</p>
      <div class="pf-grupo">
        <label class="pf-fila"><span>Se muestra en la página</span><input type="checkbox" class="pf-sw" id="of-web" ${editando && o.web_visible ? 'checked' : ''}></label>
        <label class="pf-fila"><span>Etiqueta</span><input id="of-label" maxlength="40" value="${editando ? esc(o.label || '') : ''}" placeholder="ej. Combo del mes"></label>
        <label class="pf-fila pf-col"><span>Descripción</span><input id="of-desc" maxlength="200" value="${editando ? esc(o.description || '') : ''}" placeholder="Opcional · ej. Tu batida favorita con un waffle"></label>
        <div class="pf-fila pf-col pf-foto">${Fotos.fieldHtml('of-image', editando ? o.image_url : '', 'Foto de la oferta')}</div>
      </div>
      <div class="error" id="of-error" role="alert" hidden></div>
      <div class="pf-acciones"><button type="button" class="btn" id="of-cancelar">Cancelar</button><button type="button" class="btn btn-primary" id="of-guardar">${editando ? 'Guardar' : 'Crear oferta'}</button></div>
    </div>`);
    const el = modal.el, $ = s => el.querySelector(s);
    Fotos.bind(el);
    const prods = $('#of-prods');
    const leer = () => Array.from(prods.querySelectorAll('.of-prod')).map(r => ({ product_id: Number(r.querySelector('select').value), quantity: Math.floor(Number(r.querySelector('input').value)) })).filter(r => r.product_id && r.quantity > 0);
    function resumen() {
      const items = leer(), suma = normal(items), precio = Number($('#of-precio').value);
      $('#of-resumen').innerHTML = items.length ? `<span>Por separado: <b>${fmt(suma)}</b>${precio > 0 ? (precio < suma ? ` · el cliente ahorra <b>${fmt(suma - precio)}</b>` : precio > suma ? ' · <span class="of-falta">el combo sale más caro que por separado</span>' : '') : ''}` : '';
    }
    prods.addEventListener('click', e => {
      const k = e.target.closest('[data-k]');
      if (k) { const inp = k.parentElement.querySelector('input'); inp.value = Math.max(1, (Number(inp.value) || 1) + Number(k.dataset.k)); resumen(); return; }
      if (e.target.closest('.of-quitar')) { if (prods.children.length > 1) e.target.closest('.of-prod').remove(); else UI.toast('El combo necesita al menos un producto', 'error'); resumen(); }
    });
    prods.addEventListener('input', resumen); prods.addEventListener('change', resumen);
    $('#of-precio').addEventListener('input', resumen);
    $('#of-add').addEventListener('click', () => { prods.insertAdjacentHTML('beforeend', filaProd(vasos[0].id, 1)); resumen(); });
    resumen();
    const err = m => { $('#of-error').textContent = m; $('#of-error').hidden = !m; };
    $('#of-cancelar').addEventListener('click', () => modal.close());
    $('#of-guardar').addEventListener('click', async () => {
      const name = $('#of-nombre').value.trim(), price = Number($('#of-precio').value), items = leer();
      if (!name) { err('Escribe el nombre del combo'); $('#of-nombre').focus(); return; }
      if (!(price > 0)) { err('El precio tiene que ser mayor que 0'); $('#of-precio').focus(); return; }
      if (!items.length) { err('Agrega al menos un producto'); return; }
      if (new Set(items.map(i => i.product_id)).size !== items.length) { err('Un producto está repetido: súmale la cantidad en vez de repetirlo'); return; }
      const locIds = Array.from(el.querySelectorAll('[data-loc]:checked')).map(c => Number(c.dataset.loc));
      const web = { web_visible: $('#of-web').checked, label: $('#of-label').value.trim(), description: $('#of-desc').value.trim(), image_url: $('#of-image').value || null };
      try {
        let id;
        if (editando) { id = o.id; await Api.offers.update(id, { name, price, items, active: $('#of-activa').checked, ...web }); }
        else { id = (await Api.offers.create({ name, price, items })).id; await Api.offers.update(id, web); }
        await Api.offers.setLocations(id, locIds);
        modal.close();
        UI.toast(editando ? 'Oferta guardada' : (locIds.length ? 'Oferta creada' : 'Oferta creada — elige dónde se vende para que salga en la caja'));
        render();
      } catch (x) { err(x.message); }
    });
    setTimeout(() => $('#of-nombre').focus(), 50);
  }

  document.getElementById('btn-oferta-nueva').addEventListener('click', () => hoja(null));

  async function render() {
    offers = await Api.offers.list();
    renderGrid();
  }

  window.addEventListener('view:show', async e => {
    if (e.detail.view === 'ofertas') {
      await loadOptions();
      await render();
    }
  });
})();
