/* ═══ Empleados: quién trabaja en cada punto de venta/almacén ═══
   v4: lista como Insumos (iniciales, nombre, local y rol); tocar abre la hoja agrupada para editar,
   «⋯» trae Editar, Cambiar PIN y Desactivar; «+ Empleado» abre la misma hoja vacía. */
(function () {
  'use strict';
  const listaEl = document.getElementById('empleados-lista');
  if (!listaEl) return;
  const esc = UI.escapeHtml;
  const buscar = document.getElementById('empleados-buscar');

  const ROLES = [['cajero', 'Cajero', 'Vende en la caja'], ['gerente', 'Gerente', 'Vende, sin tope de descuento'], ['cocina', 'Cocina', 'Solo la pantalla de cocina']];
  const rolDe = r => (ROLES.find(x => x[0] === r) || ROLES[0])[1];
  const MAS = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/></svg>';

  let employees = [];
  let locations = [];

  async function load() {
    try { [employees, locations] = await Promise.all([Api.employees.list(), Api.locations.list()]); }
    catch (err) { listaEl.innerHTML = `<p class="error">${esc(err.message)}</p>`; return; }
    render();
  }

  function render() {
    buscar.hidden = employees.length < 8;
    const q = (buscar.value || '').trim().toLowerCase();
    const vis = employees.filter(e => !q || e.name.toLowerCase().includes(q));
    if (!employees.length) {
      listaEl.innerHTML = '<div class="hv-vacio"><b>Todavía no hay empleados</b><span class="muted">Crea el primero con «+ Empleado». Cada uno entra a la caja con su propio PIN.</span></div>';
      return;
    }
    const activos = vis.filter(e => e.active), inactivos = vis.filter(e => !e.active);
    const fila = e => {
      const loc = locations.find(l => l.id === e.location_id);
      const ini = e.name.trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
      return `<div class="in-fila${e.active ? '' : ' row-inactive'}" role="listitem" tabindex="0" data-id="${e.id}">
        <span class="ex-ini emp-ini">${esc(ini)}</span>
        <span class="in-n"><b>${esc(e.name)}</b><small>${esc(loc ? loc.name : 'Sin local')} · ${rolDe(e.role)}</small></span>
        <span class="in-c">${e.active ? '<span class="pend ok">Activo</span>' : '<span class="pend g">Desactivado</span>'}</span>
        <button type="button" class="hv-mas" aria-label="Acciones de ${esc(e.name)}" aria-haspopup="menu">${MAS}</button>
      </div>`;
    };
    listaEl.innerHTML = (activos.length ? `<div class="in-lista" role="list">${activos.map(fila).join('')}</div>` : '') +
      (inactivos.length ? `<p class="pf-sec in-sec">Desactivados</p><div class="in-lista" role="list">${inactivos.map(fila).join('')}</div>` : '') +
      (!vis.length ? '<p class="muted">Nadie con ese nombre.</p>' : '');
  }

  buscar.addEventListener('input', render);
  listaEl.addEventListener('click', async ev => {
    const f = ev.target.closest('[data-id]'); if (!f) return;
    const e = employees.find(x => String(x.id) === f.dataset.id); if (!e) return;
    const mas = ev.target.closest('.hv-mas');
    if (!mas) { hoja(e); return; }
    const a = await UI.rowMenu(mas, e.name, [{ a: 'editar', t: 'Editar' }, { a: 'pin', t: 'Cambiar PIN…' }, e.active ? { a: 'toggle', t: 'Desactivar…', peligro: true, sep: true } : { a: 'toggle', t: 'Reactivar', sep: true }]);
    if (a === 'editar') hoja(e);
    if (a === 'pin') cambiarPin(e);
    if (a === 'toggle') activar(e, !e.active);
  });
  listaEl.addEventListener('keydown', ev => { const f = ev.target.closest('.in-fila'); if (f && ev.key === 'Enter' && ev.target === f) f.click(); });

  async function cambiarPin(e) {
    const pin = await UI.promptDialog(`Nuevo PIN de ${esc(e.name)} (4 dígitos):`, 'ej. 4821');
    if (pin === null) return;
    try { await Api.employees.update(e.id, { pin }); UI.toast('PIN cambiado'); load(); } catch (err) { UI.toast(err.message, 'error'); }
  }
  async function activar(e, on) {
    if (!on && !(await UI.confirmDialog(`¿Desactivar a ${esc(e.name)}? Ya no podrá entrar con su PIN. Su historial queda intacto y puedes reactivarlo cuando quieras.`))) return;
    try { await Api.employees.update(e.id, { active: on }); UI.toast(on ? 'Reactivado' : 'Desactivado'); load(); } catch (err) { UI.toast(err.message, 'error'); }
  }

  // Hoja agrupada (como «Editar producto») para crear o editar.
  function hoja(e) {
    const editando = !!e;
    const locOpts = locations.filter(l => l.active !== false || (e && l.id === e.location_id)).map(l => `<option value="${l.id}" ${e && l.id === e.location_id ? 'selected' : ''}>${esc(l.name)}</option>`).join('');
    const modal = UI.showModal(editando ? esc(e.name) : 'Empleado nuevo', `<div class="pf">
      <div class="pf-grupo">
        <label class="pf-fila"><span>Nombre</span><input id="em-nombre" maxlength="80" autocomplete="off" value="${editando ? esc(e.name) : ''}" placeholder="ej. Ana Rodríguez"></label>
        ${editando ? `<div class="pf-fila"><span>PIN</span><button type="button" class="pin-mask" data-pin="${esc(e.pin)}" aria-label="Ver PIN">••••</button><button type="button" class="btn btn-sm em-pin">Cambiar</button></div>`
          : '<label class="pf-fila"><span>PIN<small>4 números, solo de esta persona</small></span><input id="em-pin" inputmode="numeric" pattern="\\d{4}" maxlength="4" autocomplete="off" placeholder="0000"></label>'}
      </div>
      <p class="pf-sec">Dónde trabaja</p>
      <div class="pf-grupo">
        <label class="pf-fila"><span>Local</span><select id="em-local">${locOpts}</select></label>
        ${ROLES.map(([v, t, sub]) => `<label class="pf-fila"><span>${t}<small>${sub}</small></span><input type="radio" name="em-rol" class="pf-check" value="${v}" ${(e ? e.role : 'cajero') === v ? 'checked' : ''}></label>`).join('')}
      </div>
      ${editando ? `<div class="pf-grupo" style="margin-top:12px"><label class="pf-fila"><span>Activo<small>Si se apaga, ya no entra con su PIN</small></span><input type="checkbox" class="pf-sw" id="em-activo" ${e.active ? 'checked' : ''}></label></div>` : ''}
      <div class="error" id="em-error" role="alert" hidden></div>
      <div class="pf-acciones"><button type="button" class="btn" id="em-cancelar">Cancelar</button><button type="button" class="btn btn-primary" id="em-guardar">${editando ? 'Guardar' : 'Crear empleado'}</button></div>
    </div>`);
    const el = modal.el, $ = s => el.querySelector(s);
    const err = m => { $('#em-error').textContent = m; $('#em-error').hidden = !m; };
    $('#em-cancelar').addEventListener('click', () => modal.close());
    if (editando) $('.em-pin').addEventListener('click', () => { modal.close(); cambiarPin(e); });
    $('#em-guardar').addEventListener('click', async () => {
      const name = $('#em-nombre').value.trim();
      const role = (el.querySelector('input[name="em-rol"]:checked') || {}).value || 'cajero';
      const location_id = Number($('#em-local').value);
      if (!name) { err('Escribe el nombre'); $('#em-nombre').focus(); return; }
      try {
        if (editando) {
          const activo = $('#em-activo').checked;
          if (!activo && e.active && !(await UI.confirmDialog(`¿Desactivar a ${esc(e.name)}? Ya no podrá entrar con su PIN.`))) return;
          await Api.employees.update(e.id, { name, role, location_id, active: activo });
          UI.toast('Guardado');
        } else {
          const pin = $('#em-pin').value.trim();
          if (!/^\d{4}$/.test(pin)) { err('El PIN son 4 números'); $('#em-pin').focus(); return; }
          await Api.employees.create({ name, pin, role, location_id });
          UI.toast(`${name} ya puede entrar con su PIN`);
        }
        modal.close(); load();
      } catch (x) { err(x.message); }
    });
    setTimeout(() => $('#em-nombre').focus(), 50);
  }

  document.getElementById('btn-empleado-nuevo').addEventListener('click', () => {
    if (!locations.length) { UI.toast('Primero crea un local en Ubicaciones', 'error'); return; }
    hoja(null);
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'empleados') load();
  });
  // v3.12: el PIN no queda a la vista de quien mire la pantalla; un toque lo
  // muestra 5 segundos.
  document.addEventListener('click', e => {
    const b = e.target.closest('.pin-mask');
    if (!b) return;
    if (b.textContent !== '••••') { b.textContent = '••••'; return; }
    b.textContent = b.dataset.pin;
    setTimeout(() => { b.textContent = '••••'; }, 5000);
  });
})();
