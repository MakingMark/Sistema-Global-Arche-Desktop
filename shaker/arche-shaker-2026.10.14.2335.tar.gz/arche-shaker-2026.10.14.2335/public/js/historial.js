/* ═══ Historial de ventas (dueño, todas las ubicaciones, filtrable) ═══ */
(function () {
  'use strict';
  const grid = document.getElementById('historial-grid');
  if (!grid) return;
  const form = document.getElementById('form-historial-filtro');
  const locationSelect = form.querySelector('[name="location_id"]');
  const fromInput = form.querySelector('[name="from"]');
  const toInput = form.querySelector('[name="to"]');

  // Componentes LOCALES de la fecha — nunca .toISOString().slice(0,10), que
  // da la fecha en UTC y se adelanta un día entero entre las 8pm y la
  // medianoche en Santo Domingo (UTC-4). Mismo bug ya encontrado y
  // corregido en pos.js/reportes.js/dashboard.js.
  // localIsoDate ahora es global — ver api.js.

  async function loadLocations() {
    const locations = await Api.locations.list();
    // Solo ubicaciones activas: "Todas" ya suma el historial completo
    // (retiradas incluidas) — el filtro puntual por una ya dada de baja no
    // aporta y solo ensucia la lista con puntos de venta de prueba nunca limpiados.
    locationSelect.innerHTML = '<option value="">Todas</option>' +
      locations.filter(l => l.active).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');
    // Formas de pago del negocio (Configuración), para el filtro «Pago».
    const pago = form.querySelector('[name="payment_method"]'), elegido = pago.value;
    pago.innerHTML = '<option value="">Todos</option>' + AppLocale.payments().map(m => `<option>${UI.escapeHtml(m)}</option>`).join('');
    pago.value = elegido;
  }

  // v4 (DISENO-ARCHE.md): de tarjetas a una lista con forma de tabla. En la computadora cada venta es una
  // fila (hora, cliente, quién, pago, estado y total) con sus acciones en un menú «⋯»; en el celular la
  // misma fila se apila y al tocarla sube la factura. Anular queda aparte y en rojo.
  const hora = iso => new Date(iso).toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit' });
  const diaCorto = iso => new Date(iso).toLocaleDateString('es-DO', { weekday: 'short', day: 'numeric', month: 'short' }).replace(/\./g, '');
  async function verFactura(id) {
    const win = openReceiptWindow(false);
    // Sin try/catch, un fallo de red dejaba la ventana nueva trabada en "Cargando…" para siempre.
    try { const detail = await Api.sales.get(id); fillReceiptWindow(win, detail.receipt); }
    catch (err) { if (win && !win.closed) fillReceiptWindow(win, `No se pudo cargar la factura: ${err.message}`); }
  }
  // v4: anular es una hoja, no una ventana de texto. Muestra qué venta es (total, cuándo, qué llevó),
  // qué va a pasar, y motivos de un toque; el botón rojo solo se activa con un motivo.
  const MOTIVOS = ['Error al cobrar', 'Cobro repetido', 'El cliente se arrepintió', 'Producto equivocado', 'Venta de prueba'];
  async function anular(s) {
    let det = null;
    try { det = await Api.sales.get(s.id); } catch (_) { /* sin detalle se anula igual con lo que trae la fila */ }
    const items = det && det.items ? det.items : [];
    const total = s.amount_due != null ? s.amount_due : s.total;
    const cuando = new Date(s.created_at).toLocaleString('es-DO', { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }).replace(/([a-zé]{3})\.(?= )/g, '$1');
    const esc = UI.escapeHtml;
    const modal = UI.showModal('Anular venta', `<div class="pf an">
      <div class="an-resumen">
        <span class="an-num">Venta #${s.id}</span>
        <b class="an-total">${fmt(total)}</b>
        <span class="an-meta">${esc(cuando)}${s.payment_method ? ' · ' + esc(s.payment_method) : ''}${s.customer_name ? ' · ' + esc(s.customer_name) : ''}</span>
        ${items.length ? `<ul class="an-items">${items.slice(0, 4).map(i => `<li><span>${fmtNum(Number(i.quantity))} × ${esc(i.product_name)}</span><span>${fmt(i.subtotal)}</span></li>`).join('')}${items.length > 4 ? `<li class="muted"><span>y ${items.length - 4} más</span></li>` : ''}</ul>` : ''}
      </div>
      <div class="pf-sec">Qué va a pasar</div>
      <div class="pf-grupo">
        <div class="pf-fila an-paso"><span class="an-ic">↺</span><span>Lo que se descontó del inventario vuelve a su lugar.</span></div>
        <div class="pf-fila an-paso"><span class="an-ic">≡</span><span>La venta no se borra: queda en Ventas marcada como <b>Anulada</b>, con el motivo.</span></div>
        ${s.payment_method && !/fiado/i.test(s.payment_method) ? '<div class="pf-fila an-paso"><span class="an-ic">$</span><span>Si ya cobraste, devuelve el dinero al cliente aparte.</span></div>' : ''}
      </div>
      <div class="pf-sec">Motivo</div>
      <div class="an-chips" role="group" aria-label="Motivos rápidos">${MOTIVOS.map(m => `<button type="button" class="an-chip">${m}</button>`).join('')}</div>
      <div class="pf-grupo"><label class="pf-fila pf-col"><span>Escríbelo o toca uno de arriba</span><textarea id="an-motivo" rows="2" maxlength="200" placeholder="ej. Se cobró dos veces"></textarea></label></div>
      <div class="pf-acciones"><button class="btn" id="an-no">Cancelar</button><button class="btn btn-peligro" id="an-si" disabled>Anular venta</button></div>
    </div>`);
    const el = modal.el, txt = el.querySelector('#an-motivo'), si = el.querySelector('#an-si');
    const listo = () => { si.disabled = !txt.value.trim(); };
    txt.addEventListener('input', () => { el.querySelectorAll('.an-chip').forEach(c => c.classList.toggle('is-on', c.textContent === txt.value.trim())); listo(); });
    el.querySelectorAll('.an-chip').forEach(c => c.addEventListener('click', () => {
      txt.value = c.textContent; el.querySelectorAll('.an-chip').forEach(x => x.classList.toggle('is-on', x === c)); listo();
    }));
    el.querySelector('#an-no').addEventListener('click', () => modal.close());
    si.addEventListener('click', async () => {
      si.disabled = true;
      // Puede rechazar en 409 real (ya anulada desde otra pestaña): se avisa y se recarga.
      try { await Api.sales.void(s.id, txt.value.trim()); modal.close(); UI.toast(`Venta #${s.id} anulada`); }
      catch (err) { UI.toast(err.message, 'error'); si.disabled = false; return; }
      render(currentParams());
    });
  }
  let menu = null;
  const cerrarMenu = () => { if (menu) { menu.remove(); menu = null; } };
  document.addEventListener('click', e => { if (menu && !menu.contains(e.target) && !e.target.closest('.hv-mas')) cerrarMenu(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarMenu(); });
  function abrirMenu(btn, s) {
    cerrarMenu();
    const voided = s.status === 'anulada';
    menu = document.createElement('div'); menu.className = 'v4-menu'; menu.setAttribute('role', 'menu');
    menu.innerHTML = `<div class="v4-menu-cab">Venta #${s.id} · ${fmt(s.amount_due != null ? s.amount_due : s.total)}</div>
      <button type="button" role="menuitem" data-a="ver">Ver / imprimir</button>
      ${!voided && !s.return_of ? '<button type="button" role="menuitem" data-a="dev">Devolver productos…</button>' : ''}
      ${!voided ? '<hr><button type="button" role="menuitem" class="is-peligro" data-a="anular">Anular venta…</button>' : ''}`;
    document.body.appendChild(menu);
    const r = btn.getBoundingClientRect(), mw = menu.offsetWidth, mh = menu.offsetHeight;
    menu.style.left = Math.max(8, Math.min(window.innerWidth - mw - 8, r.right - mw)) + 'px';
    menu.style.top = (r.bottom + mh + 8 > window.innerHeight ? r.top - mh - 6 : r.bottom + 6) + 'px';
    menu.style.transformOrigin = 'top right';
    menu.addEventListener('click', ev => {
      const a = ev.target.closest('[data-a]'); if (!a) return;
      cerrarMenu();
      if (a.dataset.a === 'ver') verFactura(s.id);
      if (a.dataset.a === 'dev') Devoluciones.open(s.id, { detail: Api.sales.get, submit: Api.sales.returnItems }, () => render(currentParams()));
      if (a.dataset.a === 'anular') anular(s);
    });
    const primero = menu.querySelector('button'); if (primero) primero.focus();
  }

  async function render(params) {
    // Placeholder mientras llega la respuesta (el filtro puede tardar si hay muchas ventas).
    grid.innerHTML = UI.skeletonCards(4);
    const sales = await Api.sales.list(params);
    ultimas = { sales, params };
    grid.innerHTML = '';
    if (!sales.length) {
      grid.innerHTML = `<div class="hv-vacio"><b>Sin ventas para este filtro</b><span class="muted">Prueba con otro día o con «Todas» las ubicaciones.</span></div>`;
      return;
    }
    const vivas = sales.filter(s => s.status !== 'anulada');
    const total = vivas.reduce((t, s) => t + Number(s.amount_due != null ? s.amount_due : s.total), 0);
    const facturas = vivas.filter(s => !s.return_of).length;
    const variosDias = new Set(sales.map(s => new Date(s.created_at).toDateString())).size > 1;
    grid.insertAdjacentHTML('beforeend', `<div class="hv-resumen"><div><small>Cobrado</small><b>${fmt(total)}</b></div><div><small>Facturas</small><b>${facturas}</b></div><div><small>Ticket promedio</small><b>${fmt(facturas ? total / facturas : 0)}</b></div>${sales.length - vivas.length ? `<div><small>Anuladas</small><b>${sales.length - vivas.length}</b></div>` : ''}<button type="button" class="hv-exportar" id="hv-exportar"><svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><path d="M12 4v11m0 0l-4-4m4 4l4-4M5 19h14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Exportar</button></div>
      <div class="hv-cab" aria-hidden="true"><span>Venta</span><span>${variosDias ? 'Fecha' : 'Hora'}</span><span>Cliente</span><span>Ubicación y cajero</span><span>Pago</span><span>Estado</span><span class="r">Total</span><span></span></div>`);
    const lista = document.createElement('div');
    lista.className = 'hv-lista'; lista.setAttribute('role', 'list');
    // Grupos por momento del día (o por día si el rango es de varios días), como en la maqueta.
    const momento = iso => { const d = new Date(iso), h = d.getHours(); const parte = h < 12 ? 'Esta mañana' : h < 18 ? 'Esta tarde' : 'Esta noche';
      if (variosDias) return d.toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long' });
      return new Date(iso).toDateString() === new Date().toDateString() ? parte : parte.replace('Esta', 'En la').replace('En la mañana', 'En la mañana'); };
    let grupoAnt = null;
    sales.forEach(s => {
      const g = momento(s.created_at);
      if (g !== grupoAnt) { grupoAnt = g; const gh = document.createElement('div'); gh.className = 'hv-grupo'; gh.setAttribute('role', 'presentation'); gh.textContent = g; lista.appendChild(gh); }
      const voided = s.status === 'anulada';
      const estado = voided ? '<span class="pend b">Anulada</span>' : s.return_of ? `<span class="pend am">Devolución de #${s.return_of}</span>` : Number(s.discount_amount) > 0 ? '<span class="pend g">Con descuento</span>' : '<span class="pend ok">Pagada</span>';
      const fila = document.createElement('div');
      fila.className = 'hv-fila' + (voided ? ' row-voided' : '');
      fila.setAttribute('role', 'listitem'); fila.tabIndex = 0;
      fila.innerHTML = `<span class="hv-id">#${s.id}</span>
        <span class="hv-hora">${variosDias ? `${diaCorto(s.created_at)} · ` : ''}${hora(s.created_at)}</span>
        <span class="hv-cli">${UI.escapeHtml(s.customer_name) || '<span class="muted">Mostrador</span>'}</span>
        <span class="hv-quien muted"><span class="hv-solo-mov">${hora(s.created_at)} · </span>${UI.escapeHtml(s.location_name)}${s.employee_name ? ' · ' + UI.escapeHtml(s.employee_name) : ''}</span>
        <span class="hv-pago muted">${UI.escapeHtml(s.payment_method || '—')}</span>
        <span class="hv-est">${estado}</span>
        <span class="hv-total">${fmt(s.amount_due != null ? s.amount_due : s.total)}</span>
        <button type="button" class="hv-mas" aria-label="Acciones de la venta #${s.id}" aria-haspopup="menu"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/></svg></button>`;
      fila.addEventListener('click', e => {
        const mas = e.target.closest('.hv-mas');
        if (mas) { e.stopPropagation(); abrirMenu(mas, s); return; }
        // En el celular la fila entera abre las acciones; en la computadora abre la factura.
        // stopPropagation: sin esto, el mismo toque llegaba al «clic afuera» del documento y cerraba el menú al instante.
        if (matchMedia('(max-width:820px)').matches) { e.stopPropagation(); abrirMenu(fila.querySelector('.hv-mas'), s); } else verFactura(s.id);
      });
      fila.addEventListener('keydown', e => { if (e.key === 'Enter') verFactura(s.id); if (e.key === 'ContextMenu' || (e.shiftKey && e.key === 'F10')) { e.preventDefault(); abrirMenu(fila.querySelector('.hv-mas'), s); } });
      fila.addEventListener('contextmenu', e => { e.preventDefault(); abrirMenu(fila.querySelector('.hv-mas'), s); });
      lista.appendChild(fila);
    });
    grid.appendChild(lista);
  }

  // «Exportar»: las ventas que se están viendo, en un archivo que abre Excel (con tildes, separado por comas).
  let ultimas = { sales: [], params: {} };
  function exportar() {
    const esc = v => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const filas = [['Venta', 'Fecha', 'Hora', 'Cliente', 'Ubicación', 'Cajero', 'Pago', 'Estado', 'Total'].join(',')];
    ultimas.sales.forEach(s => {
      const d = new Date(s.created_at);
      const estado = s.status === 'anulada' ? 'Anulada' : s.return_of ? `Devolución de #${s.return_of}` : 'Pagada';
      filas.push([s.id, localIsoDate(d), hora(s.created_at), esc(s.customer_name || 'Mostrador'), esc(s.location_name), esc(s.employee_name || ''), esc(s.payment_method || ''), estado, Number(s.amount_due != null ? s.amount_due : s.total).toFixed(2)].join(','));
    });
    const blob = new Blob(['\ufeff' + filas.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    const p = ultimas.params;
    a.href = url; a.download = `ventas-${p.from || 'todas'}${p.to && p.to !== p.from ? '-a-' + p.to : ''}.csv`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    UI.toast(`${ultimas.sales.length} ventas exportadas`, 'success');
  }
  grid.addEventListener('click', e => { if (e.target.closest('#hv-exportar')) exportar(); });

  function currentParams() {
    const fd = new FormData(form);
    const params = {};
    if (fd.get('from')) params.from = fd.get('from');
    if (fd.get('to')) params.to = fd.get('to');
    if (fd.get('location_id')) params.location_id = fd.get('location_id');
    if (fd.get('payment_method')) params.payment_method = fd.get('payment_method');
    return params;
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    render(currentParams());
  });
  document.getElementById('btn-historial-limpiar').addEventListener('click', () => {
    form.reset();
    render({});
  });

  window.addEventListener('view:show', async e => {
    if (e.detail.view === 'historial') {
      await loadLocations();
      // Arranca en "hoy" — pedido explícito del dueño: sin esto mostraba
      // las últimas 300 ventas de TODO el historial de una, que no es lo
      // que casi nadie quiere ver al entrar. Si ya había un rango propio
      // puesto (volviendo de otra pantalla), no se pisa — mismo criterio
      // que ya usa Reportes y el Historial del punto de venta.
      if (!fromInput.value && !toInput.value) {
        fromInput.value = toInput.value = localIsoDate();
      }
      render(currentParams());
    }
  });
})();
