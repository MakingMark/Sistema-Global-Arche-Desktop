/* ═══ Login «B · con el color del negocio» (13-oct; DISENO-ARCHE.md) ═══
   Sin nombres de personas en pantalla: el código dice quién entra (como Toast o Shopify POS). Antes este login
   recordaba en cada equipo a quién había entrado y lo mostraba en círculos; eso se quitó y se borra lo guardado.
   Aquí: «Entrar como dueño» (cambia a contraseña), «¿Olvidaste tu código?», el nombre del negocio en la fecha
   del celular y el círculo de quien entra en la pantalla de carga. El formulario y la entrada siguen en auth.js. */
(function () {
  'use strict';
  const pantalla = document.getElementById('login-screen');
  if (!pantalla || typeof Auth === 'undefined') return;
  try { localStorage.removeItem('arche_personas_v1'); } catch (_) {}
  document.documentElement.classList.add('v4-login');
  const iniciales = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();

  // Pantalla de carga: el círculo de quien entra (solo lo ve esa persona, al entrar).
  const setOriginal = Auth.set;
  Auth.set = function (s) {
    try {
      const av = document.getElementById('v4-carga-av');
      if (av && s) {
        av.textContent = s.role === 'owner' ? '' : iniciales(s.employeeName || '');
        av.classList.toggle('es-dueno', s.role === 'owner');
        document.getElementById('access-loading').classList.add('v4-con-av');
      }
    } catch (_) {}
    return setOriginal.apply(this, arguments);
  };

  const pinpad = document.getElementById('login-pinpad');
  const tit = document.getElementById('ln-t-tit'), sub = document.getElementById('ln-t-sub');
  const dueno = document.getElementById('ln-dueno'), olvido = document.getElementById('ln-olvido'), ayuda = document.getElementById('ln-ayuda');
  const enPin = () => !pinpad.hidden;
  const modo = m => { const b = document.querySelector(`#login-mode [data-mode="${m}"]`); if (b && b.getAttribute('aria-checked') !== 'true') b.click(); };
  function textos() {
    const pin = enPin();
    tit.textContent = pin ? 'Tu código' : 'Contraseña del dueño';
    sub.textContent = pin ? '4 dígitos · entra solo al terminar' : 'Solo el dueño entra con contraseña';
    dueno.textContent = pin ? 'Entrar como dueño' : 'Usar código';
    olvido.textContent = pin ? '¿Olvidaste tu código?' : '¿Olvidaste la contraseña?';
    pantalla.classList.toggle('ln-modo-dueno', !pin);
    const st = pantalla.querySelector('.ln-sub-t'); if (st) st.textContent = pin ? 'Escribe tu código para entrar' : 'Entra con la contraseña del dueño';
    ayuda.hidden = true;
  }
  dueno.addEventListener('click', () => {
    modo(enPin() ? 'keyboard' : 'pin');
    if (!enPin()) setTimeout(() => { const c = document.getElementById('login-credential'); if (c) c.focus(); }, 40);
  });
  olvido.addEventListener('click', () => {
    if (enPin()) { ayuda.hidden = !ayuda.hidden; return; }
    document.getElementById('login-forgot-link').click();
  });
  new MutationObserver(textos).observe(pinpad, { attributes: true, attributeFilter: ['hidden'] });
  // Mientras se recupera la contraseña, los enlaces de abajo sobran.
  const forgot = document.getElementById('forgot-form');
  if (forgot) new MutationObserver(() => {
    pantalla.classList.toggle('ln-recuperando', !forgot.hidden);
    if (!forgot.hidden) { tit.textContent = 'Recuperar la contraseña'; sub.textContent = 'Te mandamos un código al correo del dueño'; } else textos();
  }).observe(forgot, { attributes: true, attributeFilter: ['hidden'] });
  textos();

  // El negocio arriba, como en la barra lateral: su logo (o sus iniciales en su color) y su nombre, también en
  // «Escribe tu código para entrar a Café Arche».
  const neg = document.getElementById('brand-name-login'), logo = document.getElementById('ln-logo'), subNeg = pantalla.querySelector('.ln-sub-neg');
  let logoUrl = null;
  function marca() {
    const n = neg ? neg.textContent.trim() : '';
    if (subNeg) subNeg.textContent = n && n !== 'Mi negocio' ? ' a ' + n : '';
    if (!logo) return;
    logo.classList.toggle('con-imagen', !!logoUrl);
    logo.textContent = logoUrl ? '' : iniciales(n || 'Arche');
    if (logoUrl) { const img = new Image(); img.alt = ''; img.src = logoUrl; logo.appendChild(img); }
  }
  window.addEventListener('arche:marca', e => { logoUrl = (e.detail && e.detail.logo) || null; marca(); });
  if (neg) new MutationObserver(marca).observe(neg, { childList: true, characterData: true, subtree: true });
  marca();
})();

/* Facturación: subtítulo del título «Vender» con el punto de venta y la persona (en el celular). */
(function () {
  const h = document.getElementById('pos-venta-titulo'); if (!h) return;
  const poner = () => { try { const s = Auth.get(); if (s && s.role === 'cart') h.dataset.sub = [s.locationName, (s.employeeName || '').split(' ')[0]].filter(Boolean).join(' · '); } catch (_) {} };
  poner(); window.addEventListener('view:show', poner);
})();
