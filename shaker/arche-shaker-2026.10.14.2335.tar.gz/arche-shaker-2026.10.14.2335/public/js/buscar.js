/* ═══ Búsqueda global del administrativo (v3.10) ═══
   Ctrl+K (⌘K en Mac), la tecla «/» o la lupa de la barra superior abren un
   buscador que encuentra pantallas, productos, insumos y clientes. Elegir uno
   lleva a su pantalla con el buscador de esa pantalla ya escrito (así se ve
   enseguida, sin tener que buscar otra vez). Respeta los módulos apagados. */
(function () {
  'use strict';
  const app = document.getElementById('owner-app');
  const btn = document.getElementById('buscar-btn');
  if (!app || !btn) return;
  const esc = s => UI.escapeHtml(String(s));
  const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const T = (k, f) => (window.Vocab ? Vocab.t(k, f) : f);

  // v4: los nombres de las pantallas como se ven ahora en la barra lateral.
  const PANTALLAS = [
    ['panel', 'Hoy', 'inicio resumen panel ganancia dia'], ['historial', 'Ventas', 'historial facturas anular devolver exportar'],
    ['inv-existencias', 'Inventario', 'existencias stock bajo'], ['inv-entradas', 'Registrar compra', 'entradas inventario recibir mercancia'],
    ['compras', 'Compras', 'proveedores ordenes'], ['inv-preparar', 'Preparar', 'cocinar porcionar elaborados'],
    ['inv-transferir', 'Transferir', 'enviar mercancia almacen'], ['inv-ajustes', 'Ajustes y merma', 'corregir perdida vencido'],
    ['menu', () => T('menu', 'Catálogo'), 'productos menu recetas opciones categorias'], ['insumos', () => T('insumos', 'Insumos'), 'costos materia prima'],
    ['ofertas', 'Ofertas', 'combos promociones'], ['reportes', 'Reportes', 'ganancias utilidad margen cierres de caja'],
    ['gastos', 'Gastos', 'alquiler nomina luz'], ['analitica', 'Tendencias', 'horas pico mas vendidos'],
    ['clientes', 'Clientes', 'fiado credito telefono'], ['pagina', 'Página web', 'tienda en linea pedidos fotos horarios'],
    ['empleados', 'Equipo', 'empleados pin cajero rol'], ['turnos', 'Turnos', 'horas llegada salida'],
    ['salon', 'Mesas', 'mesas salon terraza zonas barra'], ['ubicaciones', 'Ubicaciones', 'locales almacen'], ['configuracion', 'Configuración', 'ajustes marca logo modulos impuestos itbis licencia respaldo contraseña']
  ];
  // Acciones de un toque (lo que más se hace desde cualquier lado).
  const ACCIONES = [
    { t: 'Registrar compra', s: 'Lo que llegó y cuánto costó', go: 'inv-entradas', ic: 'compra' },
    { t: 'Nuevo producto', s: 'Al catálogo, con su receta', go: 'menu', clic: 'btn-menu-producto', ic: 'producto' },
    { t: 'Anotar un gasto', s: 'Alquiler, luz, nómina…', go: 'gastos', clic: 'btn-gasto-nuevo', ic: 'gasto' }
  ];
  const ICONOS = {
    Pantallas: ['#8E8E93', '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 9h16"/>'],
    Productos: ['#FF9F0A', '<path d="M6.5 4h11l-1.3 14.2a2 2 0 0 1-2 1.8h-4.4a2 2 0 0 1-2-1.8z"/>'],
    Insumos: ['#34C759', '<path d="M3 7.5L12 3l9 4.5-9 4.5z"/><path d="M3 7.5v9L12 21l9-4.5v-9"/>'],
    Clientes: ['#AF52DE', '<circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c0-3.6 3.1-6 7-6s7 2.4 7 6"/>'],
    Recientes: ['#636366', '<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>'],
    compra: ['#0A84FF', '<path d="M12 4v11m0 0l-4-4m4 4l4-4M5 19h14"/>'],
    producto: ['#FF9F0A', '<path d="M12 5v14M5 12h14"/>'],
    gasto: ['#FF3B30', '<rect x="3.5" y="6" width="17" height="12" rx="2"/><path d="M3.5 10h17"/>']
  };
  const icono = k => { const [c, d] = ICONOS[k] || ICONOS.Pantallas; return `<span class="buscar-ic" style="background:${c}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg></span>`; };
  const RECIENTES = 'arche_buscar_recientes';
  const recientes = () => { try { return JSON.parse(localStorage.getItem(RECIENTES) || '[]'); } catch (_) { return []; } };
  const recordar = r => { try { const k = r.g + '|' + r.t; localStorage.setItem(RECIENTES, JSON.stringify([{ ...r, g: r.g }, ...recientes().filter(x => x.g + '|' + x.t !== k)].slice(0, 5))); } catch (_) {} };
  const label = l => (typeof l === 'function' ? l() : l);

  let datos = null, cargadoEn = 0;
  async function cargar() {
    if (datos && Date.now() - cargadoEn < 120000) return datos;
    const on = m => !window.Modules || Modules.enabled(m);
    const [prods, sups, clis] = await Promise.all([
      Api.products.list().catch(() => []),
      on('insumos') ? Api.supplies.list().catch(() => []) : [],
      on('clientes') ? Api.customers.list().catch(() => []) : []
    ]);
    datos = { prods: prods || [], sups: sups || [], clis: clis || [] };
    cargadoEn = Date.now();
    return datos;
  }

  /* ── Ventana ── */
  const ov = document.createElement('div');
  ov.className = 'buscar-overlay';
  ov.hidden = true;
  ov.innerHTML = `<div class="buscar-box" role="dialog" aria-modal="true" aria-label="Buscar">
      <div class="buscar-input"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>
        <input type="search" id="buscar-q" placeholder="Productos, insumos, clientes o pantallas" autocomplete="off" spellcheck="false"><kbd>Esc</kbd><button type="button" class="buscar-cancelar">Cancelar</button></div>
      <div class="buscar-res" id="buscar-res" role="listbox"></div>
    </div>`;
  document.body.appendChild(ov);
  const q = ov.querySelector('#buscar-q');
  const res = ov.querySelector('#buscar-res');
  let resultados = [], sel = 0;

  function buscar() {
    const t = norm(q.value.trim());
    const out = [];
    const pantallas = PANTALLAS.filter(([v]) => !(window.Modules && Modules.viewOff(v)));
    if (!t) {
      recientes().forEach(r => out.push({ ...r, g: 'Recientes', ic: r.ic || r.g }));
      ACCIONES.filter(a => !(window.Modules && Modules.viewOff(a.go))).forEach(a => out.push({ ...a, g: 'Acciones' }));
      const PRINCIPALES = ['panel', 'historial', 'inv-existencias', 'menu', 'reportes', 'clientes'];
      pantallas.filter(([v]) => PRINCIPALES.includes(v)).forEach(([v, l]) => out.push({ g: 'Pantallas', t: label(l), s: '', go: v }));
      resultados = out; sel = 0; pintar(); return;
    }
    ACCIONES.filter(a => norm(a.t + ' ' + a.s).includes(t) && !(window.Modules && Modules.viewOff(a.go))).forEach(a => out.push({ ...a, g: 'Acciones' }));
    pantallas.forEach(([v, l, k]) => { if (norm(label(l) + ' ' + k).includes(t)) out.push({ g: 'Pantallas', t: label(l), s: '', go: v }); });
    if (datos) {
      datos.prods.filter(p => p.active !== false && norm(p.name + ' ' + (p.barcode || '') + ' ' + (p.sku || '')).includes(t)).slice(0, 6)
        .forEach(p => out.push({ g: 'Productos', t: p.name, s: fmt(p.sale_price), go: 'menu', campo: 'menu-search', valor: p.name }));
      datos.sups.filter(x => x.active !== false && norm(x.name).includes(t)).slice(0, 6)
        .forEach(x => out.push({ g: 'Insumos', gt: label(() => T('insumos', 'Insumos')), t: x.name, s: x.unit || '', go: 'insumos', campo: 'insumos-search', valor: x.name }));
      datos.clis.filter(c => norm((c.name || '') + ' ' + (c.phone || '')).includes(t)).slice(0, 6)
        .forEach(c => out.push({ g: 'Clientes', t: c.name || c.phone, s: c.phone || '', go: 'clientes', campo: 'clientes-search', valor: c.phone || c.name }));
    }
    resultados = out;
    sel = 0;
    pintar();
  }
  function pintar() {
    if (!resultados.length) { res.innerHTML = `<p class="buscar-vacio"><b>Sin resultados para «${esc(q.value.trim())}»</b><br>Prueba con otra palabra o con parte del nombre.</p>`; return; }
    let grupo = null, html = '';
    resultados.forEach((r, i) => {
      if (r.g !== grupo) { html += `${grupo === null ? '' : '</div>'}<p class="buscar-g">${esc(r.gt || r.g)}</p><div class="buscar-grupo">`; grupo = r.g; }
      html += `<button type="button" class="buscar-item${i === sel ? ' is-sel' : ''}" role="option" aria-selected="${i === sel}" data-i="${i}">${icono(r.ic || r.g)}<span class="buscar-t"><b>${esc(r.t)}</b>${r.s ? `<small>${esc(r.s)}</small>` : ''}</span><span class="buscar-enter" aria-hidden="true">↵</span></button>`;
    });
    res.innerHTML = html + '</div>';
  }
  function ir(r) {
    if (!r) return;
    if (r.g !== 'Acciones') recordar({ g: r.g === 'Recientes' ? (r.gOrig || 'Pantallas') : r.g, gOrig: r.gOrig || r.g, t: r.t, s: r.s, go: r.go, campo: r.campo, valor: r.valor, ic: r.ic || r.g });
    cerrar();
    if (r.clic) { window.showView(r.go); window.scrollTo({ top: 0 }); setTimeout(() => { const b = document.getElementById(r.clic); if (b) b.click(); }, 450); return; }
    if (r.campo) { const inp = document.getElementById(r.campo); if (inp) inp.value = r.valor; }
    window.showView(r.go);
    window.scrollTo({ top: 0 });
    if (r.campo) setTimeout(() => { const inp = document.getElementById(r.campo); if (inp) { inp.value = r.valor; inp.dispatchEvent(new Event('input', { bubbles: true })); } }, 700);
  }

  async function abrir() {
    if (app.hidden) return;
    ov.hidden = false;
    q.value = '';
    buscar();
    requestAnimationFrame(() => { ov.classList.add('is-open'); q.focus(); });
    await cargar().catch(() => null);
    if (!ov.hidden) buscar();
  }
  function cerrar() { ov.classList.remove('is-open'); ov.hidden = true; }

  btn.addEventListener('click', abrir);
  ov.querySelector('.buscar-cancelar').addEventListener('click', cerrar);
  q.addEventListener('input', buscar);
  q.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(resultados.length - 1, sel + 1); pintar(); res.querySelector('.is-sel')?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); pintar(); res.querySelector('.is-sel')?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'Enter') { e.preventDefault(); ir(resultados[sel]); }
  });
  res.addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (b) ir(resultados[Number(b.dataset.i)]); });
  ov.addEventListener('click', e => { if (e.target === ov) cerrar(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !ov.hidden) { cerrar(); return; }
    if (app.hidden || !ov.hidden) return;
    const escribiendo = e.target && e.target.matches && e.target.matches('input, textarea, select, [contenteditable]');
    if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) { e.preventDefault(); abrir(); }
    else if (e.key === '/' && !escribiendo) { e.preventDefault(); abrir(); }
  });
  // Lo cambiado en el sistema se ve en la próxima búsqueda.
  window.addEventListener('view:show', () => { cargadoEn = 0; });
})();
