/* ═══ v4: ubicación que se está viendo y «Cambiar de persona» (menú de identidad, hoja del celular y «Hoy») ═══
   La ubicación escogida se recuerda en ESTE equipo y avisa con el evento «v4:ubicacion»; «Hoy» la usa. Con un
   solo local no se ofrece. «Cambiar de persona» vuelve directo al teclado del código, sin pantalla de salida. */
window.V4 = window.V4 || {};
(function () {
  'use strict';
  const CLAVE = 'arche_v4_ubicacion';
  let lista = null;
  V4.ubicacion = () => { try { return localStorage.getItem(CLAVE) || ''; } catch (_) { return ''; } };
  V4.ponerUbicacion = id => { try { localStorage.setItem(CLAVE, id || ''); } catch (_) {} window.dispatchEvent(new CustomEvent('v4:ubicacion', { detail: id || '' })); };
  V4.ubicaciones = async () => {
    if (lista) return lista;
    try { lista = Modules.visibleLocations((await Api.locations.list()).filter(l => l.active && l.kind === 'carrito')); } catch (_) { lista = []; }
    return lista;
  };
  V4.cambiarPersona = () => {
    try { localStorage.setItem('shaker_login_mode', 'pin'); localStorage.removeItem('shaker_locked'); localStorage.removeItem('shaker_last_active'); } catch (_) {}
    Auth.clear(); location.reload();
  };
})();

/* ═══ Arche v4 (DISENO-ARCHE.md): identidad unificada en la barra lateral ═══
   Negocio + persona en un solo bloque arriba, con menú (ayuda, tema, salir); buscar ⌘K; pie de estado.
   Reusa los controles que ya existen (buscar, tema, salir) para no duplicar lógica. */
(function () {
  'use strict';
  const side = document.querySelector('#owner-app .sidebar');
  if (!side) return;
  const nombre = () => (document.getElementById('brand-name-owner') || {}).textContent || 'Mi negocio';
  const iniciales = t => t.trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
  const ident = document.createElement('button');
  ident.type = 'button'; ident.className = 'v4-ident'; ident.setAttribute('aria-haspopup', 'menu'); ident.setAttribute('aria-expanded', 'false');
  const pintar = () => { const n = nombre(); ident.innerHTML = `<span class="v4-logo" aria-hidden="true">${iniciales(n)}</span><span class="v4-ident-t"><b></b><small>Dueño · Administrativo</small></span><svg class="v4-ident-c" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3.5 4.5L6 2l2.5 2.5M3.5 7.5L6 10l2.5-2.5"/></svg>`; ident.querySelector('b').textContent = n; };
  pintar();
  new MutationObserver(pintar).observe(document.getElementById('brand-name-owner') || document.body, { childList: true, characterData: true, subtree: true });
  const buscar = document.createElement('button');
  buscar.type = 'button'; buscar.className = 'v4-buscar';
  buscar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>Buscar<kbd>⌘K</kbd>';
  buscar.addEventListener('click', () => { const b = document.getElementById('buscar-btn'); if (b) b.click(); });
  const brand = side.querySelector('.sidebar-brand');
  side.insertBefore(buscar, brand); side.insertBefore(ident, buscar);
  const pie = document.createElement('div'); pie.className = 'v4-pie';
  const copia = document.getElementById('footer-copyright-owner');
  const pintarPie = () => { const st = document.querySelector('#owner-app [data-ux-status]'); const off = st && st.classList.contains('is-off'); const v = ((copia && copia.textContent) || '').match(/v\d+(\.\d+)*/); pie.classList.toggle('is-off', !!off); pie.innerHTML = `<i></i>${off ? 'Sin conexión' : 'En línea'}<span class="v4-ver">${v ? v[0] : ''}</span>`; };
  pintarPie(); setInterval(pintarPie, 5000);
  (side.querySelector('.sidebar-footer') || side).appendChild(pie);
  let menu = null;
  const cerrar = () => { if (menu) { menu.remove(); menu = null; ident.setAttribute('aria-expanded', 'false'); } };
  ident.addEventListener('click', e => {
    e.stopPropagation(); if (menu) { cerrar(); return; }
    menu = document.createElement('div'); menu.className = 'v4-menu'; menu.setAttribute('role', 'menu');
    menu.innerHTML = `<div class="v4-menu-cab"><b></b><small>Dueño · Administrativo</small></div><div class="v4-menu-ubic" hidden></div>
      <button role="menuitem" type="button" data-a="persona">Cambiar de persona</button>
      <a role="menuitem" href="ayuda.html?role=owner" target="shaker-ayuda">Ayuda</a><button role="menuitem" type="button" data-a="tema">Cambiar tema claro / oscuro</button><hr><button role="menuitem" type="button" class="is-peligro" data-a="salir">Cerrar sesión</button>`;
    menu.querySelector('.v4-menu-cab b').textContent = nombre();
    // Ubicación (solo con más de un local): «Todas» o uno, con ✓ en la escogida.
    V4.ubicaciones().then(locs => {
      const caja = menu && menu.querySelector('.v4-menu-ubic'); if (!caja || locs.length < 2) return;
      const actual = V4.ubicacion();
      caja.innerHTML = '<span class="v4-menu-sec">Ubicación</span>' + [{ id: '', name: 'Todas las ubicaciones' }, ...locs].map(l =>
        `<button role="menuitemradio" type="button" data-loc="${l.id}" aria-checked="${String(l.id) === actual}"><span>${UI.escapeHtml(l.name)}</span>${String(l.id) === actual ? '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>' : ''}</button>`).join('') + '<hr>';
      caja.hidden = false;
    });
    const r = ident.getBoundingClientRect(); menu.style.left = r.left + 'px'; menu.style.top = (r.bottom + 6) + 'px';
    document.body.appendChild(menu); ident.setAttribute('aria-expanded', 'true');
    menu.addEventListener('click', ev => {
      const l = ev.target.closest('[data-loc]');
      if (l) { V4.ponerUbicacion(l.dataset.loc); UI.toast(l.textContent.trim() === 'Todas las ubicaciones' ? 'Viendo todas las ubicaciones' : `Viendo ${l.textContent.trim()}`); cerrar(); return; }
      const a = ev.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'persona') { cerrar(); V4.cambiarPersona(); return; }
      if (a.dataset.a === 'tema') { const t = document.querySelector('#owner-app [data-theme-toggle]'); if (t) t.click(); }
      if (a.dataset.a === 'salir') { const s = side.querySelector('.sidebar-footer [data-logout]'); if (s) s.click(); }
      cerrar();
    });
    const primero = menu.querySelector('a,button'); if (primero) primero.focus();
  });
  document.addEventListener('click', e => { if (menu && !menu.contains(e.target)) cerrar(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrar(); });
})();

/* v4: en las hojas agrupadas el símbolo de moneda va pegado al monto («RD$ 1300»). field-sizing no
   achica los campos numéricos en todos los navegadores, así que el ancho se ajusta a lo escrito. */
(function () {
  'use strict';
  const SEL = '.pf-pre + input';
  const ajustar = e => { e.style.width = Math.max(3, String(e.value || e.placeholder || '').length + 1) + 'ch'; };
  const todos = raiz => raiz.querySelectorAll && raiz.querySelectorAll(SEL).forEach(ajustar);
  document.addEventListener('input', e => { if (e.target.matches && e.target.matches(SEL)) ajustar(e.target); });
  document.addEventListener('reset', e => setTimeout(() => todos(e.target)), true);
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1) todos(n); })))
    .observe(document.body, { childList: true, subtree: true });
  todos(document);
})();

/* v4: las barras del navegador (Safari del iPhone, Chrome de Android) toman el MISMO color del fondo del sistema:
   gris claro en claro, negro en oscuro. Antes eran azul marino fijo (y luego el color oscuro de la marca): con el
   login y el sistema claros quedaban franjas oscuras arriba y abajo en el iPhone. */
(function () {
  'use strict';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (!meta) return;
  const oscuro = matchMedia('(prefers-color-scheme: dark)');
  const pintar = () => {
    const t = document.documentElement.dataset.theme;
    meta.setAttribute('content', (t === 'dark' || (!t && oscuro.matches)) ? '#000000' : '#F5F5F7');
  };
  pintar();
  oscuro.addEventListener('change', pintar);
  new MutationObserver(pintar).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
})();
