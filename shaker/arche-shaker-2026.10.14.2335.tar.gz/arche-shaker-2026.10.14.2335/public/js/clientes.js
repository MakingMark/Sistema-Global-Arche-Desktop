/* ═══ Clientes: se arman solos desde el teléfono que se anota en una venta
   (ver customerService.js) — esta pantalla es para COMPARAR, no para dar de
   alta nada a mano. Pedido real del dueño: saber quién compró más (para un
   sorteo, o para mandar una oferta por WhatsApp a los números que ya
   tenemos). ═══ */
(function () {
  'use strict';
  const gridEl = document.getElementById('clientes-grid');
  if (!gridEl) return;
  const searchInput = document.getElementById('clientes-search');

  let customers = [];

  // Mismo formato que ya usa el resto de la app para mostrar el teléfono de
  // WhatsApp: "+1 809 555 1234", más fácil de leer que 11 dígitos pegados.
  function formatPhone(phone) {
    const d = String(phone || '');
    if (d.length !== 11) return `+${d}`;
    return `+${d[0]} ${d.slice(1, 4)} ${d.slice(4, 7)} ${d.slice(7)}`;
  }

  async function showEditModal(c) {
    const body = `
      <div class="f" style="margin-bottom:6px"><span>Teléfono</span><input value="${formatPhone(c.phone)}" disabled></div>
      <p class="muted" style="margin:0 0 14px;font-size:.82em">El teléfono es el identificador del cliente — no se puede cambiar acá. Si es un error real, hay que ir a la venta que lo generó.</p>
      <div class="f" style="margin-bottom:16px"><span>Nombre</span><input id="edit-cliente-name" value="${UI.escapeHtml(c.name)}"></div>
      ${Modules.enabled('fiado') ? `<div class="f" style="margin-bottom:16px"><span>Límite de crédito (vacío = sin límite)</span><input id="edit-cliente-limit" type="number" min="0" step="1" inputmode="decimal" value="${c.credit_limit !== null && c.credit_limit !== undefined ? Number(c.credit_limit) : ''}"></div>` : ''}
      <div class="modal-actions">
        <button class="btn" id="edit-cliente-cancel">Cancelar</button>
        <button class="btn btn-primary" id="edit-cliente-save">Guardar</button>
      </div>
    `;
    const modal = UI.showModal(`Editar · ${UI.escapeHtml(c.name)}`, body);
    modal.el.querySelector('#edit-cliente-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#edit-cliente-save').addEventListener('click', async () => {
      const name = modal.el.querySelector('#edit-cliente-name').value.trim();
      if (!name) { UI.toast('El nombre no puede quedar vacío', 'error'); return; }
      try {
        const limitEl = modal.el.querySelector('#edit-cliente-limit');
        await Api.customers.update(c.id, name, limitEl ? limitEl.value : undefined);
        modal.close();
        UI.toast('Cliente actualizado');
        render();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  // Estado de cuenta (fiado): cargos, abonos y cobrar un abono.
  async function showStatement(c) {
    let st;
    try { st = await Api.customers.statement(c.id); } catch (err) { UI.toast(err.message, 'error'); return; }
    const rows = st.entries.map(e => `<tr><td data-th="Fecha">${fmtDate(e.created_at)}</td><td data-th="Movimiento">${e.kind === 'cargo' ? 'Venta a crédito' : 'Abono'}${e.note ? `<div class="cell-subtitle muted">${UI.escapeHtml(e.note)}</div>` : ''}</td><td class="num" data-th="Importe">${e.kind === 'cargo' ? '+' : '-'}${fmt(e.amount)}</td></tr>`).join('');
    const modal = UI.showModal(`Cuenta · ${UI.escapeHtml(c.name)}`, `
      <div class="pay-total">${st.balance > 0 ? 'Debe ' + fmt(st.balance) : st.balance < 0 ? 'A favor ' + fmt(-st.balance) : 'Sin deuda'}</div>
      ${c.credit_limit !== null && c.credit_limit !== undefined ? `<p class="muted" style="text-align:center;margin-top:-6px">Límite de crédito: ${fmt(c.credit_limit)}</p>` : ''}
      ${st.balance > 0 ? `<div class="form-inline" style="margin:12px 0"><label class="f"><span>Abono</span><input id="ab-amount" type="number" min="0.01" step="0.01" max="${st.balance}" value="${st.balance}" inputmode="decimal"></label>
        <label class="f"><span>Forma de pago</span><select id="ab-method">${AppLocale.payments().filter(m => !/^fiado$/i.test(m)).map(m => `<option>${UI.escapeHtml(m)}</option>`).join('')}</select></label>
        <button class="btn btn-primary" id="ab-ok">Cobrar abono</button></div><div class="error" id="ab-error" role="alert" hidden></div>` : ''}
      <table class="table"><thead><tr><th>Fecha</th><th>Movimiento</th><th class="num">Importe</th></tr></thead><tbody>${rows || '<tr><td colspan="3" class="muted">Sin movimientos.</td></tr>'}</tbody></table>`);
    const ok = modal.el.querySelector('#ab-ok');
    if (ok) ok.addEventListener('click', async () => {
      const err = modal.el.querySelector('#ab-error'); err.hidden = true; ok.disabled = true;
      try {
        await Api.customers.payment(c.id, { amount: Number(modal.el.querySelector('#ab-amount').value), method: modal.el.querySelector('#ab-method').value });
        modal.close(); UI.toast('Abono registrado'); await render();
        showStatement(customers.find(x => x.id === c.id) || c);
      } catch (e) { err.textContent = e.message; err.hidden = false; ok.disabled = false; }
    });
  }

  // v4 (DISENO-ARCHE.md): lista a la izquierda y ficha a la derecha, como Contactos. La ficha dice cuánto
  // ha gastado, cada cuánto vuelve, qué pide siempre y sus últimas compras, con WhatsApp y llamar a un toque.
  // En el celular la lista ocupa todo y la ficha sube como hoja.
  let escogido = null;
  const COLORES = ['#FF8A3D,#C34908', '#64D2FF,#0A84FF', '#BF5AF2,#8E44AD', '#30D158,#1E8E3E', '#FF9F0A,#FF6B00'];
  const color = n => { let h = 0; for (const ch of String(n)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return COLORES[h % COLORES.length]; };
  const ini = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
  const hace = iso => { if (!iso) return '—'; const d = Math.floor((Date.now() - new Date(iso)) / 86400000); return d <= 0 ? 'Hoy' : d === 1 ? 'Ayer' : d < 7 ? `Hace ${d} días` : d < 14 ? 'La semana pasada' : d < 60 ? `Hace ${Math.round(d / 7)} semanas` : `Hace ${Math.round(d / 30)} meses`; };
  const ficha = (c, f) => {
    const deuda = Modules.enabled('fiado') && Number(c.balance) > 0;
    const tel = String(c.phone || '').replace(/\D/g, '');
    return `<div class="cl-perfil"><span class="cl-av grande" style="background:linear-gradient(135deg,${color(c.name)})">${UI.escapeHtml(ini(c.name))}</span>
        <div><h2>${UI.escapeHtml(c.name)}</h2><p class="muted">${formatPhone(c.phone)}</p>
          <div class="cl-tags">${c.sales_count >= 5 ? '<span class="cl-tag">Frecuente</span>' : ''}${deuda ? `<span class="cl-tag rojo">Debe ${fmt(c.balance)}</span>` : ''}${f && f.primera ? `<span class="cl-tag g">Cliente desde ${new Date(f.primera).toLocaleDateString('es-DO', { month: 'long', year: 'numeric' })}</span>` : ''}</div></div></div>
      <div class="cl-acc">
        <a class="btn" href="https://wa.me/${tel}" target="_blank" rel="noopener">WhatsApp</a>
        <a class="btn" href="tel:+${tel}">Llamar</a>
        <button type="button" class="btn" data-cl="editar">Editar</button>
        ${Modules.enabled('fiado') ? '<button type="button" class="btn" data-cl="cuenta">Cuenta y abonos</button>' : ''}
      </div>
      <div class="cl-kpis"><div><small>Total gastado</small><b>${fmt(c.total_spent)}</b></div><div><small>Compras</small><b>${c.sales_count}</b></div><div><small>Ticket promedio</small><b>${fmt(c.sales_count ? c.total_spent / c.sales_count : 0)}</b></div><div><small>Viene cada</small><b>${f && f.cada_dias ? `${f.cada_dias} día${f.cada_dias === 1 ? '' : 's'}` : '—'}</b></div></div>
      ${f ? `${f.favoritos.length ? `<div><p class="cl-t">Siempre pide</p><div class="cl-favs">${f.favoritos.map(x => `<span class="chip">${UI.escapeHtml(x.nombre)} <b>${Math.round(x.veces)}</b></span>`).join('')}</div></div>` : ''}
        <div><p class="cl-t">Últimas compras</p><div class="cl-compras">${f.compras.length ? f.compras.map(v => `<div class="cl-compra${v.status === 'anulada' ? ' row-voided' : ''}"><span>${fmtDate(v.created_at)}</span><span class="muted">#${v.id}</span><span class="cl-prod">${UI.escapeHtml(v.productos || '—')}</span><span class="muted cl-pago">${UI.escapeHtml(v.payment_method || '')}</span><b>${fmt(v.amount_due)}</b></div>`).join('') : '<p class="muted">Sin compras.</p>'}</div></div>` : '<p class="muted">Cargando…</p>'}`;
  };
  async function mostrar(c, destino) {
    destino.innerHTML = ficha(c, null);
    let f = null; try { f = await Api.customers.ficha(c.id); } catch (_) {}
    if (escogido === c.id || destino.closest('.modal-box')) destino.innerHTML = ficha(c, f);
  }
  function renderGrid() {
    const q = searchInput.value.trim().toLowerCase();
    const filtered = q
      ? customers.filter(c => c.name.toLowerCase().includes(q) || c.phone.includes(q.replace(/\D/g, '')))
      : customers;
    if (!filtered.length) {
      gridEl.innerHTML = customers.length
        ? `<p class="muted">Sin resultados para "${UI.escapeHtml(q)}".</p>`
        : '<p class="muted">Todavía no hay clientes — se cargan solos apenas alguien anota un teléfono en una venta.</p>';
      return;
    }
    if (!escogido || !filtered.some(c => c.id === escogido)) escogido = filtered[0].id;
    gridEl.innerHTML = `<div class="cl-split"><div class="cl-lista" role="list">${filtered.map(c => `<button type="button" role="listitem" class="cl-fila${c.id === escogido ? ' on' : ''}" data-id="${c.id}">
        <span class="cl-av" style="background:linear-gradient(135deg,${color(c.name)})">${UI.escapeHtml(ini(c.name))}</span>
        <span class="cl-t2"><b>${UI.escapeHtml(c.name)}</b><small>${hace(c.last_purchase_at)} · ${fmt(c.total_spent)}</small></span>
        ${Modules.enabled('fiado') && Number(c.balance) > 0 ? `<span class="cl-debe">Debe ${fmt(c.balance)}</span>` : c.sales_count >= 5 ? '<span class="cl-m">Frecuente</span>' : ''}</button>`).join('')}</div>
      <section class="card cl-ficha" aria-live="polite"></section></div>`;
    const c = customers.find(x => x.id === escogido);
    if (c && !matchMedia('(max-width:820px)').matches) mostrar(c, gridEl.querySelector('.cl-ficha'));
  }
  gridEl.addEventListener('click', e => {
    const f = e.target.closest('.cl-fila');
    if (f) {
      escogido = Number(f.dataset.id);
      const c = customers.find(x => x.id === escogido); if (!c) return;
      if (matchMedia('(max-width:820px)').matches) {
        const m = UI.showModal(UI.escapeHtml(c.name), '<div class="cl-ficha cl-hoja"></div>');
        const d = m.el.querySelector('.cl-ficha'); mostrar(c, d);
        d.addEventListener('click', ev => accion(ev, c, m));
        return;
      }
      gridEl.querySelectorAll('.cl-fila').forEach(b => b.classList.toggle('on', b === f));
      mostrar(c, gridEl.querySelector('.cl-ficha'));
      return;
    }
    const c = customers.find(x => x.id === escogido);
    if (c) accion(e, c, null);
  });
  function accion(e, c, modal) {
    const b = e.target.closest('[data-cl]'); if (!b) return;
    if (modal) modal.close();
    if (b.dataset.cl === 'editar') showEditModal(c);
    if (b.dataset.cl === 'cuenta') showStatement(c);
  }

  // Mismo patrón de CSV que ya usa Reportes (BOM + comillas donde haga
  // falta) — pero armado directo desde el array en memoria, no desde una
  // <table> oculta, porque acá el dato vive en tarjetas, no en filas.
  document.getElementById('btn-clientes-csv').addEventListener('click', () => {
    const esc = s => { const v = String(s ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const rows = [
      ['Nombre', 'Teléfono', 'Compras', 'Total gastado', 'Última compra', 'Debe'].join(','),
      ...customers.map(c => [
        esc(c.name), esc(formatPhone(c.phone)), c.sales_count, c.total_spent,
        esc(c.last_purchase_at ? fmtDate(c.last_purchase_at) : ''), c.balance
      ].join(','))
    ];
    const blob = new Blob(['﻿' + rows.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clientes-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  async function render() {
    customers = await Api.customers.list();
    renderGrid();
  }

  searchInput.addEventListener('input', renderGrid);

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'clientes') render();
  });
})();
