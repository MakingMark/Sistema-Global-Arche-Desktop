/* ═══ Login v3.0: el lado de Arche + reloj, saludo y estado del servidor ═══
   (ANALISIS-LOGIN-V3.md) Por este login entran el dueño y cualquier
   empleado, así que el panel izquierdo no muestra nada del negocio: es
   Arche presentándose. Blanco y negro puro, igual para todos.

   1) Canvas «Origen»: Arche viene del griego arkhé, «origen». La «A» del
      logo queda de marca de agua y su nodo (la punta redonda del
      travesaño) es el punto de origen: los nodos nacen de ahí al abrir el
      login, giran alrededor en órbitas lentas, y cada pocos segundos sale
      un pulso que los enciende al pasar. El mouse atrae un poco a los
      nodos cercanos y se conecta con ellos.
   2) Frase que rota palabra por palabra, con una barra de progreso.
   3) Reloj y fecha (en el celular, en la píldora de arriba), saludo según
      la hora y estado del servidor (/api/health cada 30 s mientras el
      login está a la vista).

   Se porta bien: con prefers-reduced-motion se dibuja un solo cuadro y la
   frase no rota; todo se pausa si la pestaña o el login no están visibles. */
(function () {
  'use strict';

  const loginScreen = document.getElementById('login-screen');
  if (!loginScreen) return;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isVisible = () => !loginScreen.hidden && !document.hidden;

  const watchers = [];
  const notify = () => { const v = isVisible(); watchers.forEach(fn => fn(v)); };
  new MutationObserver(notify).observe(loginScreen, { attributes: true, attributeFilter: ['hidden'] });
  document.addEventListener('visibilitychange', notify);

  /* ── 1) Canvas «Origen» ── */
  const panel = document.querySelector('.login-showcase-panel');
  const canvas = document.getElementById('login-showcase-canvas');
  if (panel && canvas && canvas.getContext) {
    const ctx = canvas.getContext('2d');
    const mark = new Image();
    // Proporción de la «A» (sacada en alta del Logo.ai original, 900×649) y
    // posición de su nodo dentro de ella.
    const MARK_RATIO = 900 / 649, NODE_X = 0.502, NODE_Y = 0.616;
    const LINK = 118, MOUSE_LINK = 170, PULSE_EVERY = 3400, PULSE_SPEED = 0.16; // px por ms
    let W = 0, H = 0, nodes = [], pulses = [], box = null, origin = { x: 0, y: 0 };
    let raf = null, running = false, born = 0, lastPulse = 0, lastT = 0;
    const mouse = { x: 0, y: 0, on: false, px: 0, py: 0 };

    function layout() {
      const r = panel.getBoundingClientRect();
      W = Math.max(1, Math.round(r.width)); H = Math.max(1, Math.round(r.height));
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = W * dpr; canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      // La «A» grande, a la derecha y un poco abajo, para no tapar la frase.
      const h = Math.min(H * 0.6, W * 0.62 / MARK_RATIO);
      const w = h * MARK_RATIO;
      box = { x: W - w - W * 0.04, y: H - h - H * 0.12, w, h };
      origin = { x: box.x + w * NODE_X, y: box.y + h * NODE_Y };
      // v4 (DISENO-ARCHE.md): pantalla completa; el nodo queda detrás de la persona escogida.
      if (document.getElementById('v4-personas')) {
        const hv = Math.min(H * 0.42, (W * 0.5) / MARK_RATIO), wv = hv * MARK_RATIO;
        origin = { x: W / 2, y: H * (W < 700 ? 0.6 : 0.64) };
        const av = document.querySelector('#v4-personas:not([hidden]) .v4-usu.on .v4-usu-av');
        if (av) { const pr = panel.getBoundingClientRect(), ar = av.getBoundingClientRect(); if (ar.width) origin = { x: ar.left + ar.width / 2 - pr.left, y: ar.top + ar.height / 2 - pr.top }; }
        box = { x: origin.x - wv * NODE_X, y: origin.y - hv * NODE_Y, w: wv, h: hv };
      }
      const maxR = Math.hypot(Math.max(origin.x, W - origin.x), Math.max(origin.y, H - origin.y));
      const n = document.getElementById('v4-personas') ? (W < 520 ? 72 : W < 900 ? 80 : 96) : (W < 520 ? 34 : W < 900 ? 52 : 68);
      nodes = [];
      for (let i = 0; i < n; i++) {
        // Más nodos cerca del origen que lejos (raíz cuadrada = reparto parejo por área).
        const rr = 26 + Math.sqrt(Math.random()) * maxR * 0.95;
        nodes.push({
          a: Math.random() * Math.PI * 2, r: rr,
          w: (Math.random() < 0.5 ? -1 : 1) * (0.00003 + Math.random() * 0.00007) * (380 / (rr + 120)) * 2.2,
          wob: Math.random() * Math.PI * 2, size: 0.9 + Math.random() * 1.5, glow: 0,
          x: origin.x, y: origin.y, dx: 0, dy: 0
        });
      }
      born = performance.now();
    }

    const ease = t => 1 - Math.pow(1 - Math.min(1, Math.max(0, t)), 3);

    function update(now, dt) {
      const grow = reduceMotion ? 1 : ease((now - born) / 1700);
      if (!reduceMotion && now - lastPulse > (W < 700 ? 2200 : PULSE_EVERY)) { pulses.push({ t: now }); lastPulse = now; }
      pulses = pulses.filter(p => (now - p.t) * PULSE_SPEED < Math.max(W, H) * 1.2);
      // Parallax suave hacia el mouse.
      mouse.px += ((mouse.on ? (mouse.x - W / 2) / W : 0) - mouse.px) * 0.05;
      mouse.py += ((mouse.on ? (mouse.y - H / 2) / H : 0) - mouse.py) * 0.05;
      for (const n of nodes) {
        n.a += n.w * dt;
        const r = n.r * grow + Math.sin(now * 0.0006 + n.wob) * 6;
        let x = origin.x + Math.cos(n.a) * r + mouse.px * -14;
        let y = origin.y + Math.sin(n.a) * r * 0.82 + mouse.py * -10;
        // Atracción leve hacia el mouse.
        let tx = 0, ty = 0;
        if (mouse.on) {
          const mx = mouse.x - x, my = mouse.y - y, d = Math.hypot(mx, my);
          if (d < MOUSE_LINK) { const f = (1 - d / MOUSE_LINK) * 0.22; tx = mx * f; ty = my * f; }
        }
        n.dx += (tx - n.dx) * 0.08; n.dy += (ty - n.dy) * 0.08;
        n.x = x + n.dx; n.y = y + n.dy;
        // El pulso enciende al nodo cuando su anillo pasa por encima.
        for (const p of pulses) {
          const pr = (now - p.t) * PULSE_SPEED;
          const nr = Math.hypot((n.x - origin.x), (n.y - origin.y) / 0.82);
          if (Math.abs(pr - nr) < 14) n.glow = 1;
        }
        n.glow *= Math.pow(0.9975, dt);
      }
    }

    function draw(now) {
      ctx.clearRect(0, 0, W, H);
      const grow = reduceMotion ? 1 : ease((now - born) / 1700);
      // Marca de agua: la «A», respirando muy despacio.
      if (mark.complete && mark.naturalWidth) {
        ctx.globalAlpha = (document.getElementById('v4-personas') ? 0.03 : 0.055 + Math.sin(now * 0.0009) * 0.012) * grow;
        ctx.drawImage(mark, box.x + mouse.px * -8, box.y + mouse.py * -6, box.w, box.h);
        ctx.globalAlpha = 1;
      }
      // Órbitas guía.
      ctx.lineWidth = 1;
      [0.22, 0.42, 0.66].forEach((k, i) => {
        const rr = Math.max(W, H) * k * grow;
        ctx.strokeStyle = `rgba(255,255,255,${0.045 - i * 0.01})`;
        ctx.beginPath(); ctx.ellipse(origin.x, origin.y, rr, rr * 0.82, 0, 0, Math.PI * 2); ctx.stroke();
      });
      // Pulsos.
      for (const p of pulses) {
        const pr = (now - p.t) * PULSE_SPEED;
        const a = Math.max(0, 0.22 * (1 - pr / (Math.max(W, H) * 1.1)));
        ctx.strokeStyle = `rgba(255,255,255,${a.toFixed(3)})`;
        ctx.beginPath(); ctx.ellipse(origin.x, origin.y, pr, pr * 0.82, 0, 0, Math.PI * 2); ctx.stroke();
      }
      // Conexiones entre nodos cercanos (y con el mouse).
      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j], d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < LINK) {
            const al = (1 - d / LINK) * (0.13 + Math.max(a.glow, b.glow) * 0.3);
            ctx.strokeStyle = `rgba(255,255,255,${al.toFixed(3)})`;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
        if (mouse.on) {
          const d = Math.hypot(a.x - mouse.x, a.y - mouse.y);
          if (d < MOUSE_LINK) {
            ctx.strokeStyle = `rgba(255,255,255,${((1 - d / MOUSE_LINK) * 0.35).toFixed(3)})`;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke();
          }
        }
      }
      // Nodos.
      for (const n of nodes) {
        ctx.fillStyle = `rgba(255,255,255,${(0.42 + n.glow * 0.55).toFixed(3)})`;
        ctx.beginPath(); ctx.arc(n.x, n.y, n.size + n.glow * 1.6, 0, Math.PI * 2); ctx.fill();
      }
      // El origen: un punto brillante con halo que late.
      const beat = 0.5 + 0.5 * Math.sin(now * 0.003);
      const g = ctx.createRadialGradient(origin.x, origin.y, 0, origin.x, origin.y, 34);
      g.addColorStop(0, `rgba(255,255,255,${(0.16 + beat * 0.08) * grow})`);
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(origin.x, origin.y, 34, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = `rgba(255,255,255,${0.95 * grow})`;
      ctx.beginPath(); ctx.arc(origin.x, origin.y, 3.2, 0, Math.PI * 2); ctx.fill();
    }

    function frame(now) {
      if (!running) return;
      const dt = Math.min(64, now - (lastT || now)); lastT = now;
      update(now, dt); draw(now);
      raf = requestAnimationFrame(frame);
    }
    function still() { const t = performance.now(); update(t, 0); draw(t); }
    function start() {
      if (running) return;
      if (reduceMotion) { still(); return; }
      running = true; lastT = 0; lastPulse = performance.now() - PULSE_EVERY + 1200;
      raf = requestAnimationFrame(frame);
    }
    function stop() { running = false; if (raf) cancelAnimationFrame(raf); raf = null; }
    const shown = () => panel.offsetWidth > 0;

    mark.onload = () => { if (!running && shown()) still(); };
    mark.src = 'img/brand/arche-mark-hd.png';

    panel.addEventListener('pointermove', e => {
      const r = panel.getBoundingClientRect();
      mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; mouse.on = e.pointerType === 'mouse' || e.pressure > 0;
    });
    panel.addEventListener('pointerleave', () => { mouse.on = false; });

    // Al reabrir el login (cerrar sesión) los nodos vuelven a nacer del origen.
    const relayout = () => { if (shown()) { layout(); if (!running) still(); } };
    if (window.ResizeObserver) new ResizeObserver(relayout).observe(panel);
    else window.addEventListener('resize', relayout);
    window.addEventListener('v4:personas', relayout);   // v4: el nodo sigue a la persona escogida
    // v4: cada dígito enciende un anillo desde el origen; en el celular los pulsos van más seguido (no hay mouse).
    window.addEventListener('v4:pulso', () => { if (!reduceMotion && running) pulses.push({ t: performance.now() }); });
    watchers.push(v => { if (v && shown()) { layout(); start(); } else stop(); });
    if (isVisible() && shown()) { layout(); start(); }
  }

  /* ── 2) Frase que rota, palabra por palabra ── */
  const taglineEl = document.getElementById('login-tagline');
  const stepsEl = document.getElementById('login-tag-steps');
  if (taglineEl) {
    // Frases propias de Arche (el nombre significa «origen»), no genéricas.
    const TAGLINES = [
      'El origen de tu negocio, en un solo lugar.',
      'Hecho por emprendedores, para emprendedores.',
      'Un sistema que crece contigo, no al revés.',
      'Ventas, inventario y reportes, siempre a mano.',
      'Todo conectado desde un mismo origen.'
    ];
    const INTERVAL = 4800;
    let idx = 0, timer = null;

    if (stepsEl) {
      stepsEl.innerHTML = TAGLINES.map(() => '<span><i></i></span>').join('');
      stepsEl.style.setProperty('--dur', INTERVAL + 'ms');
    }
    function paintSteps() {
      if (!stepsEl) return;
      Array.from(stepsEl.children).forEach((s, i) => {
        s.className = i < idx ? 'done' : '';
        if (i === idx) { void s.offsetWidth; s.className = 'run'; }
      });
    }
    function render(animate) {
      const words = TAGLINES[idx].split(' ');
      taglineEl.innerHTML = '';
      words.forEach((w, i) => {
        const s = document.createElement('span');
        s.className = 'lx-word' + (animate ? '' : ' is-on');
        s.style.setProperty('--w', i);
        s.textContent = w;
        taglineEl.appendChild(s);
        if (i < words.length - 1) taglineEl.appendChild(document.createTextNode(' '));
      });
      if (animate) requestAnimationFrame(() => requestAnimationFrame(() => {
        taglineEl.querySelectorAll('.lx-word').forEach(s => s.classList.add('is-on'));
      }));
      paintSteps();
    }
    function next() {
      taglineEl.querySelectorAll('.lx-word').forEach(s => s.classList.add('is-out'));
      timer = setTimeout(() => {
        idx = (idx + 1) % TAGLINES.length;
        render(true);
        timer = setTimeout(next, INTERVAL - 420);
      }, 420);
    }
    function start() { if (reduceMotion || timer) return; render(true); timer = setTimeout(next, INTERVAL - 420); }
    function stop() { clearTimeout(timer); timer = null; }

    render(false);
    if (reduceMotion && stepsEl) stepsEl.hidden = true;
    watchers.push(v => (v ? start() : stop()));
    if (isVisible()) start();
  }

  /* ── 3) Reloj, fecha, saludo y estado del servidor ── */
  const $all = sel => Array.from(document.querySelectorAll(sel));
  const greetingEl = document.getElementById('login-greeting');
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
  let clockTimer = null;
  function tick() {
    const d = new Date();
    const full = d.toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit', hour12: true });
    const m = full.match(/^(\S+)\s*(.*)$/) || [full, full, ''];
    $all('[data-lx-time]').forEach(el => { el.textContent = m[1]; });
    $all('[data-lx-ampm]').forEach(el => { el.textContent = m[2]; });
    $all('[data-lx-time-short]').forEach(el => { el.textContent = full; });
    $all('[data-lx-date]').forEach(el => { el.textContent = cap(d.toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long' })); });
    $all('[data-lx-date-short]').forEach(el => { el.textContent = cap(d.toLocaleDateString('es-DO', { weekday: 'short', day: 'numeric', month: 'short' }).replace(/\./g, '')); });
    if (greetingEl) {
      const h = d.getHours();
      greetingEl.textContent = h >= 5 && h < 12 ? 'Buenos días' : h >= 12 && h < 19 ? 'Buenas tardes' : 'Buenas noches';
    }
    clockTimer = setTimeout(tick, 60000 - (Date.now() % 60000) + 50);
  }

  let healthTimer = null;
  function setStatus(ok, text) {
    $all('[data-lx-status]').forEach(el => { el.classList.toggle('is-off', !ok); el.title = text; });
    $all('[data-lx-status-text]').forEach(el => { el.textContent = text; });
  }
  async function checkHealth() {
    if (!navigator.onLine) setStatus(false, 'Sin conexión');
    else {
      const ctl = window.AbortController ? new AbortController() : null;
      const to = ctl && setTimeout(() => ctl.abort(), 5000);
      try {
        const r = await fetch('/api/health', { cache: 'no-store', signal: ctl && ctl.signal });
        setStatus(r.ok, r.ok ? 'Servidor en línea' : 'Servidor sin respuesta');
      } catch (_) {
        setStatus(false, 'Servidor sin respuesta');
      } finally { if (to) clearTimeout(to); }
    }
    healthTimer = setTimeout(checkHealth, 30000);
  }
  window.addEventListener('online', () => { if (isVisible()) { clearTimeout(healthTimer); checkHealth(); } });
  window.addEventListener('offline', () => setStatus(false, 'Sin conexión'));

  function startInfo() { clearTimeout(clockTimer); tick(); clearTimeout(healthTimer); checkHealth(); }
  function stopInfo() { clearTimeout(clockTimer); clearTimeout(healthTimer); }
  watchers.push(v => (v ? startInfo() : stopInfo()));
  tick();
  if (isVisible()) startInfo(); else stopInfo();
})();
