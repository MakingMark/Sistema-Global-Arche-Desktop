/* ═══ Medidas ═══
   El sistema trae su lista oficial de medidas y NO deja escribir cualquier cosa como unidad de un insumo
   (una «cucharadita» o «una vaina» descontrola recetas e inventario). Si el negocio de verdad necesita una
   medida que no está, se crea aquí, a propósito. Al iniciar, las medidas propias se pasan a Unidades para que
   salgan en las listas de «Se cuenta en». */
(function () {
  'use strict';
  const esc = t => UI.escapeHtml(String(t == null ? '' : t));

  async function cargar() {
    try { const r = await Api.unidades.list(); Unidades.registrarPersonalizadas(r.personalizadas); return r; }
    catch (_) { return null; }
  }
  // Las listas ya armadas (ej. «Se cuenta en» de insumo nuevo) se vuelven a pintar con las medidas propias.
  function repintar() {
    const sel = document.getElementById('compra-nuevo-unidad');
    if (sel && sel.tagName === 'SELECT') { const v = sel.value; sel.innerHTML = Unidades.opcionesHtml(''); if (v) sel.value = v; }
  }

  async function abrir() {
    const r = await cargar();
    if (!r) { UI.toast('No se pudieron cargar las medidas', 'error'); return; }
    const oficiales = r.oficiales.map(g => `<p style="margin:6px 0 2px"><b>${esc(g.grupo)}:</b> <span class="muted">${g.items.map(i => esc(i[0])).join(', ')}</span></p>`).join('');
    const propias = r.personalizadas.length
      ? r.personalizadas.map(m => `<div class="receta-row" style="align-items:center"><span style="flex:1"><b>${esc(m.nombre)}</b></span><button type="button" class="btn btn-sm" data-borrar="${m.id}">Quitar</button></div>`).join('')
      : '<p class="muted" style="margin:4px 0">Todavía no hay medidas propias. Casi nunca hacen falta.</p>';
    const modal = UI.showModal('Medidas', `
      <p class="muted" style="margin-top:0">Estas son las medidas del sistema. Un insumo solo puede contarse en una de ellas: así las compras, las recetas y el inventario siempre cuadran.</p>
      ${oficiales}
      <h3 style="margin:16px 0 4px">Medidas propias</h3>
      <div id="med-propias">${propias}</div>
      <div class="card-quiet" style="margin-top:12px">
        <b>Crear una medida propia</b>
        <p class="muted" style="margin:4px 0 8px;font-size:.85em">Úsalo solo si de verdad hace falta. Una medida propia <b>no se convierte</b> a gramos, libras ni onzas: sirve para contar piezas. Para algo que se pesa o se mide (azúcar, aceite…) usa gramo, onza o mililitro. «Taza», «cucharada» y «porción» no se permiten.</p>
        <div style="display:flex;gap:8px"><input type="text" id="med-nueva" maxlength="20" placeholder="ej. bandeja" style="flex:1"><button type="button" class="btn btn-primary" id="med-crear">Crear</button></div>
      </div>`);
    const el = modal.el;
    el.querySelector('#med-crear').addEventListener('click', async () => {
      const nombre = el.querySelector('#med-nueva').value.trim();
      if (!nombre) return;
      if (!(await UI.confirmDialog(`¿Crear la medida propia «${nombre}»? Quedará disponible para todos los insumos.`))) return;
      try { await Api.unidades.create(nombre); modal.close(); await cargar(); repintar(); UI.toast('Medida creada'); }
      catch (e) { UI.toast(e.message, 'error'); }
    });
    el.querySelectorAll('[data-borrar]').forEach(b => b.addEventListener('click', async () => {
      try { await Api.unidades.remove(Number(b.dataset.borrar)); modal.close(); await cargar(); repintar(); UI.toast('Medida quitada'); }
      catch (e) { UI.toast(e.message, 'error'); }
    }));
  }

  function montar() {
    const b = document.getElementById('btn-medidas');
    if (b) b.addEventListener('click', abrir);
    cargar().then(repintar);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', montar); else montar();
})();
