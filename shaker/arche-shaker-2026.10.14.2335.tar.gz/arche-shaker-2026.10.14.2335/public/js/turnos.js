/* ═══ Turnos: llegada y salida de cada empleado (dueño) ═══
   El cierre real es que la persona toque "Salir" (close_type='manual') —
   'reported_next_login' es cuando se le olvidó y lo resolvió al volver a
   entrar; 'auto_timeout' es cuando nadie lo resolvió nunca y el sistema lo
   cerró solo (ver shiftService.js). Ninguno de los dos últimos es "malo" en
   sí — son la señal de que a alguien se le está olvidando seguido tocar
   "Salir", que es justo lo que esta pantalla deja ver. */
(function () {
  'use strict';
  const form = document.getElementById('form-turnos');
  if (!form) return;
  const tbody = document.querySelector('#tabla-turnos tbody');
  const nota = document.getElementById('turnos-nota');
  const LIMIT = 200;

  const CLOSE_LABEL = {
    manual: '<span class="badge badge-sage">Cerrado por el empleado</span>',
    reported_next_login: '<span class="badge badge-warn">Reportado al día siguiente</span>',
    auto_timeout: '<span class="badge badge-voided">Cierre automático</span>'
  };

  // localIsoDate/daysAgo ahora son globales — ver api.js.
  function fmtDuration(startIso, endIso) {
    const mins = Math.round((new Date(endIso) - new Date(startIso)) / 60000);
    if (mins < 0) return '—';
    return `${Math.floor(mins / 60)}h ${mins % 60}min`;
  }

  async function loadFilters() {
    const [locations, employees] = await Promise.all([Api.locations.list(), Api.employees.list()]);
    const locSel = form.elements.location_id;
    const keepLoc = locSel.value;
    locSel.innerHTML = '<option value="">Todas</option>' +
      locations.filter(l => l.active).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');
    locSel.value = keepLoc;
    const empSel = form.elements.employee_id;
    const keepEmp = empSel.value;
    empSel.innerHTML = '<option value="">Todos</option>' +
      employees.map(e => `<option value="${e.id}">${UI.escapeHtml(e.name)}${e.active ? '' : ' (inactivo)'}</option>`).join('');
    empSel.value = keepEmp;
  }

  function params() {
    const fd = new FormData(form);
    const out = { limit: LIMIT };
    for (const [k, v] of fd.entries()) if (v) out[k] = v;
    return out;
  }

  async function render() {
    let rows;
    try {
      rows = await Api.employees.shifts(params());
    } catch (err) {
      UI.toast(err.message, 'error');
      return;
    }
    tbody.innerHTML = rows.map(s => `
      <tr>
        <td data-th="Empleado">${UI.escapeHtml(s.employee_name)}</td>
        <td data-th="Ubicación">${UI.escapeHtml(s.location_name)}</td>
        <td data-th="Llegada">${fmtDate(s.started_at)}</td>
        <td data-th="Salida">${s.ended_at ? fmtDate(s.ended_at) : '<span class="badge badge-warn">Sigue abierto</span>'}</td>
        <td data-th="Duración">${s.ended_at ? fmtDuration(s.started_at, s.ended_at) : '—'}</td>
        <td data-th="Cierre">${s.close_type ? (CLOSE_LABEL[s.close_type] || s.close_type) : ''}</td>
      </tr>
    `).join('') || '<tr><td colspan="6" class="muted">Sin turnos para este filtro.</td></tr>';
    nota.textContent = rows.length >= LIMIT ? `Se muestran los ${LIMIT} más recientes — acota las fechas para ver el resto.` : '';
  }

  /* v4 (DISENO-ARCHE.md): la semana trabajada como calendario (una fila por persona, un bloque por turno con
     sus horas) y, al lado, quién está ahora y las horas de la semana. Son turnos REALES (entrada y salida),
     no programados: el sistema no planifica horarios. La tabla de abajo sigue con el detalle. */
  const semanaEl = document.createElement('div');
  semanaEl.className = 'tu-semana';
  // El calendario va antes del detalle plegado (o antes del filtro si no hay detalle).
  (form.closest('.tr-detalle') || form.closest('.card-quiet, .card') || form).before(semanaEl);
  let lunes = (() => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d; })();
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const h12 = d => d.toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit' }).replace(/\s?([ap])\.\s?m\./, ' $1. m.');
  const COLS = ['naranja', 'azul', 'morado', 'verde', 'rosa'];
  async function renderSemana() {
    const dias = Array.from({ length: 7 }, (_, i) => { const d = new Date(lunes); d.setDate(d.getDate() + i); return d; });
    let rows = [];
    try { rows = await Api.employees.shifts({ from: iso(dias[0]), to: iso(dias[6]), limit: 500 }); } catch (_) {}
    const gente = [...new Map(rows.map(r => [r.employee_name, r])).keys()].sort();
    const hoy = iso(new Date());
    const horas = (a, b) => Math.max(0, (new Date(b || Date.now()) - new Date(a)) / 3600000);
    const total = rows.reduce((t, r) => t + horas(r.started_at, r.ended_at), 0);
    const abiertos = rows.filter(r => !r.ended_at);
    const fmtD = d => d.toLocaleDateString('es-DO', { weekday: 'short', day: 'numeric' }).replace(/\./g, '');
    const cab = `<div class="tu-h tu-p">${dias[0].toLocaleDateString('es-DO', { day: 'numeric', month: 'short' }).replace(/\./g, '')} – ${dias[6].toLocaleDateString('es-DO', { day: 'numeric', month: 'short' }).replace(/\./g, '')}</div>` + dias.map(d => `<div class="tu-h${iso(d) === hoy ? ' hoy' : ''}">${fmtD(d)}</div>`).join('');
    const cuerpo = gente.map((n, gi) => {
      const suyos = rows.filter(r => r.employee_name === n);
      const hs = suyos.reduce((t, r) => t + horas(r.started_at, r.ended_at), 0);
      return `<div class="tu-p"><span class="tu-av ${COLS[gi % COLS.length]}">${UI.escapeHtml(n.split(' ').map(w => w[0]).join('').slice(0, 2))}</span><span>${UI.escapeHtml(n)}<small>${Math.round(hs)} h esta semana</small></span></div>` +
        dias.map(d => `<div class="tu-c${iso(d) === hoy ? ' hoy' : ''}">${suyos.filter(r => iso(new Date(r.started_at)) === iso(d)).map(r => `<div class="tu-b ${COLS[gi % COLS.length]}${r.ended_at ? '' : ' vivo'}">${h12(new Date(r.started_at))}–${r.ended_at ? h12(new Date(r.ended_at)) : 'ahora'}<small>${UI.escapeHtml(r.location_name)}</small></div>`).join('')}</div>`).join('');
    }).join('');
    semanaEl.innerHTML = `<div class="tu-cab"><div class="v4-seg"><button type="button" class="v4-seg-b" data-sem="-1" aria-label="Semana anterior">‹</button><button type="button" class="v4-seg-b is-active" data-sem="0">Esta semana</button><button type="button" class="v4-seg-b" data-sem="1" aria-label="Semana siguiente">›</button></div></div>
      <div class="tu-split"><div class="card tu-grid-c">${gente.length ? `<div class="tu-grid">${cab}${cuerpo}</div>` : '<p class="muted tu-vacio">Nadie ha marcado entrada esta semana.</p>'}</div>
        <aside class="tu-lado"><section class="card"><h2 class="hoy-h">Ahora en turno</h2>${abiertos.length ? abiertos.map((r, i) => `<div class="hoy-fila"><span class="tu-av ${COLS[gente.indexOf(r.employee_name) % COLS.length]}">${UI.escapeHtml(r.employee_name[0])}</span><div class="t">${UI.escapeHtml(r.employee_name)}<small>${UI.escapeHtml(r.location_name)} · entró ${h12(new Date(r.started_at))}</small></div></div>`).join('') : '<p class="muted hoy-nota">Nadie en turno ahora.</p>'}</section>
          <section class="card"><h2 class="hoy-h">Esta semana</h2><dl class="ex-kv"><dt>Horas trabajadas</dt><dd>${Math.round(total)} h</dd><dt>Personas</dt><dd>${gente.length}</dd><dt>Turnos</dt><dd>${rows.length}</dd></dl></section></aside></div>`;
  }
  semanaEl.addEventListener('click', e => {
    const b = e.target.closest('[data-sem]'); if (!b) return;
    const k = Number(b.dataset.sem);
    if (k === 0) { lunes = (() => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d; })(); }
    else lunes.setDate(lunes.getDate() + 7 * k);
    renderSemana();
  });

  form.addEventListener('submit', e => { e.preventDefault(); render(); });
  document.getElementById('btn-turnos-limpiar').addEventListener('click', () => {
    form.reset();
    form.elements.from.value = daysAgo(14);
    form.elements.to.value = localIsoDate();
    render();
  });

  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'turnos') return;
    renderSemana();
    await loadFilters();
    if (!form.elements.from.value && !form.elements.to.value) {
      form.elements.from.value = daysAgo(14);
      form.elements.to.value = localIsoDate();
    }
    render();
  });
})();
