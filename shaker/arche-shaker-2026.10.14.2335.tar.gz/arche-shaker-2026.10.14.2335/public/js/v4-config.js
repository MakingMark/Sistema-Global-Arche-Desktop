/* ═══ Configuración al estilo de Ajustes (rediseño v4, DISENO-ARCHE.md) ═══
   A la izquierda, todas las secciones con su ícono en un cuadrito de color (agrupadas por General,
   Seguridad, WhatsApp y Respaldo); a la derecha, una sección a la vez. En el celular la lista ocupa
   la pantalla y la sección se abre con «‹ Ajustes» para volver. No cambia ningún formulario: solo
   muestra u oculta las tarjetas que ya existen y activa su pestaña (subtabs.js). */
(function () {
  'use strict';
  const vista = document.querySelector('section.view[data-view="configuracion"]');
  if (!vista) return;
  const barra = vista.querySelector('.subtabs[data-subtabs]');
  if (!barra) return;
  const ICONOS = {
    'licencia': ['#636366', '<rect x="4" y="10" width="16" height="10" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>'],
    'apariencia': ['#5856D6', '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>'],
    'tipo de negocio': ['#007AFF', '<path d="M4 9l2-5h12l2 5M4 9v10h16V9M4 9h16"/><path d="M10 19v-5h4v5"/>'],
    'módulos': ['#34C759', '<rect x="4" y="4" width="7" height="7" rx="1.6"/><rect x="13" y="4" width="7" height="7" rx="1.6"/><rect x="4" y="13" width="7" height="7" rx="1.6"/><rect x="13" y="13" width="7" height="7" rx="1.6"/>'],
    'colores': ['#AF52DE', '<circle cx="12" cy="12" r="8.5"/><circle cx="9" cy="9" r="1.3" fill="currentColor"/><circle cx="14.5" cy="8.5" r="1.3" fill="currentColor"/><circle cx="8.5" cy="14" r="1.3" fill="currentColor"/>'],
    'nombre y logo': ['#FF9500', '<rect x="4" y="5" width="16" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M20 16l-5-5-8 8"/>'],
    'itbis': ['#FF3B30', '<path d="M6 18L18 6"/><circle cx="7.5" cy="7.5" r="2"/><circle cx="16.5" cy="16.5" r="2"/>'],
    'descuentos': ['#FF2D55', '<path d="M4 12V5a1 1 0 0 1 1-1h7l8 8-8 8z"/><circle cx="8.5" cy="8.5" r="1.4"/>'],
    'vencimientos': ['#FF9500', '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'],
    'contraseña': ['#8E8E93', '<circle cx="8" cy="15" r="3.5"/><path d="M10.5 12.5L19 4M16 7l2 2"/>'],
    'correo': ['#007AFF', '<rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="M4 7l8 6 8-6"/>'],
    'whatsapp': ['#34C759', '<path d="M5 19l1.2-3.6A7.5 7.5 0 1 1 9 18.6z"/>'],
    'respaldo': ['#5AC8FA', '<path d="M7 18a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 9.5a4 4 0 0 1-.5 8.5z"/>']
  };
  const icono = titulo => { const t = titulo.toLowerCase(); const k = Object.keys(ICONOS).find(x => t.includes(x)); return ICONOS[k] || ['#8E8E93', '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>']; };
  const corto = t => t.replace(/: .*$/, '').replace(/^Tipo de negocio, moneda y medios de pago$/, 'Negocio, moneda y pagos').replace(/^Colores de la marca$/, 'Colores');
  const tabs = Array.from(barra.querySelectorAll('[data-subtab]'));
  let actual = null;

  const lista = document.createElement('nav');
  lista.className = 'cfg-lista'; lista.setAttribute('aria-label', 'Secciones de Configuración');
  const volver = document.createElement('button');
  volver.type = 'button'; volver.className = 'cfg-volver'; volver.innerHTML = '‹ Ajustes';
  barra.before(lista); vista.classList.add('cfg-v4');

  function secciones() {
    const out = [];
    for (const b of tabs) {
      if (b.hidden || getComputedStyle(b).display === 'none') continue;
      const panel = vista.querySelector(`[data-subpanel="${b.dataset.subtab}"]`);
      if (!panel) continue;
      panel.querySelectorAll(':scope > .card-quiet, :scope > .card').forEach((c, i) => {
        const h = c.querySelector('h2'); if (!h || c.id === 'lic-card' && c.hidden) return;
        if (!c.dataset.cfg) c.dataset.cfg = `${b.dataset.subtab}-${i}`;
        out.push({ id: c.dataset.cfg, grupo: b.textContent.trim(), tab: b.dataset.subtab, titulo: h.textContent.trim(), card: c });
      });
    }
    return out;
  }
  function pintarLista() {
    const s = secciones(); let grupo = '';
    lista.innerHTML = s.map(x => { const [col, path] = icono(x.titulo); const cab = x.grupo !== grupo ? `<p class="cfg-g">${UI.escapeHtml((grupo = x.grupo))}</p>` : '';
      return `${cab}<button type="button" class="cfg-it${x.id === actual ? ' on' : ''}" data-cfg="${x.id}"><span class="cfg-ic" style="background:${col}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg></span><span class="cfg-t">${UI.escapeHtml(corto(x.titulo))}</span><svg class="v4-chev" viewBox="0 0 8 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.5 1.5L6.5 7l-5 5.5"/></svg></button>`; }).join('');
  }
  function abrir(id, { foco = false } = {}) {
    const s = secciones(); const x = s.find(y => y.id === id) || s[0]; if (!x) return;
    actual = x.id;
    const b = tabs.find(t => t.dataset.subtab === x.tab); if (b && !b.classList.contains('active')) b.click();
    s.forEach(y => y.card.classList.toggle('cfg-oculta', y.id !== x.id));
    x.card.before(volver);
    vista.classList.add('cfg-abierta');
    lista.querySelectorAll('.cfg-it').forEach(it => it.classList.toggle('on', it.dataset.cfg === actual));
    if (foco) { const h = x.card.querySelector('h2'); if (h) { h.tabIndex = -1; h.focus({ preventScroll: true }); } }
    window.scrollTo({ top: 0 });
  }
  lista.addEventListener('click', e => { const it = e.target.closest('[data-cfg]'); if (it) abrir(it.dataset.cfg, { foco: true }); });
  volver.addEventListener('click', () => { vista.classList.remove('cfg-abierta'); window.scrollTo({ top: 0 }); });
  window.addEventListener('view:show', e => {
    if (e.detail.view !== 'configuracion') return;
    setTimeout(() => { pintarLista(); abrir(actual || (secciones()[0] || {}).id); if (matchMedia('(max-width:820px)').matches) vista.classList.remove('cfg-abierta'); }, 60);
  });
})();
