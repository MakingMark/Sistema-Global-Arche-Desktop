/* ═══ Mesas del salón (Equipo › Mesas) ═══
   Antes las mesas solo se editaban dentro de Ubicaciones, que se esconde cuando el negocio es un solo local:
   un restaurante así no tenía dónde agregar o renombrar mesas. Esta pantalla sale siempre que el módulo de
   mesas esté encendido. Lista agrupada por zona; tocar edita en una hoja; «⋯» con Editar, Pausar y Quitar. */
(function () {
  'use strict';
  const listaEl = document.getElementById('salon-lista');
  if (!listaEl) return;
  const esc = UI.escapeHtml;
  const segLocales = document.getElementById('salon-locales');
  const MAS = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/></svg>';
  let locales = [], local = null, mesas = [];

  const zonas = () => [...new Set(mesas.map(t => t.zone).filter(Boolean))];
  const zonasSugeridas = () => [...new Set(['Salón', 'Terraza', 'Barra', ...zonas()])];

  async function load() {
    try { locales = (await Api.locations.list()).filter(l => l.kind === 'carrito' && l.active); }
    catch (err) { listaEl.innerHTML = `<p class="error">${esc(err.message)}</p>`; return; }
    if (!locales.length) { listaEl.innerHTML = '<div class="hv-vacio"><b>No hay un punto de venta</b><span class="muted">Las mesas pertenecen a un punto de venta.</span></div>'; return; }
    if (window.salonLocal) { local = locales.find(l => l.id === window.salonLocal) || null; window.salonLocal = null; }
    if (!local || !locales.some(l => l.id === local.id)) local = locales[0];
    segLocales.hidden = locales.length < 2;
    segLocales.innerHTML = locales.map(l => `<button type="button" class="v4-seg-b${l.id === local.id ? ' is-active' : ''}" role="tab" aria-selected="${l.id === local.id}" data-loc="${l.id}">${esc(l.name)}</button>`).join('');
    await cargarMesas();
  }
  async function cargarMesas() {
    try { mesas = await Api.tables.list(local.id); } catch (err) { UI.toast(err.message, 'error'); return; }
    render();
  }

  function render() {
    if (!mesas.length) {
      listaEl.innerHTML = '<div class="hv-vacio"><b>Todavía no hay mesas</b><span class="muted">Crea varias de una vez (Mesa 1, Mesa 2…) o una por una. Mientras tanto, la caja puede usar «Para llevar» y «Vender».</span></div>';
      return;
    }
    const grupos = new Map();
    mesas.forEach(t => { const z = t.zone || ''; if (!grupos.has(z)) grupos.set(z, []); grupos.get(z).push(t); });
    const orden = [...grupos.keys()].sort((a, b) => (a === '') - (b === '') || a.localeCompare(b, 'es'));
    const conZonas = orden.some(z => z);
    listaEl.innerHTML = orden.map(z => `${conZonas ? `<p class="pf-sec in-sec">${z ? esc(z) : 'Sin zona'} <small>· ${grupos.get(z).length}</small></p>` : ''}<div class="in-lista" role="list">${grupos.get(z).map(t => `
      <div class="in-fila${t.active ? '' : ' row-inactive'}" role="listitem" tabindex="0" data-id="${t.id}">
        <span class="ex-ini sl-ini" aria-hidden="true">${esc((t.name.match(/\d+/) || [t.name.slice(0, 2)])[0].slice(0, 3).toUpperCase())}</span>
        <span class="in-n"><b>${esc(t.name)}${t.active ? '' : ' <span class="pend g">Pausada</span>'}</b><small>${t.seats ? `${t.seats} lugares` : 'Sin lugares indicados'}${t.zone && !conZonas ? ' · ' + esc(t.zone) : ''}</small></span>
        <span class="in-c">${t.occupied ? '<span class="pend am">Ocupada</span>' : ''}</span>
        <button type="button" class="hv-mas" aria-label="Acciones de ${esc(t.name)}" aria-haspopup="menu">${MAS}</button>
      </div>`).join('')}</div>`).join('');
  }

  segLocales.addEventListener('click', e => {
    const b = e.target.closest('[data-loc]'); if (!b) return;
    local = locales.find(l => l.id === Number(b.dataset.loc));
    segLocales.querySelectorAll('[data-loc]').forEach(x => { const on = x === b; x.classList.toggle('is-active', on); x.setAttribute('aria-selected', String(on)); });
    cargarMesas();
  });

  listaEl.addEventListener('click', async ev => {
    const f = ev.target.closest('[data-id]'); if (!f) return;
    const t = mesas.find(x => String(x.id) === f.dataset.id); if (!t) return;
    const mas = ev.target.closest('.hv-mas');
    if (!mas) { hoja(t); return; }
    const a = await UI.rowMenu(mas, t.name, [{ a: 'editar', t: 'Editar' }, { a: 'pausa', t: t.active ? 'Pausar (no sale en la caja)' : 'Activar' }, { a: 'quitar', t: 'Quitar…', peligro: true, sep: true }]);
    if (a === 'editar') hoja(t);
    if (a === 'pausa') { try { await Api.tables.update(t.id, { active: !t.active }); cargarMesas(); } catch (err) { UI.toast(err.message, 'error'); } }
    if (a === 'quitar') {
      if (!(await UI.confirmDialog(`¿Quitar "${esc(t.name)}"?`))) return;
      try { const r = await Api.tables.remove(t.id); UI.toast(r.deactivated ? 'La mesa ya tuvo cuentas: quedó pausada' : 'Mesa quitada'); cargarMesas(); } catch (err) { UI.toast(err.message, 'error'); }
    }
  });
  listaEl.addEventListener('keydown', ev => { const f = ev.target.closest('.in-fila'); if (f && ev.key === 'Enter' && ev.target === f) f.click(); });

  const zonaInput = (id, valor) => `<input id="${id}" list="${id}-l" maxlength="30" value="${esc(valor || '')}" placeholder="Opcional · ej. Terraza"><datalist id="${id}-l">${zonasSugeridas().map(z => `<option value="${esc(z)}">`).join('')}</datalist>`;

  function hoja(t) {
    const ed = !!t;
    const modal = UI.showModal(ed ? esc(t.name) : 'Mesa nueva', `<div class="pf">
      <div class="pf-grupo">
        <label class="pf-fila"><span>Nombre</span><input id="sl-nombre" maxlength="40" autocomplete="off" value="${ed ? esc(t.name) : ''}" placeholder="ej. Mesa 7 / Barra 1"></label>
        <label class="pf-fila"><span>Zona</span>${zonaInput('sl-zona', ed ? t.zone : '')}</label>
        <label class="pf-fila"><span>Lugares</span><input id="sl-lugares" type="number" min="1" step="1" inputmode="numeric" value="${ed && t.seats ? t.seats : ''}" placeholder="Opcional"></label>
        ${ed ? `<label class="pf-fila"><span>Activa<small>Pausada no sale en la caja</small></span><input type="checkbox" class="pf-sw" id="sl-activa" ${t.active ? 'checked' : ''}></label>` : ''}
      </div>
      <div class="error" id="sl-error" role="alert" hidden></div>
      <div class="pf-acciones"><button type="button" class="btn" id="sl-cancelar">Cancelar</button><button type="button" class="btn btn-primary" id="sl-guardar">${ed ? 'Guardar' : 'Crear mesa'}</button></div>
    </div>`);
    const el = modal.el, $ = s => el.querySelector(s);
    const err = m => { $('#sl-error').textContent = m; $('#sl-error').hidden = !m; };
    $('#sl-cancelar').addEventListener('click', () => modal.close());
    $('#sl-guardar').addEventListener('click', async () => {
      const name = $('#sl-nombre').value.trim(), zone = $('#sl-zona').value.trim(), lug = $('#sl-lugares').value;
      if (!name) { err('Escribe el nombre de la mesa'); $('#sl-nombre').focus(); return; }
      if (lug !== '' && !(Number(lug) >= 1)) { err('Los lugares tienen que ser 1 o más'); return; }
      const seats = lug === '' ? null : Math.floor(Number(lug));
      try {
        if (ed) await Api.tables.update(t.id, { name, zone, seats, active: $('#sl-activa').checked });
        else await Api.tables.create({ location_id: local.id, name, zone, seats });
        modal.close(); UI.toast(ed ? 'Mesa guardada' : 'Mesa creada'); cargarMesas();
      } catch (x) { err(x.message); }
    });
    setTimeout(() => $('#sl-nombre').focus(), 50);
  }

  function varias() {
    const modal = UI.showModal('Crear varias mesas', `<div class="pf">
      <div class="pf-grupo">
        <label class="pf-fila"><span>¿Cuántas?</span><input id="sv-n" type="number" min="1" max="100" step="1" inputmode="numeric" value="6"></label>
        <label class="pf-fila"><span>Nombre base</span><input id="sv-base" maxlength="30" value="Mesa"></label>
        <label class="pf-fila"><span>Zona</span>${zonaInput('sv-zona', '')}</label>
        <label class="pf-fila"><span>Lugares</span><input id="sv-lugares" type="number" min="1" step="1" inputmode="numeric" placeholder="Opcional"></label>
      </div>
      <p class="pf-nota" id="sv-ej" style="margin:8px 14px 0"></p>
      <div class="error" id="sv-error" role="alert" hidden></div>
      <div class="pf-acciones"><button type="button" class="btn" id="sv-cancelar">Cancelar</button><button type="button" class="btn btn-primary" id="sv-ok">Crear</button></div>
    </div>`);
    const el = modal.el, $ = s => el.querySelector(s);
    const ej = () => {
      const base = $('#sv-base').value.trim() || 'Mesa', n = Math.floor(Number($('#sv-n').value)) || 0;
      const ya = mesas.filter(t => new RegExp(`^${base.replace(/[^\wÀ-ÿ ]/g, '')} \\d+$`, 'i').test(t.name)).length;
      $('#sv-ej').textContent = n > 0 ? `Se crean ${base} ${ya + 1}${n > 1 ? ` a ${base} ${ya + n}` : ''}, siguiendo las que ya existen.` : '';
    };
    el.addEventListener('input', ej); ej();
    $('#sv-cancelar').addEventListener('click', () => modal.close());
    $('#sv-ok').addEventListener('click', async () => {
      const count = Math.floor(Number($('#sv-n').value)), lug = $('#sv-lugares').value;
      const e = el.querySelector('#sv-error');
      if (!(count >= 1 && count <= 100)) { e.textContent = 'Escribe entre 1 y 100'; e.hidden = false; return; }
      try {
        await Api.tables.create({ location_id: local.id, count, prefix: $('#sv-base').value.trim() || 'Mesa', zone: $('#sv-zona').value.trim(), seats: lug === '' ? null : Math.floor(Number(lug)) });
        modal.close(); UI.toast(`${count} ${count === 1 ? 'mesa creada' : 'mesas creadas'}`); cargarMesas();
      } catch (x) { e.textContent = x.message; e.hidden = false; }
    });
  }

  document.getElementById('btn-salon-nueva').addEventListener('click', () => local && hoja(null));
  document.getElementById('btn-salon-varias').addEventListener('click', () => local && varias());
  window.addEventListener('view:show', e => { if (e.detail.view === 'salon') load(); });
})();
