-- Medidas propias del negocio (ej. «cachimbo», «bandeja»). El sistema trae su lista oficial (gramo, libra, kilo, onza,
-- mililitro, litro, galón, unidad, lonja, scoop…) y NO deja escribir cualquier cosa como unidad de un insumo: lo que no
-- está en esa lista tiene que crearse aquí, de forma explícita. Una medida propia no se convierte a otras (para eso están
-- las medidas oficiales y la equivalencia del insumo). Solo el dueño las crea.
CREATE TABLE IF NOT EXISTS unidades_personalizadas (
  id         SERIAL PRIMARY KEY,
  nombre     TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
