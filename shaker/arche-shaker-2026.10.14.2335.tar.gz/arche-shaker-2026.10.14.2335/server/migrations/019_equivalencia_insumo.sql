-- Cuánto pesa o mide UNA unidad base cuando esa unidad no es de peso ni de líquido (taza, lonja, scoop,
-- porción, rebanada…). Con esto el sistema ofrece solo las medidas de la factura (libra, kilo, gramo,
-- onza, galón, litro…) también para esos insumos: «1 taza de azúcar = 200 g» y se puede comprar en libras.
-- NULL = no se ha definido (el insumo solo ofrece su unidad y sus empaques, como antes).
-- Es un valor aproximado que el dueño ajusta pesando una vez; las compras ya hechas no cambian.
ALTER TABLE supplies ADD COLUMN IF NOT EXISTS equiv_g  NUMERIC(12,4) CHECK (equiv_g  IS NULL OR equiv_g  > 0);
ALTER TABLE supplies ADD COLUMN IF NOT EXISTS equiv_ml NUMERIC(12,4) CHECK (equiv_ml IS NULL OR equiv_ml > 0);
