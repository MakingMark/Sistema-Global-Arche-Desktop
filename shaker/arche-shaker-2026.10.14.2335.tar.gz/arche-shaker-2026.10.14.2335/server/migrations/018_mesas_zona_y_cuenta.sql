-- Mesas por zona («Salón», «Terraza», «Barra»): la pantalla de Mesas las agrupa con un selector.
-- NULL = sin zona (todas juntas, como antes).
ALTER TABLE dining_tables ADD COLUMN IF NOT EXISTS zone TEXT;
-- Cuándo la mesa pidió la cuenta: la mesa se ve «Por cobrar» (ámbar) hasta que se cobra.
-- Si después anotan algo más, se borra (vuelve a «Comiendo» / «En cocina»).
ALTER TABLE orders ADD COLUMN IF NOT EXISTS bill_requested_at TIMESTAMPTZ;
