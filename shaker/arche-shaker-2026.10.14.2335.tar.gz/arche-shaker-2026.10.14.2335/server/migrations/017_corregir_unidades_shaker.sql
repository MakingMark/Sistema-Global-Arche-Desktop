-- Corrección única de los insumos de Shaker (13-oct-2026, aprobada por el dueño).
--
-- Qué pasó: el 12-oct en la noche se puso a 37 insumos el precio de COMO SE COMPRAN (la libra, el
-- galón, el paquete) y en varios se cambió la unidad (gramo → libra, onza → galón 1/2…), pero las
-- recetas seguían en la unidad pequeña. Resultado: 30 de 38 productos con margen negativo.
-- Devuelve cada insumo a la unidad de sus recetas e inventario, deja el empaque con lo que trae y el
-- costo por unidad base. Solo toca un insumo si sigue EXACTAMENTE como estaba en el respaldo del
-- 13-oct (id, nombre, unidad y costo) y el negocio se llama Shaker: en cualquier otra instalación, o
-- si ya se corrigió a mano, no cambia nada. Antes de migrar se guarda un respaldo completo.
-- Probado en una copia de ese respaldo: de 30 productos con margen negativo a 0.
DO $$
DECLARE
  c RECORD;
  n INTEGER := 0;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM app_settings WHERE business_name ILIKE 'shaker%') THEN
    RETURN;
  END IF;
  FOR c IN SELECT * FROM (VALUES
    (15, 'Carne molida',       'gramo',       135::numeric, 'gramo', round(135/453.592, 4),  NULL::text, NULL::numeric),
    (16, 'Carne de res',       'Libra',       135, 'gramo', round(135/453.592, 4),  NULL, NULL),
    (17, 'Lomo de cerdo',      'libra',       135, 'gramo', round(135/453.592, 4),  NULL, NULL),
    (14, 'Pollo (pechuga)',    '125g',         60, 'gramo', round(140/453.592, 4),  NULL, NULL),
    (12, 'Pimientos',          'libra',        75, 'gramo', round(75/453.6, 4),     'libra', 453.6),
    (71, 'Cebolla',            'gramo',        60, 'gramo', round(60/453.592, 4),   NULL, NULL),
    (2,  'Yautía',             '150 gramos',   25, 'gramo', round(25/453.6, 4),     'libra', 453.6),
    (11, 'Tomate',             '1 lonja',       5, 'gramo', 0.1000,                 'libra', 453.6),
    (7,  'Lechosa',            '1',            90, 'gramo', round(90/1360.8, 4),    'lechosa (aprox. 3 lb)', 1360.8),
    (6,  'Fresa',              'libra',        90, 'unidad', round(90/25.0, 4),     'libra (aprox. 25)', 25),
    (9,  'Zapote',             '1/2 porcion',  25, 'unidad', 50,                    NULL, NULL),
    (30, 'Tortilla',           '1',            21, 'unidad', 21,                    'paquete', 5),
    (28, 'Pan de hamburguesa', 'paquete',     125, 'unidad', round(125/8.0, 4),     'paquete', 8),
    (19, 'Salchicha',          'paquete',     139, 'unidad', round(139/8.0, 4),     'paquete', 8),
    (13, 'Pepinillos',         'frasco',      140, 'rodaja', round(140/58.0, 4),    'frasco', 58),
    (44, 'Leche evaporada',    'unidad',       55, 'onza', round(55/12.0, 4),       'lata', 12),
    (43, 'Leche',              'unidad',       60, 'onza', round(60/33.814, 4),     'litro', 33.814),
    (72, 'Pulpa de fresa',     'galon 1/2',   400, 'onza', round(400/64.0, 4),      'medio galón', 64),
    (73, 'Pulpa de chinola',   'galon 1/2',   750, 'onza', round(750/64.0, 4),      'medio galón', 64),
    (74, 'Pulpa de naranja',   'galon 1/2',   600, 'onza', round(600/64.0, 4),      'medio galón', 64),
    (75, 'Pulpa de limón',     'galon 1/2',   550, 'onza', round(550/64.0, 4),      'medio galón', 64),
    (35, 'Aderezo',            'porción',    1000, 'porción', round(1000/128.0, 4), 'galón', 128),
    (36, 'Aderezo especial',   'ketchp mayonesa', 400, 'porción', round(400/50.0, 4), 'envase', 50),
    (38, 'Ketchup',            'lata',        400, 'porción', round(400/100.0, 4),  'lata', 100),
    (39, 'Mayonesa',           'galon',       560, 'porción', round(560/128.0, 4),  'galón', 128),
    (40, 'Mantequilla',        'embase',      230, 'porción', round(230/32.0, 4),   'envase', 32),
    (51, 'Hielo',              'porción',      27.5, 'porción', round(27.5/10.0, 4), 'funda', 10)
  ) AS t(id, nombre, unidad_hoy, costo_hoy, unidad, costo, empaque, trae)
  LOOP
    UPDATE supplies s
       SET unit = c.unidad, unit_cost = c.costo,
           pack_name = COALESCE(c.empaque, s.pack_name),
           pack_size = CASE WHEN c.empaque IS NULL THEN s.pack_size ELSE c.trae END
     WHERE s.id = c.id AND s.name = c.nombre AND s.unit = c.unidad_hoy AND s.unit_cost = c.costo_hoy;
    IF FOUND THEN
      n := n + 1;
      INSERT INTO audit_log (entity_type, entity_id, entity_name, field, old_value, new_value)
      VALUES ('supply', c.id, c.nombre, 'unit_cost', c.costo_hoy, c.costo);
    END IF;
  END LOOP;

  -- Batata: queda una sola (la original, en gramos) a RD$30 la libra; lo de «BATATA» (libras) pasa a gramos.
  IF EXISTS (SELECT 1 FROM supplies WHERE id = 3 AND name = 'Batata' AND unit = 'gramo' AND active = false)
     AND EXISTS (SELECT 1 FROM supplies WHERE id = 89 AND name = 'BATATA' AND unit = 'libras' AND active = true) THEN
    INSERT INTO audit_log (entity_type, entity_id, entity_name, field, old_value, new_value)
    SELECT 'supply', 3, 'Batata', 'unit_cost', unit_cost, round(30/453.6, 4) FROM supplies WHERE id = 3;
    UPDATE supplies SET active = true, unit_cost = round(30/453.6, 4) WHERE id = 3;
    FOR c IN SELECT location_id, stock FROM location_supply_stock WHERE supply_id = 89 AND stock <> 0 LOOP
      INSERT INTO location_supply_stock (location_id, supply_id, stock) VALUES (c.location_id, 3, 0)
        ON CONFLICT (location_id, supply_id) DO NOTHING;
      UPDATE location_supply_stock SET stock = stock + round(c.stock * 453.592, 3) WHERE location_id = c.location_id AND supply_id = 3;
      UPDATE location_supply_stock SET stock = 0 WHERE location_id = c.location_id AND supply_id = 89;
      INSERT INTO inventory_movements (location_id, supply_id, type, quantity, note)
      VALUES (c.location_id, 89, 'ajuste', -c.stock, 'Unificado con «Batata» (corrección de unidades)'),
             (c.location_id, 3, 'ajuste', round(c.stock * 453.592, 3), 'Viene de «BATATA»: ' || c.stock || ' libra(s) = ' || round(c.stock * 453.592, 1) || ' gramos');
    END LOOP;
    UPDATE supplies SET active = false WHERE id = 89;
    n := n + 1;
  END IF;
  RAISE NOTICE 'corregidos: %', n;
END $$;
