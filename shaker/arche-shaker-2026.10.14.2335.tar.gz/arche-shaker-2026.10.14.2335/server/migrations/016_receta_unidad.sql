-- En qué medida se escribió cada insumo de la receta (ej. «libra» en un insumo que se cuenta en
-- gramos). La cantidad sigue guardada en la unidad base del insumo — esto es solo para volver a
-- mostrarla como la escribió el dueño. NULL = la unidad base.
ALTER TABLE product_supplies ADD COLUMN IF NOT EXISTS unidad TEXT;
