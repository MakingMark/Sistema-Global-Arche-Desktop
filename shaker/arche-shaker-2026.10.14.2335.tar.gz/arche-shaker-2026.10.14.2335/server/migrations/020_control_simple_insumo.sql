-- «Control simple»: insumos que NO se cuentan ni se descuentan (sal, sazones, recaíto, canela, hielo…).
-- Son baratos o difíciles de medir: se tratan como merma. Con control_stock = false el sistema no pide
-- que haya existencia para vender, no descuenta nada al vender, no los marca «agotado» y no aparecen
-- en los avisos de poco stock. Su costo (si se le pone) sigue contando en el costo de la receta.
-- true = se controla como siempre (lo normal).
ALTER TABLE supplies ADD COLUMN IF NOT EXISTS control_stock BOOLEAN NOT NULL DEFAULT true;
