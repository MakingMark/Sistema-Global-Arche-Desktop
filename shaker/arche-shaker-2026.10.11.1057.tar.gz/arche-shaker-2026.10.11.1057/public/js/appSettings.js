/* ═══ Nombre y logo del negocio: se aplican en toda la app (login incluido,
   por eso esto corre solo, sin esperar a que haya sesión) + pantalla de
   Configuración para editarlos ═══ */
(function () {
  'use strict';

  const NAME_TARGETS = ['brand-name-login', 'brand-name-owner', 'brand-name-cart'];
  // Undécima vuelta — pedido explícito: el logo del negocio sale otra vez
  // del login (queda solo su nombre en texto) — el login ahora muestra
  // capturas reales del sistema, así que el logo del cliente ahí ya no
  // suma. Sigue con toda su fuerza en los menús laterales, en su propia
  // placa clara (funciona con cualquier logo, sea de trazo oscuro o claro).
  const LOGO_SIDEBARS = ['brand-logo-owner', 'brand-logo-cart'];
  // ANALISIS-LOGIN.md, recomendación #1: el pie de marca del login (logo +
  // derechos) se agrega también a bloqueo por inactividad, cierre de turno
  // y el asistente de primer uso — antes solo estaban en login/sidebar,
  // así que esas pantallas se sentían "de otro sistema".
  const COPYRIGHT_TARGETS = [
    'footer-copyright-login', 'footer-copyright-owner', 'footer-copyright-cart',
    'footer-copyright-lock', 'footer-copyright-shift', 'footer-copyright-setup'
  ];
  // Etiqueta de instalación (ej. la sucursal) — viene de INSTANCE_LABEL (variable de entorno del proceso, no de la
  // base de datos) para que el dueño sepa en qué instalación está parado
  // cuando tiene varias abiertas a la vez. Cada contexto usa su propio
  // par badge/línea porque el sidebar (fondo oscuro fijo) necesita otros
  // colores que la tarjeta de login (clara, según el tema).
  const INSTANCE_TARGETS = [
    ['instance-line-login', 'instance-badge-login'],
    ['instance-line-owner', 'instance-badge-owner'],
    ['instance-line-cart', 'instance-badge-cart'],
  ];
  // Versión visible de la app (pedido del dueño: no había forma de
  // confirmar, desde la propia interfaz, que un despliegue/reinicio tomó
  // efecto de verdad). Se actualiza a mano en cada release, junto con la
  // entrada nueva de CHANGELOG.md — mismo número, mismo momento.
  //
  // Quedó pegada en "v1.3" desde el primer commit ("copia del sistema de
  // Shaker v1.3") durante 21 entradas de CHANGELOG — multi-negocio con
  // consola y planes, tienda/retail completa (código de barras, fiado,
  // proveedores, mayoreo), sistema de módulos por tipo de negocio,
  // reposición, auditoría de seguridad — sin que nadie la subiera. v2.0
  // marca ese salto real (de "un restaurante" a "varios negocios,
  // cualquier tipo, con su propia página web"), no un cambio puntual.
  // v2.1: la marca Arche (logo, SEO, "© Arche" fijo) y el login rediseñado
  // de punta a punta — pedido explícito del dueño de no dejar pasar más
  // tiempo sin subir el número, ver CHANGELOG.md.
  // v2.2: el dueño notó que el número se había vuelto a quedar pegado —
  // 7 commits reales después de v2.1 (pulido del login, análisis
  // exhaustivo con sus mejoras, y el arreglo de toppings/Galón en el
  // punto de venta) sin subirlo. Corregido; ver CHANGELOG.md.
  // v2.3: segundo examen visual del login (pantalla completa en vez de
  // tarjeta flotando en un vacío, teclado numérico para el PIN, panel
  // animado ya visible en el celular) — pedido explícito, "aplica las
  // mejoras". Ver CHANGELOG.md.
  // v2.4: probado en un iPhone 14 Pro real, el panel animado apilado en el
  // celular se veía mal — vuelve a ocultarse en móvil, como antes de v2.3.
  // v2.5: en iOS, 100vh mide la pantalla con la barra de Safari oculta — con
  // la barra visible tapaba el pie de marca del login. Se usa dvh (se ajusta
  // sola), no detección de navegador.
  // v2.6: en escritorio el login arrancaba con el teclado numérico del PIN
  // por defecto — "se ve feo" ahí (tiene sentido en el celular del
  // carrito, no en el escritorio del dueño). Arranca con teclado normal
  // en escritorio, numérico en móvil; de paso, un bug real: el modo se
  // guardaba como si fuera una elección aunque fuera solo el default
  // aplicándose solo.
  // v3.0: login rediseñado (ANALISIS-LOGIN-V3.md) — selector PIN/Contraseña,
  // PIN que entra solo al 4.º dígito, panel «Origen» de Arche, reloj y estado
  // del servidor, pantalla de entrada con la «A» dibujándose.
  // v3.1: administrativo y facturación con la misma línea (ANALISIS-INTERFAZ-V3.1.md).
  // v3.2: administrativo en el celular con barra de pestañas + hoja «Más» (ownerNav.js).
  // v3.3: facturación en el celular — hoja de cobro, pago en botones, vuelto, pestañas + «Más».
  // v3.4: fase 2 — opciones en botones, Más vendidos, lista sin fotos, recibo por WhatsApp, historial por días.
  const APP_VERSION = 'v3.4';
  function applyBranding(settings) {
    const name = settings.business_name || 'Mi negocio';
    document.title = name + ' · Facturación';
    NAME_TARGETS.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = name;
    });
    if (settings.modules && window.Modules) Modules.set(settings.modules);
    AppLocale.set(settings);
    // Paleta de la marca (Configuración → Marca).
    const palette = Brand.apply({ accent: settings.brand_accent, ink: settings.brand_ink, paper: settings.brand_paper, highlight: settings.brand_highlight }, { persist: true });
    LOGO_SIDEBARS.forEach(id => {
      const img = document.getElementById(id);
      if (!img) return;
      const plate = img.closest('.brand-plate');
      if (settings.logo_data_url) img.src = settings.logo_data_url;
      if (plate) plate.hidden = !settings.logo_data_url;
      const brand = img.closest('.sidebar-brand');
      if (brand) brand.classList.toggle('has-logo', !!settings.logo_data_url);
    });
    const favicon = document.getElementById('favicon');
    if (favicon) { favicon.href = settings.logo_data_url || Brand.faviconFor(name, palette); favicon.type = settings.logo_data_url ? '' : 'image/svg+xml'; }
    // Pie de página tipo "derechos reservados". Dice "Arche" — el software
    // en sí — y no el nombre del negocio: el negocio es dueño de SUS datos
    // (ventas, clientes, inventario — todo exportable e intacto), pero no
    // del sistema que corre por debajo, así que los derechos reservados del
    // propio software no son de quien solo le puso su nombre en
    // Configuración. El nombre del negocio ya tiene su lugar propio (el
    // título de arriba, el logo del sidebar) — este pie es del sistema, no
    // del negocio, y por eso NO depende de `name` ni de ningún dato
    // editable por el dueño del negocio. El año se calcula solo.
    const copyright = `© ${new Date().getFullYear()} Arche — Todos los derechos reservados · ${APP_VERSION}`;
    COPYRIGHT_TARGETS.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = copyright;
    });
    INSTANCE_TARGETS.forEach(([lineId, badgeId]) => {
      const line = document.getElementById(lineId);
      const badge = document.getElementById(badgeId);
      if (!line || !badge) return;
      if (settings.instance_label) {
        badge.textContent = settings.instance_label;
        line.hidden = false;
      } else {
        line.hidden = true;
      }
    });
  }

  // Se corre de una vez al cargar cualquier pantalla (login, dueño o
  // carrito) — todas necesitan mostrar el nombre/logo correctos.
  Api.settings.get().then(applyBranding).catch(() => {});

  const nameInput = document.getElementById('config-business-name');
  if (!nameInput) return; // esta parte solo existe en la app del dueño

  const fileInput = document.getElementById('config-logo-file');
  const preview = document.getElementById('config-logo-preview');
  const emptyLabel = document.getElementById('config-logo-empty');
  const removeBtn = document.getElementById('config-logo-remove');
  const saveBtn = document.getElementById('config-save');
  const errorEl = document.getElementById('config-error');

  let currentLogo = null;
  let pendingLogo = undefined; // undefined = sin cambio, string = nuevo, null = quitar

  function showLogo(dataUrl) {
    if (dataUrl) {
      preview.src = dataUrl;
      preview.hidden = false;
      emptyLabel.hidden = true;
      removeBtn.hidden = false;
    } else {
      preview.hidden = true;
      emptyLabel.hidden = false;
      removeBtn.hidden = true;
    }
  }

  async function render() {
    const settings = await Api.settings.get();
    nameInput.value = settings.business_name || 'Mi negocio';
    renderTaxes(settings);
    document.getElementById('config-expiry-days').value = Number(settings.expiry_alert_days ?? 3);
    currentLogo = settings.logo_data_url || null;
    pendingLogo = undefined;
    showLogo(currentLogo);
    fileInput.value = '';
  }

  fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      UI.toast('Esa imagen pesa mucho — prueba con una más chica (menos de 1.5MB)', 'error');
      fileInput.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      pendingLogo = reader.result;
      showLogo(pendingLogo);
    };
    reader.readAsDataURL(file);
  });

  removeBtn.addEventListener('click', () => {
    pendingLogo = null;
    showLogo(null);
  });

  /* ── ITBIS y propina legal (opcionales) ── */
  const itbisEnabled = document.getElementById('config-itbis-enabled');
  const itbisRate = document.getElementById('config-itbis-rate');
  const tipEnabled = document.getElementById('config-tip-enabled');
  const tipRate = document.getElementById('config-tip-rate');
  const taxesSaveBtn = document.getElementById('config-taxes-save');
  const taxesErrorEl = document.getElementById('config-taxes-error');

  function syncTaxInputs() {
    // El porcentaje solo se edita con el interruptor prendido, pero se
    // conserva el valor (apagar y prender no lo pierde).
    itbisRate.disabled = !itbisEnabled.checked;
    tipRate.disabled = !tipEnabled.checked;
  }
  function renderTaxes(settings) {
    itbisEnabled.checked = !!settings.itbis_enabled;
    itbisRate.value = Number(settings.itbis_rate ?? 18);
    tipEnabled.checked = !!settings.tip_enabled;
    tipRate.value = Number(settings.tip_rate ?? 10);
    if (settings.discount_max_pct !== undefined) document.getElementById('config-discount-max').value = Number(settings.discount_max_pct);
    syncTaxInputs();
  }
  document.getElementById('config-discount-save').addEventListener('click', async () => {
    const v = Number(document.getElementById('config-discount-max').value);
    if (!(v >= 0 && v <= 100)) { UI.toast('El tope debe estar entre 0 y 100', 'error'); return; }
    try { await Api.settings.update({ discount_max_pct: v }); UI.toast('Tope de descuento guardado'); } catch (err) { UI.toast(err.message, 'error'); }
  });
  itbisEnabled.addEventListener('change', syncTaxInputs);
  tipEnabled.addEventListener('change', syncTaxInputs);

  taxesSaveBtn.addEventListener('click', async () => {
    taxesErrorEl.hidden = true;
    const rates = [Number(itbisRate.value), Number(tipRate.value)];
    if (rates.some(r => !Number.isFinite(r) || r < 0 || r > 100)) {
      taxesErrorEl.textContent = 'Los porcentajes tienen que estar entre 0 y 100';
      taxesErrorEl.hidden = false;
      return;
    }
    const textoOriginal = taxesSaveBtn.textContent;
    try {
      taxesSaveBtn.disabled = true;
      taxesSaveBtn.textContent = 'Guardando…';
      await Api.settings.update({
        itbis_enabled: itbisEnabled.checked, itbis_rate: rates[0],
        tip_enabled: tipEnabled.checked, tip_rate: rates[1]
      });
      UI.toast('Impuestos guardados — se aplican a las próximas ventas');
    } catch (err) {
      taxesErrorEl.textContent = err.message;
      taxesErrorEl.hidden = false;
    } finally {
      taxesSaveBtn.disabled = false;
      taxesSaveBtn.textContent = textoOriginal;
    }
  });

  document.getElementById('config-expiry-save').addEventListener('click', async () => {
    const days = Number(document.getElementById('config-expiry-days').value);
    if (!Number.isInteger(days) || days < 0 || days > 60) { UI.toast('Los días de aviso deben ser un número entero entre 0 y 60', 'error'); return; }
    try {
      await Api.settings.update({ expiry_alert_days: days });
      UI.toast('Aviso de vencimientos guardado');
    } catch (err) { UI.toast(err.message, 'error'); }
  });

  saveBtn.addEventListener('click', async () => {
    errorEl.hidden = true;
    const business_name = nameInput.value.trim();
    if (!business_name) {
      errorEl.textContent = 'El nombre no puede quedar vacío';
      errorEl.hidden = false;
      return;
    }
    const textoOriginal = saveBtn.textContent;
    try {
      saveBtn.disabled = true;
      saveBtn.textContent = 'Guardando…';
      if (pendingLogo === null) {
        await Api.settings.removeLogo();
      }
      const data = { business_name };
      if (typeof pendingLogo === 'string') data.logo_data_url = pendingLogo;
      const updated = await Api.settings.update(data);
      applyBranding(updated);
      UI.toast('Configuración guardada');
      render();
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = textoOriginal;
    }
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'configuracion') render();
  });

  const currentPasswordInput = document.getElementById('config-current-password');
  const newPasswordInput = document.getElementById('config-new-password');
  const newPasswordConfirmInput = document.getElementById('config-new-password-confirm');
  const passwordSaveBtn = document.getElementById('config-password-save');
  const passwordErrorEl = document.getElementById('config-password-error');

  passwordSaveBtn.addEventListener('click', async () => {
    passwordErrorEl.hidden = true;
    const current_password = currentPasswordInput.value;
    const new_password = newPasswordInput.value;
    if (!current_password || !new_password) {
      passwordErrorEl.textContent = 'Completa la contraseña actual y la nueva';
      passwordErrorEl.hidden = false;
      return;
    }
    if (new_password !== newPasswordConfirmInput.value) {
      passwordErrorEl.textContent = 'La contraseña nueva no coincide en los dos campos';
      passwordErrorEl.hidden = false;
      return;
    }
    const textoOriginal = passwordSaveBtn.textContent;
    try {
      passwordSaveBtn.disabled = true;
      passwordSaveBtn.textContent = 'Cambiando…';
      const { token } = await Api.auth.changePassword(current_password, new_password);
      // El propio dispositivo sigue conectado con un token nuevo — solo los
      // demás (si había otro con la contraseña vieja guardada) quedan fuera,
      // porque su token lleva la huella del hash anterior.
      const session = Auth.get();
      Auth.set({ ...session, token });
      currentPasswordInput.value = '';
      newPasswordInput.value = '';
      newPasswordConfirmInput.value = '';
      UI.toast('Contraseña cambiada');
    } catch (err) {
      passwordErrorEl.textContent = err.message;
      passwordErrorEl.hidden = false;
    } finally {
      passwordSaveBtn.disabled = false;
      passwordSaveBtn.textContent = textoOriginal;
    }
  });

  /* ── Correo de recuperación ── */
  const emailInput = document.getElementById('config-owner-email');
  const emailPass = document.getElementById('config-email-password');
  const emailErr = document.getElementById('config-email-error');
  const emailNote = document.getElementById('config-email-note');
  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'configuracion') return;
    try {
      const a = await Api.auth.account();
      emailInput.value = a.email || '';
      emailNote.hidden = a.mail_configured;
      emailNote.textContent = a.mail_configured ? '' : 'Este servidor todavía no tiene el envío de correos configurado: el código no llegará hasta que se configure (ver la guía de instalación).';
    } catch (_) {}
  });
  document.getElementById('config-email-save').addEventListener('click', async () => {
    emailErr.hidden = true;
    try {
      await Api.auth.setEmail(emailInput.value, emailPass.value);
      emailPass.value = '';
      UI.toast('Correo guardado');
    } catch (err) { emailErr.textContent = err.message; emailErr.hidden = false; }
  });

  /* ── Respaldo / restauración de la base de datos ── */
  const backupDownloadBtn = document.getElementById('btn-backup-descargar');
  const restoreFileInput = document.getElementById('backup-restore-file');
  const restoreBtn = document.getElementById('btn-backup-restaurar');
  const backupErrorEl = document.getElementById('backup-error');
  let restoreFileText = null;

  // Respaldo fuera del servidor: si hay un depósito configurado, muestra el botón y cuándo se copió por última vez.
  async function renderOffsiteStatus() {
    try {
      const s = await Api.backup.status();
      const note = document.getElementById('backup-offsite-note');
      const btn = document.getElementById('btn-backup-offsite-now');
      btn.hidden = !s.offsite_configured;
      note.textContent = s.offsite_configured
        ? (s.last_offsite_backup_at ? `Se copió por última vez el ${fmtDate(s.last_offsite_backup_at)}.` : 'Configurado, todavía no se ha copiado ninguno.')
        : 'Si este servidor se pierde (o el disco falla), un respaldo guardado solo aquí no sirve. Se puede configurar un depósito externo (ver deploy/ADAPTADORES.md): a partir de eso, cada respaldo automático se copia también ahí.';
    } catch (_) {}
  }
  document.getElementById('btn-backup-offsite-now').addEventListener('click', async ev => {
    const btn = ev.currentTarget; const err = document.getElementById('backup-offsite-error');
    err.hidden = true; btn.disabled = true; const orig = btn.textContent; btn.textContent = 'Copiando…';
    try { await Api.backup.offsite(); UI.toast('Copiado fuera del servidor'); await renderOffsiteStatus(); }
    catch (e) { err.textContent = e.message; err.hidden = false; }
    finally { btn.disabled = false; btn.textContent = orig; }
  });
  window.addEventListener('view:show', e => { if (e.detail.view === 'configuracion') renderOffsiteStatus(); });

  backupDownloadBtn.addEventListener('click', async () => {
    backupErrorEl.hidden = true;
    const textoOriginal = backupDownloadBtn.textContent;
    try {
      backupDownloadBtn.disabled = true;
      backupDownloadBtn.textContent = 'Descargando…';
      await Api.backup.download();
      UI.toast('Respaldo descargado');
    } catch (err) {
      backupErrorEl.textContent = err.message;
      backupErrorEl.hidden = false;
    } finally {
      backupDownloadBtn.disabled = false;
      backupDownloadBtn.textContent = textoOriginal;
    }
  });

  restoreFileInput.addEventListener('change', () => {
    backupErrorEl.hidden = true;
    const file = restoreFileInput.files[0];
    restoreFileText = null;
    restoreBtn.disabled = true;
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      restoreFileText = reader.result;
      restoreBtn.disabled = false;
    };
    reader.onerror = () => {
      backupErrorEl.textContent = 'No se pudo leer el archivo';
      backupErrorEl.hidden = false;
    };
    reader.readAsText(file);
  });

  restoreBtn.addEventListener('click', async () => {
    backupErrorEl.hidden = true;
    if (!restoreFileText) return;
    // Es irreversible (reemplaza TODO) — un solo click no alcanza. Pedirle
    // que escriba una palabra exacta es más difícil de tocar por accidente
    // que un confirmDialog común, que se puede aceptar sin leer.
    const typed = await UI.promptDialog(
      'Esto va a BORRAR todos los datos actuales (ventas, inventario, clientes, catálogo) y reemplazarlos por los del archivo elegido. No se puede deshacer. Para confirmar, escribe RESTAURAR (en mayúsculas):'
    );
    if (typed === null) return;
    if (typed.trim() !== 'RESTAURAR') {
      backupErrorEl.textContent = 'No escribiste "RESTAURAR" tal cual — no se restauró nada.';
      backupErrorEl.hidden = false;
      return;
    }
    const textoOriginal = restoreBtn.textContent;
    try {
      restoreBtn.disabled = true;
      restoreBtn.textContent = 'Restaurando…';
      await Api.backup.restore(restoreFileText);
      UI.toast('Base de datos restaurada — recargando…');
      // Todo pudo cambiar (nombre del negocio, contraseña, sesión) — un
      // reload completo (no solo re-renderizar) es lo único que deja la app
      // consistente con los datos que se acaban de restaurar. Si la
      // contraseña del respaldo es distinta, el login se va a pedir de
      // nuevo solo (mismo manejo de 401 que ya tiene el resto de la app).
      setTimeout(() => location.reload(), 800);
    } catch (err) {
      backupErrorEl.textContent = err.message;
      backupErrorEl.hidden = false;
      restoreBtn.disabled = false;
      restoreBtn.textContent = textoOriginal;
    }
  });
})();
