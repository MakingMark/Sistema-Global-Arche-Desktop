/* Arche Escritorio: aviso de licencia por vencer (15 días antes). Lo ve todo
   el que use el sistema en esta PC o en los teléfonos; tocarlo lleva a la
   pantalla de licencia, donde se escribe la clave nueva. */
(function () {
  'use strict';
  fetch('/api/licencia', { cache: 'no-store' }).then(r => r.ok ? r.json() : null).then(e => {
    if (!e) return;
    if (!e.valida) { location.href = '/licencia.html'; return; }
    if (!e.aviso) return;
    const a = document.createElement('a');
    a.href = '/licencia.html';
    a.textContent = e.diasRestantes > 0
      ? `La licencia del sistema vence en ${e.diasRestantes} día${e.diasRestantes === 1 ? '' : 's'} (${e.vence}). Contacta a Arche para renovarla.`
      : `La licencia del sistema vence hoy. Contacta a Arche para renovarla.`;
    a.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:99999;padding:10px 16px;text-align:center;font:700 14px/1.4 system-ui,sans-serif;background:#b23a22;color:#fff;text-decoration:none';
    document.body.appendChild(a);
  }).catch(() => {});
})();
