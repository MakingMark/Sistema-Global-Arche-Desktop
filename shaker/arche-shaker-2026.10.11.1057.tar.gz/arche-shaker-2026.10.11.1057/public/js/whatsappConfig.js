/* ═══ Configuración → Avisos por WhatsApp: vincular/desvincular, ver estado ═══ */
(function () {
  'use strict';
  const unlinkedEl = document.getElementById('whatsapp-unlinked');
  if (!unlinkedEl) return;
  const pairingEl = document.getElementById('whatsapp-pairing');
  const linkedEl = document.getElementById('whatsapp-linked');
  const pairingCodeEl = document.getElementById('whatsapp-pairing-code');
  const linkedNumberEl = document.getElementById('whatsapp-linked-number');
  const errorEl = document.getElementById('whatsapp-error');
  const phoneInput = document.getElementById('whatsapp-phone');

  let pollTimer = null;

  function showOnly(el) {
    [unlinkedEl, pairingEl, linkedEl].forEach(x => { x.hidden = x !== el; });
  }

  function stopPolling() {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  }

  async function render() {
    errorEl.hidden = true;
    const status = await Api.whatsapp.status();
    if (status.status === 'connected') {
      stopPolling();
      showOnly(linkedEl);
      linkedNumberEl.textContent = '+' + status.ownerNumber;
    } else if (status.status === 'awaiting_pairing' && status.pairingCode) {
      showOnly(pairingEl);
      pairingCodeEl.textContent = status.pairingCode;
      startPolling();
    } else {
      stopPolling();
      showOnly(unlinkedEl);
    }
  }

  // Mientras se espera que el dueño escriba el código en su teléfono, hay
  // que revisar solo cuándo terminó — no hay ningún evento que avise desde
  // el teléfono, así que preguntarle a la API cada 2s es la única forma.
  function startPolling() {
    if (pollTimer) return;
    pollTimer = setInterval(async () => {
      const status = await Api.whatsapp.status().catch(() => null);
      if (status && status.status === 'connected') render();
      else if (status && status.status === 'disconnected' && status.lastError) {
        stopPolling();
        errorEl.textContent = status.lastError;
        errorEl.hidden = false;
        showOnly(unlinkedEl);
      } else if (status && status.status === 'awaiting_pairing' && status.pairingCode
                 && status.pairingCode !== pairingCodeEl.textContent) {
        // El servidor renueva el código solo cada vez que su conexión
        // interna se renueva (ver whatsappService.js) — sin esto, la
        // pantalla se quedaba mostrando el primer código para siempre,
        // aunque ya no sirviera para nada.
        pairingCodeEl.textContent = status.pairingCode;
      }
    }, 2000);
  }

  document.getElementById('btn-whatsapp-vincular').addEventListener('click', async () => {
    errorEl.hidden = true;
    const digits = phoneInput.value.replace(/\D/g, '');
    // El campo pide solo el número local (10 dígitos, sin "+1") — pedido
    // real del dueño, se confundía escribiendo el código de país a mano y
    // eso hacía que el número mandado a WhatsApp no fuera el suyo de
    // verdad. Si alguien de todos modos pega el número completo con el 1
    // adelante (11 dígitos empezando en 1), se respeta tal cual en vez de
    // duplicarlo a "1" + "1809...".
    const phone = (digits.length === 11 && digits.startsWith('1')) ? digits : `1${digits}`;
    if (digits.length < 10) {
      errorEl.textContent = 'Escribe tu número local completo, 10 dígitos (ej. 8095551234)';
      errorEl.hidden = false;
      return;
    }
    const btn = document.getElementById('btn-whatsapp-vincular');
    const original = btn.textContent;
    try {
      btn.disabled = true;
      btn.textContent = 'Generando código…';
      const { pairingCode } = await Api.whatsapp.pair(phone);
      pairingCodeEl.textContent = pairingCode;
      showOnly(pairingEl);
      startPolling();
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
    } finally {
      btn.disabled = false;
      btn.textContent = original;
    }
  });

  // Antes, si el código vencía o el dueño se arrepentía, la pantalla se
  // quedaba mostrando ese código muerto para siempre sin ninguna salida —
  // pedido real del dueño, lo vio en vivo intentando vincular. "Cancelar"
  // reusa el mismo unlink() de siempre (ya es seguro llamarlo mid-vínculo,
  // solo corta el socket y borra la sesión a medias) para volver limpio a
  // la pantalla de arranque.
  document.getElementById('btn-whatsapp-cancelar').addEventListener('click', async () => {
    stopPolling();
    await Api.whatsapp.unlink().catch(() => {});
    showOnly(unlinkedEl);
  });

  document.getElementById('btn-whatsapp-probar').addEventListener('click', async () => {
    try {
      await Api.whatsapp.test();
      UI.toast('Mensaje de prueba enviado — revisa tu WhatsApp');
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  document.getElementById('btn-whatsapp-desvincular').addEventListener('click', async () => {
    const ok = await UI.confirmDialog('¿Desvincular WhatsApp? Dejarás de recibir avisos de stock bajo hasta que vincules de nuevo.');
    if (!ok) return;
    try {
      await Api.whatsapp.unlink();
      UI.toast('WhatsApp desvinculado');
      phoneInput.value = '';
      render();
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'configuracion') render();
    else stopPolling(); // no seguir preguntando de fondo si el dueño ya se fue a otra pantalla
  });
})();
