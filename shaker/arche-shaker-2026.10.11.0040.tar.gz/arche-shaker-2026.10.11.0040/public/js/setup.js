/* ═══ Asistente de primer uso — solo corre si el servidor no tiene todavía
   una contraseña de administrativo guardada (ver server/routes/setup.js) ═══ */
(function () {
  'use strict';
  const form = document.getElementById('setup-form');
  if (!form) return;

  const fileInput = document.getElementById('setup-logo-file');
  const preview = document.getElementById('setup-logo-preview');
  const errorEl = document.getElementById('setup-error');
  let pendingLogo = null;
  let brand = null;
  let single = true;

  // Paletas: se ve al instante y se manda al servidor.
  const palettes = document.getElementById('setup-palettes');
  const setPalette = p => { brand = Brand.normalize(p); Brand.apply(brand); drawPalettes(); };
  function drawPalettes() {
    palettes.innerHTML = Brand.PRESETS.map(p => {
      const n = Brand.normalize(p); const cur = brand && brand.accent === n.accent && brand.ink === n.ink;
      return `<button type="button" class="brand-preset${cur ? ' is-current' : ''}" data-p="${p.id}"><span class="brand-swatches"><i style="background:${n.ink}"></i><i style="background:${n.accent}"></i><i style="background:${n.highlight}"></i><i style="background:${n.paper}"></i></span><strong>${p.name}</strong></button>`;
    }).join('');
  }
  drawPalettes();
  palettes.addEventListener('click', e => { const b = e.target.closest('[data-p]'); if (b) setPalette(Brand.PRESETS.find(p => p.id === b.dataset.p)); });
  document.getElementById('setup-locales').addEventListener('click', e => {
    const b = e.target.closest('[data-single]'); if (!b) return;
    single = b.dataset.single === '1';
    document.querySelectorAll('#setup-locales .chip').forEach(c => { const on = c === b; c.classList.toggle('active', on); c.setAttribute('aria-pressed', String(on)); });
  });
  document.getElementById('setup-delivery').addEventListener('change', e => { document.getElementById('setup-fee-wrap').hidden = !e.target.checked; });
  // Sin página web no tiene sentido pedir WhatsApp de pedidos/Instagram/
  // delivery en este paso — esos campos son justo para armarla. Los
  // valores quedan en el formulario (no se borran) por si el dueño la
  // vuelve a activar antes de enviar.
  document.getElementById('setup-website').addEventListener('change', e => {
    document.getElementById('setup-website-fields').hidden = !e.target.checked;
  });

  fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      UI.toast('Esa imagen pesa mucho — prueba con una más chica (menos de 1.5MB)', 'error');
      fileInput.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      pendingLogo = reader.result;
      preview.src = pendingLogo;
      preview.hidden = false;
    };
    reader.readAsDataURL(file);
  });

  form.addEventListener('submit', async e => {
    e.preventDefault();
    errorEl.hidden = true;

    const business_name = document.getElementById('setup-business-name').value.trim();
    const password = document.getElementById('setup-password').value;
    const passwordConfirm = document.getElementById('setup-password-confirm').value;
    const cartName = document.getElementById('setup-cart-name').value.trim();
    const cartAddress = document.getElementById('setup-cart-address').value.trim();
    const cartPin = document.getElementById('setup-cart-pin').value.trim();

    if (password !== passwordConfirm) {
      errorEl.textContent = 'Las dos contraseñas no coinciden';
      errorEl.hidden = false;
      return;
    }
    // El carrito es opcional en su conjunto, pero si se completó CUALQUIER
    // campo suyo, tiene que estar completo — nombre y PIN son los mínimos
    // que exige el backend (ver POST /api/locations), la dirección es
    // opcional ahí también.
    let first_cart = null;
    if (cartName || cartPin) {
      if (!cartName || !cartPin) {
        errorEl.textContent = 'Para crear el primer punto de venta hacen falta al menos su nombre y su PIN';
        errorEl.hidden = false;
        return;
      }
      if (!/^\d{4}$/.test(cartPin)) {
        errorEl.textContent = 'El PIN del punto de venta debe ser de exactamente 4 dígitos';
        errorEl.hidden = false;
        return;
      }
      first_cart = { name: cartName, address: cartAddress || null, pin: cartPin };
    }
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    try {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Configurando…';
      const { token } = await Api.setup.complete({
        business_name, logo_data_url: pendingLogo, owner_password: password, first_cart, owner_email: document.getElementById('setup-owner-email').value.trim() || undefined,
        activity: (document.querySelector('input[name="setup-activity"]:checked') || {}).value || 'restaurante',
        single_location: single, brand, examples: document.getElementById('setup-examples').checked,
        website_enabled: document.getElementById('setup-website').checked,
        contact: { whatsapp: document.getElementById('setup-whatsapp').value, instagram: document.getElementById('setup-instagram').value, address: document.getElementById('setup-address').value },
        delivery: { enabled: document.getElementById('setup-delivery').checked, fee: Number(document.getElementById('setup-fee').value) || 0 }
      });
      Auth.set({ role: 'owner', token });
      location.reload();
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });
})();
