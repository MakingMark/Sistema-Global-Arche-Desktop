/* ═══ Carrusel del login: siempre 5 láminas ═══
   Presenta lo que hace el sistema con gráficos dibujados (sin capturas ni datos reales). Cada versión de
   novedades.json que traiga "carrusel": { titulo, texto, vis } entra de primera, marcada «Nuevo», y empuja a la
   lámina más vieja: las de BASE solo rellenan hasta llegar a 5. Se pausa con el mouse, el foco o el botón, y no
   gira solo si el equipo pide reducir el movimiento. */
(function () {
  'use strict';
  const caja = document.getElementById('l6-car');
  if (!caja) return;
  const TOTAL = 5, PASO = 6500;
  const BASE = [
    { vis: 'factura', titulo: 'Factura en segundos', texto: 'Vende, cobra y entrega el recibo sin enredos.' },
    { vis: 'inventario', titulo: 'Inventario al día', texto: 'Cada venta descuenta lo que usaste, con tus recetas.' },
    { vis: 'caja', titulo: 'Cierra la caja tranquilo', texto: 'Cuadra el turno y mira lo que entró por cada forma de pago.' },
    { vis: 'reportes', titulo: 'Tus números, claros', texto: 'Ventas y gastos explicados, para decidir con calma.' },
    { vis: 'mesas', titulo: 'Mesas, cocina y pedidos', texto: 'Todo el servicio en un solo lugar, sin papelitos.' }
  ];
  const ok = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  const chip = t => `<b class="c-chip">${ok}${t}</b>`;
  const fila = (a, b, c = '') => `<div class="c-r ${c}"><span>${a}</span><span>${b}</span></div>`;
  // Cada dibujo tiene su propia forma y sus textos: son de ejemplo, no datos del negocio.
  const VIS = {
    factura: () => `<div class="c-recibo"><p class="c-h c-c">Recibo</p>${fila('Café', 'RD$ 120')}${fila('Sándwich', 'RD$ 275')}${fila('Jugo natural', 'RD$ 130')}<hr>${fila('Total', 'RD$ 525', 'c-tot')}</div>${chip('Pagada')}`,
    inventario: () => `<div class="c-card c-inv"><p class="c-h">Insumos</p>${[['Café', 82, 'Bien', ''], ['Leche', 46, 'Bien', ''], ['Azúcar', 14, 'Pedir', 'bajo']].map(([n, w, e, c]) => `<div class="c-it ${c}"><div class="c-r"><span>${n}</span><em>${e}</em></div><span class="c-barra"><u style="width:${w}%"></u></span></div>`).join('')}</div>`,
    caja: () => `<div class="c-card c-dona"><span class="c-anillo"><i>Caja<br>cuadrada</i></span><div class="c-ley"><p><em class="p0"></em>Efectivo</p><p><em class="p1"></em>Tarjeta</p><p><em class="p2"></em>Transferencia</p></div></div>`,
    reportes: () => `<div class="c-card"><div class="c-r"><p class="c-h">Ventas de la semana</p><b class="c-sube">▲ 18 %</b></div><div class="c-barras">${[['L', 34], ['M', 52], ['M', 44], ['J', 68], ['V', 60], ['S', 92]].map(([d, h], i) => `<div class="c-col"><span class="${i === 5 ? 'a' : ''}" style="--h:${h}%;--i:${i}"></span><small>${d}</small></div>`).join('')}</div></div>`,
    mesas: () => `<div class="c-card"><p class="c-h">Salón</p><div class="c-plano">${[['1', 'o'], ['2', ''], ['3', 'k'], ['4', 'o'], ['5', ''], ['6', 'k']].map(([n, c]) => `<span class="${c}">${n}</span>`).join('')}</div></div>${chip('Mesa 3 en cocina')}`,
    marca: () => `<div class="c-mini"><div class="c-mini-f"><p class="c-h">Hola de nuevo</p><div class="c-mini-pin"><i></i><i></i><i></i><i></i></div><span class="c-mini-b">Entrar</span></div><div class="c-mini-p"><span class="c-mini-logo">Tu logo</span><p>Tus colores</p><div class="c-tonos"><i></i><i></i><i></i></div></div></div>`,
    receta: () => `<div class="c-card"><div class="c-r"><p class="c-h">Batida verde</p><b class="c-boton">Editar receta</b></div><p class="c-sub">Receta</p>${fila('Espinaca', '40 g')}${fila('Piña', '120 g')}${fila('Jugo de naranja', '200 ml')}</div>`,
    novedades: () => `<div class="c-pila"><span></span><span></span><div class="c-card"><b class="c-marca">Nuevo</b><p class="c-h">En esta actualización</p><p class="c-sub">Lo que cambió, aquí al entrar.</p><div class="c-pts"><i class="on"></i><i></i><i></i><i></i><i></i></div></div></div>`
  };
  VIS.nuevo = VIS.novedades;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const pista = caja.querySelector('.l6-laminas'), puntos = caja.querySelector('.l6-puntos'), pausa = caja.querySelector('.l6-pausa');
  const quieto = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let actual = 0, reloj = null, enPausa = quieto, tocando = false;

  function pintar(laminas) {
    pista.innerHTML = laminas.map((l, i) => `<article class="l6-lam" role="group" aria-roledescription="lámina" aria-label="${i + 1} de ${laminas.length}">
      <div class="l6-vis" aria-hidden="true"><div class="c-esc">${(VIS[l.vis] || VIS.nuevo)()}</div></div>
      ${l.nuevo ? `<span class="l6-nuevo">Nuevo${l.version ? ' en ' + esc(l.version) : ''}</span>` : ''}
      <h2 class="l6-lam-t">${esc(l.titulo)}</h2><p class="l6-lam-x">${esc(l.texto)}</p></article>`).join('');
    puntos.innerHTML = laminas.map((_, i) => `<button type="button" class="l6-punto" aria-label="Ver lámina ${i + 1}"></button>`).join('');
    ir(0);
  }
  function ir(n) {
    const lam = pista.children, pts = puntos.children;
    actual = (n + lam.length) % lam.length;
    Array.from(lam).forEach((el, i) => { el.classList.toggle('activa', i === actual); el.setAttribute('aria-hidden', String(i !== actual)); });
    Array.from(pts).forEach((el, i) => { el.classList.toggle('activo', i === actual); if (i === actual) el.setAttribute('aria-current', 'true'); else el.removeAttribute('aria-current'); });
    programar();
  }
  function programar() {
    clearTimeout(reloj);
    const pantalla = document.getElementById('login-screen');
    if (enPausa || tocando || document.hidden || !pantalla || pantalla.hidden) return;
    reloj = setTimeout(() => ir(actual + 1), PASO);
  }
  function ponerPausa(si) {
    enPausa = si;
    pausa.setAttribute('aria-label', si ? 'Seguir presentación' : 'Pausar presentación');
    pausa.classList.toggle('en-pausa', si);
    programar();
  }
  puntos.addEventListener('click', e => { const b = e.target.closest('.l6-punto'); if (b) ir(Array.from(puntos.children).indexOf(b)); });
  pausa.addEventListener('click', () => ponerPausa(!enPausa));
  caja.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') { tocando = true; programar(); } });
  caja.addEventListener('pointerleave', () => { tocando = false; programar(); });
  caja.addEventListener('focusin', () => { tocando = true; programar(); });
  caja.addEventListener('focusout', () => { tocando = false; programar(); });
  document.addEventListener('visibilitychange', programar);
  new MutationObserver(programar).observe(document.getElementById('login-screen'), { attributes: true, attributeFilter: ['hidden'] });
  let x0 = null; // deslizar con el dedo
  pista.addEventListener('touchstart', e => { x0 = e.touches[0].clientX; }, { passive: true });
  pista.addEventListener('touchend', e => { if (x0 === null) return; const d = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(d) > 40) ir(actual + (d < 0 ? 1 : -1)); }, { passive: true });

  ponerPausa(enPausa);
  pintar(BASE);
  fetch('novedades.json', { cache: 'no-cache' }).then(r => r.ok ? r.json() : []).then(lista => {
    const nuevas = (Array.isArray(lista) ? lista : []).filter(n => n && n.carrusel && n.carrusel.titulo)
      .map(n => ({ vis: n.carrusel.vis || 'nuevo', titulo: n.carrusel.titulo, texto: n.carrusel.texto, version: n.version, nuevo: true }));
    if (nuevas.length) pintar(nuevas.concat(BASE).slice(0, TOTAL));
  }).catch(() => {});
})();
