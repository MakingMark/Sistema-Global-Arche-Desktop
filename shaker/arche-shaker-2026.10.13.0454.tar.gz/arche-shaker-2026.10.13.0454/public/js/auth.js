/* ═══ Pantalla de entrada: dueño (contraseña) o empleado (PIN) ═══ */
(function () {
  'use strict';

  // Entrada de soporte desde la consola de la plataforma: la dirección trae una sesión de dueño de 1 hora.
  try {
    const q = new URLSearchParams(location.search);
    if (q.get('soporte')) {
      Auth.set({ role: 'owner', token: q.get('soporte') });
      history.replaceState(null, '', location.pathname);
    }
  } catch (_) {}

  const loginScreen = document.getElementById('login-screen');
  const setupScreen = document.getElementById('setup-screen');
  const dbSetupScreen = document.getElementById('db-setup-screen');
  const ownerApp = document.getElementById('owner-app');
  const cartApp = document.getElementById('cart-app');

  const dbSetupExplain = document.getElementById('db-setup-explain');
  const dbSetupError = document.getElementById('db-setup-error');
  const dbSetupManual = document.getElementById('db-setup-manual');
  const btnDbSetupInit = document.getElementById('btn-db-setup-init');
  const btnDbSetupSpinner = document.getElementById('btn-db-setup-spinner');
  const btnDbSetupLabel = document.getElementById('btn-db-setup-label');

  const DB_STATE_COPY = {
    db_missing: 'Este servidor todavía no tiene una base de datos creada para este negocio.',
    schema_missing: 'Ya existe la base de datos, pero le faltan las tablas del sistema (el esquema nunca se terminó de instalar).',
    unreachable: 'No se pudo conectar a Postgres — puede que el servicio no esté corriendo, o que la configuración de conexión (DATABASE_URL) esté mal.'
  };

  function showDbSetupScreen(dbState) {
    dbSetupExplain.textContent = DB_STATE_COPY[dbState] || DB_STATE_COPY.unreachable;
    dbSetupError.hidden = true;
    if (dbState === 'unreachable') {
      btnDbSetupInit.hidden = true;
      dbSetupManual.hidden = false;
      dbSetupManual.textContent = 'Esto no se puede resolver desde el navegador: revisa que Postgres esté corriendo en esta máquina y que server/.env tenga el DATABASE_URL correcto, después recarga esta página.';
    } else {
      btnDbSetupInit.hidden = false;
      dbSetupManual.hidden = true;
    }
    dbSetupScreen.hidden = false;
  }

  btnDbSetupInit.addEventListener('click', async () => {
    dbSetupError.hidden = true;
    btnDbSetupInit.disabled = true;
    btnDbSetupSpinner.hidden = false;
    btnDbSetupLabel.textContent = 'Creando…';
    try {
      await Api.setup.initDatabase();
      location.reload();
    } catch (err) {
      dbSetupError.textContent = err.message || 'No se pudo crear la base de datos — prueba de nuevo en un momento.';
      dbSetupError.hidden = false;
      btnDbSetupInit.disabled = false;
      btnDbSetupSpinner.hidden = true;
      btnDbSetupLabel.textContent = 'Crear base de datos';
    }
  });

  const formLogin = document.getElementById('login-form');
  const errorLogin = document.getElementById('login-error');
  const loginCredential = document.getElementById('login-credential');
  const loginSubmit = document.getElementById('login-submit');
  const loginSubmitSpinner = document.getElementById('login-submit-spinner');
  const loginSubmitLabel = document.getElementById('login-submit-label');

  // Análisis exhaustivo del login (ANALISIS-LOGIN.md) — mejora de bajo
  // riesgo: mientras se escriben solo dígitos (un PIN), el teclado del
  // celular pasa a numérico; en cuanto aparece una letra (contraseña de
  // dueño), vuelve al teclado normal. Nunca se fuerza de entrada porque
  // un teclado numérico no deja escribir una contraseña con letras.
  loginCredential.addEventListener('input', () => {
    const v = loginCredential.value;
    loginCredential.inputMode = (v && /^[0-9]+$/.test(v)) ? 'numeric' : 'text';
  });

  // Login v3.0 (ANALISIS-LOGIN-V3.md). Dos modos: teclado numérico propio
  // para el PIN (lo normal en un carrito) y campo de contraseña (el dueño).
  // Se cambia con el selector PIN / Contraseña y la elección se recuerda por
  // DISPOSITIVO (localStorage): es una preferencia del equipo, no de quien entra.
  const loginCredentialField = document.querySelector('.login-credential-field');
  const loginPinpad = document.getElementById('login-pinpad');
  const loginPinDots = document.getElementById('login-pin-dots');
  const loginPinHint = document.getElementById('login-pin-hint');
  const loginMode = document.getElementById('login-mode');
  const loginEye = document.getElementById('login-eye');
  const loginCaps = document.getElementById('login-caps');
  const LOGIN_MODE_KEY = 'shaker_login_mode';
  // Los PIN son siempre de 4 dígitos (routes/employees.js): al cuarto se
  // entra solo, como en cualquier terminal de punto de venta.
  const PIN_LEN = 4;
  const PIN_HINT = 'Escribe tu PIN de 4 dígitos';
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let pinBusy = false;

  const isPinMode = () => !loginPinpad.hidden;
  // Reinicia una animación CSS aunque la clase ya estuviera puesta.
  function replay(el, cls) { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); }

  function renderPinDots() {
    const len = loginCredential.value.length;
    const slots = Math.max(PIN_LEN, len);
    if (loginPinDots.children.length !== slots) {
      loginPinDots.innerHTML = '';
      for (let i = 0; i < slots; i++) {
        const d = document.createElement('span');
        d.className = 'pin-dot';
        d.style.setProperty('--d', i);
        loginPinDots.appendChild(d);
      }
    }
    // Solo cambia la clase: así la animación de "pop" la hace el punto nuevo, no todos.
    Array.from(loginPinDots.children).forEach((d, i) => d.classList.toggle('filled', i < len));
  }

  // `remember`: solo cuando alguien tocó el selector — el arranque aplica el
  // default según el ancho de pantalla y eso no es una elección real.
  function setLoginMode(mode, remember, animate) {
    const isPin = mode !== 'keyboard';
    loginPinpad.hidden = !isPin;
    loginCredentialField.hidden = isPin;
    formLogin.classList.toggle('is-pin', isPin);
    loginMode.dataset.mode = isPin ? 'pin' : 'keyboard';
    loginMode.querySelectorAll('[data-mode]').forEach(b => b.setAttribute('aria-checked', String((b.dataset.mode === 'pin') === isPin)));
    loginCredential.value = '';
    loginCredential.type = 'password';
    loginCredential.autocomplete = isPin ? 'off' : 'current-password';
    loginEye.setAttribute('aria-pressed', 'false');
    loginEye.setAttribute('aria-label', 'Mostrar contraseña');
    loginCaps.hidden = true;
    errorLogin.hidden = true;
    loginPinDots.classList.remove('is-error', 'is-ok', 'is-checking');
    loginPinHint.textContent = PIN_HINT;
    pinBusy = false;
    if (animate && !reduceMotion) replay(formLogin, 'is-switching');
    if (isPin) renderPinDots(); else if (remember) loginCredential.focus();
    if (remember) { try { localStorage.setItem(LOGIN_MODE_KEY, isPin ? 'pin' : 'keyboard'); } catch (_) {} }
  }

  loginMode.addEventListener('click', e => {
    const b = e.target.closest('[data-mode]');
    if (b && b.dataset.mode !== loginMode.dataset.mode) setLoginMode(b.dataset.mode, true, true);
  });
  // Flechas izquierda/derecha, como cualquier grupo de opciones.
  loginMode.addEventListener('keydown', e => {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    e.preventDefault();
    const next = e.key === 'ArrowLeft' ? 'pin' : 'keyboard';
    if (next !== loginMode.dataset.mode) setLoginMode(next, true, true);
    loginMode.querySelector(`[data-mode="${next}"]`).focus();
  });

  /* ── Teclado del PIN ── */
  function pressFx(btn, e) {
    if (!btn) return;
    btn.classList.add('is-press');
    setTimeout(() => btn.classList.remove('is-press'), 120);
    if (reduceMotion) return;
    const r = btn.getBoundingClientRect();
    const fromPointer = e && e.detail !== 0 && typeof e.clientX === 'number';
    const x = fromPointer ? e.clientX - r.left : r.width / 2;
    const y = fromPointer ? e.clientY - r.top : r.height / 2;
    const s = document.createElement('span');
    s.className = 'lx-ripple';
    s.style.left = (x - r.width / 2) + 'px';
    s.style.top = (y - r.width / 2) + 'px';
    btn.appendChild(s);
    s.addEventListener('animationend', () => s.remove());
  }
  function afterPinChange() {
    loginPinDots.classList.remove('is-error');
    errorLogin.hidden = true;
    loginPinHint.textContent = PIN_HINT;
    renderPinDots();
    if (loginCredential.value.length === PIN_LEN) {
      pinBusy = true;
      // Un respiro para que se vea el cuarto punto lleno antes de verificar.
      setTimeout(() => formLogin.requestSubmit(), 160);
    }
  }
  function typeDigit(d) {
    if (pinBusy || loginCredential.value.length >= PIN_LEN) return;
    loginCredential.value += d;
    afterPinChange();
  }
  function erase(all) {
    if (pinBusy || !loginCredential.value) return;
    loginCredential.value = all ? '' : loginCredential.value.slice(0, -1);
    afterPinChange();
  }

  loginPinpad.addEventListener('click', e => {
    const btn = e.target.closest('.pin-key');
    if (!btn || !btn.matches('button')) return;
    pressFx(btn, e);
    if (btn.dataset.digit) typeDigit(btn.dataset.digit);
    else if (btn.id === 'login-pin-backspace') erase(false);
    else if (btn.id === 'login-pin-clear') erase(true);
  });
  // En escritorio también se puede escribir el PIN con el teclado de la PC.
  document.addEventListener('keydown', e => {
    if (loginScreen.hidden || formLogin.hidden || !isPinMode()) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.target && e.target.matches && e.target.matches('input, textarea, select')) return;
    let btn = null;
    if (/^[0-9]$/.test(e.key)) { btn = loginPinpad.querySelector(`[data-digit="${e.key}"]`); typeDigit(e.key); }
    else if (e.key === 'Backspace') { btn = document.getElementById('login-pin-backspace'); erase(false); }
    else if (e.key === 'Escape' || e.key === 'Delete') { btn = document.getElementById('login-pin-clear'); erase(true); }
    else return;
    e.preventDefault();
    pressFx(btn);
  });

  /* ── Campo de contraseña ── */
  loginEye.addEventListener('click', () => {
    const show = loginCredential.type === 'password';
    loginCredential.type = show ? 'text' : 'password';
    loginEye.setAttribute('aria-pressed', String(show));
    loginEye.setAttribute('aria-label', show ? 'Ocultar contraseña' : 'Mostrar contraseña');
    loginCredential.focus();
  });
  const checkCaps = e => { if (e.getModifierState) loginCaps.hidden = !e.getModifierState('CapsLock'); };
  loginCredential.addEventListener('keydown', checkCaps);
  loginCredential.addEventListener('keyup', checkCaps);
  loginCredential.addEventListener('blur', () => { loginCaps.hidden = true; });

  // Pedido explícito: en escritorio casi siempre entra el dueño con su
  // contraseña; el teclado numérico por defecto es para el celular/tablet
  // del carrito. Si alguien ya eligió a mano en ESE dispositivo, manda eso.
  const defaultLoginMode = window.matchMedia('(min-width: 760px)').matches ? 'keyboard' : 'pin';
  let savedLoginMode = defaultLoginMode;
  try { savedLoginMode = localStorage.getItem(LOGIN_MODE_KEY) || defaultLoginMode; } catch (_) {}
  setLoginMode(savedLoginMode);
  // El campo no se puede enfocar mientras el login está oculto: se enfoca al aparecer.
  new MutationObserver(() => {
    if (!loginScreen.hidden && !isPinMode() && window.matchMedia('(min-width: 760px)').matches) {
      setTimeout(() => loginCredential.focus(), 450);
    }
  }).observe(loginScreen, { attributes: true, attributeFilter: ['hidden'] });

  // Pantalla de carga al entrar y al salir: confirma A QUÉ se entra.
  const accessLoading = document.getElementById('access-loading');
  const accessLoadingText = document.getElementById('access-loading-text');
  const accessLoadingSub = document.getElementById('access-loading-sub');

  // Hoy el login solo resuelve dos destinos: el dueño (administrativo) o un
  // empleado de un carrito (facturación) — ver server/routes/auth.js.
  const firstName = n => String(n || '').trim().split(/\s+/)[0];
  function accessLabelFor(result) {
    if (result.role === 'owner') return { title: 'Bienvenido', sub: 'Entrando a Administrativo' };
    const n = firstName(result.employeeName);
    return { title: n ? `Hola, ${n}` : 'Bienvenido', sub: 'Entrando a Facturación' };
  }
  function exitLabelFor(session) {
    if (!session || session.role === 'owner') return { title: 'Hasta pronto', sub: 'Saliendo de Administrativo' };
    const n = firstName(session.employeeName);
    return { title: n ? `Hasta luego, ${n}` : 'Hasta luego', sub: 'Saliendo de Facturación' };
  }

  function showLoadingScreen(title, sub) {
    accessLoadingText.textContent = title;
    accessLoadingSub.hidden = !sub;
    accessLoadingSub.textContent = sub;
    accessLoading.classList.add('is-visible');
  }

  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

  function loginErrorText(err) {
    if (err.status === 429) return err.message; // bloqueado por intentos (bruteforce.js)
    if (err.status === undefined) return 'No hay conexión con el servidor. Revisa el internet o el Wi-Fi.';
    if (err.status >= 500) return 'El servidor tuvo un problema. Intenta de nuevo en un momento.';
    return isPinMode() ? 'PIN incorrecto' : 'Contraseña o PIN incorrecto';
  }

  formLogin.addEventListener('submit', async e => {
    e.preventDefault();
    const pinMode = isPinMode();
    const credential = loginCredential.value;
    if (!credential) { if (!pinMode) loginCredential.focus(); return; }
    errorLogin.hidden = true;
    loginSubmit.disabled = true;
    loginSubmitSpinner.hidden = false;
    loginSubmitLabel.textContent = 'Entrando…';
    if (pinMode) {
      pinBusy = true;
      loginPinDots.classList.add('is-checking');
      loginPinHint.textContent = 'Verificando…';
    }
    try {
      // Un solo campo: contraseña del dueño o PIN de un empleado; el
      // servidor resuelve cuál es.
      const result = await Api.auth.resolve(credential);
      loginPinDots.classList.remove('is-checking');
      loginPinDots.classList.add('is-ok');
      showLoadingScreen(...Object.values(accessLabelFor(result)));
      if (result.role === 'owner') {
        Auth.set({ role: 'owner', token: result.token });
      } else {
        Auth.set({
          role: result.role, // 'cart'
          employeeId: result.employeeId,
          employeeName: result.employeeName,
          employeeRole: result.employeeRole || 'cajero',
          pin: result.pin,
          locationId: result.locationId,
          locationName: result.locationName
        });
      }
      // Lo justo para que la «A» termine de dibujarse antes de recargar.
      await wait(reduceMotion ? 500 : 1050);
      location.reload();
    } catch (err) {
      errorLogin.textContent = loginErrorText(err);
      errorLogin.hidden = false;
      loginSubmit.disabled = false;
      loginSubmitSpinner.hidden = true;
      loginSubmitLabel.textContent = 'Entrar';
      if (!reduceMotion) replay(formLogin, 'is-shake');
      if (navigator.vibrate) { try { navigator.vibrate([35, 45, 35]); } catch (_) {} }
      if (pinMode) {
        loginPinDots.classList.remove('is-checking');
        loginPinDots.classList.add('is-error');
        loginPinHint.textContent = 'Intenta de nuevo';
        // Listo para escribir el PIN de nuevo sin borrar a mano.
        setTimeout(() => {
          loginCredential.value = '';
          loginPinDots.classList.remove('is-error');
          renderPinDots();
          pinBusy = false;
        }, 650);
      } else {
        loginCredential.select();
      }
    }
  });

  /* ── Recuperar la contraseña con un código enviado al correo del dueño ── */
  const forgotForm = document.getElementById('forgot-form');
  const forgotErr = document.getElementById('forgot-error');
  let forgotStep = 1;
  function showForgot(on) {
    formLogin.hidden = on; forgotForm.hidden = !on; loginMode.hidden = on;
    forgotStep = 1; document.getElementById('forgot-step2').hidden = true; forgotErr.hidden = true;
    document.getElementById('forgot-go').textContent = 'Enviar código';
    if (on) document.getElementById('forgot-email').focus();
  }
  document.getElementById('login-forgot-link').addEventListener('click', e => { e.preventDefault(); showForgot(true); });
  document.getElementById('forgot-back').addEventListener('click', e => { e.preventDefault(); showForgot(false); });
  forgotForm.addEventListener('submit', async e => {
    e.preventDefault();
    forgotErr.hidden = true;
    const email = document.getElementById('forgot-email').value.trim();
    try {
      if (forgotStep === 1) {
        await Api.auth.forgot(email);
        forgotStep = 2;
        document.getElementById('forgot-step2').hidden = false;
        document.getElementById('forgot-intro').textContent = 'Si ese correo es el del dueño, te llegó un código de 6 dígitos (vale 30 minutos). Escríbelo aquí con tu contraseña nueva.';
        document.getElementById('forgot-go').textContent = 'Cambiar contraseña';
        document.getElementById('forgot-code').focus();
      } else {
        const r = await Api.auth.reset(email, document.getElementById('forgot-code').value, document.getElementById('forgot-pass').value);
        Auth.set({ role: 'owner', token: r.token });
        location.reload();
      }
    } catch (err) {
      forgotErr.textContent = err.message || 'No se pudo completar';
      forgotErr.hidden = false;
    }
  });

  function logout() {
    // La sesión se lee ANTES de Auth.clear() — si no, exitLabelFor ya no
    // tiene con qué distinguir administrativo de facturación.
    showLoadingScreen(...Object.values(exitLabelFor(Auth.get())));
    Auth.clear();
    try { localStorage.removeItem('shaker_locked'); localStorage.removeItem('shaker_last_active'); } catch (_) {}
    wait(900).then(() => location.reload());
  }
  window.addEventListener('click', e => {
    if (!e.target.matches('[data-logout]')) return;
    // "Salir" es el ÚNICO cierre que cuenta como que el empleado se fue de
    // verdad (ver shiftService.js) — se intenta avisar al servidor antes de
    // cerrar la sesión local; sin señal, el turno queda para que se resuelva
    // en el próximo login, no bloquea el logout.
    const s = Auth.get();
    if (s && s.role === 'cart') {
      if (Modules.enabled('turnos')) Api.shift.end().catch(() => {}).finally(logout); else logout();
    } else {
      logout();
    }
  });

  /* ── Bloqueo por inactividad (punto de venta) ──
     No cierra la sesión: tapa la pantalla y pide el PIN otra vez, comparado
     localmente con el guardado en el dispositivo — así un carrito SIN señal
     puede volver a entrar (cerrar sesión de verdad exigiría al servidor). La
     cola de ventas offline (IndexedDB) no se toca. El estado y la última
     actividad viven en localStorage: recargar o cerrar la app no evita el
     bloqueo. */
  const IDLE_MS = 3 * 60 * 60 * 1000;
  const K_ACTIVE = 'shaker_last_active';
  const K_LOCKED = 'shaker_locked';
  const lockScreen = document.getElementById('lock-screen');
  const lockForm = document.getElementById('lock-form');
  const lockPin = document.getElementById('lock-pin');
  const lockError = document.getElementById('lock-error');
  let failedPins = 0;
  let coolUntil = 0;

  function lsGet(k) { try { return localStorage.getItem(k); } catch (_) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (_) {} }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (_) {} }

  // Pedido del dueño: "que no permita la facturación antes de hacer el
  // inventario" — con el bloqueo por PIN, el turno sin cerrar o el conteo
  // de inventario pendientes, no alcanza con TAPAR la app con una pantalla
  // encima (se puede pasar de largo); se OCULTA la app entera mientras
  // cualquiera de las tres siga sin resolver, para que no haya cómo llegar
  // a "Nueva venta" por accidente. Nunca se aplica al dueño (no tiene
  // turnos ni conteo). Es un candado del lado del cliente, no del
  // servidor — bloquear la venta en el servidor rompería la promesa central
  // de la app (vender SIEMPRE, incluso sin señal): una venta hecha offline
  // se sincroniza tal cual pasó de verdad, nunca se rechaza después.
  function setAppGated(hidden) {
    const s = Auth.get();
    if (s && s.role === 'cart') cartApp.hidden = hidden;
  }

  const lockDots = document.getElementById('lock-dots');
  function paintLockDots() {
    Array.from(lockDots.children).forEach((d, i) => d.classList.toggle('filled', i < lockPin.value.length));
  }
  function lockKey(k) {
    if (!k) return;
    lockError.hidden = true;
    if (k === 'back') lockPin.value = lockPin.value.slice(0, -1);
    else if (k === 'clear') lockPin.value = '';
    else if (lockPin.value.length < 4) lockPin.value += k;
    paintLockDots();
    if (lockPin.value.length === 4) setTimeout(() => lockForm.requestSubmit(), 150);
  }

  function lockNow() {
    lsSet(K_LOCKED, '1');
    const s = Auth.get();
    document.getElementById('lock-who').textContent = s && s.employeeName ? s.employeeName : '';
    lockPin.value = '';
    paintLockDots();
    lockError.hidden = true;
    lockScreen.hidden = false;
    setAppGated(true);
  }

  function unlock() {
    lsDel(K_LOCKED);
    lsSet(K_ACTIVE, String(Date.now()));
    lockScreen.hidden = true;
    failedPins = 0;
    // Con señal, revalidar el PIN en el servidor: si el dueño lo desactivó
    // o cambió mientras el equipo estaba bloqueado, se cierra la sesión.
    // Sin señal el error no trae status y no se hace nada.
    const s = Auth.get();
    Api.auth.resolve(s.pin).then(r => { if (r && r.employeeRole && r.employeeRole !== s.employeeRole) { Auth.set({ ...s, employeeRole: r.employeeRole }); location.reload(); } }).catch(err => { if (err.status === 401) logout(); });
    // No se destapa la app todavía — resumeShift() decide si hace falta
    // pedir el turno o el conteo antes de dejar ver "Nueva venta".
    resumeShift();
  }

  function setupIdleLock() {
    // Bug encontrado el 22 sept: un login recién hecho, antes de que exista
    // ALGUNA actividad guardada, calculaba "inactivo desde 1970" y
    // bloqueaba la sesión de una — nadie podía entrar sin verse bloqueado
    // al instante. Sin actividad registrada todavía, no hay nada que
    // evaluar: se cuenta como activo AHORA, no como inactivo para siempre.
    const lastActive = lsGet(K_ACTIVE);
    if (lsGet(K_LOCKED) === '1' || (lastActive !== null && Date.now() - Number(lastActive) > IDLE_MS)) lockNow();
    let lastWrite = 0;
    function touch() {
      if (!lockScreen.hidden) return;
      const now = Date.now();
      if (now - lastWrite > 15000) { lastWrite = now; lsSet(K_ACTIVE, String(now)); }
    }
    ['pointerdown', 'keydown', 'touchstart', 'scroll'].forEach(ev => window.addEventListener(ev, touch, { passive: true, capture: true }));
    setInterval(() => {
      if (lockScreen.hidden && Date.now() - Number(lsGet(K_ACTIVE) || 0) > IDLE_MS) lockNow();
    }, 30000);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && lockScreen.hidden && Date.now() - Number(lsGet(K_ACTIVE) || 0) > IDLE_MS) lockNow();
    });
    if (lockScreen.hidden) lsSet(K_ACTIVE, String(Date.now()));

    lockForm.addEventListener('submit', e => {
      e.preventDefault();
      const s = Auth.get();
      if (Date.now() < coolUntil) {
        lockError.textContent = 'Demasiados intentos — espera unos segundos';
        lockError.hidden = false;
        return;
      }
      if (lockPin.value === String(s.pin)) { lockDots.classList.add('is-ok'); setTimeout(() => { lockDots.classList.remove('is-ok'); unlock(); }, 180); return; }
      if (++failedPins >= 5) { failedPins = 0; coolUntil = Date.now() + 30000; }
      lockError.textContent = 'PIN incorrecto';
      lockError.hidden = false;
      lockDots.classList.add('is-error');
      replay(lockForm, 'is-shake');
      if (navigator.vibrate) { try { navigator.vibrate([35, 45, 35]); } catch (_) {} }
      setTimeout(() => { lockPin.value = ''; lockDots.classList.remove('is-error'); paintLockDots(); }, 600);
    });
    // v3.17: teclado del PIN (en pantalla y en el teclado de la PC), igual que el login.
    lockForm.addEventListener('click', e => {
      const b = e.target.closest('.pin-key');
      if (!b || !b.matches('button')) return;
      lockKey(b.dataset.digit || b.dataset.lock);
    });
    document.addEventListener('keydown', e => {
      if (lockScreen.hidden || e.ctrlKey || e.metaKey || e.altKey) return;
      if (/^[0-9]$/.test(e.key)) { e.preventDefault(); lockKey(e.key); }
      else if (e.key === 'Backspace') { e.preventDefault(); lockKey('back'); }
      else if (e.key === 'Escape') lockKey('clear');
    });
    document.getElementById('lock-switch').addEventListener('click', e => {
      e.preventDefault();
      lsDel(K_LOCKED);
      logout();
    });
  }

  /* ── Turnos (llegada/salida) + conteo de inventario semanal ──
     Se llama al iniciar sesión (si no estaba bloqueado) y cada vez que se
     desbloquea — es idempotente (ver Api.shift.resume/shiftService.js), así
     que llamarla seguido no crea turnos de más. Si no hay señal, no bloquea
     nada: se reintenta solo la próxima vez que haya conexión. */
  const shiftReportScreen = document.getElementById('shift-report-screen');
  const shiftReportForm = document.getElementById('shift-report-form');
  const shiftReportInfo = document.getElementById('shift-report-info');
  const shiftReportTime = document.getElementById('shift-report-time');
  const shiftReportError = document.getElementById('shift-report-error');
  let staleShiftId = null;
  let elapsedIntervalId = null;

  function pad2(n) { return String(n).padStart(2, '0'); }
  // Valor "YYYY-MM-DDTHH:MM" en hora LOCAL (nunca toISOString, que da la
  // hora en UTC) — es lo que espera un <input type="datetime-local">.
  function toLocalDatetimeValue(d) {
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}T${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  }

  function startElapsedTicker(startedAtIso, role) {
    const el = document.getElementById('shift-elapsed-cart');
    if (!el) return;
    if (elapsedIntervalId) clearInterval(elapsedIntervalId);
    const start = new Date(startedAtIso).getTime();
    function render() {
      const mins = Math.max(0, Math.floor((Date.now() - start) / 60000));
      el.textContent = `Turno: ${Math.floor(mins / 60)}h ${mins % 60}min`;
      el.hidden = false;
    }
    render();
    elapsedIntervalId = setInterval(render, 60000);
  }

  function announceArrival(startedAtIso) {
    const s = Auth.get();
    const timeStr = new Date(startedAtIso).toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit' });
    UI.toast(`Llegada: ${timeStr}`, 'success');
    startElapsedTicker(startedAtIso, s.role);
  }

  function showShiftReport(shift) {
    staleShiftId = shift.id;
    const arrived = new Date(shift.started_at);
    shiftReportInfo.textContent = `Llegaste el ${fmtDate(shift.started_at)} y no se cerró — dinos a qué hora te fuiste antes de seguir.`;
    shiftReportError.hidden = true;
    shiftReportTime.min = toLocalDatetimeValue(arrived);
    shiftReportTime.max = toLocalDatetimeValue(new Date());
    shiftReportTime.value = '';
    shiftReportScreen.hidden = false;
    setAppGated(true);
  }

  shiftReportForm.addEventListener('submit', async e => {
    e.preventDefault();
    shiftReportError.hidden = true;
    if (!shiftReportTime.value) return;
    const submitBtn = shiftReportForm.querySelector('button[type="submit"]');
    const textoOriginal = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Guardando…';
    try {
      const reportedIso = new Date(shiftReportTime.value).toISOString();
      const result = await Api.shift.report(staleShiftId, reportedIso);
      shiftReportScreen.hidden = true;
      announceArrival(result.shift.started_at);
      setAppGated(false);
    } catch (err) {
      // Sin señal (err.status===undefined, ver api.js) no hay cómo guardar
      // esto — no se deja a nadie sin poder vender solo porque no hay
      // conexión; se reintenta en el próximo login. Un error real del
      // servidor (ej. hora inválida) sí se muestra para que lo corrija.
      if (err.status === undefined) {
        shiftReportScreen.hidden = true;
        setAppGated(false);
      } else {
        shiftReportError.textContent = err.message || 'No se pudo guardar — prueba de nuevo';
        shiftReportError.hidden = false;
      }
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = textoOriginal;
    }
  });

  async function resumeShift() {
    if (!Modules.enabled('turnos')) { setAppGated(false); return; }
    let result;
    try {
      result = await Api.shift.resume();
    } catch (_) {
      // Sin señal no hay cómo saber si hace falta reportar un turno viejo o
      // contar inventario — nunca se deja a nadie sin poder vender por eso.
      setAppGated(false);
      return;
    }
    if (result.status === 'stale') { showShiftReport(result.shift); return; }
    if (result.status === 'started') {
      announceArrival(result.shift.started_at);
      setAppGated(false);
    } else {
      setAppGated(false);
      startElapsedTicker(result.shift.started_at, Auth.get().role);
    }
  }

  // El primer 'view:show' solo debe salir una vez que TODOS los scripts de
  // sección (dashboard.js, pos.js, etc.) ya registraron su propio listener —
  // si no, el evento se pierde y esa pantalla queda pegada en su estado
  // inicial ("Cargando…") hasta que el usuario navegue manualmente. Un
  // setTimeout(fn, 0) apostaba a que los demás scripts (todos locales, muy
  // rápidos) ya habrían corrido para ese momento — funcionaba en la práctica,
  // pero es una carrera de tiempos, no una garantía. Esperar a que el
  // documento termine de parsearse si hace falta (DOMContentLoaded) sí lo es.
  function announceInitialView(view) {
    const dispatch = () => window.dispatchEvent(new CustomEvent('view:show', { detail: { view } }));
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', dispatch, { once: true });
    } else {
      dispatch();
    }
  }

  const session = Auth.get();
  if (session && session.role === 'owner') {
    loginScreen.hidden = true;
    ownerApp.hidden = false;
    announceInitialView('panel');
  } else if (session && session.role === 'cart') {
    loginScreen.hidden = true;
    // OJO: cartApp arranca oculto (atributo "hidden" en el HTML) y se
    // revela recién cuando resumeShift()/maybeShowInventoryCheck() confirman
    // que no falta nada (ver setAppGated) — así nunca hay ni un instante
    // donde "Nueva venta" se alcance a ver antes de resolver el turno/
    // conteo pendiente. Si nunca hay señal, esas mismas funciones lo
    // revelan igual (nunca se bloquea la venta por falta de conexión).
    document.querySelectorAll('[data-cart-name]').forEach(el => { el.textContent = session.locationName; });
    document.querySelectorAll('[data-employee-name]').forEach(el => { el.textContent = session.employeeName; });
    // Rol «cocina»: solo ve la pantalla de cocina (el servidor además cierra todo lo demás).
    if (session.employeeRole === 'cocina') cartApp.dataset.empRole = 'cocina';
    setupIdleLock();
    // Si arrancó bloqueado (ver setupIdleLock), esto se resuelve recién al
    // desbloquear (ver unlock()) — pedirle el turno/conteo ANTES de que
    // escriba su PIN no tendría sentido.
    if (lockScreen.hidden) resumeShift();
    announceInitialView(session.employeeRole === 'cocina' ? 'pos-cocina' : 'pos-venta');
  } else {
    // Antes de mostrar el login normal, preguntar si este servidor todavía
    // no tiene ninguna contraseña de administrativo guardada — un despliegue
    // recién instalado no tiene con qué loguearse, así que le corresponde el
    // asistente de primer uso en vez de una pantalla de login que nadie
    // podría pasar. dbState distingue un paso ANTES de eso: si ni siquiera
    // hay base de datos/esquema creado, el asistente de negocio se
    // estrellaría solo con abrirlo (necesita guardar en app_settings) — ver
    // db-setup-screen arriba. Si la consulta falla por lo que sea (network
    // caído, etc — no una respuesta 200 con dbState), mostrar el login
    // normal es lo más seguro por defecto (nunca dejar a nadie sin login).
    Api.setup.status()
      .then(({ needsSetup, dbState, prefill }) => {
        if (dbState && dbState !== 'ready') { showDbSetupScreen(dbState); return; }
        if (needsSetup && prefill) {   // negocio dado de alta desde el registro: ya trae nombre y correo
          if (prefill.business_name) document.getElementById('setup-business-name').value = prefill.business_name;
          if (prefill.owner_email) document.getElementById('setup-owner-email').value = prefill.owner_email;
        }
        (needsSetup ? setupScreen : loginScreen).hidden = false;
      })
      .catch(() => { loginScreen.hidden = false; });
  }
})();
