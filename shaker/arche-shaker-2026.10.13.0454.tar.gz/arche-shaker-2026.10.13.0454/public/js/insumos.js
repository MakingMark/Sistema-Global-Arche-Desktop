/* ═══ Insumos: catálogo + registrar compras (nuevas o de reposición) ═══ */
(function () {
  'use strict';
  const grid = document.getElementById('insumos-grid');
  if (!grid) return;

  const NEW = '__new__';

  const compraInsumo = document.getElementById('compra-insumo');
  const compraUbicacion = document.getElementById('compra-ubicacion');
  const compraUnidadTipo = document.getElementById('compra-unidad-tipo');
  const compraCantidad = document.getElementById('compra-cantidad');
  const compraPrecio = document.getElementById('compra-precio');
  const compraPreview = document.getElementById('compra-preview');
  const formCompra = document.getElementById('form-compra');
  const searchInput = document.getElementById('insumos-search');

  const nuevoFields = document.getElementById('compra-nuevo-fields');
  const nuevoNombre = document.getElementById('compra-nuevo-nombre');
  const nuevoUnidad = document.getElementById('compra-nuevo-unidad');
  const nuevoEmpaqueNombre = document.getElementById('compra-nuevo-empaque-nombre');
  const nuevoEmpaqueSize = document.getElementById('compra-nuevo-empaque-size');

  // fmt() redondea a pesos enteros — bien para un cobro real, pero acá
  // esconde insumos baratos: Canela o Servilleta se veían como "RD$0"
  // (parece gratis) cuando en realidad cuestan RD$0.39 y RD$0.23. Mismo
  // ajuste pedido por el dueño para el desglose de Productos, aplicado
  // acá porque es el mismo problema — un costo por unidad, no un cobro.
  // fmtDec ahora es global — ver api.js.

  let supplies = [];

  /* ── Existencias por ubicación (insumo × ubicación) ── */
  const existenciasGrid = document.getElementById('existencias-grid');
  const existenciasResumen = document.getElementById('existencias-resumen');
  const existenciasBuscar = document.getElementById('existencias-buscar');
  const soloBajos = document.getElementById('existencias-solo-bajos');
  let overview = null;

  function fmtQty(n) {
    return Number(n).toLocaleString('es-DO', { maximumFractionDigits: 3 });
  }

  // Una tarjeta por insumo, con una fila por ubicación:
  // nombre, barra de nivel, cantidad y su nivel de aviso. Antes era una
  // tabla con una columna por ubicación que, en pantallas medianas, se
  // apilaba en un montón de texto suelto sin jerarquía.
  // Un solo local con el inventario repartido (ej. compras que entraron al almacén): se ofrece unirlo.
  let unir = null;
  async function revisarUnir() {
    try { unir = await Api.locations.unirEstado(); } catch (_) { unir = null; }
    const caja = document.getElementById('ex-unir') || (() => { const d = document.createElement('div'); d.id = 'ex-unir'; existenciasResumen.before(d); return d; })();
    const otras = unir && unir.un_solo_local && unir.principal ? unir.otras.filter(o => o.insumos > 0) : [];
    caja.hidden = !otras.length;
    if (!otras.length) return;
    const n = otras.reduce((t, o) => t + o.insumos, 0);
    caja.className = 'ex-unir';
    caja.innerHTML = `<div class="t"><b>Tu negocio es un solo local, pero ${n} insumo${n === 1 ? '' : 's'} está${n === 1 ? '' : 'n'} en «${UI.escapeHtml(otras.map(o => o.name).join('», «'))}».</b>
      <span class="muted">Las ventas descuentan de «${UI.escapeHtml(unir.principal.name)}», así que ese inventario no se está usando. Al unirlo pasa todo a «${UI.escapeHtml(unir.principal.name)}» y queda un solo inventario. Antes se guarda un respaldo completo, y cada traspaso queda anotado.</span></div>
      <button type="button" class="btn btn-primary" id="ex-unir-btn">Unir en ${UI.escapeHtml(unir.principal.name)}</button>`;
    caja.querySelector('#ex-unir-btn').addEventListener('click', async e => {
      if (!(await UI.confirmDialog(`¿Unir todo el inventario en «${unir.principal.name}»? Se guarda un respaldo antes, el almacén se da de baja y queda un solo inventario.`))) return;
      e.target.disabled = true;
      try { const r = await Api.locations.unir(); UI.toast(`Listo: ${r.insumos_movidos} insumos unidos en ${r.principal}`); overview = await Api.reports.stockOverview(); revisarUnir(); renderExistencias(); }
      catch (err) { UI.toast(err.message, 'error'); e.target.disabled = false; }
    });
  }
  window.addEventListener('view:show', e => { if (e.detail.view === 'inv-existencias') revisarUnir(); });

  function renderExistencias() {
    if (!overview) return;
    const { rows } = overview;
    const locations = Modules.visibleLocations(overview.locations);
    const q = existenciasBuscar.value.trim().toLowerCase();
    const lowCount = r => Object.values(r.cells).filter(c => c.low).length;
    const totalLow = rows.reduce((n, r) => n + lowCount(r), 0);
    const shown = rows
      .filter(r => (!soloBajos.checked || lowCount(r)) && (!q || r.name.toLowerCase().includes(q)))
      // Lo que tiene algo bajo primero — es lo que se viene a buscar acá.
      .sort((a, b) => lowCount(b) - lowCount(a));

    existenciasResumen.innerHTML = totalLow
      ? `<span class="pill pill-danger">${totalLow} ${totalLow === 1 ? 'nivel bajo' : 'niveles bajos'}</span> en ${rows.filter(r => lowCount(r)).length} ${rows.filter(r => lowCount(r)).length === 1 ? 'insumo' : 'insumos'}`
      : '<span class="pill pill-ok">Todo por encima de su nivel de aviso</span>';

    existenciasGrid.innerHTML = shown.length ? shown.map(r => {
      const cells = locations.map(l => ({ loc: l, c: r.cells[l.id] })).filter(x => x.c);
      const max = Math.max(...cells.map(x => x.c.value), 1);
      const nLow = lowCount(r);
      return `
        <article class="stock-card${nLow ? ' has-low' : ''}">
          <header class="stock-card-head">
            <h3>${UI.escapeHtml(r.name)}</h3>
            <span class="muted">${UI.escapeHtml(r.unit)}</span>
            ${nLow ? '<span class="pill pill-danger">Bajo</span>' : ''}
          </header>
          <ul class="stock-rows">
            ${locations.map(l => {
              const c = r.cells[l.id];
              if (!c) return '';
              const pct = Math.max(c.value / max * 100, c.value > 0 ? 4 : 0);
              return `
                <li class="stock-row${c.low ? ' is-low' : ''}">
                  <span class="stock-loc">${UI.escapeHtml(l.name)}</span>
                  <span class="stock-bar" aria-hidden="true"><span style="width:${pct}%"></span></span>
                  <strong class="stock-val">${fmtQty(c.value)}</strong>
                  <button type="button" class="aviso-btn" data-aviso-row="${r.id}" data-aviso-loc="${l.id}" title="Cambiar el nivel de aviso">${c.threshold > 0 ? 'aviso en ' + fmtQty(c.threshold) : 'sin aviso'}</button>
                </li>`;
            }).join('')}
          </ul>
          ${locations.some(l => !r.cells[l.id]) ? `<p class="muted stock-none">Aún sin este insumo: ${locations.filter(l => !r.cells[l.id]).map(l => UI.escapeHtml(l.name)).join(', ')}</p>` : ''}
        </article>`;
    }).join('') : `<p class="muted">${q || soloBajos.checked ? 'Nada coincide con este filtro.' : 'Todavía no hay insumos.'}</p>`;
  }

  // El nivel de aviso (cuánto es "poco") se cambia acá mismo, en la celda
  // donde se ve el stock. 0 = no avisar para ese insumo.
  existenciasGrid.addEventListener('click', e => {
    const btn = e.target.closest('[data-aviso-row]');
    if (!btn || !overview) return;
    const row = overview.rows.find(r => String(r.id) === btn.dataset.avisoRow);
    const loc = overview.locations.find(l => String(l.id) === btn.dataset.avisoLoc);
    const cell = row && row.cells[loc.id];
    if (!row || !loc || !cell) return;
    const modal = UI.showModal('Nivel de aviso', `
      <p>Avisar cuando queden <strong>${UI.escapeHtml(row.name)}</strong> en <strong>${UI.escapeHtml(loc.name)}</strong> esta cantidad o menos (${UI.escapeHtml(row.unit)}). Con 0 no se avisa.</p>
      <label class="f" style="max-width:none"><span>Cantidad</span><input id="aviso-valor" type="number" min="0" step="1" value="${cell.threshold}"></label>
      <div class="modal-actions" style="margin-top:16px">
        <button class="btn" id="aviso-cancel">Cancelar</button>
        <button class="btn btn-primary" id="aviso-save">Guardar</button>
      </div>`);
    modal.el.querySelector('#aviso-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#aviso-save').addEventListener('click', async () => {
      const value = Number(modal.el.querySelector('#aviso-valor').value);
      if (!(value >= 0)) { UI.toast('Escribe 0 o un número positivo', 'error'); return; }
      try {
        await Api.supplies.setThreshold(row.id, loc.id, value);
        modal.close();
        UI.toast('Nivel de aviso guardado');
        loadExistencias();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  });

  async function loadExistencias() {
    try {
      overview = await Api.reports.stockOverview();
      renderExistencias();
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  }
  soloBajos.addEventListener('change', renderExistencias);
  existenciasBuscar.addEventListener('input', renderExistencias);

  // Lo usa el aviso del Panel: abre Existencias ya filtrado a lo bajo.
  window.showExistencias = function (onlyLow) {
    soloBajos.checked = !!onlyLow;
    window.showView('inv-existencias');
    const card = document.getElementById('existencias-card');
    card.scrollIntoView({ block: 'start' });
    // El alto de la página cambia al cargar la tabla; reafirmar la posición.
    setTimeout(() => card.scrollIntoView({ block: 'start' }), 300);
  };

  async function render() {
    supplies = await Api.supplies.list();
    renderTable();

    const selected = compraInsumo.value;
    compraInsumo.innerHTML = supplies.map(s => `<option value="${s.id}">${UI.escapeHtml(s.name)}</option>`).join('')
      + `<option value="${NEW}">+ Insumo nuevo…</option>`;
    // Preservar la selección al re-renderizar (ej. después de guardar una
    // compra) — sin esto, cada render() volvía siempre al primer insumo de
    // la lista en vez de quedarse donde el dueño estaba parado.
    if (supplies.some(s => String(s.id) === selected) || selected === NEW) {
      compraInsumo.value = selected;
    }
    toggleNuevoFields();

    const locations = await Api.locations.list();
    // Solo activas: no tiene sentido registrar una compra nueva con destino
    // a un punto de venta ya dado de baja.
    compraUbicacion.innerHTML = Modules.visibleLocations(locations.filter(l => l.active)).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');

    window.dispatchEvent(new CustomEvent('supplies:updated', { detail: supplies }));
  }

  // Antes esto era una <table> de 5 columnas + acciones — mismo problema
  // estructural que ya tenía Productos (y Reportes): a un ancho intermedio
  // (~1042px) la columna de acciones fija tapaba "Costo del empaque" y hacía
  // falta un punto de quiebre medido a mano solo para esta tabla. Se pasa al
  // mismo componente de tarjetas ya probado en Productos — fase 3 de la
  // propuesta de rediseño: "un solo componente de datos, no una tabla
  // distinta por pantalla".
  function renderTable() {
    const q = searchInput.value.trim().toLowerCase();
    const filtered = q ? supplies.filter(s => s.name.toLowerCase().includes(q)) : supplies;
    grid.innerHTML = '';
    if (!filtered.length) {
      grid.innerHTML = `<p class="muted">Sin resultados para "${q}".</p>`;
      return;
    }
    filtered.forEach(s => {
      // "Costo/u" es el costo de oportunidad por unidad base (el que usan las
      // recetas) — pero el dueño no compra "una unidad", compra el empaque
      // completo (ej. una caja de 1000 vasos por RD$4,200). "Costo del
      // empaque" muestra ESE número, el que él reconoce de la compra real,
      // derivado del mismo costo por unidad (no un dato aparte que se pueda
      // desalinear).
      const packCost = s.pack_name && s.pack_size
        ? `${fmt(Number(s.unit_cost) * Number(s.pack_size))} el ${UI.escapeHtml(s.pack_name)}`
        : null;
      const packsLine = [
        s.pack_name ? `${UI.escapeHtml(s.pack_name)} (compra) = ${fmtNum(s.pack_size)} ${UI.escapeHtml(s.unit)}` : null,
        s.transfer_pack_name ? `${UI.escapeHtml(s.transfer_pack_name)} (reparto) = ${fmtNum(s.transfer_pack_size)} ${UI.escapeHtml(s.unit)}` : null
      ].filter(Boolean).join(' · ');
      const card = document.createElement('div');
      card.className = 'product-card' + (s.active ? '' : ' row-inactive');
      card.innerHTML = `
        <div class="product-card-header">
          <strong>${UI.escapeHtml(s.name)}</strong>${s.active ? '' : ' <span class="badge badge-muted">Inactivo</span>'}
          <div class="muted product-card-subtitle">${UI.escapeHtml(s.unit)}${packsLine ? ` · ${packsLine}` : ''}</div>
        </div>
        <div class="product-card-stats">
          <div><span class="label">Costo/u</span><span class="value">${fmtCost(s.unit_cost)}</span></div>
          ${packCost ? `<div><span class="label">Costo del empaque</span><span class="value">${packCost}</span></div>` : ''}
        </div>
        <div class="product-card-actions"></div>
      `;
      const actions = card.querySelector('.product-card-actions');

      const editBtn = document.createElement('button');
      editBtn.className = 'btn btn-sm';
      editBtn.innerHTML = UI.iconLabel('edit', 'Editar');
      editBtn.addEventListener('click', () => showEditSupplyModal(s));
      actions.appendChild(editBtn);

      const delBtn = document.createElement('button');
      delBtn.className = 'btn btn-sm';
      delBtn.innerHTML = UI.iconLabel('trash', 'Eliminar');
      delBtn.addEventListener('click', async () => {
        const ok = await UI.confirmDialog(`¿Eliminar "${UI.escapeHtml(s.name)}"?`);
        if (!ok) return;
        try {
          await Api.supplies.remove(s.id);
          render();
        } catch (err) {
          UI.toast('No se pudo eliminar: ' + err.message, 'error');
        }
      });
      actions.appendChild(delBtn);
      grid.appendChild(card);
    });
  }

  // Un insumo usado en la receta de algún producto no se puede borrar (el
  // esquema lo protege a propósito — ver product_supplies ON DELETE
  // RESTRICT), y hasta ahora tampoco había forma de editarlo: un typo en el
  // nombre de "Leche condensada" quedaba ahí para siempre. PUT /supplies/:id
  // ya existía en el backend, solo faltaba esta parte.
  // Solo aparecen acá las correcciones manuales de costo (Editar) — las que
  // ya deja "Registrar compra" viven en la bitácora de movimientos de
  // inventario (la nota "Compra: X..."), no hace falta duplicarlas.
  function costHistoryRows(log) {
    if (!log.length) return '';
    return `
      <div style="margin:-4px 0 16px;padding-top:10px;border-top:1px dashed var(--line)">
        <div style="font-weight:700;font-size:.85em;margin-bottom:6px">Correcciones manuales de costo</div>
        ${log.map(l => `
          <div class="muted" style="font-size:.82em;margin-bottom:3px">
            ${fmtDate(l.created_at)} — ${fmtDec(l.old_value)} → <strong>${fmtDec(l.new_value)}</strong>
          </div>
        `).join('')}
      </div>
    `;
  }

  async function showEditSupplyModal(s) {
    const log = await Api.auditLog.list('supply', s.id).catch(() => []);
    const body = `
      <div class="f" style="margin-bottom:12px"><span>Nombre</span><input id="edit-sup-name" value="${UI.escapeHtml(s.name)}"></div>
      <div class="f" style="margin-bottom:12px"><span>Unidad base</span><input id="edit-sup-unit" value="${UI.escapeHtml(s.unit)}"></div>
      <div class="f" style="margin-bottom:12px"><span>Costo por unidad (RD$)</span><input id="edit-sup-cost" type="number" step="0.0001" min="0" value="${s.unit_cost}"></div>
      <p class="muted" style="margin:-6px 0 12px;font-size:.82em">Normalmente el costo se actualiza solo con "Registrar compra" — cambiarlo acá es para corregir un error puntual.</p>
      ${costHistoryRows(log)}
      <p class="muted" style="margin:0 0 4px;font-size:.82em">Empaque de compra — cómo lo vende el proveedor (ej. "caja" de 1000).</p>
      <div class="f" style="margin-bottom:12px"><span>Empaque de compra (opcional)</span><input id="edit-sup-pack-name" value="${UI.escapeHtml(s.pack_name || '')}" placeholder="ej. caja"></div>
      <div class="f" style="margin-bottom:12px"><span>Unidades por empaque de compra</span><input id="edit-sup-pack-size" type="number" step="0.001" min="0" value="${s.pack_size ? Number(s.pack_size) : ''}"></div>
      <p class="muted" style="margin:0 0 4px;font-size:.82em">Empaque de reparto — cómo se maneja al transferir entre almacén y puntos de venta, si es distinto al de compra (ej. "paquete" de 50, dentro de una caja de 1000).</p>
      <div class="f" style="margin-bottom:12px"><span>Empaque de reparto (opcional)</span><input id="edit-sup-transfer-pack-name" value="${UI.escapeHtml(s.transfer_pack_name || '')}" placeholder="ej. paquete"></div>
      <div class="f" style="margin-bottom:12px"><span>Unidades por empaque de reparto</span><input id="edit-sup-transfer-pack-size" type="number" step="0.001" min="0" value="${s.transfer_pack_size ? Number(s.transfer_pack_size) : ''}"></div>
      <label class="f-check" style="margin-bottom:4px"><input type="checkbox" id="edit-sup-is-prep" ${s.preparation ? 'checked' : ''}><span>Es un insumo preparado (se hace a partir de otros)</span></label>
      <p class="muted" style="margin:0 0 8px;font-size:.82em">Ej. pollo cocido y desmenuzado, carne porcionada, salsa de la casa. Se prepara desde <strong>Inventario → Preparar</strong>: gasta los ingredientes, suma lo preparado y calcula su costo solo. Después lo usas en las recetas de los platos.</p>
      <div id="edit-sup-prep-body" style="margin-bottom:14px;${s.preparation ? '' : 'display:none'}">
        <div class="f" style="margin-bottom:8px"><span>Una tanda rinde (${UI.escapeHtml(s.unit)})</span><input id="edit-sup-prep-yield" type="number" step="0.001" min="0" value="${s.preparation ? s.preparation.batch_yield : ''}" placeholder="ej. 700"></div>
        <div style="font-size:.85em;font-weight:700;color:var(--ink-soft);margin-bottom:6px">Ingredientes de UNA tanda</div>
        <div id="edit-sup-prep-rows" class="receta-builder"></div>
        <button type="button" class="btn btn-sm" id="edit-sup-prep-add" style="margin-top:6px">+ Ingrediente</button>
      </div>
      <label class="f-check" style="margin-bottom:4px"><input type="checkbox" id="edit-sup-expiry" ${s.track_expiry ? 'checked' : ''}><span>Controlar fecha de vencimiento</span></label>
      <p class="muted" style="margin:0 0 12px;font-size:.82em">Para lo perecedero (carnes, lácteos, vegetales): cada compra o entrada lleva su fecha, las ventas gastan primero lo que vence antes y el sistema avisa lo que está por vencer.</p>
      <label class="f-check" style="margin-bottom:16px"><input type="checkbox" id="edit-sup-active" ${s.active ? 'checked' : ''}><span>Activo (visible para comprar/recetas nuevas)</span></label>
      <div class="modal-actions" style="margin-top:20px">
        <button class="btn" id="edit-sup-cancel">Cancelar</button>
        <button class="btn btn-primary" id="edit-sup-save">Guardar</button>
      </div>
    `;
    const modal = UI.showModal(`Editar · ${UI.escapeHtml(s.name)}`, body);
    modal.el.querySelector('#edit-sup-cancel').addEventListener('click', () => modal.close());
    const prepRows = modal.el.querySelector('#edit-sup-prep-rows');
    const ingredientOptions = selectedId => supplies.filter(x => x.id !== s.id && (x.active || x.id === selectedId))
      .map(x => `<option value="${x.id}" ${x.id === selectedId ? 'selected' : ''}>${UI.escapeHtml(x.name)} (${UI.escapeHtml(x.unit)})</option>`).join('');
    function addPrepRow(supplyId, qty) {
      const row = document.createElement('div');
      row.className = 'receta-row';
      row.innerHTML = `<select>${ingredientOptions(supplyId)}</select><input type="number" step="0.001" min="0" placeholder="Cantidad" value="${qty || ''}"><button type="button" class="btn btn-sm">Quitar</button>`;
      row.querySelector('button').addEventListener('click', () => row.remove());
      prepRows.appendChild(row);
    }
    if (s.preparation) s.preparation.inputs.forEach(i => addPrepRow(i.supply_id, i.quantity));
    modal.el.querySelector('#edit-sup-prep-add').addEventListener('click', () => addPrepRow());
    modal.el.querySelector('#edit-sup-is-prep').addEventListener('change', e => {
      modal.el.querySelector('#edit-sup-prep-body').style.display = e.target.checked ? '' : 'none';
      if (e.target.checked && !prepRows.children.length) addPrepRow();
    });
    modal.el.querySelector('#edit-sup-save').addEventListener('click', async () => {
      const name = modal.el.querySelector('#edit-sup-name').value.trim();
      const unit = modal.el.querySelector('#edit-sup-unit').value.trim();
      const unit_cost = Number(modal.el.querySelector('#edit-sup-cost').value);
      const pack_name = modal.el.querySelector('#edit-sup-pack-name').value.trim() || null;
      const pack_size = Number(modal.el.querySelector('#edit-sup-pack-size').value) || null;
      const transfer_pack_name = modal.el.querySelector('#edit-sup-transfer-pack-name').value.trim() || null;
      const transfer_pack_size = Number(modal.el.querySelector('#edit-sup-transfer-pack-size').value) || null;
      const active = modal.el.querySelector('#edit-sup-active').checked;
      const track_expiry = modal.el.querySelector('#edit-sup-expiry').checked;
      if (!name || !unit || !(unit_cost >= 0)) {
        UI.toast('Nombre, unidad y costo (0 o más) son obligatorios', 'error');
        return;
      }
      try {
        await Api.supplies.update(s.id, { name, unit, unit_cost, pack_name, pack_size, transfer_pack_name, transfer_pack_size, active, track_expiry });
        if (modal.el.querySelector('#edit-sup-is-prep').checked) {
          const inputs = Array.from(prepRows.querySelectorAll('.receta-row')).map(r => ({ supply_id: Number(r.querySelector('select').value), quantity: Number(r.querySelector('input').value) })).filter(i => i.supply_id && i.quantity > 0);
          await Api.supplies.setPreparation(s.id, { batch_yield: Number(modal.el.querySelector('#edit-sup-prep-yield').value), inputs });
        } else if (s.preparation) {
          await Api.supplies.setPreparation(s.id, null);
        }
        modal.close();
        UI.toast('Insumo actualizado');
        render();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  function isNewSelected() {
    return compraInsumo.value === NEW;
  }

  function currentSupply() {
    return supplies.find(s => String(s.id) === compraInsumo.value);
  }

  // Ambos casos (insumo existente vs. "+ Insumo nuevo") arman el mismo tipo
  // de dato — { unit, packName, packSize } — solo que uno lo lee del insumo
  // ya guardado y el otro de lo que se va escribiendo en los campos nuevos.
  // Unificar esto es lo que permite que "Unidad de compra" y la vista previa
  // usen una sola lógica en vez de una copia para cada caso (que es como
  // terminaba desalineándose antes, entre "Agregar insumo" y "Registrar
  // compra" por separado).
  function currentUnitInfo() {
    if (isNewSelected()) {
      return {
        unit: nuevoUnidad.value.trim() || 'unidad',
        packName: nuevoEmpaqueNombre.value.trim(),
        packSize: Number(nuevoEmpaqueSize.value) || 0,
        transferPackName: '', transferPackSize: 0
      };
    }
    const s = currentSupply();
    return {
      unit: s ? s.unit : 'unidad',
      packName: s && s.pack_name ? s.pack_name : '',
      packSize: s && s.pack_size ? Number(s.pack_size) : 0,
      transferPackName: s && s.transfer_pack_name ? s.transfer_pack_name : '',
      transferPackSize: s && s.transfer_pack_size ? Number(s.transfer_pack_size) : 0
    };
  }

  function toggleNuevoFields() {
    nuevoFields.hidden = !isNewSelected();
    updateUnidadTipoOptions();
    updateVenceField();
  }

  // La fecha de vencimiento solo se pide si el insumo lo controla (o si se
  // está dando de alta uno nuevo con el control activado).
  const compraVenceWrap = document.getElementById('compra-vence-wrap');
  const compraNuevoVence = document.getElementById('compra-nuevo-vence');
  function updateVenceField() {
    const tracked = isNewSelected() ? compraNuevoVence.checked : !!(currentSupply() && currentSupply().track_expiry);
    compraVenceWrap.hidden = !tracked;
  }
  compraNuevoVence.addEventListener('change', updateVenceField);

  function updateUnidadTipoOptions() {
    const { unit, packName, packSize, transferPackName, transferPackSize } = currentUnitInfo();
    const opts = [`<option value="unit">unidad (${unit})</option>`];
    if (packName && packSize > 0) {
      opts.push(`<option value="pack">${packName} (${fmtNum(packSize)} ${unit})</option>`);
    }
    // Empaque de reparto — un insumo comprado por caja también puede
    // comprarse ya contando por paquete si así llega la factura (ej. el
    // proveedor a veces vende sueltos por paquete, no siempre la caja
    // completa). Se ofrece como una opción MÁS, nunca reemplaza a la de compra.
    if (transferPackName && transferPackSize > 0) {
      opts.push(`<option value="transfer_pack">${transferPackName} (${fmtNum(transferPackSize)} ${unit})</option>`);
    }
    compraUnidadTipo.innerHTML = opts.join('');
    updatePreview();
  }

  function updatePreview() {
    const { unit, packSize, transferPackSize } = currentUnitInfo();
    const qty = Number(compraCantidad.value);
    const price = Number(compraPrecio.value);
    if (!qty || !price) { compraPreview.textContent = ''; return; }
    const size = compraUnidadTipo.value === 'pack' ? packSize : compraUnidadTipo.value === 'transfer_pack' ? transferPackSize : 1;
    const totalUnits = size > 0 ? qty * size : qty;
    compraPreview.textContent = `= ${fmtNum(totalUnits)} ${unit} · costo por unidad quedará en ${fmtCost(price / totalUnits)}`;
  }

  compraInsumo.addEventListener('change', toggleNuevoFields);
  compraUnidadTipo.addEventListener('change', updatePreview);
  compraCantidad.addEventListener('input', updatePreview);
  compraPrecio.addEventListener('input', updatePreview);
  [nuevoUnidad, nuevoEmpaqueNombre, nuevoEmpaqueSize].forEach(el => {
    el.addEventListener('input', updateUnidadTipoOptions);
  });

  formCompra.addEventListener('submit', async e => {
    e.preventDefault();
    if (isNewSelected() && !nuevoNombre.value.trim()) {
      UI.toast('El insumo nuevo necesita un nombre', 'error');
      return;
    }
    // Sin esto, un doble toque mandaba la misma compra dos veces — duplica
    // el stock recibido de verdad y desvía el costo por unidad calculado,
    // no es solo un problema visual.
    const submitBtn = formCompra.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    try {
      let supplyId = compraInsumo.value;
      if (isNewSelected()) {
        const created = await Api.supplies.create({
          name: nuevoNombre.value.trim(),
          unit: nuevoUnidad.value.trim() || 'unidad',
          pack_name: nuevoEmpaqueNombre.value.trim() || null,
          pack_size: Number(nuevoEmpaqueSize.value) || null,
          track_expiry: compraNuevoVence.checked
        });
        supplyId = created.id;
      }
      const result = await Api.supplies.purchase(supplyId, {
        location_id: Number(compraUbicacion.value),
        quantity: Number(compraCantidad.value),
        quantity_unit: compraUnidadTipo.value,
        total_price: Number(compraPrecio.value),
        note: document.getElementById('compra-nota').value || null,
        expires_on: (!compraVenceWrap.hidden && document.getElementById('compra-vence').value) || null
      });
      UI.toast(`Compra registrada — costo por unidad: ${fmtCost(result.unit_cost)}`);
      formCompra.reset();
      updateVenceField();
      compraPreview.textContent = '';
      render();
    } catch (err) {
      UI.toast(err.message, 'error');
    } finally {
      submitBtn.disabled = false;
    }
  });

  searchInput.addEventListener('input', renderTable);

  // El catálogo (Insumos) y el formulario de compra (Entradas) comparten la
  // misma lista de insumos/ubicaciones, así que se cargan igual.
  document.getElementById('btn-insumo-nuevo').addEventListener('click', () => {
    window.showView('inv-entradas');
    compraInsumo.value = NEW;
    toggleNuevoFields();
    nuevoNombre.focus();
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'insumos' || e.detail.view === 'inv-entradas') render();
    if (e.detail.view === 'inv-existencias') loadExistencias();
  });
})();
