/* ═══ Botón «Buscar actualización» (v3.20, solo la versión de escritorio) ═══
   Aparece en la pantalla de licencia, en el login y en Configuración → Licencia y plan.
   El servidor no actualiza directo (no es administrador): deja un aviso que un servicio de la PC
   recoge y corre el actualizador. Aquí solo se pide y se va mostrando qué pasa, en palabras.
   Se ve solo en la propia PC del negocio o con la sesión del dueño. */
(function () {
  'use strict';
  const RUTA = '/api/escritorio/actualizacion';
  const cab = () => {
    try { const s = JSON.parse(localStorage.getItem('shaker_session') || 'null'); return s && s.role === 'owner' && s.token ? { Authorization: 'Bearer ' + s.token } : {}; } catch (_) { return {}; }
  };
  const leer = () => fetch(RUTA, { headers: cab(), cache: 'no-store' }).then(r => r.json());
  const hace = iso => {
    const min = Math.round((Date.now() - Date.parse(iso)) / 60000);
    if (!isFinite(min)) return '';
    if (min < 1) return 'hace un momento';
    if (min < 60) return `hace ${min} min`;
    const h = Math.round(min / 60);
    return h < 24 ? `hace ${h} h` : `hace ${Math.round(h / 24)} d`;
  };

  function montar(caja) {
    if (!caja) return;
    caja.hidden = true;
    caja.innerHTML = '<button type="button" class="act-btn">Buscar actualización</button><p class="act-msg" role="status" aria-live="polite"></p>';
    const btn = caja.querySelector('.act-btn'), msg = caja.querySelector('.act-msg');
    let versionInicial = null, pedidoEn = 0, vigilando = null;

    const resumen = d => {
      const e = d.estado;
      return [d.version ? `Versión ${d.version}` : '', e ? `${e.mensaje.replace(/…$/, '')} (${hace(e.cuando)})` : ''].filter(Boolean).join(' · ');
    };
    leer().then(d => {
      if (!d.disponible || !d.puede) return;
      caja.hidden = false;
      versionInicial = d.version;
      msg.textContent = resumen(d);
    }).catch(() => {});

    btn.addEventListener('click', async () => {
      btn.disabled = true;
      msg.textContent = 'Buscando actualizaciones…';
      pedidoEn = Date.now() - 5000;
      try {
        const r = await fetch(RUTA, { method: 'POST', headers: cab() });
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'No se pudo pedir');
      } catch (e) { msg.textContent = e.message; btn.disabled = false; return; }
      clearInterval(vigilando);
      const fin = Date.now() + 5 * 60000;
      vigilando = setInterval(async () => {
        if (Date.now() > fin) { clearInterval(vigilando); btn.disabled = false; msg.textContent = 'Está tardando más de lo normal. Vuelve a intentarlo en unos minutos.'; return; }
        let d;
        try { d = await leer(); } catch (_) { msg.textContent = 'Instalando y reiniciando el sistema…'; return; }   // el servicio se está reiniciando
        if (versionInicial && d.version && d.version !== versionInicial) {
          clearInterval(vigilando); msg.textContent = `Listo: actualizado a la versión ${d.version}. Recargando…`;
          setTimeout(() => location.reload(), 2000); return;
        }
        const e = d.estado;
        if (!e || Date.parse(e.cuando) < pedidoEn || d.pendiente || e.estado === 'buscando') { msg.textContent = 'Buscando actualizaciones…'; return; }
        clearInterval(vigilando); btn.disabled = false;
        msg.textContent = e.estado === 'al-dia' ? `Ya tienes la última versión (${d.version || e.version}).` : e.mensaje;
      }, 2500);
    });
  }

  window.Actualizacion = { montar };
  const iniciar = () => document.querySelectorAll('[data-actualizacion]').forEach(montar);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
