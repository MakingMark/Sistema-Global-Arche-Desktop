# Shaker en tu PC (Arche Escritorio)

La PC del negocio hace de servidor: no hace falta pagar un VPS. El sistema se
enciende solo al prender la PC y se usa desde la PC y desde los teléfonos.

## Instalar (una sola vez, con internet)

Abre la **Terminal** y pega:

```bash
wget https://raw.githubusercontent.com/MakingMark/Sistema-Global-Arche-Desktop/master/instalar
bash instalar
```

Te pide la clave de administrador de la PC y hace todo solo. Después:
1. Pega la **licencia** que te da Arche. El botón verde envía el código de la PC por WhatsApp.
2. Si traes los datos de otro equipo, toca **«Cargar un respaldo (.json)»**. Si es un negocio
   nuevo, llena el asistente.

Guía completa: `INSTALAR-EN-PC-CLIENTE.md`.

## Uso diario

| Acceso directo | Qué hace |
|---|---|
| **Shaker** | Abre el sistema en esta PC |
| **Shaker · Conectar teléfono** | Muestra el QR para abrir el sistema en un teléfono |

- **Desde cualquier lugar** (datos móviles, otro Wi-Fi): la dirección `https://…ts.net`
  del QR «Recomendado». En el teléfono, menú del navegador → **«Agregar a pantalla de
  inicio»** para tenerlo como app.
- **En el Wi-Fi del local**: la dirección `http://192.168…:4340`. Sirve aunque se caiga
  el internet.
- La PC **no se suspende sola** (la pantalla sí se apaga). Si la apagas, al prenderla
  el sistema vuelve solo.

## Licencia

La primera vez (y cada año al renovar) el sistema muestra la pantalla **Licencia**
con el **código de esta PC**. Envíaselo a Arche y pega la clave que te den. Si la
licencia vence, el sistema se bloquea hasta escribir la clave nueva; 15 días antes
avisa en la parte de abajo de la pantalla.

## Respaldos

- Todos los días a las **11:30 p. m.** (o al prender la PC si se lo perdió) en la
  carpeta **`Respaldos Shaker`** de tu usuario. Se guardan los últimos 30.
- Para tener copia fuera de la PC: crea una carpeta llamada **`Respaldos-Shaker`** en
  una memoria USB y déjala conectada; el respaldo se copia ahí también.
- Restaurar uno: `bash /opt/arche-shaker/actual/escritorio/restaurar.sh ARCHIVO`

## Si hace falta

| Problema | Solución |
|---|---|
| Olvidé la contraseña de administrador | `bash /opt/arche-shaker/actual/escritorio/cambiar-clave.sh` |
| Quiero la IP fija en el Wi-Fi del local | `bash /opt/arche-shaker/actual/escritorio/fijar-ip.sh` (o reservarla en el router) |
| El sistema no abre | Reinicia la PC. Si sigue: `journalctl -u arche-shaker -n 50` |
| Actualizar el programa | Se actualiza solo: revisa al prender la PC y cada 2 horas (si están vendiendo, espera a un momento tranquilo). Para hacerlo ya: `sudo bash /opt/arche-shaker/actual/escritorio/actualizar.sh --ahora`. Desde una USB: `sudo bash /opt/arche-shaker/actual/escritorio/actualizar.sh --desde /media/…/CARPETA` (la carpeta con `manifest.json` y el `.tar.gz` que te pasó Arche) |
| La dirección de afuera no funciona | `tailscale funnel status` debe mostrar la dirección; si no, corre otra vez `bash instalar.sh` |

## Qué instala y dónde

- Programa: `/opt/arche-shaker` (con su propio Node; no toca nada más de la PC)
- Configuración: `/etc/arche-shaker/arche.env` (clave de la base generada al azar)
- Base de datos: PostgreSQL, base `shaker`
- Datos y respaldos: `/var/lib/arche-shaker`
- Servicios: `arche-shaker` (el sistema) y `arche-shaker-respaldo.timer` (respaldo diario)
