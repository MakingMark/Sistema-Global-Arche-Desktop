#!/usr/bin/env bash
# Instala Arche Escritorio · Shaker en esta PC bajando la última versión desde
# GitHub. herramientas/publicar.js lo sube como «instalar» al repositorio de
# actualizaciones, así que en la PC del cliente basta con:
#
#   wget https://raw.githubusercontent.com/MakingMark/Sistema-Global-Arche-Desktop/master/instalar
#   bash instalar
#   (dos comandos sin opciones, a prueba de errores al escribirlos; wget viene
#    siempre en Zorin/Ubuntu, curl a veces no — este script usa el que haya)
#
# Con una llave de Tailscale (para no abrir enlaces):
#   curl -fsSL …/instalar | bash -s -- --tailscale-clave tskey-auth-XXXX
#
# Qué hace: baja el manifiesto y el paquete, comprueba que el paquete es
# exactamente el del manifiesto (huella sha256) y corre escritorio/instalar.sh,
# que además verifica la FIRMA de Arche en cuanto tiene Node instalado.
set -euo pipefail
BASE="https://raw.githubusercontent.com/MakingMark/Sistema-Global-Arche-Desktop/master/shaker"
falla() { printf '\n\033[1;31m✖ %s\033[0m\n' "$*"; exit 1; }
# Para bajar archivos sirve curl o wget (wget viene siempre en Zorin/Ubuntu).
if command -v curl >/dev/null; then bajar() { curl -fsSL "$1" -o "$2"; }; bajar_largo() { curl -fSL --progress-bar "$1" -o "$2"; }
elif command -v wget >/dev/null; then bajar() { wget -q "$1" -O "$2"; }; bajar_largo() { echo "  (bajando, puede tardar un momento…)"; wget -q "$1" -O "$2"; }
else falla "No hay curl ni wget. Corre: sudo apt install -y wget"; fi
command -v python3 >/dev/null || falla "Falta python3: sudo apt install -y python3"
command -v sha256sum >/dev/null || falla "Falta sha256sum: sudo apt install -y coreutils"

DIR="$HOME/arche-instalador"
rm -rf "$DIR"; mkdir -p "$DIR"; cd "$DIR"
printf '\n\033[1;34m▶ Bajando la última versión de Arche…\033[0m\n'
bajar "$BASE/manifest.json" manifest.json || falla "No se pudo bajar el manifiesto (¿hay internet?)"
read -r VERSION ARCHIVO SHA < <(python3 - <<'PY'
import json, base64
m = json.load(open('manifest.json'))
d = m['datos']; d += '=' * (-len(d) % 4)
info = json.loads(base64.urlsafe_b64decode(d))
print(info['version'], info['archivo'], info['sha256'])
PY
)
bajar_largo "$BASE/$ARCHIVO" "$ARCHIVO" || falla "No se pudo bajar el paquete"
[ "$(sha256sum "$ARCHIVO" | cut -d' ' -f1)" = "$SHA" ] || falla "El paquete descargado está dañado o alterado. No se instala."
tar --warning=no-unknown-keyword -xzf "$ARCHIVO" 2>/dev/null || tar -xzf "$ARCHIVO"
printf '  \033[32m✔\033[0m Versión %s descargada\n' "$VERSION"

# El instalador pregunta cosas (la clave de la PC): se le da el teclado aunque
# este script haya llegado por «curl | bash».
cd "$DIR/arche-shaker-$VERSION/escritorio"
exec bash instalar.sh --manifest "$DIR/manifest.json" --paquete "$DIR/$ARCHIVO" "$@" </dev/tty
