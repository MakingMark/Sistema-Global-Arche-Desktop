#!/usr/bin/env bash
# Lo que corren los accesos directos del escritorio.
#   abrir.sh sistema    → abre el sistema en esta PC
#   abrir.sh conectar   → abre la página con el código QR para los teléfonos
# Si el sistema no responde (se cayó, la PC recién prendió), intenta encenderlo
# y espera antes de abrir el navegador.
PORT=4340
SERVICE=arche-shaker
URL="http://localhost:$PORT/"
[ "${1:-sistema}" = "conectar" ] && URL="http://localhost:$PORT/conectar.html"

listo() { curl -fs -m 2 "http://127.0.0.1:$PORT/api/setup/status" >/dev/null; }
avisar() { command -v notify-send >/dev/null && notify-send -i dialog-information "Shaker" "$1"; }

if ! listo; then
  avisar "Encendiendo el sistema, un momento…"
  for i in $(seq 1 10); do listo && break; sleep 1; done
  if ! listo; then
    pkexec systemctl restart "$SERVICE" 2>/dev/null || true
    for i in $(seq 1 30); do listo && break; sleep 1; done
  fi
  if ! listo; then
    avisar "El sistema no arrancó. Reinicia la PC; si sigue igual, revisa con: journalctl -u $SERVICE -n 50"
    exit 1
  fi
fi
xdg-open "$URL" >/dev/null 2>&1 &
