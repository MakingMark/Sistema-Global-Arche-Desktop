#!/usr/bin/env bash
# Reemplaza TODOS los datos de Shaker en esta PC por los de un respaldo.
#   bash restaurar.sh ARCHIVO.json      respaldo descargado desde el sistema (Configuración → Respaldo)
#   bash restaurar.sh ARCHIVO.sql.gz    respaldo diario automático de esta PC
# Antes de reemplazar guarda una copia de lo que hay ahora.
set -euo pipefail
[ "$(id -u)" -ne 0 ] && exec sudo -E bash "$0" "$@"
ARCHIVO="$(realpath "${1:?Uso: restaurar.sh ARCHIVO}")"
[ -f "$ARCHIVO" ] || { echo "No existe $ARCHIVO"; exit 1; }
APP_DIR=/opt/arche-shaker
ENV_FILE=/etc/arche-shaker/arche.env
SERVICE=arche-shaker
DB_NAME=shaker

if [ "${2:-}" != "--sin-confirmar" ]; then
  echo "Esto REEMPLAZA todos los datos actuales de Shaker por los de:"
  echo "  $ARCHIVO"
  read -r -p "Escribe RESTAURAR para seguir: " r
  [ "$r" = "RESTAURAR" ] || { echo "Cancelado."; exit 1; }
fi

echo "Guardando una copia de lo que hay ahora…"
USUARIO_ESCRITORIO="${SUDO_USER:-}" bash "$APP_DIR/actual/escritorio/respaldo.sh" >/dev/null && echo "  listo"

systemctl stop "$SERVICE"
case "$ARCHIVO" in
  *.sql.gz)
    sudo -u postgres dropdb --if-exists "$DB_NAME"
    sudo -u postgres createdb -O arche "$DB_NAME"
    gunzip -c "$ARCHIVO" | sudo -u postgres psql -q -v ON_ERROR_STOP=1 "$DB_NAME" >/dev/null
    sudo -u postgres psql -q -d "$DB_NAME" -c "REASSIGN OWNED BY postgres TO arche" >/dev/null
    ;;
  *.json)
    # Mismo camino que "Restaurar" dentro del sistema (valida el archivo antes de tocar nada).
    # El servicio corre con el usuario "arche", que no puede leer la carpeta
    # personal: se trabaja con una copia temporal.
    TMP="$(mktemp --suffix=.json)"; cp "$ARCHIVO" "$TMP"; chown arche "$TMP"
    cd "$APP_DIR/actual/server"
    RESPALDO_JSON="$TMP" sudo -u arche --preserve-env=RESPALDO_JSON "$APP_DIR/node/bin/node" -e "
      require('dotenv').config({ path: '$ENV_FILE' });
      const { pool } = require('./db');
      const { runMigrations } = require('./services/migrationService');
      const { restoreBackup } = require('./services/backupService');
      (async () => {
        await runMigrations();
        const c = await pool.connect();
        try { await restoreBackup(c, JSON.parse(require('fs').readFileSync(process.env.RESPALDO_JSON, 'utf8'))); } finally { c.release(); }
        await pool.end();
        console.log('Datos restaurados.');
      })().catch(e => { console.error('No se restauró nada:', e.message); process.exit(1); });" || { rm -f "$TMP"; systemctl start "$SERVICE"; exit 1; }
    rm -f "$TMP"
    ;;
  *) echo "Formato no reconocido (usa .json o .sql.gz)"; systemctl start "$SERVICE"; exit 1 ;;
esac
systemctl start "$SERVICE"
echo "✔ Listo. La contraseña de administrador es la que tenía el respaldo."
echo "  Si no la sabes: bash $APP_DIR/actual/escritorio/cambiar-clave.sh"
