// Comprueba que un manifiesto de actualización lo firmó Arche y, si se pasa el
// paquete, que el paquete es exactamente el del manifiesto.
//   node verificar-actualizacion.js manifest.json [paquete.tar.gz]
// Imprime "version<TAB>archivo<TAB>sha256" si todo está bien; si no, sale con error.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { PUBLIC_KEY_PEM } = require(path.join(__dirname, '..', 'server', 'services', 'licencia.js'));

const [manifestPath, paquete] = process.argv.slice(2);
const falla = m => { console.error(m); process.exit(1); };
let m;
try { m = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); } catch (_) { falla('Manifiesto ilegible'); }
const ok = crypto.verify(null, Buffer.from(String(m.datos)), crypto.createPublicKey(PUBLIC_KEY_PEM), Buffer.from(String(m.firma), 'base64url'));
if (!ok) falla('La firma del manifiesto NO es de Arche — actualización rechazada');
const info = JSON.parse(Buffer.from(m.datos, 'base64url').toString('utf8'));
if (info.producto !== 'arche-shaker') falla('El paquete es de otro producto');
if (!/^[0-9A-Za-z.\-]+$/.test(info.version) || !/^[0-9A-Za-z.\-]+\.tar\.gz$/.test(info.archivo)) falla('Manifiesto con datos inválidos');
if (paquete) {
  const sha = crypto.createHash('sha256').update(fs.readFileSync(paquete)).digest('hex');
  if (sha !== info.sha256) falla('El paquete no coincide con el manifiesto (archivo dañado o alterado)');
}
process.stdout.write(`${info.version}\t${info.archivo}\t${info.sha256}\n`);
