#!/usr/bin/env bash
# Respaldo diario de la base de Shaker (lo corre el temporizador arche-shaker-respaldo).
# Deja la copia en:
#   · /var/lib/arche-shaker/respaldos-diarios        (se guardan los últimos 30 días)
#   · ~/Respaldos Shaker del usuario de la PC        (los últimos 30)
#   · cualquier memoria USB conectada que tenga una carpeta llamada "Respaldos-Shaker"
# Para restaurar uno: bash /opt/arche-shaker/actual/escritorio/restaurar.sh ARCHIVO
set -euo pipefail
NEGOCIO="Shaker"
DB_NAME="shaker"
DIR="/var/lib/arche-shaker/respaldos-diarios"
KEEP=30
USUARIO="${USUARIO_ESCRITORIO:-}"
ARCHIVO="shaker-$(date +%F_%H%M).sql.gz"

mkdir -p "$DIR"
sudo -u postgres pg_dump --no-owner --no-acl "$DB_NAME" | gzip > "$DIR/$ARCHIVO"
[ -s "$DIR/$ARCHIVO" ] || { echo "El respaldo salió vacío"; exit 1; }
ls -1t "$DIR"/shaker-*.sql.gz | tail -n +$((KEEP + 1)) | xargs -r rm -f
echo "Respaldo: $DIR/$ARCHIVO"

copiar() { # destino dueño
  mkdir -p "$1" && cp "$DIR/$ARCHIVO" "$1/" && [ -n "$2" ] && chown -R "$2:$2" "$1" || true
  ls -1t "$1"/shaker-*.sql.gz 2>/dev/null | tail -n +$((KEEP + 1)) | xargs -r rm -f
  echo "Copia: $1/$ARCHIVO"
}
if [ -n "$USUARIO" ]; then
  HOME_U="$(getent passwd "$USUARIO" | cut -d: -f6)"
  [ -n "$HOME_U" ] && copiar "$HOME_U/Respaldos $NEGOCIO" "$USUARIO"
  for usb in /media/"$USUARIO"/*/Respaldos-"$NEGOCIO"; do
    [ -d "$usb" ] && copiar "$usb" ""
  done
fi
