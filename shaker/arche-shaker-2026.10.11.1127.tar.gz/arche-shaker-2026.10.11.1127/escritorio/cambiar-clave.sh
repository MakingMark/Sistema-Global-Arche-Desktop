#!/usr/bin/env bash
# Pone una contraseña de administrador nueva (si se olvidó). Pide la clave sin
# mostrarla en pantalla ni dejarla en el historial de la terminal.
set -euo pipefail
[ "$(id -u)" -ne 0 ] && exec sudo -E bash "$0" "$@"
read -r -s -p "Contraseña nueva de administrador: " C1; echo
read -r -s -p "Repítela: " C2; echo
[ "$C1" = "$C2" ] || { echo "No coinciden."; exit 1; }
[ ${#C1} -ge 4 ] || { echo "Mínimo 4 caracteres."; exit 1; }
cd /opt/arche-shaker/actual/server
NUEVA="$C1" sudo -u arche --preserve-env=NUEVA /opt/arche-shaker/node/bin/node -e "
  require('dotenv').config({ path: '/etc/arche-shaker/arche.env' });
  const { pool } = require('./db');
  const { hashPassword } = require('./services/authService');
  pool.query('UPDATE app_settings SET owner_password_hash = \$1 WHERE id = 1', [hashPassword(process.env.NUEVA)])
    .then(r => { if (!r.rowCount) throw new Error('Primero completa la configuración inicial del sistema'); console.log('✔ Contraseña cambiada. Las sesiones abiertas se cerraron.'); return pool.end(); })
    .catch(e => { console.error('Error:', e.message); process.exit(1); });"
