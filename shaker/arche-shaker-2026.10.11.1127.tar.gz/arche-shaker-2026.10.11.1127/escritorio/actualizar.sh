#!/usr/bin/env bash
# Actualiza Arche · Shaker en esta PC. Lo corre solo arche-shaker-actualizar.timer
# (3 minutos después de prender la PC y cada 2 horas) y también se puede correr a mano:
#   sudo bash /opt/arche-shaker/actual/escritorio/actualizar.sh                   busca en internet
#   sudo bash /opt/arche-shaker/actual/escritorio/actualizar.sh --ahora           igual, aunque estén vendiendo
#   sudo bash /opt/arche-shaker/actual/escritorio/actualizar.sh --desde CARPETA   desde una USB
#
# Para no cortar una venta: si la PC lleva más de 15 minutos prendida y hubo
# ventas en los últimos 15 minutos, no instala y lo deja para la próxima revisión
# (el reinicio dura unos segundos; aun así, mejor en un momento tranquilo).
#        (la carpeta tiene manifest.json y el arche-shaker-<versión>.tar.gz que te pasó Arche)
#
# Seguridad: solo instala paquetes FIRMADOS por Arche (verificar-actualizacion.js).
# Antes de cambiar guarda un respaldo; si la versión nueva no arranca, vuelve sola
# a la anterior.
set -euo pipefail
[ "$(id -u)" -ne 0 ] && exec sudo -E bash "$0" "$@"
APP_DIR=/opt/arche-shaker
ENV_FILE=/etc/arche-shaker/arche.env
SERVICE=arche-shaker
PORT=4340
NODE="$APP_DIR/node/bin/node"
GUARDAR=3   # versiones que se conservan para volver atrás

DB_NAME=shaker
DESDE=""; AHORA=0
while [ $# -gt 0 ]; do
  case "$1" in
    --desde) DESDE="$(realpath "${2:?Indica la carpeta}")"; AHORA=1; shift 2 ;;
    --ahora) AHORA=1; shift ;;
    *) echo "Opción desconocida: $1"; exit 1 ;;
  esac
done
log() { echo "[$(date '+%F %T')] $*"; }

ACTUAL_DIR="$(readlink -f "$APP_DIR/actual")"
ACTUAL="$(cat "$ACTUAL_DIR/VERSION" 2>/dev/null || echo 0)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

# 1) Manifiesto (y paquete, si viene de una carpeta).
if [ -n "$DESDE" ]; then
  cp "$DESDE/manifest.json" "$TMP/manifest.json"
else
  # La de arche.env manda; si está vacía, la que vino dentro del paquete instalado.
  URL="$(sed -n 's/^UPDATE_URL=//p' "$ENV_FILE")"
  [ -n "$URL" ] || URL="$(tr -d '[:space:]' < "$ACTUAL_DIR/escritorio/UPDATE_URL" 2>/dev/null || true)"
  [ -n "$URL" ] || { log "No hay dirección de actualizaciones configurada (UPDATE_URL)."; exit 0; }
  URL="${URL%/}"
  curl -fsSL --max-time 60 "$URL/manifest.json" -o "$TMP/manifest.json" || { log "Sin conexión con el servidor de actualizaciones."; exit 0; }
fi
INFO="$("$NODE" "$ACTUAL_DIR/escritorio/verificar-actualizacion.js" "$TMP/manifest.json")" || { log "Manifiesto rechazado."; exit 1; }
IFS=$'\t' read -r NUEVA ARCHIVO SHA <<<"$INFO"

if [ "$NUEVA" = "$ACTUAL" ] || [ "$(printf '%s\n%s\n' "$NUEVA" "$ACTUAL" | sort -V | tail -1)" = "$ACTUAL" ]; then
  log "Ya está en la última versión ($ACTUAL)."; exit 0
fi
log "Versión nueva: $NUEVA (instalada: $ACTUAL)"

# 2) Paquete y verificación de que es exactamente el firmado.
if [ -n "$DESDE" ]; then cp "$DESDE/$ARCHIVO" "$TMP/$ARCHIVO"
else curl -fsSL --max-time 600 "$URL/$ARCHIVO" -o "$TMP/$ARCHIVO"; fi
"$NODE" "$ACTUAL_DIR/escritorio/verificar-actualizacion.js" "$TMP/manifest.json" "$TMP/$ARCHIVO" >/dev/null || { log "Paquete rechazado."; exit 1; }

# 2b) ¿Momento tranquilo? (al prender la PC siempre lo es)
if [ "$AHORA" = 0 ] && [ "$(awk '{print int($1)}' /proc/uptime)" -gt 900 ]; then
  MIN="$(sudo -u postgres psql -tAc "SELECT COALESCE(FLOOR(EXTRACT(EPOCH FROM now() - max(created_at)) / 60), 99999)::int FROM sales" "$DB_NAME" 2>/dev/null || echo 99999)"
  if [ "${MIN:-99999}" -lt 15 ]; then
    log "Hay ventas recientes (hace $MIN min): la versión $NUEVA se instala en la próxima revisión."
    exit 0
  fi
fi

# 3) Respaldo antes de tocar nada.
USUARIO_ESCRITORIO="$(sed -n 's/^USUARIO_ESCRITORIO=//p' "$ENV_FILE")" bash "$ACTUAL_DIR/escritorio/respaldo.sh" >/dev/null && log "Respaldo hecho."

# 4) Instalar al lado de la versión actual.
DEST="$APP_DIR/versiones/$NUEVA"
rm -rf "$DEST"; mkdir -p "$DEST"
tar -xzf "$TMP/$ARCHIVO" -C "$DEST" --strip-components=1
(cd "$DEST/server" && PATH="$APP_DIR/node/bin:$PATH" npm ci --omit=dev --no-audit --no-fund --loglevel=error) || { log "No se pudieron instalar las dependencias; se queda la versión $ACTUAL."; rm -rf "$DEST"; exit 1; }
chmod +x "$DEST"/escritorio/*.sh
chown -R arche:arche "$DEST"

# 5) Cambiar y comprobar que arranca; si no, volver atrás.
ln -sfn "$DEST" "$APP_DIR/actual"
systemctl restart "$SERVICE"
for i in $(seq 1 60); do curl -fs "http://127.0.0.1:$PORT/api/health" >/dev/null && break; sleep 1; done
if ! curl -fs "http://127.0.0.1:$PORT/api/health" >/dev/null; then
  log "La versión $NUEVA no arrancó: vuelvo a $ACTUAL."
  ln -sfn "$ACTUAL_DIR" "$APP_DIR/actual"
  systemctl restart "$SERVICE"
  exit 1
fi
log "Actualizado a $NUEVA."

# 6) Limpiar versiones viejas (se quedan las últimas $GUARDAR).
ls -1dt "$APP_DIR"/versiones/*/ 2>/dev/null | tail -n +$((GUARDAR + 1)) | while read -r v; do
  [ "$(readlink -f "$v")" != "$(readlink -f "$APP_DIR/actual")" ] && rm -rf "$v"
done
