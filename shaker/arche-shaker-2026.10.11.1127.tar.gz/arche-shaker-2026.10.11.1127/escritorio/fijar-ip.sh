#!/usr/bin/env bash
# Deja fija la IP de esta PC en la red del local (Wi-Fi o cable), para que los
# teléfonos del local siempre la encuentren en la misma dirección.
#
# Lo más seguro es hacerlo en el ROUTER ("reservar IP" / "DHCP estático" para
# esta PC); este script es la alternativa si no tienes acceso al router: toma
# la IP que la PC tiene ahora y la deja fija con la misma puerta de enlace y DNS.
set -euo pipefail
command -v nmcli >/dev/null || { echo "Este script necesita NetworkManager (nmcli)."; exit 1; }
DEV="$(ip route show default | awk '/default/ {print $5; exit}')"
[ -n "$DEV" ] || { echo "No hay conexión de red activa."; exit 1; }
CON="$(nmcli -g GENERAL.CONNECTION device show "$DEV")"
CIDR="$(ip -4 -o addr show dev "$DEV" | awk '{print $4; exit}')"
GW="$(ip route show default | awk '/default/ {print $3; exit}')"
DNS="$(nmcli -g IP4.DNS device show "$DEV" | tr '\n' ' ' | sed 's/ *$//; s/ \+/,/g')"
[ -n "$DNS" ] || DNS="$GW"
MODO="$(nmcli -g ipv4.method connection show "$CON")"

echo "Conexión:   $CON ($DEV)"
echo "IP actual:  $CIDR   (modo: $MODO)"
echo "Router:     $GW"
echo "DNS:        $DNS"
if [ "$MODO" = "manual" ]; then echo "La IP ya está fija."; exit 0; fi
echo
echo "Se dejará FIJA la IP ${CIDR%/*}. Si otro equipo llegara a tomar esa misma IP"
echo "habría un choque; por eso lo ideal es reservarla también en el router."
read -r -p "¿Fijarla? (s/n): " r
[ "$r" = "s" ] || [ "$r" = "S" ] || { echo "Cancelado."; exit 0; }
sudo nmcli connection modify "$CON" ipv4.method manual ipv4.addresses "$CIDR" ipv4.gateway "$GW" ipv4.dns "$DNS"
sudo nmcli connection up "$CON" >/dev/null
echo "✔ IP fija: ${CIDR%/*}. Para el Wi-Fi del local: http://${CIDR%/*}:4340"
echo "  Para volver a automática: sudo nmcli connection modify \"$CON\" ipv4.method auto ipv4.addresses '' ipv4.gateway '' ipv4.dns '' && sudo nmcli connection up \"$CON\""
