-- Dominio propio de la tienda web (ej. pedidos.minegocio.com): si la petición llega a ese dominio, se muestra la tienda.
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_store_domain TEXT CHECK (web_store_domain IS NULL OR web_store_domain ~ '^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$');
