-- Módulos por negocio ({} = todo encendido salvo "pedidos directos").
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS modules JSONB NOT NULL DEFAULT '{}'::jsonb;
