-- Tienda / retail: código de barras y SKU, ITBIS por producto, descuentos, devoluciones (nota de crédito),
-- crédito a clientes (fiado) y proveedores con órdenes de compra.

-- Productos
ALTER TABLE products ADD COLUMN IF NOT EXISTS barcode TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS sku TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS itbis_rate NUMERIC(5,2) CHECK (itbis_rate IS NULL OR (itbis_rate >= 0 AND itbis_rate <= 100));
CREATE UNIQUE INDEX IF NOT EXISTS idx_products_barcode_active ON products(barcode) WHERE barcode IS NOT NULL AND active = true;

-- Ventas: descuento y devoluciones (una devolución es una venta con importes negativos que apunta a la original)
ALTER TABLE sales ADD COLUMN IF NOT EXISTS discount_amount NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (discount_amount >= 0);
ALTER TABLE sales ADD COLUMN IF NOT EXISTS discount_note TEXT;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS return_of INTEGER REFERENCES sales(id);
CREATE INDEX IF NOT EXISTS idx_sales_return_of ON sales(return_of) WHERE return_of IS NOT NULL;
ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS itbis_rate NUMERIC(5,2);
ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS discount_share NUMERIC(10,2) NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS return_of_item INTEGER REFERENCES sale_items(id);

-- Tope de descuento que puede dar un empleado (el dueño no tiene tope)
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS discount_max_pct NUMERIC(5,2) NOT NULL DEFAULT 10 CHECK (discount_max_pct >= 0 AND discount_max_pct <= 100);

-- Crédito a clientes (fiado): cada cargo es una venta a crédito; cada abono, un pago
ALTER TABLE customers ADD COLUMN IF NOT EXISTS credit_limit NUMERIC(10,2) CHECK (credit_limit IS NULL OR credit_limit >= 0);
CREATE TABLE IF NOT EXISTS customer_ledger (
  id           SERIAL PRIMARY KEY,
  customer_id  INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  kind         TEXT NOT NULL CHECK (kind IN ('cargo', 'abono')),
  amount       NUMERIC(10,2) NOT NULL CHECK (amount > 0),
  sale_id      INTEGER REFERENCES sales(id) ON DELETE SET NULL,
  method       TEXT,
  note         TEXT,
  employee_id  INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  location_id  INTEGER REFERENCES locations(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_customer_ledger_customer ON customer_ledger(customer_id);

-- Proveedores y órdenes de compra
CREATE TABLE IF NOT EXISTS vendors (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  phone       TEXT,
  email       TEXT,
  rnc         TEXT,
  notes       TEXT,
  active      BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE supplies ADD COLUMN IF NOT EXISTS vendor_id INTEGER REFERENCES vendors(id) ON DELETE SET NULL;
CREATE TABLE IF NOT EXISTS purchase_orders (
  id          SERIAL PRIMARY KEY,
  vendor_id   INTEGER REFERENCES vendors(id) ON DELETE SET NULL,
  location_id INTEGER REFERENCES locations(id),
  status      TEXT NOT NULL DEFAULT 'borrador' CHECK (status IN ('borrador', 'enviada', 'recibida', 'cancelada')),
  notes       TEXT,
  expected_on DATE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  sent_at     TIMESTAMPTZ,
  received_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS purchase_order_items (
  id          SERIAL PRIMARY KEY,
  po_id       INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  supply_id   INTEGER NOT NULL REFERENCES supplies(id),
  quantity    NUMERIC(12,3) NOT NULL CHECK (quantity > 0),
  unit_cost   NUMERIC(12,4) NOT NULL DEFAULT 0 CHECK (unit_cost >= 0)
);
CREATE INDEX IF NOT EXISTS idx_po_items_po ON purchase_order_items(po_id);

-- Roles de empleado: cajero (vende), cocina (solo la pantalla de cocina), gerente (vende sin tope de descuento y sin límite de día para anular/devolver)
ALTER TABLE employees ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'cajero' CHECK (role IN ('cajero', 'cocina', 'gerente'));

-- Última vez que el respaldo automático se copió con éxito fuera del servidor (ver services/offsiteBackup.js).
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS last_offsite_backup_at TIMESTAMPTZ;
