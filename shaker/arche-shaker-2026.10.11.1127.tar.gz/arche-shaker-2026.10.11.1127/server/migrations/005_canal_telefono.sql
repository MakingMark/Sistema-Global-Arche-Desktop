-- Canal de venta "teléfono" (pedidos por llamada) además de mostrador, mesa, llevar y web.
ALTER TABLE sales DROP CONSTRAINT IF EXISTS sales_channel_check;
ALTER TABLE sales ADD CONSTRAINT sales_channel_check CHECK (channel IN ('mostrador', 'mesa', 'llevar', 'web', 'telefono'));
