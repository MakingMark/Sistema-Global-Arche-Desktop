-- Productos que solo debe poder vender un gerente, no cualquier cajero — el
-- caso real: ventas al por mayor (ej. un galón de chicha) que en la práctica
-- solo hace quien administra, no cualquier empleado del punto de venta.
-- Sirve para cualquier negocio con productos de acceso restringido, no solo
-- uno (server/routes/pos.js filtra el menú según el rol del empleado).
ALTER TABLE products ADD COLUMN IF NOT EXISTS manager_only BOOLEAN NOT NULL DEFAULT false;
