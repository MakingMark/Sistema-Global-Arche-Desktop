-- Mayoreo: precio distinto a partir de cierta cantidad en una misma línea (ej. 6 o más — vasos, botellas…).
-- Sirve para cualquier negocio que revenda al por mayor (chicha por galón, relojes por caja, etc.), no solo uno.
ALTER TABLE products ADD COLUMN IF NOT EXISTS wholesale_price NUMERIC(10,2) CHECK (wholesale_price IS NULL OR wholesale_price >= 0);
ALTER TABLE products ADD COLUMN IF NOT EXISTS wholesale_min_qty INTEGER CHECK (wholesale_min_qty IS NULL OR wholesale_min_qty > 0);
ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS is_wholesale BOOLEAN NOT NULL DEFAULT false;
