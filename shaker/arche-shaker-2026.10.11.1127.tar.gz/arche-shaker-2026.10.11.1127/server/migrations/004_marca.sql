-- Colores de la marca (Configuración → Marca): NULL = paleta por defecto.
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS brand_accent    TEXT CHECK (brand_accent    IS NULL OR brand_accent    ~ '^#[0-9a-fA-F]{6}$');
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS brand_ink       TEXT CHECK (brand_ink       IS NULL OR brand_ink       ~ '^#[0-9a-fA-F]{6}$');
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS brand_paper     TEXT CHECK (brand_paper     IS NULL OR brand_paper     ~ '^#[0-9a-fA-F]{6}$');
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS brand_highlight TEXT CHECK (brand_highlight IS NULL OR brand_highlight ~ '^#[0-9a-fA-F]{6}$');
