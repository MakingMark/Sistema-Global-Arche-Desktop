-- Última vez que la página pidió sus datos (para mostrar en el administrativo si está conectada).
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_last_site_fetch  TIMESTAMPTZ;
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_last_site_origin TEXT;
