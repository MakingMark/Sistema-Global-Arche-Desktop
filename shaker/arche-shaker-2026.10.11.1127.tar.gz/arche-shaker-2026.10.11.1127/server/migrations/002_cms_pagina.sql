-- Mini CMS de la página web: textos y fotos editables, ficha del plato y
-- "agotado por hoy". (Mismo cambio que schema.sql para instalaciones nuevas.)
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_content JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_site_url TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS badge TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS calories INTEGER CHECK (calories IS NULL OR (calories >= 0 AND calories <= 5000));
ALTER TABLE products ADD COLUMN IF NOT EXISTS protein_g NUMERIC(6,1) CHECK (protein_g IS NULL OR (protein_g >= 0 AND protein_g <= 500));
ALTER TABLE products ADD COLUMN IF NOT EXISTS sold_out_on DATE;
CREATE TABLE IF NOT EXISTS media (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  mime        TEXT NOT NULL,
  data_url    TEXT NOT NULL,
  size_bytes  INTEGER NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
