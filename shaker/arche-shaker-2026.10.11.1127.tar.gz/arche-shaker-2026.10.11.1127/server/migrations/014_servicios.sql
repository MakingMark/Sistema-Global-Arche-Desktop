-- Tipo de negocio "servicios" (citas, reparaciones, salón...) en el asistente
-- de primer uso y en Configuración → Negocio, junto a restaurante/cafetería/tienda/otro.
ALTER TABLE app_settings DROP CONSTRAINT IF EXISTS app_settings_activity_check;
ALTER TABLE app_settings ADD CONSTRAINT app_settings_activity_check
  CHECK (activity IN ('restaurante', 'cafeteria', 'tienda', 'servicios', 'otro'));
