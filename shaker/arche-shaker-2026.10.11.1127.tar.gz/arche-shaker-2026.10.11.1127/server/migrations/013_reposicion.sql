-- Solicitudes de reposición: un carrito le pide al almacén que le mande insumos (en vez de esperar
-- a que el dueño se acuerde solo). El dueño la aprueba (arma la transferencia) o la rechaza con motivo.
CREATE TABLE restock_requests (
  id                       SERIAL PRIMARY KEY,
  location_id              INTEGER NOT NULL REFERENCES locations(id),      -- el carrito que pide
  requested_by_employee_id INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  status                   TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente', 'aprobada', 'rechazada', 'cancelada')),
  note                     TEXT,
  transfer_id              INTEGER REFERENCES transfers(id),               -- la transferencia que la aprobación armó
  reject_reason            TEXT,
  resolved_at              TIMESTAMPTZ,
  resolved_by_employee_id  INTEGER REFERENCES employees(id) ON DELETE SET NULL,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_restock_requests_location ON restock_requests(location_id);
CREATE INDEX idx_restock_requests_status ON restock_requests(status);

CREATE TABLE restock_request_items (
  id          SERIAL PRIMARY KEY,
  request_id  INTEGER NOT NULL REFERENCES restock_requests(id) ON DELETE CASCADE,
  supply_id   INTEGER NOT NULL REFERENCES supplies(id),
  quantity    NUMERIC(12,3) NOT NULL CHECK (quantity > 0)
);
CREATE INDEX idx_restock_request_items_request ON restock_request_items(request_id);
