-- Pedidos web más sólidos: vencimiento, cancelación, estado de pago, "en camino",
-- clave anti-duplicado, zonas de delivery, horario de la tienda y lista de bloqueo.
ALTER TABLE web_orders DROP CONSTRAINT IF EXISTS web_orders_status_check;
ALTER TABLE web_orders ADD CONSTRAINT web_orders_status_check CHECK (status IN ('nuevo', 'aceptado', 'rechazado', 'vencido', 'cancelado'));
ALTER TABLE web_orders ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'contra_entrega' CHECK (payment_status IN ('pendiente', 'contra_entrega', 'pagado'));
ALTER TABLE web_orders ADD COLUMN IF NOT EXISTS client_key TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS idx_web_orders_client_key ON web_orders(client_key) WHERE client_key IS NOT NULL;
ALTER TABLE web_orders ADD COLUMN IF NOT EXISTS zone TEXT;
ALTER TABLE web_orders ADD COLUMN IF NOT EXISTS customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL;
ALTER TABLE web_orders ADD COLUMN IF NOT EXISTS cancel_reason TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'contra_entrega' CHECK (payment_status IN ('pendiente', 'contra_entrega', 'pagado'));
ALTER TABLE orders ADD COLUMN IF NOT EXISTS dispatched_at TIMESTAMPTZ;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS last_address TEXT;
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_expire_minutes SMALLINT NOT NULL DEFAULT 15 CHECK (web_expire_minutes >= 0 AND web_expire_minutes <= 240);
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_hours JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_delivery_zones JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_blocked_phones TEXT;
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS web_require_payment_confirmation BOOLEAN NOT NULL DEFAULT false;
