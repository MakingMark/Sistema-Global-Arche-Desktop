-- Correo del dueño y códigos de recuperación de contraseña.
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS owner_email TEXT;
CREATE TABLE IF NOT EXISTS password_resets (
  id SERIAL PRIMARY KEY,
  code_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  used_at TIMESTAMPTZ,
  ip TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
