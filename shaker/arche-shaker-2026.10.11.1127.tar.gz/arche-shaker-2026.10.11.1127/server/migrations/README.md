# Migraciones

`schema.sql` crea una instalación NUEVA desde cero. Para cambiar una base que ya
tiene datos (producción), cada cambio va acá como un archivo SQL numerado:

    migrations/002_agregar_algo.sql
    migrations/003_otro_cambio.sql

Al arrancar, el servidor aplica en orden las que todavía no se aplicaron (queda
constancia en la tabla `schema_migrations`), cada una dentro de una transacción.
Una instalación nueva ya nace con todo lo que trae `schema.sql`, así que queda
marcada con la versión más alta sin ejecutar nada.

Reglas: nunca editar una migración ya aplicada; hacer respaldo antes de
actualizar; y reflejar el mismo cambio en `schema.sql` para las instalaciones
nuevas. Ver `services/migrationService.js`.
