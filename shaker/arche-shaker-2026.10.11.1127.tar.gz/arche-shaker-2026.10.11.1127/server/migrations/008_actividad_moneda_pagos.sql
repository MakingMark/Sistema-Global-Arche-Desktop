-- Tipo de negocio, símbolo de moneda y medios de pago configurables.
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS activity TEXT NOT NULL DEFAULT 'restaurante' CHECK (activity IN ('restaurante', 'cafeteria', 'tienda', 'otro'));
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS currency_symbol TEXT NOT NULL DEFAULT 'RD$' CHECK (char_length(currency_symbol) BETWEEN 1 AND 6);
ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS payment_methods JSONB NOT NULL DEFAULT '["Efectivo", "Transferencia", "Tarjeta"]'::jsonb;
