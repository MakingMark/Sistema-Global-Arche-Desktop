/* ═══ Configuración → Módulos (dueño) ═══ */
(function () {
  'use strict';
  const card = document.getElementById('modulos-card');
  if (!card) return;
  const esc = UI.escapeHtml;
  const $ = id => document.getElementById(id);
  let list = [], presets = [], draft = {}, saved = {};

  const label = id => (list.find(m => m.id === id) || {}).label || id;
  const same = () => Object.keys(draft).every(k => draft[k] === saved[k]);

  // Encender uno enciende lo que necesita; apagar uno apaga lo que lo necesita (se avisa).
  function toggle(id, on) {
    draft[id] = on;
    if (on) {
      const m = list.find(x => x.id === id);
      (m.requires || []).forEach(r => { if (!draft[r]) toggle(r, true); });
    } else {
      list.filter(x => (x.requires || []).includes(id) && draft[x.id]).forEach(x => toggle(x.id, false));
    }
  }

  function paint() {
    $('modulos-presets').innerHTML = presets.map(p => `<button type="button" class="btn btn-sm" data-preset="${esc(p.id)}" title="${esc(p.description)}">${esc(p.label)}</button>`).join('');
    // Fase 4: los 20 módulos agrupados en paquetes, con cuántos están encendidos.
    const PAQUETES = [
      ['Vender', 'Caja, ofertas, clientes y turnos.', ['caja', 'ofertas', 'clientes', 'fiado', 'turnos']],
      ['Salón y cocina', 'Para restaurantes con mesas.', ['mesas', 'cocina']],
      ['Inventario', 'Recetas, compras y existencias.', ['insumos', 'preparar', 'merma', 'vencimientos', 'proveedores', 'ubicaciones', 'transferencias']],
      ['En línea', 'Página web y avisos.', ['pagina', 'pedidos_directos', 'whatsapp']],
      ['Números', 'Ganancias, gastos y tendencias.', ['reportes', 'gastos', 'tendencias']]
    ];
    const enPaquete = new Set(PAQUETES.flatMap(p => p[2]));
    const sueltos = list.filter(m => !enPaquete.has(m.id)).map(m => m.id);
    const grupos = sueltos.length ? [...PAQUETES, ['Otros', '', sueltos]] : PAQUETES;
    const tpl = m => `
      <label class="mod-item${draft[m.id] ? ' is-on' : ''}${m.locked ? ' mod-off' : ''}">
        <span class="pw-switch"><input type="checkbox" data-mod="${esc(m.id)}" ${draft[m.id] ? 'checked' : ''} ${m.locked ? 'disabled' : ''}><span class="pw-track"></span></span>
        <span><strong>${esc(m.label)}</strong><small>${esc(m.description)}</small>
        ${m.locked ? '<span class="mod-req">No incluido en tu plan — pide cambiar de plan para usarlo.</span>' : ''}
        ${m.requires.length ? `<span class="mod-req">Necesita: ${m.requires.map(r => esc(label(r))).join(', ')}</span>` : ''}</span>
      </label>`;
    $('modulos-lista').innerHTML = grupos.map(([nombre, desc, ids]) => {
      const mods = ids.map(id => list.find(m => m.id === id)).filter(Boolean);
      if (!mods.length) return '';
      const on = mods.filter(m => draft[m.id]).length;
      return `<div class="mod-pack"><div class="mod-pack-head"><strong>${esc(nombre)}</strong><span class="muted">${esc(desc)}</span><span class="badge ${on ? 'badge-ok' : 'badge-muted'}">${on} de ${mods.length}</span></div>${mods.map(tpl).join('')}</div>`;
    }).join('');
    $('modulos-save').disabled = same();
    $('modulos-status').textContent = same() ? '' : 'Cambios sin guardar.';
  }

  async function load() {
    const r = await Api.settings.modules();
    list = r.modules; presets = r.presets;
    saved = Object.fromEntries(list.map(m => [m.id, m.enabled]));
    draft = { ...saved };
    paint();
  }

  $('modulos-lista').addEventListener('change', e => {
    const id = e.target.dataset.mod; if (!id) return;
    toggle(id, e.target.checked);
    paint();
  });
  $('modulos-presets').addEventListener('click', e => {
    const b = e.target.closest('[data-preset]'); if (!b) return;
    const p = presets.find(x => x.id === b.dataset.preset);
    list.forEach(m => { if (!m.locked) draft[m.id] = p.modules[m.id] === undefined ? true : !!p.modules[m.id]; });
    paint();
  });
  $('modulos-save').addEventListener('click', async () => {
    $('modulos-error').hidden = true;
    const btn = $('modulos-save'); btn.disabled = true;
    try {
      const r = await Api.settings.saveModules(Object.fromEntries(Object.entries(draft).filter(([id]) => !(list.find(m => m.id === id) || {}).locked)));
      list = r.modules;
      saved = Object.fromEntries(list.map(m => [m.id, m.enabled]));
      draft = { ...saved };
      Modules.set(saved);
      UI.toast('Módulos guardados');
      paint();
    } catch (err) { $('modulos-error').textContent = err.message; $('modulos-error').hidden = false; btn.disabled = false; }
  });
  window.addEventListener('view:show', e => { if (e.detail.view === 'configuracion') load().catch(err => UI.toast(err.message, 'error')); });
})();
