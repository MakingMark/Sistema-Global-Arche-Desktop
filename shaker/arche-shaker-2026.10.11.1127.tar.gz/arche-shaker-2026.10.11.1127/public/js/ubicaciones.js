/* ═══ Ubicaciones: los puntos de venta y el almacén como fichas (crear, editar, ver su estado) ═══
   Transferir y corregir stock viven en Inventario (transferir.js); envíos y
   movimientos, en Historial (historialInventario.js) — acá solo hay enlaces. */
(function () {
  'use strict';
  const formCarrito = document.getElementById('form-carrito');
  if (!formCarrito) return;

  const grid = document.getElementById('ubicaciones-grid');
  const detalleCard = document.getElementById('ubicacion-detalle');
  const detalleNombre = document.getElementById('ubicacion-detalle-nombre');
  const stockTbody = document.querySelector('#tabla-ubicacion-stock tbody');

  let locations = [];
  let selectedLocation = null;

  // El panel de detalle es compartido (uno solo, se rellena al elegir "Ver
  // detalle") y no tenía forma de cerrarlo — en celular ocupa bastante
  // pantalla y quedarse ahí sin
  // poder volver a la lista sin cambiar de vista era incómodo.
  document.getElementById('btn-cerrar-ubicacion-detalle').addEventListener('click', () => {
    detalleCard.hidden = true;
    selectedLocation = null;
  });

  async function loadLocations() {
    locations = await Api.locations.list();

    grid.innerHTML = '';
    // Los puntos de venta activos van primero; el almacén y los desactivados
    // al final (dentro de cada grupo, el orden alfabético del servidor).
    const rank = l => (l.kind === 'carrito' && l.active) ? 0 : (l.kind === 'central' ? 1 : 2);
    const sorted = [...locations].sort((a, b) => rank(a) - rank(b));
    sorted.forEach(loc => {
      const card = document.createElement('div');
      card.className = 'product-card' + (loc.kind === 'carrito' && !loc.active ? ' row-inactive' : '');
      card.innerHTML = `
        <div class="product-card-header">
          <strong>${UI.escapeHtml(loc.name)}</strong>${loc.kind === 'carrito' && !loc.active ? ' <span class="badge badge-muted">Inactivo</span>' : ''}
          <div class="muted product-card-subtitle">${loc.kind === 'central' ? 'Almacén' : 'Punto de venta'}${loc.address ? ' · ' + UI.escapeHtml(loc.address) : ''}</div>
        </div>
        <div class="product-card-actions"></div>
      `;
      const actions = card.querySelector('.product-card-actions');

      const btn = document.createElement('button');
      btn.className = 'btn btn-sm';
      btn.innerHTML = UI.iconLabel('eye', 'Ver detalle');
      btn.addEventListener('click', () => showDetail(loc));
      actions.appendChild(btn);

      const editBtn = document.createElement('button');
      editBtn.className = 'btn btn-sm';
      editBtn.innerHTML = UI.iconLabel('edit', 'Editar');
      editBtn.addEventListener('click', () => editLocation(loc));
      actions.appendChild(editBtn);

      grid.appendChild(card);
    });

    window.dispatchEvent(new CustomEvent('locations:loaded', { detail: locations }));
  }

  function editLocation(loc) {
    // El almacén central no tiene PIN propio desde v9.53 (quien entra ahí
    // es un EMPLEADO de almacén, con su propio PIN — ver Empleados), así
    // que ese campo no aplica y tampoco tiene sentido poder "desactivarlo"
    // (el negocio solo tiene un almacén; no hay ningún flujo pensado para
    // que deje de existir). Mismo formulario, menos los campos que no
    // corresponden — no vale la pena un modal aparte para una sola
    // ubicación especial.
    const isCentral = loc.kind === 'central';
    const body = `
      <label class="f" style="max-width:none"><span>Nombre</span><input id="edit-loc-name" value="${UI.escapeHtml(loc.name)}"></label>
      <label class="f" style="max-width:none;margin-top:8px"><span>Ubicación/zona</span><input id="edit-loc-address" value="${UI.escapeHtml(loc.address || '')}"></label>
      ${isCentral ? '' : `
      <p class="muted" style="margin:8px 0 0;font-size:.82em">El PIN para entrar a este punto de venta se maneja en <strong>Empleados</strong> (el PIN es de la persona, no del punto de venta) — ahí también se cambia o se rota si alguien se va.</p>
      <label class="f-check" style="margin-top:12px"><input type="checkbox" id="edit-loc-active" ${loc.active ? 'checked' : ''}><span>Activo (puede iniciar sesión y recibir transferencias)</span></label>
      <p class="muted" style="margin:4px 0 0;font-size:.82em">Desmarcalo para archivar un punto de venta que ya no usas — no borra su historial de ventas ni de inventario, y puedes reactivarlo cuando quieras. Mientras esté desactivado, ningún PIN asignado a él puede entrar.</p>
      `}
      <div class="modal-actions" style="margin-top:16px">
        <button class="btn" id="edit-loc-cancel">Cancelar</button>
        <button class="btn btn-primary" id="edit-loc-save">Guardar</button>
      </div>
    `;
    // UI.showModal (en vez del overlay armado a mano que había acá antes)
    // trae de fábrica lo que pidió el dueño: si ya se tocó algo del
    // formulario, cerrar por el fondo, Escape o la "×" pide confirmar en
    // vez de descartar los cambios en silencio — mismo comportamiento que
    // ya tienen Insumos/Productos/Ofertas/Clientes al editar, que este
    // modal de Ubicaciones era el único que todavía no tenía.
    const modal = UI.showModal(isCentral ? 'Editar almacén' : 'Editar punto de venta', body);
    modal.el.querySelector('#edit-loc-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#edit-loc-save').addEventListener('click', async () => {
      const name = modal.el.querySelector('#edit-loc-name').value.trim();
      const address = modal.el.querySelector('#edit-loc-address').value.trim();
      const active = isCentral ? null : modal.el.querySelector('#edit-loc-active').checked;
      if (!name) { UI.toast('El nombre es obligatorio', 'error'); return; }
      try {
        await Api.locations.update(loc.id, { name, address: address || null, active });
        modal.close();
        UI.toast(isCentral ? 'Almacén actualizado' : 'Punto de venta actualizado');
        loadLocations();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  async function showDetail(loc, { scroll = true } = {}) {
    selectedLocation = loc;
    detalleCard.hidden = false;
    detalleNombre.textContent = loc.name;

    if (scroll) detalleCard.scrollIntoView({ behavior: 'smooth', block: 'start' });

    const stock = await Api.locations.stock(loc.id);
    renderTables(loc);

    stockTbody.innerHTML = stock.supplies.map(s => `
      <tr>
        <td data-th="Insumo">${UI.escapeHtml(s.name)}</td>
        <td class="num ${s.low ? 'low-stock' : ''}" data-th="Stock">${Number(s.stock).toLocaleString('es-DO')} ${UI.escapeHtml(s.unit)}</td>
      </tr>
    `).join('') || '<tr><td colspan="2" class="muted">Sin insumos</td></tr>';
  }

  /* ── Mesas del punto de venta ── */
  const mesasCard = document.getElementById('ubicacion-mesas-card');
  const mesasList = document.getElementById('ubicacion-mesas-list');

  async function renderTables(loc) {
    mesasCard.hidden = loc.kind !== 'carrito';
    if (loc.kind !== 'carrito') return;
    let tables;
    try { tables = await Api.tables.list(loc.id); } catch (err) { UI.toast(err.message, 'error'); return; }
    mesasList.innerHTML = tables.length ? tables.map(t => `
      <div class="table-admin-row${t.active ? '' : ' row-inactive'}">
        <span><strong>${UI.escapeHtml(t.name)}</strong>${t.seats ? ` <span class="muted">· ${t.seats} lugares</span>` : ''}${t.active ? '' : ' <span class="badge badge-muted">Inactiva</span>'}${t.occupied ? ' <span class="badge badge-warn">Ocupada</span>' : ''}</span>
        <span class="table-admin-actions">
          <button class="btn btn-sm" data-edit="${t.id}">${UI.iconLabel('edit', 'Editar')}</button>
          <button class="btn btn-sm" data-del="${t.id}">${UI.iconLabel('trash', 'Quitar')}</button>
        </span>
      </div>`).join('') : '<p class="muted">Todavía no hay mesas. Puedes usar <strong>Para llevar</strong> y la <strong>Venta rápida</strong> sin ellas.</p>';
    mesasList.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => editTable(loc, tables.find(t => t.id === Number(b.dataset.edit)))));
    mesasList.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
      const t = tables.find(x => x.id === Number(b.dataset.del));
      if (!(await UI.confirmDialog(`¿Quitar "${t.name}"?`))) return;
      try {
        const r = await Api.tables.remove(t.id);
        UI.toast(r.deactivated ? 'La mesa ya tuvo cuentas: quedó desactivada' : 'Mesa eliminada');
        renderTables(loc);
      } catch (err) { UI.toast(err.message, 'error'); }
    }));
  }

  function editTable(loc, t) {
    const editing = !!t;
    const modal = UI.showModal(editing ? `Editar · ${UI.escapeHtml(t.name)}` : 'Mesa nueva', `
      <div class="field-grid">
        <label class="f"><span>Nombre</span><input id="mesa-name" value="${UI.escapeHtml(editing ? t.name : '')}" placeholder="ej. Mesa 5 / Barra"></label>
        <label class="f"><span>Lugares (opcional)</span><input id="mesa-seats" type="number" min="1" step="1" value="${editing && t.seats ? t.seats : ''}"></label>
      </div>
      ${editing ? `<label class="f-check" style="margin-top:12px"><input type="checkbox" id="mesa-active" ${t.active ? 'checked' : ''}><span>Activa (aparece en la pantalla de Mesas)</span></label>` : ''}
      <div class="modal-actions" style="margin-top:16px"><button class="btn" id="mesa-cancel">Cancelar</button><button class="btn btn-primary" id="mesa-save">Guardar</button></div>`);
    modal.el.querySelector('#mesa-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#mesa-save').addEventListener('click', async () => {
      const name = modal.el.querySelector('#mesa-name').value.trim();
      if (!name) { UI.toast('El nombre es obligatorio', 'error'); return; }
      const seats = modal.el.querySelector('#mesa-seats').value;
      try {
        if (editing) await Api.tables.update(t.id, { name, seats: seats === '' ? null : Number(seats), active: modal.el.querySelector('#mesa-active').checked });
        else await Api.tables.create({ location_id: loc.id, name, seats: seats === '' ? null : Number(seats) });
        modal.close();
        renderTables(loc);
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  }

  document.getElementById('btn-mesa-nueva').addEventListener('click', () => selectedLocation && editTable(selectedLocation, null));
  document.getElementById('btn-mesa-varias').addEventListener('click', () => {
    if (!selectedLocation) return;
    const loc = selectedLocation;
    const modal = UI.showModal('Crear varias mesas', `
      <div class="field-grid">
        <label class="f"><span>¿Cuántas?</span><input id="mesas-count" type="number" min="1" max="100" step="1" value="6"></label>
        <label class="f"><span>Nombre base</span><input id="mesas-prefix" value="Mesa"></label>
      </div>
      <p class="muted">Se numeran solas: Mesa 1, Mesa 2… siguiendo las que ya existan.</p>
      <div class="modal-actions" style="margin-top:16px"><button class="btn" id="mesas-cancel">Cancelar</button><button class="btn btn-primary" id="mesas-ok">Crear</button></div>`);
    modal.el.querySelector('#mesas-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#mesas-ok').addEventListener('click', async () => {
      try {
        await Api.tables.create({ location_id: loc.id, count: Number(modal.el.querySelector('#mesas-count').value), prefix: modal.el.querySelector('#mesas-prefix').value.trim() || 'Mesa' });
        modal.close();
        renderTables(loc);
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  });

  formCarrito.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(formCarrito);
    // Sin try/catch acá, un rechazo real (PIN repetido, dirección vacía —
    // ambos validados server-side, ver locations.js) quedaba como una
    // excepción sin atrapar: el formulario no hacía nada visible. 
    try {
      await Api.locations.create({
        name: fd.get('name'),
        address: fd.get('address') || null,
        pin: fd.get('pin')
      });
      formCarrito.reset();
      loadLocations();
      UI.toast('Punto de venta creado');
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  // Enlaces de la ficha hacia donde ahora viven esas cosas.
  document.getElementById('btn-ubicacion-ver-envios').addEventListener('click', () => {
    if (selectedLocation) window.showHistorial('envios', { location_id: selectedLocation.id });
  });
  document.getElementById('btn-ubicacion-ver-movimientos').addEventListener('click', () => {
    if (selectedLocation) window.showHistorial('movimientos', { location_id: selectedLocation.id });
  });
  document.getElementById('btn-ubicacion-transferir').addEventListener('click', () => {
    if (!selectedLocation) return;
    // Una ficha de punto de venta casi siempre quiere RECIBIR del almacén; la
    // del almacén, ENVIAR a algún punto de venta — el destino/origen restante se elige
    // en la pantalla de Transferir.
    if (selectedLocation.kind === 'central') window.prefillTransfer({ fromId: selectedLocation.id });
    else window.prefillTransfer({ toId: selectedLocation.id });
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'ubicaciones') loadLocations();
  });
})();
