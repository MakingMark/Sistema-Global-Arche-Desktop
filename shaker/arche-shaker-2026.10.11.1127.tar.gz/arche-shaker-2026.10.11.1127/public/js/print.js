/* ═══ Factura en ventana aparte: "ver" solo la muestra, "imprimir" además dispara el diálogo ═══ */

// La ventana se abre EN EL MISMO EVENTO del clic, antes de esperar cualquier
// respuesta del servidor — la mayoría de los navegadores (sobre todo Safari
// en iPhone) bloquea un window.open() que ocurre después de un `await`,
// porque ya no lo consideran una respuesta directa al toque del usuario.
// Por eso el flujo es: abrir ya mismo con un "Cargando…", pedir el recibo
// después, y llenar la ventana cuando llegue (ver fillReceiptWindow).
// Papel de la impresora (se recuerda en este dispositivo): hoja normal o ticket térmico de 80 / 58 mm.
const RECEIPT_PAPER_CSS = {
  hoja: '@page{margin:8mm} body{max-width:320px;margin:16px auto;font-size:13px}',
  '80': '@page{size:80mm auto;margin:0} body{width:72mm;max-width:72mm;margin:0 auto;padding:3mm 0;font-size:12px;line-height:1.35}',
  '58': '@page{size:58mm auto;margin:0} body{width:48mm;max-width:48mm;margin:0 auto;padding:3mm 0;font-size:11px;line-height:1.3}'
};
function receiptPaper() { try { const p = localStorage.getItem('print_paper'); return RECEIPT_PAPER_CSS[p] ? p : 'hoja'; } catch (_) { return 'hoja'; } }

function openReceiptWindow(autoPrint) {
  const win = window.open('', '_blank', 'width=380,height=640');
  if (!win) {
    UI.toast('El navegador bloqueó la ventana — permite pop-ups para este sitio', 'error');
    return null;
  }
  win.document.write(`
    <!doctype html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <title>Factura</title>
      <style id="paper-css">${RECEIPT_PAPER_CSS[receiptPaper()]}</style>
      <style>
        body{font-family:'Courier New',monospace;line-height:1.5;color:#1a1008;background:#fff}
        .paper-pick{display:block;margin:14px auto 0;font:inherit;font-size:12px;padding:5px 8px}
        .receipt-body{white-space:pre-wrap}
        .r-header{font-size:15px;font-weight:700;text-align:center;color:#000;
                   margin-bottom:6px;letter-spacing:.02em}
        .r-gap{height:9px}
        .r-total{font-weight:700;font-size:15.5px;color:#000;
                  border-top:1px dashed #b3a48f;margin-top:2px;padding-top:7px}
        .r-voided{color:#b3261e;font-weight:700;text-align:center;
                   border:1px dashed #b3261e;border-radius:4px;padding:5px;margin-top:6px}
        .r-motivo{color:#b3261e}
        button{font:inherit;padding:8px 16px;margin:18px auto 0;display:block;
                cursor:pointer;background:#222;color:#fff;border:none;border-radius:8px;
                font-weight:700}
        button:hover{background:#000}
        @media print{button,.paper-pick{display:none}}
      </style>
    </head>
    <body>
      <div id="receipt-text" class="receipt-body">Cargando…</div>
      <select class="paper-pick" id="paper-pick" aria-label="Tipo de papel">
        <option value="hoja">Hoja normal</option>
        <option value="80">Ticket 80 mm</option>
        <option value="58">Ticket 58 mm</option>
      </select>
      <button onclick="window.print()">Imprimir</button>
    </body>
    </html>
  `);
  win.document.close();
  const pick = win.document.getElementById('paper-pick');
  if (pick) {
    pick.value = receiptPaper();
    pick.addEventListener('change', () => {
      win.document.getElementById('paper-css').textContent = RECEIPT_PAPER_CSS[pick.value];
      try { localStorage.setItem('print_paper', pick.value); } catch (_) {}
    });
  }
  win.focus();
  win.__autoPrint = !!autoPrint;
  return win;
}

// El texto del recibo trae *asteriscos* al estilo WhatsApp para el
// encabezado y "*** ANULADA ***" — acá se convierten en HTML de verdad
// (negrita, línea de total destacada, aviso de anulación en rojo) en vez
// de imprimirse como texto plano con asteriscos literales.
function receiptTextToHtml(text) {
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return text.split('\n').map(raw => {
    const line = esc(raw);
    if (!line.trim()) return '<div class="r-gap"></div>';
    // El chequeo de "*** ANULADA ***" va antes del de negrita genérica: esa
    // línea también matchea /^\*(.+)\*$/ (todo el string entre el primer y
    // último asterisco), así que si se revisara después nunca se alcanzaría.
    if (/^\*\*\* .+ \*\*\*$/.test(line.trim())) {
      return `<div class="r-voided">${line.trim().replace(/\*/g, '')}</div>`;
    }
    const header = line.match(/^\*(.+)\*$/);
    if (header) return `<div class="r-header">${header[1]}</div>`;
    if (line.startsWith('Total:')) return `<div class="r-total">${line}</div>`;
    if (line.startsWith('Motivo:')) return `<div class="r-motivo">${line}</div>`;
    return `<div>${line}</div>`;
  }).join('');
}

function fillReceiptWindow(win, receiptText) {
  if (!win || win.closed) return;
  const pre = win.document.getElementById('receipt-text');
  if (pre) pre.innerHTML = receiptTextToHtml(receiptText);
  if (win.__autoPrint) setTimeout(() => win.print(), 250);
}
