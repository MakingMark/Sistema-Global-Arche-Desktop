/* ═══ UI: toasts y diálogo de confirmación (reemplazan alert/confirm nativos) ═══ */
const UI = (function () {
  'use strict';

  // Para insertar en el DOM cualquier texto que NO haya escrito el propio
  // dueño (nombre de cliente de una venta, notas de una solicitud, motivo de
  // anulación) — quien lo escribió pudo ser un carrito con solo un PIN de 4
  // dígitos, así que no es un texto de confianza. Sin esto, algo como
  // `<img src=x onerror=...>` como "nombre de cliente" se ejecuta con los
  // permisos del dueño la próxima vez que abre Historial o Reportes.
  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  let toastHost = null;
  function ensureToastHost() {
    if (toastHost) return toastHost;
    toastHost = document.createElement('div');
    toastHost.className = 'toast-host';
    // Los toasts son la única confirmación de que una acción funcionó (o no)
    // — "Venta registrada", "Insumo actualizado", errores de validación —
    // pero al ser puramente visuales, alguien con lector de pantalla no se
    // enteraba de ninguno. aria-live="polite" en el host cubre los normales;
    // cada toast de error además lleva role="alert" (más urgente — se
    // anuncia igual aunque el lector esté leyendo otra cosa).
    toastHost.setAttribute('aria-live', 'polite');
    toastHost.setAttribute('aria-atomic', 'true');
    document.body.appendChild(toastHost);
    return toastHost;
  }

  // Foco para los 3 modales de abajo: ninguno movía el foco al abrir (el
  // teclado quedaba en lo que estuviera detrás del overlay) ni lo devolvía
  // al cerrar, y Tab podía "escaparse" hacia botones tapados visualmente por
  // el fondo oscuro. `trapFocus` cicla Tab/Shift+Tab dentro del modal;
  // `rememberFocus` guarda qué tenía el foco antes de abrir para devolvérselo.
  function trapFocus(container) {
    const selector = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
    function onKeydown(e) {
      if (e.key !== 'Tab') return;
      const focusable = Array.from(container.querySelectorAll(selector)).filter(el => !el.disabled);
      if (!focusable.length) return;
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
    container.addEventListener('keydown', onKeydown);
    return () => container.removeEventListener('keydown', onKeydown);
  }
  function rememberFocus() {
    const previous = document.activeElement;
    return () => { if (previous && typeof previous.focus === 'function') previous.focus(); };
  }

  // "Cerrar al tocar el fondo" comparaba solo el target del CLICK contra el
  // overlay — pero seleccionar texto arrastrando el mouse (ej. en el campo
  // "Unidad base" de Editar, o escribiendo un motivo de anulación) y soltar
  // apenas fuera del cuadro también dispara un click con ese mismo target
  // (el navegador lo sube al ancestro común de mousedown/mouseup), cerrando
  // el modal de golpe en pleno tipeo — "falso contacto" real, no percepción.
  // Exigir que el mousedown TAMBIÉN haya empezado en el fondo (no solo el
  // click) distingue un clic genuino de afuera de una selección que se pasó.
  function onBackdropClick(overlay, handler) {
    let downOnOverlay = false;
    overlay.addEventListener('mousedown', e => { downOnOverlay = e.target === overlay; });
    overlay.addEventListener('click', e => { if (e.target === overlay && downOnOverlay) handler(e); });
  }

  // Mismo problema (y misma solución) que el menú deslizable del dueño en
  // celular, encontrado en vivo esa misma noche: un overlay fixed no le
  // impide a iOS Safari scrollear la página de ATRÁS al arrastrar el dedo
  // sobre el fondo oscuro. Con contador en vez de un simple on/off — estos
  // 3 diálogos pueden anidarse (ej. confirmDialog al "Eliminar" arriba de un
  // showModal de "Editar" ya abierto), y el de adentro no debe destrabar el
  // scroll mientras el de afuera lo sigue necesitando.
  let scrollLockCount = 0;
  let savedScrollY = 0;
  function openOverlay(overlay) {
    document.body.appendChild(overlay);
    if (scrollLockCount === 0) {
      savedScrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${savedScrollY}px`;
      document.body.style.left = '0';
      document.body.style.right = '0';
    }
    scrollLockCount++;
  }
  function releaseScrollLock() {
    scrollLockCount = Math.max(0, scrollLockCount - 1);
    if (scrollLockCount === 0) {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.left = '';
      document.body.style.right = '';
      window.scrollTo(0, savedScrollY);
    }
  }

  // Los 3 modales de abajo entraban con fade+pop (modalFadeIn/modalPopIn)
  // pero se sacaban del DOM de un tirón con overlay.remove() — cerrar se
  // sentía brusco al lado de cómo abrían. Agrega .closing (dispara
  // modalFadeOut/modalPopOut en app.css) y espera a que termine antes de
  // limpiar de verdad. Respeta prefers-reduced-motion: esos usuarios ya no
  // reciben ninguna animación (app.css se las anula con !important), así
  // que tampoco tiene sentido hacerlos esperar la duración de una animación
  // que no van a ver.
  const REDUCED_MOTION = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function closeOverlay(overlay, cleanup) {
    releaseScrollLock();
    if (REDUCED_MOTION) { overlay.remove(); cleanup(); return; }
    overlay.classList.add('closing');
    setTimeout(() => { overlay.remove(); cleanup(); }, 150);
  }

  function toast(message, kind) {
    const host = ensureToastHost();
    const el = document.createElement('div');
    el.className = 'toast' + (kind === 'error' ? ' toast-error' : kind === 'success' ? ' toast-success' : '');
    el.setAttribute('role', kind === 'error' ? 'alert' : 'status');
    el.textContent = message;
    host.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 250);
    }, 3200);
  }

  function confirmDialog(message) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `
        <div class="modal-box">
          <p>${message}</p>
          <div class="modal-actions">
            <button class="btn" data-a="cancel">Cancelar</button>
            <button class="btn btn-primary" data-a="ok">Confirmar</button>
          </div>
        </div>
      `;
      openOverlay(overlay);
      const restoreFocus = rememberFocus();
      const untrap = trapFocus(overlay);
      // El foco por defecto va a "Cancelar", no a "Confirmar" — muchos usos de
      // este diálogo son para acciones destructivas (Eliminar), así que un
      // Enter accidental no debería completarlas.
      overlay.querySelector('[data-a="cancel"]').focus();
      const close = result => {
        document.removeEventListener('keydown', onKey); untrap();
        closeOverlay(overlay, () => { restoreFocus(); resolve(result); });
      };
      const onKey = e => { if (e.key === 'Escape') close(false); };
      document.addEventListener('keydown', onKey);
      overlay.querySelector('[data-a="ok"]').addEventListener('click', () => close(true));
      overlay.querySelector('[data-a="cancel"]').addEventListener('click', () => close(false));
      onBackdropClick(overlay, () => close(false));
    });
  }

  // Como confirmDialog, pero pide un texto (ej. motivo de anulación) —
  // devuelve el texto escrito (puede ser '' si required:false y se deja
  // vacío), o null si se canceló. required:true (default) exige texto no
  // vacío, para los casos donde de verdad hace falta (anular una venta).
  function promptDialog(message, placeholder, { required = true } = {}) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `
        <div class="modal-box">
          <p>${message}</p>
          <textarea class="prompt-input" rows="3" placeholder="${placeholder || ''}"></textarea>
          <p class="prompt-error" hidden>Este campo es obligatorio.</p>
          <div class="modal-actions">
            <button class="btn" data-a="cancel">Cancelar</button>
            <button class="btn btn-primary" data-a="ok">Confirmar</button>
          </div>
        </div>
      `;
      openOverlay(overlay);
      const textarea = overlay.querySelector('textarea');
      const errorEl = overlay.querySelector('.prompt-error');
      const restoreFocus = rememberFocus();
      const untrap = trapFocus(overlay);
      textarea.focus();
      const close = result => {
        document.removeEventListener('keydown', onKey); untrap();
        closeOverlay(overlay, () => { restoreFocus(); resolve(result); });
      };
      const onKey = e => { if (e.key === 'Escape') close(null); };
      document.addEventListener('keydown', onKey);
      overlay.querySelector('[data-a="ok"]').addEventListener('click', () => {
        const value = textarea.value.trim();
        if (required && !value) { errorEl.hidden = false; textarea.focus(); return; }
        close(value);
      });
      overlay.querySelector('[data-a="cancel"]').addEventListener('click', () => close(null));
      onBackdropClick(overlay, () => close(null));
    });
  }

  // Modal genérico de contenido libre (tablas, gráficas simples) — para
  // desgloses que no son ni una confirmación ni un formulario de una línea.
  function showModal(title, html, opts) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box modal-box-wide">
        <div class="modal-box-header">
          <h2>${title}</h2>
          <button class="modal-box-close" aria-label="Cerrar">&times;</button>
        </div>
        <div class="modal-box-body">${html}</div>
      </div>
    `;
    openOverlay(overlay);
    const restoreFocus = rememberFocus();
    const untrap = trapFocus(overlay);
    overlay.querySelector('.modal-box-close').focus();

    // Este modal es el que usan los formularios de "Editar" — si ya se
    // escribió algo (Insumos, Productos) y se cierra sin querer (fondo,
    // Escape, la X), se pierde el cambio sin aviso. Pedido explícito del
    // dueño: no dejar salir sin confirmar mientras haya algo tocado. Un
    // modal de solo lectura (ej. "Ver desglose") nunca dispara input/change,
    // así que esto no le agrega ninguna confirmación de más.
    let dirty = false;
    const body = overlay.querySelector('.modal-box-body');
    body.addEventListener('input', () => { dirty = true; });
    body.addEventListener('change', () => { dirty = true; });

    const close = () => {
      document.removeEventListener('keydown', onKey); untrap();
      closeOverlay(overlay, restoreFocus);
    };
    const requestClose = async () => {
      if (dirty && !(await confirmDialog('Hay cambios sin guardar. ¿Cerrar de todas formas?'))) return;
      close();
      if (opts && opts.onClose) opts.onClose();
    };
    const onKey = e => { if (e.key === 'Escape') requestClose(); };
    document.addEventListener('keydown', onKey);
    overlay.querySelector('.modal-box-close').addEventListener('click', requestClose);
    onBackdropClick(overlay, requestClose);
    return { close, el: overlay };
  }

  // Íconos chicos para botones de acción (Editar/Eliminar/Ver desglose) — mismo
  // estilo que los del menú (SVG a mano, stroke="currentColor", sin librería).
  const ICONS = {
    edit: '<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 2.5l3 3L4.5 12.5H1.5v-3l7-7z"/></svg>',
    trash: '<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4h9M5.5 4V2.5h3V4M5.5 6.5v4M8.5 6.5v4M3.2 4l.6 8a1 1 0 0 0 1 .9h4.4a1 1 0 0 0 1-.9l.6-8"/></svg>',
    chart: '<svg viewBox="0 0 14 14" fill="currentColor" stroke="none"><rect x="1.5" y="7" width="2.6" height="5.5"/><rect x="5.7" y="3" width="2.6" height="9.5"/><rect x="9.9" y="5.5" width="2.6" height="7"/></svg>',
    eye: '<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M1 7s2.2-4 6-4 6 4 6 4-2.2 4-6 4-6-4-6-4z"/><circle cx="7" cy="7" r="1.6"/></svg>',
    print: '<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 5V1.5h7V5M3.5 11h-2V6a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v5h-2M3.5 8.5h7v4h-7v-4z"/></svg>',
    ban: '<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="7" cy="7" r="5.3"/><path d="M3.3 3.3l7.4 7.4"/></svg>',
    chevronDown: '<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5.5l4 4 4-4"/></svg>'
  };
  function icon(name) { return ICONS[name] || ''; }
  // Arma el HTML de un botón con ícono + texto — para no repetir el mismo
  // `<span class="btn-icon">...</span><span>texto</span>` en cada archivo.
  function iconLabel(name, text) { return `<span class="btn-icon">${icon(name)}</span><span>${text}</span>`; }

  // Placeholders "esqueleto" para mientras carga una lista (Historial,
  // Reportes) — antes esas pantallas se quedaban en blanco o con un
  // "Cargando…" suelto durante el viaje al servidor; esto muestra la FORMA
  // del contenido que va a llegar (filas de tabla o tarjetas), con un brillo
  // que se desliza, así la pantalla no se siente "rota" ni vacía en esa
  // fracción de segundo. Nunca lleva datos reales — es puro relleno visual,
  // por eso aria-hidden. `.skeleton` respeta prefers-reduced-motion en CSS.
  function skeletonRows(n, cols) {
    const cells = Array.from({ length: cols }, () => '<td><div class="skeleton skeleton-text"></div></td>').join('');
    return Array.from({ length: n }, () => `<tr class="skeleton-row" aria-hidden="true">${cells}</tr>`).join('');
  }
  function skeletonCards(n) {
    return Array.from({ length: n }, () => `
      <div class="product-card skeleton-card" aria-hidden="true">
        <div class="product-card-header">
          <div class="skeleton skeleton-text" style="width:60%;height:1em"></div>
          <div class="skeleton skeleton-text" style="width:40%"></div>
        </div>
        <div class="product-card-stats">
          <div class="skeleton skeleton-text"></div>
          <div class="skeleton skeleton-text"></div>
          <div class="skeleton skeleton-text"></div>
        </div>
      </div>`).join('');
  }

  return { toast, confirmDialog, promptDialog, showModal, icon, iconLabel, escapeHtml, skeletonRows, skeletonCards };
})();
