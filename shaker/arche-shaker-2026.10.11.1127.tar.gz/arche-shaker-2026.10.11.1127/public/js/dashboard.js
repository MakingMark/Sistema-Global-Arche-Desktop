/* ═══ Panel del dueño: estadísticas de hoy/mes, por ubicación y bajo stock ═══ */
(function () {
  'use strict';
  const todayEl = document.getElementById('panel-stats-today');
  if (!todayEl) return;
  const monthEl = document.getElementById('panel-stats-month');
  const ubicacionTbody = document.querySelector('#panel-tabla-ubicacion tbody');
  const lowStockEl = document.getElementById('panel-low-stock');
  const alertStripEl = document.getElementById('panel-alert-strip');
  // El aviso lleva directo a Insumos › Existencias, ya filtrado a lo bajo.
  alertStripEl.setAttribute('role', 'button');
  alertStripEl.tabIndex = 0;
  alertStripEl.addEventListener('click', () => window.showExistencias(true));
  alertStripEl.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); window.showExistencias(true); }
  });
  const sugerenciasEl = document.getElementById('panel-sugerencias');
  const sugerenciasListEl = document.getElementById('panel-sugerencias-list');
  const chartEl = document.getElementById('panel-chart');
  const selectedDayLabelEl = document.getElementById('panel-selected-day-label');
  const btnVolverHoy = document.getElementById('btn-panel-volver-hoy');
  let chartDays = [];
  let selectedIndex = -1;

  // v3.1 (ANALISIS-INTERFAZ-V3.1.md): íconos de trazo fino, iguales al menú lateral.
  const ICONS = {
    receipt: '<path d="M4 2.5h10v13l-2-1.2-1.5 1.2L9 14.3l-1.5 1.2L6 14.3l-2 1.2z"/><path d="M6.5 6h5M6.5 9h5"/>',
    cash: '<rect x="2" y="4.5" width="14" height="9" rx="1.6"/><circle cx="9" cy="9" r="2.2"/>',
    ticket: '<path d="M2.5 6.5V4.5h13v2a2.5 2.5 0 0 0 0 5v2h-13v-2a2.5 2.5 0 0 0 0-5z"/><path d="M11 4.5v9" stroke-dasharray="1.6 1.6"/>',
    trend: '<path d="M2 14l4.5-5 3.5 3 6-7"/><path d="M12.5 5H16v3.5"/>',
    coins: '<ellipse cx="9" cy="5" rx="5.5" ry="2.2"/><path d="M3.5 5v4c0 1.2 2.5 2.2 5.5 2.2s5.5-1 5.5-2.2V5"/><path d="M3.5 9v4c0 1.2 2.5 2.2 5.5 2.2s5.5-1 5.5-2.2V9"/>',
    leaf: '<path d="M3 15c0-7 4-11 12-12-1 8-5 12-12 12z"/><path d="M3 15l6-6"/>',
    check: '<circle cx="9" cy="9" r="7"/><path d="M5.8 9.2l2.2 2.2 4.2-4.6"/>',
    chart: '<path d="M2.5 15.5h13"/><rect x="4" y="9" width="2.6" height="5"/><rect x="8" y="5" width="2.6" height="9"/><rect x="12" y="7" width="2.6" height="7"/>'
  };
  const icon = name => `<svg viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.chart}</svg>`;
  const emptyState = (name, title, text) => `<div class="ux-empty"><span class="ux-empty-icon">${icon(name)}</span><div><strong>${title}</strong>${text ? `<span>${text}</span>` : ''}</div></div>`;

  // Cifra con conteo animado (uiMotion.js): data-count lleva el número real.
  const countSpan = (n, kind) => `<span data-count="${Number(n) || 0}" data-format="${kind || 'money'}">${kind === 'int' ? Number(n) || 0 : fmt(n)}</span>`;

  function statCard(label, value, kind, iconName) {
    return `<div class="stat stat-quiet ux-stat"><span class="ux-stat-icon">${icon(iconName)}</span><div class="label">${label}</div><div class="value">${countSpan(value, kind)}</div></div>`;
  }

  // El único número que de verdad importa al entrar (ganancia) va grande y
  // primero; facturas y ventas quedan como contexto más chico. Con ITBIS o
  // propina prendidos, se muestran aparte lo cobrado de cada uno (no es del
  // negocio: el ITBIS va al fisco y la propina al personal).
  // v3.1: el hero compara con el día anterior y lleva una minigráfica de la
  // ganancia de los 14 días (el día elegido marcado). Las cifras arrancan
  // desde las que ya se veían, así tocar otro día "cuenta" la diferencia.
  let lastShown = { profit: 0, count: 0, total: 0, avg: 0 };
  function deltaHtml(index, profit) {
    const prev = chartDays[index - 1];
    if (!prev || !(prev.profit > 0)) return '';
    const pct = Math.round(((profit - prev.profit) / prev.profit) * 100);
    const isToday = chartDays[index] && dayKey(chartDays[index].date) === dayKey(new Date());
    const cls = pct > 0 ? 'is-up' : pct < 0 ? 'is-down' : '';
    const arrow = pct > 0 ? '▲' : pct < 0 ? '▼' : '＝';
    return `<span class="panel-hero-delta ${cls}">${arrow} ${Math.abs(pct)}% vs. ${isToday ? 'ayer' : 'el día anterior'}</span>`;
  }
  function sparkline(index) {
    if (chartDays.length < 2 || !chartDays.some(d => d.profit)) return '';
    const W = 220, H = 64, pad = 5;
    const vals = chartDays.map(d => Math.max(0, d.profit));
    const max = Math.max(...vals) || 1;
    const pts = vals.map((v, i) => [pad + (i * (W - pad * 2)) / (vals.length - 1), H - pad - (v / max) * (H - pad * 2)]);
    const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    const area = `${line} L${pts[pts.length - 1][0].toFixed(1)} ${H} L${pts[0][0].toFixed(1)} ${H} Z`;
    const sel = pts[index] || pts[pts.length - 1];
    return `<svg class="panel-hero-spark" viewBox="0 0 ${W} ${H}" aria-hidden="true">
      <defs><linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".35"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>
      <path class="spark-area" d="${area}" fill="url(#sparkFill)"/>
      <path class="spark-line" d="${line}" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" pathLength="1"/>
      <circle class="spark-dot" cx="${sel[0].toFixed(1)}" cy="${sel[1].toFixed(1)}" r="4"/>
    </svg>`;
  }
  function renderHero(label, profit, sub, count, total, index) {
    const avg = count ? total / count : 0;
    const shown = lastShown;
    todayEl.innerHTML = `
      <div class="panel-hero">
        <div class="panel-hero-main">
          <div class="panel-hero-top"><span class="label">${label}</span>${index !== undefined ? deltaHtml(index, profit) : ''}</div>
          <div class="value"><span data-count="${profit}" data-shown="${shown.profit}">${fmt(shown.profit)}</span></div>
          ${sub ? `<div class="sub">${sub}</div>` : '<div class="sub">Lo que queda después de pagar lo que costó cada venta.</div>'}
        </div>
        ${index !== undefined ? sparkline(index) : ''}
      </div>
      <div class="panel-mini-row">
        <div class="panel-mini"><span class="ux-stat-icon">${icon('receipt')}</span><div class="label">Facturas</div><div class="value"><span data-count="${count}" data-format="int" data-shown="${shown.count}">${shown.count}</span></div></div>
        <div class="panel-mini"><span class="ux-stat-icon">${icon('cash')}</span><div class="label">Ventas (neto)</div><div class="value"><span data-count="${total}" data-shown="${shown.total}">${fmt(shown.total)}</span></div></div>
        <div class="panel-mini"><span class="ux-stat-icon">${icon('ticket')}</span><div class="label">Ticket promedio</div><div class="value"><span data-count="${avg}" data-shown="${shown.avg}">${fmt(shown.avg)}</span></div></div>
      </div>
      <div class="card-quiet" id="panel-day-breakdown" style="margin-top:12px">
        <p class="muted" style="margin:0">Cargando por punto de venta…</p>
      </div>`;
    lastShown = { profit: Number(profit) || 0, count: Number(count) || 0, total: Number(total) || 0, avg };
    Motion.countUps(todayEl);
  }

  // Componentes LOCALES de la fecha, nunca .toISOString().slice(0,10) — esa
  // variante da la fecha en UTC, que se adelanta un día entero entre las
  // 8pm y la medianoche en Santo Domingo (UTC-4). Acá siempre se llama con
  // fechas ya ancladas a medianoche, así que hoy no cambia nada visible —
  // pero es la misma función que se rompió en otra pantalla (ver
  // reportes.js/pos.js), mejor que las tres coincidan.
  function isoDate(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  let currentStartOfMonth = null;

  // date_trunc('day', ...) en Postgres viaja como timestamp; comparar por
  // fecha de calendario LOCAL (no UTC) es lo mismo que ya hace reportes.js
  // al mostrar cada fila — evita que una venta de la noche caiga en el día
  // equivocado de la barra por el corrimiento de zona horaria.
  function dayKey(d) { return d.toDateString(); }

  // Tocar una barra pone las cifras de arriba (Facturas/Total/Ganancia) en
  // modo "ese día" en vez de "hoy" — pedido del dueño para que el Panel sea
  // más interactivo. Los datos ya están en memoria (vienen del mismo
  // `last14.byDay` que dibuja la gráfica), así que no hace falta pedirle
  // nada más al servidor para mostrarlos.
  // scrollToResult: pedido del dueño probando desde su iPhone — en móvil, la
  // gráfica de "últimos 14 días" queda bien abajo (después de "Hoy" y "Este
  // mes"), así que tocar una barra actualizaba las cifras de arriba pero el
  // dueño tenía que desplazarse manualmente hasta allá para verlas ("es
  // bastante engorroso"). Solo se activa en pantallas angostas (mismo corte
  // que el resto del responsive, 820px) y solo cuando lo dispara un toque
  // real (ver los listeners más abajo) — la selección automática al cargar
  // la pantalla no debe saltar de lugar sola.
  async function selectDay(index, { scrollToResult = false } = {}) {
    const day = chartDays[index];
    if (!day) return;
    selectedIndex = index;
    const isToday = dayKey(day.date) === dayKey(new Date());
    selectedDayLabelEl.textContent = isToday
      ? 'Hoy'
      : day.date.toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long' });
    btnVolverHoy.hidden = isToday;
    const label = isToday ? 'Ganancia de hoy' : `Ganancia — ${selectedDayLabelEl.textContent}`;
    renderHero(label, day.profit, '', day.sales_count, day.total, index);
    // Se espera este `await` ANTES de desplazar (ver abajo) — el desglose
    // por punto de venta tarda un poco en llegar (pide de nuevo al servidor), y si
    // el scroll pasa antes, después el "Cargando por punto de venta…" se reemplaza
    // por las tarjetas reales y el salto de alto empuja todo de nuevo — se
    // espera a que el contenido ya esté en su versión final.
    const breakdownPromise = renderDayBreakdown(day.date);
    chartEl.querySelectorAll('.panel-chart-bar').forEach((g, i) => {
      g.classList.toggle('is-selected', i === index);
    });
    if (scrollToResult && window.innerWidth <= 820) {
      await breakdownPromise;
      // `behavior:'smooth'` (probado primero) resultó poco confiable en la
      // práctica — a veces el desplazamiento no llegaba a completarse. Sin
      // animación, el salto es instantáneo pero siempre llega.
      selectedDayLabelEl.scrollIntoView({ behavior: 'instant', block: 'start' });
    }
  }

  // Qué punto de venta vendió qué ESE día puntual: chartDays solo trae el
  // total del día, sumado entre todos — se pide de nuevo al mismo endpoint que
  // usa Reportes (`GET /api/reports/summary?from=X&to=X`). reqId evita que, si
  // se toca una barra y enseguida otra antes de que responda la primera, la
  // respuesta vieja pise a la nueva.
  let dayBreakdownReqId = 0;
  async function renderDayBreakdown(date) {
    const reqId = ++dayBreakdownReqId;
    const dateStr = isoDate(date);
    const el = () => document.getElementById('panel-day-breakdown');
    let byLocation;
    try {
      ({ byLocation } = await Api.reports.summary({ from: dateStr, to: dateStr }));
    } catch (err) {
      if (reqId !== dayBreakdownReqId) return;
      if (el()) el().innerHTML = `<p class="muted" style="margin:0">${err.message}</p>`;
      return;
    }
    if (reqId !== dayBreakdownReqId) return;
    const target = el();
    if (!target) return;
    if (!byLocation.length) {
      target.innerHTML = emptyState('receipt', 'Sin ventas ese día', 'Cuando se facture algo, aparece aquí por punto de venta.');
      return;
    }
    const mejor = byLocation.length > 1 ? byLocation.reduce((best, l) => (!best || Number(l.total) > Number(best.total)) ? l : best, null) : null;
    target.innerHTML = `
      <p class="muted" style="margin:0 0 8px;font-size:.82em">Por punto de venta ese día</p>
      <table class="table"><thead><tr><th>Ubicación</th><th class="num">Facturas</th><th class="num">Ventas</th></tr></thead><tbody>
        ${byLocation.map(l => `
          <tr class="${l === mejor ? 'best-row' : ''}">
            <td data-th="Ubicación">${UI.escapeHtml(l.location_name)}${l === mejor ? ' <span class="best-tag">vende más</span>' : ''}</td>
            <td class="num" data-th="Facturas">${l.sales_count}</td>
            <td class="num" data-th="Ventas">${fmt(l.total)}</td>
          </tr>
        `).join('')}
      </tbody></table>`;
  }

  function renderChart(byDay) {
    const now = new Date();
    const byDayMap = new Map(byDay.map(r => [dayKey(new Date(r.day)), r]));
    const days = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      const row = byDayMap.get(dayKey(d));
      days.push({
        date: d,
        total: row ? Number(row.total) : 0,
        profit: row ? Number(row.profit) : 0,
        sales_count: row ? Number(row.sales_count) : 0
      });
    }
    chartDays = days;

    const grandTotal = days.reduce((s, d) => s + d.total, 0);
    if (!grandTotal) {
      chartEl.innerHTML = emptyState('chart', 'Sin ventas en los últimos 14 días', 'La gráfica se llena sola con cada factura.');
      renderHero('Ganancia de hoy', 0, '', 0, 0);
      // Sin ninguna venta en la ventana no tiene sentido pedir el desglose
      // por punto de venta de "hoy" — quedaría pidiendo algo que ya se sabe vacío.
      // Se reemplaza el "Cargando…" que puso renderHero por el mismo aviso.
      const breakdownEl = document.getElementById('panel-day-breakdown');
      if (breakdownEl) breakdownEl.innerHTML = emptyState('receipt', 'Sin ventas hoy todavía', 'La primera factura del día aparece aquí al momento.');
      return;
    }
    drawChart(true);
    selectDay(days.length - 1);
  }

  // v3.1: la gráfica se dibuja al ancho REAL del contenedor (antes era un
  // viewBox fijo de 700 px estirado: en una pantalla ancha las barras
  // medían ~280 px de alto y los textos se agrandaban). Barras que crecen
  // una tras otra, línea punteada del promedio y el día elegido resaltado.
  let chartW = 0;
  function drawChart(animate) {
    const days = chartDays;
    const grandTotal = days.reduce((s, d) => s + d.total, 0);
    if (!grandTotal) return;
    const now = new Date();
    const max = Math.max(...days.map(d => d.total));
    chartW = Math.max(300, Math.round(chartEl.clientWidth || 700));
    const w = chartW, h = 210, gap = w < 500 ? 4 : 8, barAreaH = h - 30;
    const barW = (w - gap * (days.length - 1)) / days.length;
    const todayKey = dayKey(now);

    const avgY = barAreaH - Math.round(((grandTotal / 14) / max) * barAreaH);
    const bars = days.map((d, i) => {
      const barH = d.total ? Math.max(4, Math.round((d.total / max) * (barAreaH - 16))) : 2;
      const x = i * (barW + gap);
      const y = barAreaH - barH;
      const isToday = dayKey(d.date) === todayKey;
      const label = d.date.toLocaleDateString('es-DO', { weekday: 'short' }).replace('.', '');
      const showValue = d.total && barH > 22;
      return `
        <g class="panel-chart-bar${isToday ? ' is-today' : ''}${i === selectedIndex ? ' is-selected' : ''}" style="--i:${i}" data-index="${i}" tabindex="0" role="button"
           aria-label="Ver cifras del ${d.date.toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long' })}">
          <title>${d.date.toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'short' })}: ${fmt(d.total)}</title>
          <rect x="${x}" y="${y}" width="${barW}" height="${barH}" rx="${Math.min(6, barW / 3)}"/>
          ${showValue ? `<text x="${x + barW / 2}" y="${y - 5}" class="panel-chart-value">${fmt(d.total).replace(AppLocale.currency(), '')}</text>` : ''}
          <text x="${x + barW / 2}" y="${h - 6}" class="panel-chart-day">${label}</text>
        </g>`;
    }).join('');

    chartEl.innerHTML = `
      <div class="panel-chart-summary"><span><span class="muted">Total</span> <strong>${fmt(grandTotal)}</strong></span><span><i class="panel-chart-avg-key" aria-hidden="true"></i><span class="muted">Promedio diario</span> <strong>${fmt(grandTotal / 14)}</strong></span></div>
      <svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" class="panel-chart-svg${animate ? ' is-animating' : ''}" role="group" aria-label="Ventas por día, últimos 14 días, total ${fmt(grandTotal)}">
        <line class="panel-chart-avg" x1="0" x2="${w}" y1="${avgY}" y2="${avgY}"/>
        ${bars}
      </svg>
    `;
  }
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (!chartDays.length || chartEl.offsetParent === null) return;
      if (Math.abs((chartEl.clientWidth || 0) - chartW) > 24) drawChart(false);
    }, 150);
  });

  // Delegado en el contenedor (el SVG se reemplaza entero en cada render,
  // así que un listener por barra se perdería) — click y teclado (Enter/
  // Espacio) activan lo mismo, igual que la fila clickeable de abajo.
  chartEl.addEventListener('click', e => {
    const bar = e.target.closest('.panel-chart-bar');
    if (bar) selectDay(Number(bar.dataset.index), { scrollToResult: true });
  });
  chartEl.addEventListener('keydown', e => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const bar = e.target.closest('.panel-chart-bar');
    if (!bar) return;
    e.preventDefault();
    selectDay(Number(bar.dataset.index), { scrollToResult: true });
  });
  btnVolverHoy.addEventListener('click', () => selectDay(chartDays.length - 1));

  // Al tocar una ubicación en "Este mes por ubicación", el dueño pidió ver
  // cuántas unidades de cada producto se vendieron ahí (no solo el total en
  // dinero) — mismo endpoint que ya usa Reportes, filtrado a esa ubicación.
  async function showLocationBreakdown(locationId, locationName) {
    const rows = await Api.reports.byProduct({ from: currentStartOfMonth, location_id: locationId });
    const totalRevenue = rows.reduce((s, r) => s + Number(r.revenue), 0);
    const totalProfit = rows.reduce((s, r) => s + Number(r.profit), 0);
    const body = `
      <p class="muted" style="margin-bottom:14px">Este mes · unidades vendidas por producto</p>
      <table class="table"><thead><tr>
        <th>Producto</th><th class="num">Unidades</th><th class="num">Ingreso</th><th class="num">Ganancia</th>
      </tr></thead><tbody>
        ${rows.map(r => `
          <tr>
            <td data-th="Producto">${UI.escapeHtml(r.product_name)}</td>
            <td class="num" data-th="Unidades">${fmtNum(r.quantity)}</td>
            <td class="num" data-th="Ingreso">${fmt(r.revenue)}</td>
            <td class="num ${Number(r.profit) < 0 ? 'low-stock' : ''}" data-th="Ganancia">${fmt(r.profit)}</td>
          </tr>
        `).join('') || '<tr><td colspan="4" class="muted">Sin ventas este mes.</td></tr>'}
      </tbody></table>
      <div class="breakdown-totals">
        <div class="stat"><div class="label">Ingreso total</div><div class="value">${fmt(totalRevenue)}</div></div>
        <div class="stat"><div class="label">Ganancia total</div><div class="value">${fmt(totalProfit)}</div></div>
      </div>
    `;
    UI.showModal(UI.escapeHtml(locationName), body);
  }

  // Pedido explícito del dueño: "sugerencias de mejora en base a las
  // ventas" — a propósito prescriptivo ("considera..."), no otro número
  // descriptivo (eso ya lo tienen Analítica/Reportes). El servidor ya
  // filtra con umbrales para no mandar nada cuando todo está sano (ver
  // GET /api/reports/suggestions) — acá solo se arma el texto. Cada una
  // señala algo puntual con una acción real ("revisa X") — se quitó la
  // tendencia general de ganancia mes-a-mes que había acá antes porque el
  // dueño notó que no cumplía esa función (ver reports.js).
  function suggestionText(s) {
    if (s.type === 'low_margin_product') {
      return `💰 "${UI.escapeHtml(s.product_name)}" tiene un margen bajo (${s.margin_pct}%) — considera revisar su precio o su receta.`;
    }
    if (s.type === 'products_without_recipe') {
      return `📋 ${s.count} ${s.count === 1 ? 'producto no tiene' : 'productos no tienen'} receta (${s.examples.map(UI.escapeHtml).join(', ')}${s.count > s.examples.length ? '…' : ''}) — sin receta no se descuenta inventario ni se calcula la ganancia real. Se carga en Menú.`;
    }
    if (s.type === 'underperforming_cart') {
      return `📍 "${UI.escapeHtml(s.location_name)}" vendió bastante menos que el resto este mes (${fmt(s.total)} vs. un promedio de ${fmt(s.avg_total)}) — podría ayudar una oferta ahí, o revisar la ubicación.`;
    }
    return '';
  }

  async function renderSuggestions() {
    const suggestions = await Api.reports.suggestions().catch(() => []);
    sugerenciasEl.hidden = !suggestions.length;
    if (!suggestions.length) return;
    sugerenciasListEl.innerHTML = suggestions.map(s => `<p style="margin:8px 0">${suggestionText(s)}</p>`).join('');
  }

  // "Así va Shaker hoy." — el nombre llega después (appSettings.js), así que
  // se repinta también cuando cambia.
  const brandEl = document.getElementById('brand-name-owner');
  function paintSubtitle() {
    const sub = document.getElementById('panel-subtitle');
    const name = brandEl && brandEl.textContent.trim();
    if (sub) sub.textContent = `Así va ${name && name !== 'Mi negocio' ? name : 'tu negocio'} hoy.`;
  }
  if (brandEl) new MutationObserver(paintSubtitle).observe(brandEl, { childList: true, characterData: true, subtree: true });

  /* ── Lista de arranque (fase 4) ──
     Para un negocio recién instalado: qué le falta para quedar listo, con un
     botón a la pantalla donde se hace. Se va sola cuando todo está hecho, o con
     «Ocultar» (se recuerda en este equipo). */
  const arranqueEl = document.getElementById('panel-arranque');
  const ARRANQUE_KEY = 'arche_arranque_oculto';
  async function renderArranque() {
    let oculto = false; try { oculto = localStorage.getItem(ARRANQUE_KEY) === '1'; } catch (_) {}
    if (oculto || !arranqueEl) { if (arranqueEl) arranqueEl.hidden = true; return; }
    let p;
    try { p = await Api.reports.setupProgress(); } catch (_) { arranqueEl.hidden = true; return; }
    const inv = Modules.enabled('insumos');
    const pct = (a, b) => (b ? a / b : 0);
    const T = (k, f) => (window.Vocab ? Vocab.t(k, f) : f);
    const steps = [
      { done: p.productos >= 3, title: `Carga tu ${T('menu', 'menú').toLowerCase()}`, text: `${p.productos} producto${p.productos === 1 ? '' : 's'} cargado${p.productos === 1 ? '' : 's'}.`, go: 'menu' },
      inv && { done: p.insumos > 0 && pct(p.insumos_con_costo, p.insumos) >= 0.8, title: 'Pon el costo de tus insumos', text: `${p.insumos_con_costo} de ${p.insumos} con costo. Sin costo, la ganancia sale inflada.`, go: 'insumos' },
      inv && { done: p.productos > 0 && pct(p.con_receta, p.productos) >= 0.8, title: 'Agrega las recetas', text: `${p.con_receta} de ${p.productos} productos con receta: así se descuenta el inventario solo.`, go: 'menu' },
      { done: p.empleados > 0, title: 'Crea a tu equipo', text: p.empleados ? `${p.empleados} empleado${p.empleados === 1 ? '' : 's'} con PIN.` : 'Cada cajero entra con su propio PIN de 4 dígitos.', go: 'empleados' },
      { done: !!p.marca, title: 'Ponle tu logo y tus colores', text: 'Configuración → Marca. Se ve en el sistema y en la página.', go: 'configuracion' },
      { done: p.ventas > 0, title: 'Haz tu primera venta', text: 'Entra con el PIN de un cajero (en el celular o la tablet) y cobra algo.', go: null }
    ].filter(Boolean);
    const hechos = steps.filter(x => x.done).length;
    if (hechos === steps.length) { arranqueEl.hidden = true; return; }
    arranqueEl.hidden = false;
    arranqueEl.innerHTML = `
      <div class="arranque-head">
        <div><p class="arranque-kicker">Primeros pasos</p><h2>Deja tu negocio listo</h2></div>
        <div class="arranque-meta"><strong>${hechos} de ${steps.length}</strong><button type="button" class="btn btn-sm" data-arranque-ocultar>Ocultar</button></div>
      </div>
      <div class="arranque-bar" aria-hidden="true"><i style="width:${Math.round((hechos / steps.length) * 100)}%"></i></div>
      <ol class="arranque-steps">${steps.map(x => `
        <li class="${x.done ? 'is-done' : ''}">
          <span class="arranque-check" aria-hidden="true">${x.done ? '✓' : ''}</span>
          <div><strong>${x.title}</strong><span>${x.text}</span></div>
          ${!x.done && x.go ? `<button type="button" class="btn btn-sm" data-goto-step="${x.go}">Ir</button>` : ''}
        </li>`).join('')}</ol>`;
  }
  if (arranqueEl) arranqueEl.addEventListener('click', e => {
    const go = e.target.closest('[data-goto-step]');
    if (go) { window.showView(go.dataset.gotoStep); return; }
    if (e.target.closest('[data-arranque-ocultar]')) {
      try { localStorage.setItem(ARRANQUE_KEY, '1'); } catch (_) {}
      arranqueEl.hidden = true;
      UI.toast('Listo. La lista vuelve si borras los datos del navegador.');
    }
  });

  async function render() {
    renderArranque();
    const now = new Date();
    paintSubtitle();
    const startOfMonth = isoDate(new Date(now.getFullYear(), now.getMonth(), 1));
    currentStartOfMonth = startOfMonth;
    const fourteenDaysAgo = isoDate(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 13));

    // "Hoy" ya no pide su propio resumen — es un día más dentro de los 14
    // que trae `last14.byDay`, y renderChart() lo deja seleccionado por
    // defecto (ver selectDay). Un fetch menos, mismo dato.
    const [month, last14, lowStock, expiring, wasteMonth, profitMonth] = await Promise.all([
      Api.reports.summary({ from: startOfMonth }),
      Api.reports.summary({ from: fourteenDaysAgo }),
      Api.reports.lowStock('all'),
      Api.reports.expiry().catch(() => []),
      Api.reports.waste({ from: startOfMonth }).catch(() => null),
      Api.reports.profit({ from: startOfMonth }).catch(() => null)
    ]);
    renderSuggestions();

    renderChart(last14.byDay);

    monthEl.innerHTML =
      statCard('Facturas este mes', month.totals.sales_count, 'int', 'receipt') +
      statCard('Ventas este mes (neto)', month.totals.total, 'money', 'cash') +
      statCard('Ganancia este mes', month.totals.profit, 'money', 'trend') +
      (Number(month.totals.itbis_total) > 0 ? statCard('ITBIS cobrado', month.totals.itbis_total, 'money', 'coins') : '') +
      (Number(month.totals.tip_total) > 0 ? statCard('Propina cobrada', month.totals.tip_total, 'money', 'coins') : '') +
      (wasteMonth && wasteMonth.totals.events > 0 ? statCard('Merma del mes', wasteMonth.totals.cost, 'money', 'leaf') : '') +
      (profitMonth && profitMonth.expenses_total > 0 ? statCard('Gastos del mes', profitMonth.expenses_total, 'money', 'cash') + statCard('Ganancia neta del mes', profitMonth.net_profit, 'money', 'trend') : '');
    Motion.countUps(monthEl);

    ubicacionTbody.innerHTML = month.byLocation.map(l => `
      <tr class="row-clickable" tabindex="0" role="button" data-location-id="${l.location_id}" data-location-name="${UI.escapeHtml(l.location_name)}" title="Ver qué se vendió en ${UI.escapeHtml(l.location_name)}" aria-label="Ver qué se vendió en ${UI.escapeHtml(l.location_name)}">
        <td data-th="Ubicación">${UI.escapeHtml(l.location_name)}</td><td class="num" data-th="Facturas">${l.sales_count}</td><td class="num" data-th="Ganancia">${fmt(l.profit)}</td>
      </tr>
    `).join('') || '<tr><td colspan="3" class="muted">Sin ventas este mes.</td></tr>';
    // <tr> no es un control nativo — sin tabindex/role/keydown, un fila
    // "clickable" solo funciona con mouse/dedo. Enter y Espacio son los que
    // activan un role="button" por convención (Espacio también scrollea la
    // página si no se lo frena con preventDefault).
    ubicacionTbody.querySelectorAll('tr[data-location-id]').forEach(tr => {
      tr.addEventListener('click', () => showLocationBreakdown(tr.dataset.locationId, tr.dataset.locationName));
      tr.addEventListener('keydown', e => {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        e.preventDefault();
        showLocationBreakdown(tr.dataset.locationId, tr.dataset.locationName);
      });
    });

    const items = lowStock.supplies.map(sp => `<div class="low-stock-item"><span>${UI.escapeHtml(sp.location_name)} — ${UI.escapeHtml(sp.supply_name)}</span><span class="low-stock">${fmtNum(sp.stock)}</span></div>`);
    const expItems = expiring.map(l => `<div class="low-stock-item"><span>${UI.escapeHtml(l.location_name)} — ${UI.escapeHtml(l.supply_name)} <span class="muted">(${fmtNum(l.quantity_remaining)} ${UI.escapeHtml(l.supply_unit)})</span></span><span class="low-stock">${l.expired ? 'VENCIDO' : l.days_left === 0 ? 'vence hoy' : `vence en ${l.days_left} d`}</span>${l.expired ? `<button type="button" class="btn btn-sm" data-baja="${l.lot_id}">Dar de baja</button>` : ''}</div>`);
    lowStockEl.innerHTML = (items.join('') || emptyState('check', 'Todo en orden', 'Ningún insumo está por debajo de su nivel de aviso.'))
      + (expItems.length ? `<h3 style="margin:14px 0 6px;font-size:.95rem">Por vencer</h3>${expItems.join('')}` : '');

    lowStockEl.querySelectorAll('[data-baja]').forEach(btn => btn.addEventListener('click', async () => {
      const l = expiring.find(x => x.lot_id === Number(btn.dataset.baja));
      if (!(await UI.confirmDialog(`¿Dar de baja ${fmtNum(l.quantity_remaining)} ${l.supply_unit} de ${l.supply_name} (${l.location_name}) como merma por vencimiento?`))) return;
      try {
        await Api.supplies.waste(l.supply_id, { location_id: l.location_id, quantity: Number(l.quantity_remaining), reason: 'vencimiento', lot_id: l.lot_id });
        UI.toast('Dado de baja');
        render();
      } catch (err) { UI.toast(err.message, 'error'); }
    }));

    if (expiring.some(l => l.expired)) {
      const n = expiring.filter(l => l.expired).length;
      alertStripEl.innerHTML = `⏰ ${n} ${n === 1 ? 'lote vencido' : 'lotes vencidos'} — dalos de baja para que el stock sea real`;
      alertStripEl.classList.add('is-urgent');
      alertStripEl.hidden = false;
    } else if (lowStock.supplies.length) {
      const first = lowStock.supplies[0];
      const more = lowStock.supplies.length - 1;
      alertStripEl.innerHTML = `${UI.escapeHtml(first.location_name)}: ${UI.escapeHtml(first.supply_name)} bajo (${fmtNum(first.stock)})${more > 0 ? ` y ${more} más` : ''} — ver existencias`;
      alertStripEl.classList.add('is-urgent');
      alertStripEl.hidden = false;
    } else {
      alertStripEl.hidden = true;
    }
  }

  document.querySelectorAll('[data-goto]').forEach(btn => {
    btn.addEventListener('click', () => window.showView(btn.dataset.goto));
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'panel') render();
  });
})();
