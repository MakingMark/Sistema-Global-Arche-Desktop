/* ═══ Configuración → Colores de la marca (dueño) ═══
   Cambios en vivo sobre toda la app; solo se guardan con "Guardar colores".
   La paleta y los tonos derivados los calcula brand.js. */
(function () {
  'use strict';
  const card = document.getElementById('brand-card');
  if (!card) return;
  const $ = id => document.getElementById(id);
  const KEYS = ['accent', 'ink', 'paper', 'highlight'];
  let saved = null;   // lo que hay guardado (normalizado)
  let draft = null;   // lo que se está probando

  function swatch(p) { return `<span class="brand-swatches"><i style="background:${p.ink}"></i><i style="background:${p.accent}"></i><i style="background:${p.highlight}"></i><i style="background:${p.paper}"></i></span>`; }
  const same = (a, b) => KEYS.every(k => a[k] === b[k]);

  function paint() {
    KEYS.forEach(k => { $(`brand-${k}`).value = draft[k].toLowerCase(); $(`brand-${k}-hex`).value = draft[k]; });
    $('brand-presets').innerHTML = Brand.PRESETS.map(p => {
      const n = Brand.normalize(p);
      return `<button type="button" class="brand-preset${same(n, draft) ? ' is-current' : ''}" data-preset="${p.id}" aria-pressed="${same(n, draft)}">${swatch(n)}<strong>${p.name}</strong></button>`;
    }).join('');
    const notes = Brand.checks(draft);
    $('brand-notes').innerHTML = notes.map(n => `<div class="brand-note is-${n.level}">${n.level === 'error' ? '⛔' : '⚠️'} ${n.text}</div>`).join('');
    const blocked = notes.some(n => n.level === 'error');
    $('brand-save').disabled = blocked || same(draft, saved);
    $('brand-cancel').disabled = same(draft, saved);
    $('brand-status').textContent = same(draft, saved) ? '' : 'Cambios sin guardar (ya los ves en pantalla).';
  }

  function set(next) {
    draft = Brand.normalize(next);
    Brand.apply(draft);     // en vivo, sin guardar
    paint();
  }

  async function load() {
    const s = await Api.settings.get();
    saved = Brand.normalize({ accent: s.brand_accent, ink: s.brand_ink, paper: s.brand_paper, highlight: s.brand_highlight });
    draft = { ...saved };
    Brand.apply(saved, { persist: true });
    paint();
  }

  $('brand-presets').addEventListener('click', e => {
    const b = e.target.closest('[data-preset]'); if (!b) return;
    set(Brand.PRESETS.find(p => p.id === b.dataset.preset));
  });
  KEYS.forEach(k => {
    $(`brand-${k}`).addEventListener('input', e => set({ ...draft, [k]: e.target.value }));
    $(`brand-${k}-hex`).addEventListener('input', e => {
      let v = e.target.value.trim(); if (v && v[0] !== '#') v = '#' + v;
      if (/^#[0-9a-fA-F]{6}$/.test(v)) set({ ...draft, [k]: v });
    });
  });
  $('brand-cancel').addEventListener('click', () => { draft = { ...saved }; Brand.apply(saved); paint(); });
  $('brand-save').addEventListener('click', async () => {
    $('brand-error').hidden = true;
    const btn = $('brand-save'); btn.disabled = true;
    try {
      const r = await Api.settings.updateBrand(draft);
      saved = Brand.normalize({ accent: r.brand_accent, ink: r.brand_ink, paper: r.brand_paper, highlight: r.brand_highlight });
      draft = { ...saved };
      Brand.apply(saved, { persist: true });
      UI.toast('Colores guardados');
      paint();
    } catch (err) { $('brand-error').textContent = err.message; $('brand-error').hidden = false; btn.disabled = false; }
  });

  window.addEventListener('view:show', e => { if (e.detail.view === 'configuracion') load().catch(err => UI.toast(err.message, 'error')); });
})();
