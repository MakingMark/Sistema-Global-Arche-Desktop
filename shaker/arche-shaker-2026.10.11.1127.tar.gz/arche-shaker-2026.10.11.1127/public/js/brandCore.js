/* ═══ Marca: matemática de color (sin DOM) ═══
   De 4 colores (acento, tinta, papel, destacado) se derivan todos los tonos de la
   interfaz. Sirve en el navegador (brand.js) y en el servidor (la tienda web). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BrandCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ── Presets: una por tipo de negocio, para arrancar rápido ── */
  const PRESETS = [
    { id: 'oceano',  name: 'Océano',          accent: '#5B9CFF', ink: '#0F1B2D', paper: '#F5F8FC', highlight: '#E0501B' },
    { id: 'lima',    name: 'Lima y negro',    accent: '#C6FF3F', ink: '#1E1A14', paper: '#FBF6EC', highlight: '#F04E23' },
    { id: 'chicha',  name: 'Café y amarillo', accent: '#FFC727', ink: '#3E1C08', paper: '#FBF8F4', highlight: '#EF5026' },
    { id: 'bosque',  name: 'Bosque',          accent: '#7BD88F', ink: '#10231A', paper: '#F6FAF5', highlight: '#E4572E' },
    { id: 'tinto',   name: 'Tinto y durazno', accent: '#FF9F68', ink: '#2B0F14', paper: '#FBF5F2', highlight: '#D7263D' },
    { id: 'violeta', name: 'Violeta',         accent: '#C3A6FF', ink: '#1B1030', paper: '#F7F4FC', highlight: '#E83E7A' }
  ];
  const DEFAULT = PRESETS[0];

  /* ── Color ── */
  const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
  const parse = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  const hex = rgb => '#' + rgb.map(v => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0')).join('').toUpperCase();
  const mix = (a, b, t) => { const x = parse(a), y = parse(b); return hex(x.map((v, i) => v + (y[i] - v) * t)); };
  const lin = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  const lum = h => { const [r, g, b] = parse(h); return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b); };
  const contrast = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
  function toHsl(h) {
    const [r, g, b] = parse(h).map(v => v / 255); const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let H = 0, S = 0; const L = (mx + mn) / 2;
    if (mx !== mn) { const d = mx - mn; S = L > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); H = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; H /= 6; }
    return [H, S, L];
  }
  function fromHsl([H, S, L]) {
    const f = (p, q, t) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
    if (S === 0) return hex([L * 255, L * 255, L * 255]);
    const q = L < 0.5 ? L * (1 + S) : L + S - L * S, p = 2 * L - q;
    return hex([f(p, q, H + 1 / 3) * 255, f(p, q, H) * 255, f(p, q, H - 1 / 3) * 255]);
  }
  const shade = (h, dl) => { const [H, S, L] = toHsl(h); return fromHsl([H, S, clamp(L + dl)]); };
  // El texto sobre el acento: la tinta si contrasta bien; si no, blanco.
  const onColor = (bg, ink) => contrast(ink, bg) >= 4.5 ? ink : (contrast('#FFFFFF', bg) >= contrast('#000000', bg) ? '#FFFFFF' : '#000000');

  function normalize(p) {
    const ok = v => typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v);
    return { accent: ok(p && p.accent) ? p.accent.toUpperCase() : DEFAULT.accent, ink: ok(p && p.ink) ? p.ink.toUpperCase() : DEFAULT.ink,
             paper: ok(p && p.paper) ? p.paper.toUpperCase() : DEFAULT.paper, highlight: ok(p && p.highlight) ? p.highlight.toUpperCase() : DEFAULT.highlight };
  }

  /* ── De 4 colores a todos los tonos ── */
  function tokens(p) {
    const { accent: A, ink: K, paper: P, highlight: H } = normalize(p);
    const light = {
      '--brown-deep': K, '--brown': mix(K, P, 0.13), '--brown-soft': mix(K, P, 0.4),
      '--cream': mix(P, K, 0.04), '--cream-2': mix(P, K, 0.08), '--paper': P,
      '--yellow': A, '--yellow-deep': shade(A, -0.12), '--lime-ink': onColor(A, K), '--orange': H,
      '--line': mix(P, K, 0.13), '--line-strong': mix(P, K, 0.24),
      '--bg': P, '--surface': '#FFFFFF', '--surface-2': mix(P, K, 0.08), '--ink': K, '--ink-soft': mix(K, P, 0.4)
    };
    const bgDark = mix(K, '#000000', 0.35);
    // En oscuro el acento se aclara si no se distingue del fondo.
    let accentDark = A; for (let i = 0; i < 6 && contrast(accentDark, K) < 4; i++) accentDark = shade(accentDark, 0.06);
    const dark = {
      '--bg': bgDark, '--surface': K, '--surface-2': mix(K, P, 0.09), '--ink': mix(P, K, 0.04), '--ink-soft': mix(P, K, 0.3),
      '--line': mix(K, P, 0.2), '--line-strong': mix(K, P, 0.38), '--yellow': accentDark, '--yellow-deep': shade(accentDark, -0.1), '--lime-ink': onColor(accentDark, K)
    };
    return { light, dark, cartLight: { '--bg': P, '--surface': '#FFFFFF', '--surface-2': mix(P, K, 0.08), '--ink': K, '--ink-soft': mix(K, P, 0.4), '--line': light['--line'], '--line-strong': light['--line-strong'], '--yellow': A, '--yellow-deep': light['--yellow-deep'], '--lime-ink': light['--lime-ink'] } };
  }
  const decl = o => Object.entries(o).map(([k, v]) => `${k}:${v}`).join(';');
  function css(p) {
    const t = tokens(p);
    const ink = normalize(p).ink;
    return `:root{${decl(t.light)};--shadow:0 1px 2px ${ink}10,0 4px 14px ${ink}12;--shadow-sm:0 1px 2px ${ink}0D}` +
      `:root[data-theme="dark"]{${decl(t.dark)}}` +
      `@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){${decl(t.dark)}}}` +
      `body:has(#cart-app:not([hidden])){${decl(t.cartLight)}}`;
  }

  // Avisos de legibilidad para la pantalla de Configuración.
  function checks(p) {
    const n = normalize(p); const out = [];
    if (contrast(n.ink, n.paper) < 7) out.push({ level: 'error', text: 'La tinta y el papel se parecen demasiado: el texto no se leería bien. Usa una tinta bien oscura y un papel claro.' });
    if (contrast(n.accent, n.ink) < 3) out.push({ level: 'warn', text: 'El acento se distingue poco de la tinta (menú lateral y cifras): prueba uno más claro.' });
    if (contrast(n.highlight, n.paper) < 3) out.push({ level: 'warn', text: 'El destacado se lee poco sobre el papel (precios y avisos): prueba uno más fuerte.' });
    return out;
  }


  return { PRESETS, DEFAULT, normalize, tokens, css, checks, contrast, mix, shade };
});
