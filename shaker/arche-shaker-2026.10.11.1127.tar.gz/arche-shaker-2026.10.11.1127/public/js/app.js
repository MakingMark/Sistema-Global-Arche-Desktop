/* ═══ Navegación entre secciones ═══ */
(function () {
  'use strict';
  const tabs = document.querySelectorAll('.nav-item');
  const views = document.querySelectorAll('.view');

  function showView(name) {
    if (window.Modules && Modules.viewOff(name)) name = document.getElementById('cart-app') && !document.getElementById('cart-app').hidden ? 'pos-venta' : 'panel';
    views.forEach(v => { v.hidden = v.dataset.view !== name; });
    tabs.forEach(t => {
      const isActive = t.dataset.view === name;
      t.classList.toggle('active', isActive);
      // La sección activa del menú solo se distinguía por color (.active,
      // fondo amarillo) — sin aria-current, un lector de pantalla anuncia
      // cada botón del menú igual, sin forma de saber cuál es la vista
      // actual. aria-current="page" es el valor correcto para "esta es la
      // sección en la que estás", el mismo patrón usado en breadcrumbs/nav.
      if (isActive) t.setAttribute('aria-current', 'page');
      else t.removeAttribute('aria-current');
    });
    window.dispatchEvent(new CustomEvent('view:show', { detail: { view: name } }));
  }

  tabs.forEach(t => t.addEventListener('click', () => showView(t.dataset.view)));

  window.showView = showView;

  // Grupos plegables del menú del dueño (Inventario/Análisis/Catálogo/Negocio) — en
  // escritorio no hacen nada (ver .nav-group-label en app.css, sin cursor de botón a
  // propósito); en el menú del teléfono se pliegan para que no haya que deslizar tanto
  // para llegar a Configuración. Clic en una etiqueta la pliega/despliega sola, sin
  // tocar las demás; navegar a una sección pliega el resto y abre solo la suya.
  const groupLabels = document.querySelectorAll('.nav-group-label');
  groupLabels.forEach(label => {
    label.addEventListener('click', () => {
      label.setAttribute('aria-expanded', label.getAttribute('aria-expanded') === 'true' ? 'false' : 'true');
    });
  });
  window.addEventListener('view:show', e => {
    const item = document.querySelector(`.nav-item[data-view="${e.detail.view}"]`);
    const ownGroup = item && item.closest('.nav-group');
    groupLabels.forEach(label => {
      label.setAttribute('aria-expanded', String(!!ownGroup && label.parentElement === ownGroup));
    });
  });

  // Menú deslizable del dueño en celular (ver app.css @media 820px): el botón
  // de hamburguesa abre/cierra el panel; tocar el fondo oscuro o elegir una
  // sección también lo cierra, para no dejarlo abierto tapando el contenido.
  const sidebar = document.querySelector('#owner-app .sidebar');
  const toggle = document.getElementById('sidebar-toggle');
  const backdrop = document.getElementById('sidebar-backdrop');
  // Encontrado en vivo desde el celular real: al abrir el menú, arrastrar el
  // dedo dentro de él (para llegar a "Reportes"/"Configuración") también
  // scrolleaba la página de ATRÁS, porque nada bloqueaba el body mientras el
  // menú estaba abierto — "overflow:hidden" en el body no alcanza en iOS
  // Safari (igual deja pasar el touch-scroll); fijar el body en su posición
  // actual (position:fixed + top negativo) es la técnica que sí funciona ahí,
  // y se revierte al mismo scroll exacto al cerrar.
  let savedScrollY = 0;
  const lockBodyScroll = () => {
    savedScrollY = window.scrollY;
    document.body.style.position = 'fixed';
    document.body.style.top = `-${savedScrollY}px`;
    document.body.style.left = '0';
    document.body.style.right = '0';
  };
  const unlockBodyScroll = () => {
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    window.scrollTo(0, savedScrollY);
  };
  if (sidebar && toggle) {
    const openMenu = () => {
      sidebar.classList.add('open');
      toggle.setAttribute('aria-expanded', 'true');
      toggle.setAttribute('aria-label', 'Cerrar menú');
      lockBodyScroll();
    };
    const closeMenu = () => {
      if (!sidebar.classList.contains('open')) return;
      sidebar.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Abrir menú');
      unlockBodyScroll();
    };
    toggle.addEventListener('click', () => {
      if (sidebar.classList.contains('open')) closeMenu(); else openMenu();
    });
    backdrop.addEventListener('click', closeMenu);
    tabs.forEach(t => t.addEventListener('click', closeMenu));
    window.__closeOwnerMobileMenu = closeMenu;
  }

  // Toda tabla ancha va dentro de un contenedor con scroll horizontal propio,
  // para que nunca "desalinee"/empuje el resto de la página en pantallas angostas.
  document.querySelectorAll('table.table').forEach(t => {
    if (t.parentElement.classList.contains('table-scroll')) return;
    const wrap = document.createElement('div');
    wrap.className = 'table-scroll';
    t.parentNode.insertBefore(wrap, t);
    wrap.appendChild(t);
  });

  // Escape cierra lo que esté abierto — el menú móvil del dueño, o el recibo
  // de "venta registrada" (`.recibo-modal`, elemento fijo con `hidden`, no un
  // overlay dinámico como los de ui.js que ya manejan su propio Escape).
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (sidebar && sidebar.classList.contains('open')) {
      window.__closeOwnerMobileMenu();
      return;
    }
    document.querySelectorAll('.recibo-modal').forEach(m => { if (!m.hidden) m.hidden = true; });
  });
})();
