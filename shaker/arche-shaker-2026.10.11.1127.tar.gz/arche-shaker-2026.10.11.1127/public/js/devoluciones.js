/* ═══ Devolución de una venta (nota de crédito) ═══
   La usan el Historial del dueño y el del punto de venta. `api` trae la venta y registra la devolución. */
const Devoluciones = (function () {
  'use strict';
  const esc = UI.escapeHtml;

  // api: { detail(id) → venta con items[].returned_quantity, submit(id, body) → nota de crédito }
  async function open(saleId, api, onDone) {
    let sale;
    try { sale = await api.detail(saleId); } catch (err) { UI.toast(err.message, 'error'); return; }
    if (sale.status === 'anulada') { UI.toast('La venta está anulada: no se puede devolver', 'error'); return; }
    if (sale.return_of) { UI.toast('Eso ya es una devolución', 'error'); return; }
    const lines = sale.items.map(i => ({ ...i, left: Number(i.quantity) - Number(i.returned_quantity || 0) })).filter(i => i.left > 1e-9);
    if (!lines.length) { UI.toast('Todo lo de esta venta ya fue devuelto', 'error'); return; }
    const methods = AppLocale.payments().filter(m => !/^fiado$/i.test(m));
    const modal = UI.showModal(`Devolver · venta #${sale.id}`, `
      <p class="muted" style="margin-top:0">Marca lo que se devuelve. El importe se calcula con el descuento e ITBIS que tuvo cada producto.</p>
      <div class="return-lines">${lines.map(i => `
        <label class="return-line">
          <input type="checkbox" data-line="${i.id}">
          <span class="return-name">${esc(i.product_name)} <span class="muted">(vendidos ${fmtNum(i.left)})</span></span>
          <input type="number" class="return-qty" data-qty="${i.id}" min="0.001" max="${i.left}" step="any" value="${i.left}" aria-label="Cantidad a devolver">
        </label>`).join('')}</div>
      <div class="field"><label for="ret-reason">Motivo (obligatorio)</label><input id="ret-reason" maxlength="200" placeholder="ej. defectuoso, no le quedó"></div>
      <div class="field"><label for="ret-method">Cómo se le devuelve</label>
        <select id="ret-method"><option value="">Igual que pagó${sale.payment_method ? ` (${esc(sale.payment_method)})` : ''}</option>${methods.map(m => `<option>${esc(m)}</option>`).join('')}</select></div>
      <label class="f-check"><input type="checkbox" id="ret-restock"><span>Vuelve al inventario (marca solo si el producto se puede volver a vender)</span></label>
      <div class="error" id="ret-error" role="alert" hidden></div>
      <div class="modal-actions" style="margin-top:14px"><button class="btn" id="ret-cancel">Cancelar</button><button class="btn btn-primary" id="ret-ok">Registrar devolución</button></div>`);
    const el = modal.el;
    el.querySelector('#ret-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#ret-ok').addEventListener('click', async ev => {
      const err = el.querySelector('#ret-error');
      err.hidden = true;
      const items = Array.from(el.querySelectorAll('[data-line]:checked')).map(c => ({ sale_item_id: Number(c.dataset.line), quantity: Number(el.querySelector(`[data-qty="${c.dataset.line}"]`).value) }));
      const reason = el.querySelector('#ret-reason').value.trim();
      if (!items.length) { err.textContent = 'Marca al menos un producto'; err.hidden = false; return; }
      if (items.some(i => !(i.quantity > 0))) { err.textContent = 'Revisa las cantidades'; err.hidden = false; return; }
      if (!reason) { err.textContent = 'Escribe el motivo de la devolución'; err.hidden = false; return; }
      const btn = ev.currentTarget; btn.disabled = true;
      try {
        const ret = await api.submit(saleId, { items, reason, refund_method: el.querySelector('#ret-method').value || undefined, restock: el.querySelector('#ret-restock').checked });
        modal.close();
        const done = UI.showModal('Devolución registrada', `<pre class="recibo-pre">${esc(ret.receipt || '')}</pre>
          <div class="modal-actions"><button class="btn btn-primary" id="rd-print">Imprimir</button><button class="btn" id="rd-close">Cerrar</button></div>`);
        done.el.querySelector('#rd-print').addEventListener('click', () => { const win = openReceiptWindow(true); fillReceiptWindow(win, ret.receipt); });
        done.el.querySelector('#rd-close').addEventListener('click', () => done.close());
        if (onDone) onDone(ret);
      } catch (e) {
        err.textContent = e.status === undefined ? 'Sin conexión — no se registró. Prueba de nuevo.' : e.message;
        err.hidden = false; btn.disabled = false;
      }
    });
  }
  return { open };
})();
