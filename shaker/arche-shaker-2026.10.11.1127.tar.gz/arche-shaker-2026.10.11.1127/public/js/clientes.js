/* ═══ Clientes: se arman solos desde el teléfono que se anota en una venta
   (ver customerService.js) — esta pantalla es para COMPARAR, no para dar de
   alta nada a mano. Pedido real del dueño: saber quién compró más (para un
   sorteo, o para mandar una oferta por WhatsApp a los números que ya
   tenemos). ═══ */
(function () {
  'use strict';
  const gridEl = document.getElementById('clientes-grid');
  if (!gridEl) return;
  const searchInput = document.getElementById('clientes-search');

  let customers = [];

  // Mismo formato que ya usa el resto de la app para mostrar el teléfono de
  // WhatsApp: "+1 809 555 1234", más fácil de leer que 11 dígitos pegados.
  function formatPhone(phone) {
    const d = String(phone || '');
    if (d.length !== 11) return `+${d}`;
    return `+${d[0]} ${d.slice(1, 4)} ${d.slice(4, 7)} ${d.slice(7)}`;
  }

  async function showEditModal(c) {
    const body = `
      <div class="f" style="margin-bottom:6px"><span>Teléfono</span><input value="${formatPhone(c.phone)}" disabled></div>
      <p class="muted" style="margin:0 0 14px;font-size:.82em">El teléfono es el identificador del cliente — no se puede cambiar acá. Si es un error real, hay que ir a la venta que lo generó.</p>
      <div class="f" style="margin-bottom:16px"><span>Nombre</span><input id="edit-cliente-name" value="${UI.escapeHtml(c.name)}"></div>
      ${Modules.enabled('fiado') ? `<div class="f" style="margin-bottom:16px"><span>Límite de crédito (vacío = sin límite)</span><input id="edit-cliente-limit" type="number" min="0" step="1" inputmode="decimal" value="${c.credit_limit !== null && c.credit_limit !== undefined ? Number(c.credit_limit) : ''}"></div>` : ''}
      <div class="modal-actions">
        <button class="btn" id="edit-cliente-cancel">Cancelar</button>
        <button class="btn btn-primary" id="edit-cliente-save">Guardar</button>
      </div>
    `;
    const modal = UI.showModal(`Editar · ${UI.escapeHtml(c.name)}`, body);
    modal.el.querySelector('#edit-cliente-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#edit-cliente-save').addEventListener('click', async () => {
      const name = modal.el.querySelector('#edit-cliente-name').value.trim();
      if (!name) { UI.toast('El nombre no puede quedar vacío', 'error'); return; }
      try {
        const limitEl = modal.el.querySelector('#edit-cliente-limit');
        await Api.customers.update(c.id, name, limitEl ? limitEl.value : undefined);
        modal.close();
        UI.toast('Cliente actualizado');
        render();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  // Estado de cuenta (fiado): cargos, abonos y cobrar un abono.
  async function showStatement(c) {
    let st;
    try { st = await Api.customers.statement(c.id); } catch (err) { UI.toast(err.message, 'error'); return; }
    const rows = st.entries.map(e => `<tr><td data-th="Fecha">${fmtDate(e.created_at)}</td><td data-th="Movimiento">${e.kind === 'cargo' ? 'Venta a crédito' : 'Abono'}${e.note ? `<div class="cell-subtitle muted">${UI.escapeHtml(e.note)}</div>` : ''}</td><td class="num" data-th="Importe">${e.kind === 'cargo' ? '+' : '-'}${fmt(e.amount)}</td></tr>`).join('');
    const modal = UI.showModal(`Cuenta · ${UI.escapeHtml(c.name)}`, `
      <div class="pay-total">${st.balance > 0 ? 'Debe ' + fmt(st.balance) : st.balance < 0 ? 'A favor ' + fmt(-st.balance) : 'Sin deuda'}</div>
      ${c.credit_limit !== null && c.credit_limit !== undefined ? `<p class="muted" style="text-align:center;margin-top:-6px">Límite de crédito: ${fmt(c.credit_limit)}</p>` : ''}
      ${st.balance > 0 ? `<div class="form-inline" style="margin:12px 0"><label class="f"><span>Abono</span><input id="ab-amount" type="number" min="0.01" step="0.01" max="${st.balance}" value="${st.balance}" inputmode="decimal"></label>
        <label class="f"><span>Forma de pago</span><select id="ab-method">${AppLocale.payments().filter(m => !/^fiado$/i.test(m)).map(m => `<option>${UI.escapeHtml(m)}</option>`).join('')}</select></label>
        <button class="btn btn-primary" id="ab-ok">Cobrar abono</button></div><div class="error" id="ab-error" role="alert" hidden></div>` : ''}
      <table class="table"><thead><tr><th>Fecha</th><th>Movimiento</th><th class="num">Importe</th></tr></thead><tbody>${rows || '<tr><td colspan="3" class="muted">Sin movimientos.</td></tr>'}</tbody></table>`);
    const ok = modal.el.querySelector('#ab-ok');
    if (ok) ok.addEventListener('click', async () => {
      const err = modal.el.querySelector('#ab-error'); err.hidden = true; ok.disabled = true;
      try {
        await Api.customers.payment(c.id, { amount: Number(modal.el.querySelector('#ab-amount').value), method: modal.el.querySelector('#ab-method').value });
        modal.close(); UI.toast('Abono registrado'); await render();
        showStatement(customers.find(x => x.id === c.id) || c);
      } catch (e) { err.textContent = e.message; err.hidden = false; ok.disabled = false; }
    });
  }

  function renderGrid() {
    const q = searchInput.value.trim().toLowerCase();
    const filtered = q
      ? customers.filter(c => c.name.toLowerCase().includes(q) || c.phone.includes(q.replace(/\D/g, '')))
      : customers;
    gridEl.innerHTML = '';
    if (!filtered.length) {
      gridEl.innerHTML = customers.length
        ? `<p class="muted">Sin resultados para "${q}".</p>`
        : '<p class="muted">Todavía no hay clientes — se cargan solos apenas alguien anota un teléfono en una venta.</p>';
      return;
    }
    filtered.forEach(c => {
      const card = document.createElement('div');
      card.className = 'product-card';
      card.innerHTML = `
        <div class="product-card-header">
          <strong>${UI.escapeHtml(c.name)}</strong>
          <div class="muted product-card-subtitle">${formatPhone(c.phone)}</div>
        </div>
        <div class="product-card-stats">
          <div><span class="label">Compras</span><span class="value">${c.sales_count}</span></div>
          <div><span class="label">Total gastado</span><span class="value">${fmt(c.total_spent)}</span></div>
          <div><span class="label">Última compra</span><span class="value">${c.last_purchase_at ? fmtDate(c.last_purchase_at) : '—'}</span></div>
          ${Modules.enabled('fiado') ? `<div><span class="label">Debe</span><span class="value${Number(c.balance) > 0 ? ' low-stock' : ''}">${fmt(Math.max(0, c.balance))}</span></div>` : ''}
        </div>
        <div class="product-card-actions"></div>
      `;
      const editBtn = document.createElement('button');
      editBtn.className = 'btn btn-sm';
      editBtn.innerHTML = UI.iconLabel('edit', 'Editar');
      editBtn.addEventListener('click', () => showEditModal(c));
      card.querySelector('.product-card-actions').appendChild(editBtn);
      if (Modules.enabled('fiado')) {
        const cuentaBtn = document.createElement('button');
        cuentaBtn.className = 'btn btn-sm';
        cuentaBtn.textContent = 'Cuenta y abonos';
        cuentaBtn.addEventListener('click', () => showStatement(c));
        card.querySelector('.product-card-actions').appendChild(cuentaBtn);
      }
      gridEl.appendChild(card);
    });
  }

  // Mismo patrón de CSV que ya usa Reportes (BOM + comillas donde haga
  // falta) — pero armado directo desde el array en memoria, no desde una
  // <table> oculta, porque acá el dato vive en tarjetas, no en filas.
  document.getElementById('btn-clientes-csv').addEventListener('click', () => {
    const esc = s => { const v = String(s ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const rows = [
      ['Nombre', 'Teléfono', 'Compras', 'Total gastado', 'Última compra', 'Debe'].join(','),
      ...customers.map(c => [
        esc(c.name), esc(formatPhone(c.phone)), c.sales_count, c.total_spent,
        esc(c.last_purchase_at ? fmtDate(c.last_purchase_at) : ''), c.balance
      ].join(','))
    ];
    const blob = new Blob(['﻿' + rows.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clientes-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  async function render() {
    customers = await Api.customers.list();
    renderGrid();
  }

  searchInput.addEventListener('input', renderGrid);

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'clientes') render();
  });
})();
