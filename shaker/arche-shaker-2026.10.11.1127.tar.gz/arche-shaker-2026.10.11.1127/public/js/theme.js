/* ═══ Modo claro/oscuro — preferencia del NAVEGADOR (localStorage), no de la
   sesión: cerrar sesión no debería resetear el tema que alguien ya eligió en
   esa pantalla. El tema en sí ya se aplica antes de esto (script inline al
   principio de <head>, para no parpadear al tema guardado al cargar).
   Dos controles, siempre sincronizados:
   - v3.2: botón sol/luna en la barra superior del administrativo (estaba muy
     escondido en Configuración). Alterna claro ↔ oscuro.
   - Configuración → Apariencia: las tres opciones (claro, oscuro, del sistema).
   La facturación siempre se ve en claro (ver brandCore.js, cartLight), por eso
   el botón vive solo en el administrativo. ═══ */
(function () {
  'use strict';
  const KEY = 'shaker_theme';
  const buttons = {
    light: document.getElementById('theme-btn-light'),
    dark: document.getElementById('theme-btn-dark'),
    system: document.getElementById('theme-btn-system')
  };
  const toggles = Array.from(document.querySelectorAll('[data-theme-toggle]'));
  const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');

  function current() {
    try { return localStorage.getItem(KEY) || 'system'; } catch (_) { return 'system'; }
  }
  // Lo que de verdad se está viendo (si es "del sistema", depende del equipo).
  function effective() {
    const m = current();
    return m === 'system' ? (darkQuery.matches ? 'dark' : 'light') : m;
  }

  function paint() {
    const mode = current();
    Object.entries(buttons).forEach(([m, btn]) => {
      if (!btn) return;
      const active = m === mode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
    const isDark = effective() === 'dark';
    toggles.forEach(t => {
      t.classList.toggle('is-dark', isDark);
      const label = isDark ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro';
      t.setAttribute('aria-label', label);
      t.title = label;
    });
  }

  function apply(mode, fade) {
    if (fade) {
      document.documentElement.classList.add('theme-fading');
      clearTimeout(apply._t); apply._t = setTimeout(() => document.documentElement.classList.remove('theme-fading'), 450);
    }
    if (mode === 'system') {
      delete document.documentElement.dataset.theme;
      try { localStorage.removeItem(KEY); } catch (_) {}
    } else {
      document.documentElement.dataset.theme = mode;
      try { localStorage.setItem(KEY, mode); } catch (_) {}
    }
    paint();
  }

  Object.entries(buttons).forEach(([mode, btn]) => { if (btn) btn.addEventListener('click', () => apply(mode, true)); });
  toggles.forEach(t => t.addEventListener('click', () => {
    if (window.Motion) Motion.replay(t, 'is-spinning');
    apply(effective() === 'dark' ? 'light' : 'dark', true);
  }));
  // Si está en "del sistema" y el equipo cambia de tema solo (de noche), el ícono se actualiza.
  if (darkQuery.addEventListener) darkQuery.addEventListener('change', paint);
  window.Theme = { apply, current, effective };
  paint();
})();
