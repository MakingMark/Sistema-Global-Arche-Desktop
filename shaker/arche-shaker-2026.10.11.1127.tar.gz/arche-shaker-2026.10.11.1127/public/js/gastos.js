/* ═══ Gastos (dueño): alquiler, nómina, servicios… ═══ */
(function () {
  'use strict';
  const form = document.getElementById('form-gastos-filtro');
  if (!form) return;
  const esc = UI.escapeHtml;
  const tbody = document.querySelector('#tabla-gastos tbody');
  const totalesEl = document.getElementById('gastos-totales');
  let categories = {};
  let locations = [];
  let data = null;

  const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const params = () => {
    const fd = new FormData(form);
    const p = {};
    ['from', 'to', 'category'].forEach(k => { if (fd.get(k)) p[k] = fd.get(k); });
    return p;
  };

  async function load() {
    data = await Api.expenses.list(params());
    categories = data.categories;
    const sel = form.querySelector('[name="category"]');
    if (sel.options.length <= 1) sel.innerHTML = '<option value="">Todas</option>' + Object.entries(categories).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('');
    const byCat = {};
    data.expenses.forEach(e => { byCat[e.category] = (byCat[e.category] || 0) + e.amount; });
    const top = Object.entries(byCat).sort((a, b) => b[1] - a[1])[0];
    totalesEl.innerHTML =
      `<div class="stat"><div class="label">Total</div><div class="value">${fmtDec(data.total)}</div></div>` +
      `<div class="stat"><div class="label">Registros</div><div class="value">${data.expenses.length}</div></div>` +
      `<div class="stat"><div class="label">Mayor gasto</div><div class="value" style="font-size:1.1rem">${top ? esc(categories[top[0]]) : '—'}</div></div>`;
    tbody.innerHTML = data.expenses.map(e => `<tr>
      <td data-th="Fecha">${e.expense_date.split('-').reverse().join('/')}</td>
      <td data-th="Categoría">${esc(e.category_label)}</td>
      <td data-th="Descripción">${esc(e.description)}${e.note ? `<div class="cell-subtitle muted">${esc(e.note)}</div>` : ''}</td>
      <td data-th="Dónde">${esc(e.location_name || 'Todo el negocio')}</td>
      <td class="num" data-th="Monto">${fmtDec(e.amount)}</td>
      <td><button class="btn btn-sm" data-edit="${e.id}">${UI.iconLabel('edit', 'Editar')}</button> <button class="btn btn-sm" data-del="${e.id}">${UI.iconLabel('trash', 'Borrar')}</button></td></tr>`).join('')
      || '<tr><td colspan="6" class="muted">Sin gastos en este rango.</td></tr>';
    tbody.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => edit(data.expenses.find(x => x.id === Number(b.dataset.edit)))));
    tbody.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
      if (!(await UI.confirmDialog('¿Borrar este gasto?'))) return;
      try { await Api.expenses.remove(Number(b.dataset.del)); UI.toast('Gasto borrado'); load(); } catch (err) { UI.toast(err.message, 'error'); }
    }));
  }

  function edit(e) {
    const editing = !!e;
    const modal = UI.showModal(editing ? 'Editar gasto' : 'Gasto nuevo', `
      <div class="field-grid">
        <label class="f"><span>Categoría</span><select id="gx-cat">${Object.entries(categories).map(([k, v]) => `<option value="${k}" ${editing && e.category === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
        <label class="f"><span>Monto (RD$)</span><input id="gx-amount" type="number" min="0" step="0.01" value="${editing ? e.amount : ''}"></label>
        <label class="f"><span>Fecha</span><input id="gx-date" type="date" value="${editing ? e.expense_date : iso(new Date())}"></label>
        <label class="f"><span>Dónde</span><select id="gx-loc"><option value="">Todo el negocio</option>${locations.filter(l => l.kind === 'carrito').map(l => `<option value="${l.id}" ${editing && e.location_id === l.id ? 'selected' : ''}>${esc(l.name)}</option>`).join('')}</select></label>
      </div>
      <label class="f" style="max-width:none;margin-top:10px"><span>Descripción</span><input id="gx-desc" maxlength="200" value="${esc(editing ? e.description : '')}" placeholder="ej. Alquiler de octubre"></label>
      <label class="f" style="max-width:none;margin-top:10px"><span>Nota (opcional)</span><input id="gx-note" maxlength="300" value="${esc(editing ? e.note || '' : '')}"></label>
      <div class="modal-actions" style="margin-top:16px"><button class="btn" id="gx-cancel">Cancelar</button><button class="btn btn-primary" id="gx-save">Guardar</button></div>`);
    modal.el.querySelector('#gx-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#gx-save').addEventListener('click', async () => {
      const body = {
        category: modal.el.querySelector('#gx-cat').value, amount: Number(modal.el.querySelector('#gx-amount').value),
        expense_date: modal.el.querySelector('#gx-date').value, location_id: modal.el.querySelector('#gx-loc').value || null,
        description: modal.el.querySelector('#gx-desc').value.trim(), note: modal.el.querySelector('#gx-note').value.trim() || null
      };
      try {
        if (editing) await Api.expenses.update(e.id, body); else await Api.expenses.create(body);
        modal.close();
        UI.toast(editing ? 'Gasto actualizado' : 'Gasto registrado');
        load();
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  }

  document.getElementById('btn-gasto-nuevo').addEventListener('click', async () => {
    if (!locations.length) locations = await Api.locations.list();
    edit(null);
  });
  form.addEventListener('submit', ev => { ev.preventDefault(); load(); });
  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'gastos') return;
    locations = await Api.locations.list().catch(() => locations);
    const from = form.querySelector('[name="from"]'), to = form.querySelector('[name="to"]');
    if (!from.value && !to.value) { const n = new Date(); from.value = iso(new Date(n.getFullYear(), n.getMonth(), 1)); to.value = iso(n); }
    load().catch(err => UI.toast(err.message, 'error'));
  });
})();
