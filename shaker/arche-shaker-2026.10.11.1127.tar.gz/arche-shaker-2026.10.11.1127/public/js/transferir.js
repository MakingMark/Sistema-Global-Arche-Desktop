/* ═══ Inventario › Transferir y corregir (dueño) ═══
   Antes estos dos formularios vivían escondidos dentro del detalle de cada
   ubicación (había que elegir un punto de venta primero, y el "Desde" quedaba fijo
   al almacén). Acá cualquier origen y destino se elige libremente — mover
   algo de un punto de venta a otro es un caso real (a uno le falta, al otro le
   sobra) — */
(function () {
  'use strict';
  const formTransfer = document.getElementById('form-transferencia');
  if (!formTransfer) return;

  const selectFrom = document.getElementById('transfer-from');
  const selectTo = document.getElementById('transfer-to');
  const suppliesBuilder = document.getElementById('transfer-supplies');
  const transferError = document.getElementById('transfer-error');
  const noteInput = document.getElementById('transfer-note');

  const adjustLocation = document.getElementById('stock-adjust-location');
  const adjustSupply = document.getElementById('stock-adjust-supply');
  const adjustUnitType = document.getElementById('stock-adjust-unit-type');
  const formAdjust = document.getElementById('form-stock-adjust');
  const mermaLocation = document.getElementById('merma-location');
  const mermaSupply = document.getElementById('merma-supply');

  let locations = [];
  let supplies = [];

  // Ver public/js/supplyPicker.js.
  function suppliesOptions() {
    return SupplyPicker.suppliesOptions(supplies, 'id');
  }
  function unitTypeOptions(supplyId) {
    return SupplyPicker.unitTypeOptions(supplies, 'id', supplyId);
  }

  async function load() {
    [locations, supplies] = await Promise.all([Api.locations.list(), Api.supplies.list()]);
    const active = Modules.visibleLocations(locations.filter(l => l.active));
    const opts = active.map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');
    const keepFrom = selectFrom.value, keepTo = selectTo.value, keepAdj = adjustLocation.value;
    selectFrom.innerHTML = opts;
    selectTo.innerHTML = opts;
    adjustLocation.innerHTML = opts;
    // Lo más común es enviar desde el almacén central — se precarga para
    // evitar un traslado accidental origen=destino; si ya había algo elegido
    // (volviendo a la pantalla) se respeta.
    const central = active.find(l => l.kind === 'central');
    if (keepFrom && active.some(l => String(l.id) === keepFrom)) selectFrom.value = keepFrom;
    else if (central) selectFrom.value = String(central.id);
    if (keepTo && active.some(l => String(l.id) === keepTo) && keepTo !== selectFrom.value) selectTo.value = keepTo;
    else {
      const other = active.find(l => String(l.id) !== selectFrom.value);
      if (other) selectTo.value = String(other.id);
    }
    if (keepAdj && active.some(l => String(l.id) === keepAdj)) adjustLocation.value = keepAdj;
    adjustSupply.innerHTML = suppliesOptions();
    adjustUnitType.innerHTML = unitTypeOptions(adjustSupply.value);
    mermaLocation.innerHTML = opts;
    mermaSupply.innerHTML = suppliesOptions();
    window.dispatchEvent(new CustomEvent('transferir:loaded'));
  }

  function addSupplyRow() {
    const row = document.createElement('div');
    row.className = 'receta-row';
    row.innerHTML = `
      <select class="supply-select">${suppliesOptions()}</select>
      <input type="number" placeholder="Cantidad" step="1" min="0">
      <select class="unit-type-select"></select>
      <button type="button" class="btn btn-sm">Quitar</button>
    `;
    const supplySelect = row.querySelector('.supply-select');
    const unitTypeSelect = row.querySelector('.unit-type-select');
    unitTypeSelect.innerHTML = unitTypeOptions(supplySelect.value);
    supplySelect.addEventListener('change', () => {
      unitTypeSelect.innerHTML = unitTypeOptions(supplySelect.value);
    });
    row.querySelector('button').addEventListener('click', () => row.remove());
    suppliesBuilder.appendChild(row);
  }
  document.getElementById('btn-add-transfer-supply').addEventListener('click', addSupplyRow);

  function readTransferSupplies() {
    return Array.from(suppliesBuilder.querySelectorAll('.receta-row')).map(row => {
      const supplyId = Number(row.querySelector('.supply-select').value);
      const qty = Number(row.querySelector('input').value);
      const unitType = row.querySelector('.unit-type-select').value;
      const s = supplies.find(x => x.id === supplyId);
      const size = unitType === 'pack' ? Number(s?.pack_size) : unitType === 'transfer_pack' ? Number(s?.transfer_pack_size) : 1;
      const quantity = s && size > 0 ? qty * size : qty;
      return { supply_id: supplyId, quantity };
    }).filter(r => r.supply_id && r.quantity > 0);
  }

  formTransfer.addEventListener('submit', async e => {
    e.preventDefault();
    transferError.hidden = true;
    const from_location_id = Number(selectFrom.value);
    const to_location_id = Number(selectTo.value);
    if (from_location_id === to_location_id) {
      transferError.textContent = 'El origen y el destino no pueden ser la misma ubicación.';
      transferError.hidden = false;
      return;
    }
    const note = noteInput.value || null;
    // Sin esto, un doble toque (común en celular con mala señal, sin
    // feedback inmediato de que el primero ya salió) podía mandar la misma
    // transferencia dos veces — mueve inventario real, no es solo cosmético.
    const submitBtn = e.target.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    try {
      await Api.transfers.create({
        from_location_id, to_location_id,
        supplies: readTransferSupplies(), note
      });
      noteInput.value = '';
      suppliesBuilder.innerHTML = '';
      UI.toast('Transferencia realizada');
    } catch (err) {
      transferError.textContent = err.message;
      transferError.hidden = false;
    } finally {
      submitBtn.disabled = false;
    }
  });

  adjustSupply.addEventListener('change', () => {
    adjustUnitType.innerHTML = unitTypeOptions(adjustSupply.value);
  });

  formAdjust.addEventListener('submit', async e => {
    e.preventDefault();
    const supplyId = Number(adjustSupply.value);
    let qty = Number(document.getElementById('stock-adjust-qty').value);
    if (!supplyId || !qty) return;
    if (adjustUnitType.value === 'pack' || adjustUnitType.value === 'transfer_pack') {
      const s = supplies.find(x => x.id === supplyId);
      const size = adjustUnitType.value === 'pack' ? Number(s?.pack_size) : Number(s?.transfer_pack_size);
      if (s && size > 0) qty = qty * size;
    }
    // Un ajuste negativo que dejaría el stock por debajo de 0 lo rechaza el
    // servidor (409, ver supplies.js) — sin try/catch acá eso quedaba como
    // una excepción sin atrapar, el formulario no avisaba nada.
    try {
      await Api.supplies.adjustStock(supplyId, {
        location_id: Number(adjustLocation.value), quantity: qty,
        note: document.getElementById('stock-adjust-note').value || null
      });
      document.getElementById('stock-adjust-qty').value = '';
      document.getElementById('stock-adjust-note').value = '';
      UI.toast('Stock actualizado');
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  document.getElementById('form-merma').addEventListener('submit', async e => {
    e.preventDefault();
    const qty = Number(document.getElementById('merma-qty').value);
    if (!(qty > 0)) return;
    try {
      await Api.supplies.waste(Number(mermaSupply.value), {
        location_id: Number(mermaLocation.value), quantity: qty,
        reason: document.getElementById('merma-reason').value,
        note: document.getElementById('merma-note').value.trim() || null
      });
      document.getElementById('merma-qty').value = '';
      document.getElementById('merma-note').value = '';
      UI.toast('Merma registrada');
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  // Lo usan otras pantallas para abrir esta ya rellena ("Transferir
  // desde/hacia aquí" en la ficha de una ubicación).
  window.prefillTransfer = async function ({ fromId, toId, note } = {}) {
    window.showView('inv-transferir');
    await loading; // el view:show de arriba ya disparó la carga
    if (fromId != null) selectFrom.value = String(fromId);
    if (toId != null) selectTo.value = String(toId);
    if (note != null) noteInput.value = note;
    selectTo.scrollIntoView({ block: 'center' });
  };

  /* ── Solicitudes de reposición (lo que cada carrito va pidiendo) ── */
  const restockList = document.getElementById('restock-list');
  const restockBadge = document.getElementById('restock-badge');
  const esc = UI.escapeHtml;

  async function loadRestock() {
    let reqs;
    try { reqs = await Api.restockRequests.list(); } catch (err) { restockList.innerHTML = `<p class="muted">${esc(err.message)}</p>`; return; }
    const pending = reqs.filter(r => r.status === 'pendiente');
    restockBadge.hidden = !pending.length;
    restockBadge.textContent = pending.length;
    if (!reqs.length) { restockList.innerHTML = '<p class="muted">Todavía no ha llegado ninguna solicitud.</p>'; return; }
    const STATE = { pendiente: ['Pendiente', 'badge-warn'], aprobada: ['Aprobada', 'badge-ok'], rechazada: ['Rechazada', 'badge-voided'], cancelada: ['Cancelada', 'badge-muted'] };
    restockList.innerHTML = reqs.map(r => {
      const [label, cls] = STATE[r.status];
      const items = r.items.map(i => `${fmtNum(i.quantity)} ${esc(i.supply_unit)} de ${esc(i.supply_name)}`).join(', ');
      return `<div class="product-card" data-id="${r.id}">
        <div class="product-card-header"><strong>${esc(r.location_name)}</strong> <span class="badge ${cls}">${label}</span>
          <div class="muted product-card-subtitle">${r.requested_by_name ? esc(r.requested_by_name) + ' · ' : ''}${fmtDate(r.created_at)}</div></div>
        <p style="margin:8px 0">${items}</p>
        ${r.note ? `<p class="muted" style="margin:0 0 8px">“${esc(r.note)}”</p>` : ''}
        ${r.status === 'rechazada' && r.reject_reason ? `<p class="muted" style="margin:0 0 8px">Motivo: ${esc(r.reject_reason)}</p>` : ''}
        ${r.status === 'pendiente' ? `<div class="product-card-actions"><button class="btn btn-sm btn-primary" data-a="approve">Aprobar</button><button class="btn btn-sm" data-a="reject">Rechazar</button></div>` : ''}
      </div>`;
    }).join('');
  }

  restockList.addEventListener('click', async e => {
    const btn = e.target.closest('[data-a]');
    if (!btn) return;
    const id = Number(btn.closest('[data-id]').dataset.id);
    if (btn.dataset.a === 'reject') {
      const reason = await UI.promptDialog('¿Rechazar esta solicitud?', 'Motivo (obligatorio)');
      if (!reason) return;
      try { await Api.restockRequests.reject(id, reason); UI.toast('Solicitud rechazada'); loadRestock(); }
      catch (err) { UI.toast(err.message, 'error'); }
      return;
    }
    // Aprobar: arma la transferencia desde el almacén central (si hay uno solo, no hace falta preguntar).
    const central = locations.filter(l => l.kind === 'central' && l.active);
    let fromId = central.length === 1 ? central[0].id : null;
    if (!fromId) {
      const opts = (central.length ? central : locations.filter(l => l.active)).map(l => `<option value="${l.id}">${esc(l.name)}</option>`).join('');
      const modal = UI.showModal('¿Desde dónde se manda?', `<div class="field"><label for="ap-from">Ubicación de origen</label><select id="ap-from">${opts}</select></div>
        <div class="modal-actions"><button class="btn" id="ap-cancel">Cancelar</button><button class="btn btn-primary" id="ap-ok">Aprobar</button></div>`);
      fromId = await new Promise(resolve => {
        modal.el.querySelector('#ap-cancel').addEventListener('click', () => { modal.close(); resolve(null); });
        modal.el.querySelector('#ap-ok').addEventListener('click', () => { const v = Number(modal.el.querySelector('#ap-from').value); modal.close(); resolve(v); });
      });
      if (!fromId) return;
    }
    try { await Api.restockRequests.approve(id, { from_location_id: fromId }); UI.toast('Solicitud aprobada — queda pendiente que el carrito confirme cuánto le llegó'); loadRestock(); }
    catch (err) { UI.toast(err.message, 'error'); }
  });

  let loading = Promise.resolve();
  window.addEventListener('view:show', e => {
    if (e.detail.view !== 'inv-transferir' && e.detail.view !== 'inv-ajustes') return;
    loading = load();
    if (e.detail.view === 'inv-transferir') loadRestock();
  });
})();
