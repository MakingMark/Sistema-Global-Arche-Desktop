/* ═══ Campana de avisos del administrativo (fase 4) ═══
   Junta en un solo lugar lo que pide atención, con un toque a donde se
   resuelve: insumos bajos, lotes vencidos o por vencer, pedidos de reposición
   de los puntos de venta y la licencia por vencer (solo en la PC de un
   cliente). Se revisa al entrar, al volver al Panel y cada 5 minutos. */
(function () {
  'use strict';
  const btn = document.getElementById('avisos-btn');
  const panel = document.getElementById('avisos-panel');
  const app = document.getElementById('owner-app');
  if (!btn || !panel || !app) return;
  const countEl = btn.querySelector('.avisos-count');
  const esc = s => UI.escapeHtml(String(s));
  let items = [], timer = null;

  async function cargar() {
    if (app.hidden) return;
    const on = m => !window.Modules || Modules.enabled(m);
    const [low, exp, rest, lic] = await Promise.all([
      on('insumos') ? Api.reports.lowStock('all').catch(() => null) : null,
      on('vencimientos') ? Api.reports.expiry().catch(() => null) : null,
      on('transferencias') ? Api.restockRequests.list('pendiente').catch(() => null) : null,
      fetch('/api/licencia', { cache: 'no-store' }).then(r => r.json()).catch(() => null)
    ]);
    items = [];
    if (lic && lic.activa && lic.aviso) items.push({ tipo: 'urgente', icon: '🔑', title: `La licencia vence en ${lic.diasRestantes} día${lic.diasRestantes === 1 ? '' : 's'}`, text: 'Renuévala en Configuración → Licencia y plan.', go: 'configuracion' });
    const vencidos = (exp || []).filter(l => l.expired);
    if (vencidos.length) items.push({ tipo: 'urgente', icon: '⏰', title: `${vencidos.length} lote${vencidos.length === 1 ? '' : 's'} vencido${vencidos.length === 1 ? '' : 's'}`, text: 'Dalos de baja para que el stock sea real.', go: 'panel' });
    const porVencer = (exp || []).filter(l => !l.expired);
    if (porVencer.length) items.push({ tipo: 'aviso', icon: '📅', title: `${porVencer.length} lote${porVencer.length === 1 ? '' : 's'} por vencer`, text: porVencer.slice(0, 3).map(l => esc(l.supply_name)).join(', ') + (porVencer.length > 3 ? '…' : ''), go: 'panel' });
    const bajos = (low && low.supplies) || [];
    if (bajos.length) items.push({ tipo: 'aviso', icon: '📦', title: `${bajos.length} insumo${bajos.length === 1 ? '' : 's'} bajo${bajos.length === 1 ? '' : 's'}`, text: bajos.slice(0, 3).map(s => `${esc(s.supply_name)} (${esc(s.location_name)})`).join(', ') + (bajos.length > 3 ? '…' : ''), go: 'existencias' });
    const pend = rest || [];
    if (pend.length) items.push({ tipo: 'aviso', icon: '🛒', title: `${pend.length} pedido${pend.length === 1 ? '' : 's'} de reposición`, text: 'Los puntos de venta esperan mercancía.', go: 'inv-transferir' });
    pintar();
  }

  function pintar() {
    const n = items.length;
    countEl.hidden = !n;
    countEl.textContent = n;
    btn.classList.toggle('has-urgent', items.some(i => i.tipo === 'urgente'));
    btn.setAttribute('aria-label', n ? `${n} aviso${n === 1 ? '' : 's'}` : 'Sin avisos');
    panel.innerHTML = `<p class="avisos-title">Avisos</p>` + (n
      ? items.map((i, k) => `<button type="button" class="aviso aviso-${i.tipo}" data-k="${k}"><span class="aviso-icon" aria-hidden="true">${i.icon}</span><span><strong>${i.title}</strong><small>${i.text}</small></span></button>`).join('')
      : `<div class="ux-empty"><span class="ux-empty-icon">✓</span><div><strong>Todo en orden</strong><span>No hay nada pendiente.</span></div></div>`);
  }

  function abrir(on) {
    panel.hidden = !on;
    btn.setAttribute('aria-expanded', String(on));
    if (on) cargar();
  }
  btn.addEventListener('click', e => { e.stopPropagation(); abrir(panel.hidden); });
  document.addEventListener('click', e => { if (!panel.hidden && !panel.contains(e.target)) abrir(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !panel.hidden) abrir(false); });
  panel.addEventListener('click', e => {
    const b = e.target.closest('[data-k]');
    if (!b) return;
    const it = items[Number(b.dataset.k)];
    abrir(false);
    if (it.go === 'existencias' && window.showExistencias) window.showExistencias(true);
    else window.showView(it.go);
  });

  new MutationObserver(() => {
    if (app.hidden) { clearInterval(timer); return; }
    cargar(); clearInterval(timer); timer = setInterval(cargar, 5 * 60000);
  }).observe(app, { attributes: true, attributeFilter: ['hidden'] });
  window.addEventListener('view:show', e => { if (e.detail.view === 'panel') cargar(); });
  if (!app.hidden) { cargar(); timer = setInterval(cargar, 5 * 60000); }
})();
