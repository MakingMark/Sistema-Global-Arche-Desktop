/* ═══ Historial de ventas (dueño, todas las ubicaciones, filtrable) ═══ */
(function () {
  'use strict';
  const grid = document.getElementById('historial-grid');
  if (!grid) return;
  const form = document.getElementById('form-historial-filtro');
  const locationSelect = form.querySelector('[name="location_id"]');
  const fromInput = form.querySelector('[name="from"]');
  const toInput = form.querySelector('[name="to"]');

  // Componentes LOCALES de la fecha — nunca .toISOString().slice(0,10), que
  // da la fecha en UTC y se adelanta un día entero entre las 8pm y la
  // medianoche en Santo Domingo (UTC-4). Mismo bug ya encontrado y
  // corregido en pos.js/reportes.js/dashboard.js.
  // localIsoDate ahora es global — ver api.js.

  async function loadLocations() {
    const locations = await Api.locations.list();
    // Solo ubicaciones activas: "Todas" ya suma el historial completo
    // (retiradas incluidas) — el filtro puntual por una ya dada de baja no
    // aporta y solo ensucia la lista con puntos de venta de prueba nunca limpiados.
    locationSelect.innerHTML = '<option value="">Todas</option>' +
      locations.filter(l => l.active).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');
  }

  // Antes una <table> de 5 columnas + acciones (necesitaba su propio punto
  // de quiebre a los ~1150px — ver el comentario grande en app.css) — misma
  // migración a tarjetas que ya se hizo en Insumos y Ubicaciones (fase 3 de
  // la propuesta de rediseño).
  async function render(params) {
    // Placeholder mientras llega la respuesta — antes la grilla quedaba en
    // blanco durante ese viaje al servidor (el filtro por fecha/ubicación
    // puede tardar si hay muchas ventas), sin ninguna señal de que algo
    // estaba pasando.
    grid.innerHTML = UI.skeletonCards(4);
    const sales = await Api.sales.list(params);
    grid.innerHTML = '';
    if (!sales.length) {
      grid.innerHTML = `<p class="muted">Sin ventas para este filtro.</p>`;
      return;
    }
    // Resumen a propósito: fecha, ubicación, cliente y total — lo que hace
    // falta para ubicar una factura de un vistazo. Tipo, ganancia y estado se
    // sacaron de la lista (pedido del dueño: la ganancia es un dato para
    // analizar, no para ver factura por factura, y ese detalle ya vive en
    // "Ver / imprimir"); una venta anulada igual se distingue por el
    // atenuado + tachado de .row-voided, sin necesitar su propio campo.
    sales.forEach(s => {
      const voided = s.status === 'anulada';
      const card = document.createElement('div');
      card.className = 'product-card' + (voided ? ' row-voided' : '');
      card.innerHTML = `
        <div class="product-card-header">
          <strong>#${s.id}</strong>${voided ? ' <span class="badge badge-voided">Anulada</span>' : ''}${s.return_of ? ` <span class="badge badge-warn">Devolución de #${s.return_of}</span>` : ''}${Number(s.discount_amount) > 0 ? ' <span class="badge badge-muted">Con descuento</span>' : ''}
          <div class="muted product-card-subtitle">${fmtDate(s.created_at)} · ${UI.escapeHtml(s.location_name)}${s.employee_name ? ' · ' + UI.escapeHtml(s.employee_name) : ''}</div>
        </div>
        <div class="product-card-stats">
          <div><span class="label">Cliente</span><span class="value">${UI.escapeHtml(s.customer_name) || '—'}</span></div>
          <div><span class="label">Cobrado</span><span class="value">${fmt(s.amount_due != null ? s.amount_due : s.total)}</span></div>
        </div>
        <div class="product-card-actions"></div>
      `;
      const actions = card.querySelector('.product-card-actions');

      const btnVer = document.createElement('button');
      btnVer.className = 'btn btn-sm';
      // "Ver" abre la factura en su propia ventana, que ya trae su botón
      // "Imprimir" — un botón de Imprimir aparte acá era el mismo destino
      // dos veces, así que se quitó (pedido del dueño).
      btnVer.innerHTML = UI.iconLabel('eye', 'Ver / imprimir');
      btnVer.addEventListener('click', async () => {
        const win = openReceiptWindow(false);
        // Sin try/catch, un fallo de red dejaba la ventana nueva trabada
        // en "Cargando…" para siempre, sin explicar nada.
        try {
          const detail = await Api.sales.get(s.id);
          fillReceiptWindow(win, detail.receipt);
        } catch (err) {
          if (win && !win.closed) fillReceiptWindow(win, `No se pudo cargar la factura: ${err.message}`);
        }
      });
      actions.appendChild(btnVer);

      if (!voided) {
        const btnAnular = document.createElement('button');
        btnAnular.className = 'btn btn-sm';
        btnAnular.innerHTML = UI.iconLabel('ban', 'Anular');
        btnAnular.addEventListener('click', async () => {
          const reason = await UI.promptDialog(
            `¿Anular la venta #${s.id}? Esto repone el inventario descontado.`,
            'Motivo de la anulación (obligatorio)'
          );
          if (!reason) return;
          // Puede rechazar en 409 real (ej. ya se anuló desde otra pestaña
          // justo antes) — sin try/catch quedaba como una excepción sin
          // atrapar, sin avisar nada.
          try {
            await Api.sales.void(s.id, reason);
            UI.toast('Venta anulada');
            render(currentParams());
          } catch (err) {
            UI.toast(err.message, 'error');
            render(currentParams());
          }
        });
        actions.appendChild(btnAnular);
      }
      if (!voided && !s.return_of) {
        const btnDev = document.createElement('button');
        btnDev.className = 'btn btn-sm';
        btnDev.textContent = 'Devolver';
        btnDev.addEventListener('click', () => Devoluciones.open(s.id, { detail: Api.sales.get, submit: Api.sales.returnItems }, () => render(currentParams())));
        actions.appendChild(btnDev);
      }
      grid.appendChild(card);
    });
  }

  function currentParams() {
    const fd = new FormData(form);
    const params = {};
    if (fd.get('from')) params.from = fd.get('from');
    if (fd.get('to')) params.to = fd.get('to');
    if (fd.get('location_id')) params.location_id = fd.get('location_id');
    return params;
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    render(currentParams());
  });
  document.getElementById('btn-historial-limpiar').addEventListener('click', () => {
    form.reset();
    render({});
  });

  window.addEventListener('view:show', async e => {
    if (e.detail.view === 'historial') {
      await loadLocations();
      // Arranca en "hoy" — pedido explícito del dueño: sin esto mostraba
      // las últimas 300 ventas de TODO el historial de una, que no es lo
      // que casi nadie quiere ver al entrar. Si ya había un rango propio
      // puesto (volviendo de otra pantalla), no se pisa — mismo criterio
      // que ya usa Reportes y el Historial del punto de venta.
      if (!fromInput.value && !toInput.value) {
        fromInput.value = toInput.value = localIsoDate();
      }
      render(currentParams());
    }
  });
})();
