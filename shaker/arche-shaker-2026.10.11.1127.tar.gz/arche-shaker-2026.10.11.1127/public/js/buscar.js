/* ═══ Búsqueda global del administrativo (v3.10) ═══
   Ctrl+K (⌘K en Mac), la tecla «/» o la lupa de la barra superior abren un
   buscador que encuentra pantallas, productos, insumos y clientes. Elegir uno
   lleva a su pantalla con el buscador de esa pantalla ya escrito (así se ve
   enseguida, sin tener que buscar otra vez). Respeta los módulos apagados. */
(function () {
  'use strict';
  const app = document.getElementById('owner-app');
  const btn = document.getElementById('buscar-btn');
  if (!app || !btn) return;
  const esc = s => UI.escapeHtml(String(s));
  const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const T = (k, f) => (window.Vocab ? Vocab.t(k, f) : f);

  const PANTALLAS = [
    ['panel', 'Panel', 'inicio resumen hoy ganancia'], ['historial', 'Historial', 'ventas facturas anular devolver'],
    ['inv-existencias', 'Existencias', 'inventario stock bajo'], ['inv-entradas', 'Entradas', 'inventario recibir mercancia'],
    ['compras', 'Compras', 'proveedores ordenes'], ['inv-preparar', 'Preparar', 'cocinar porcionar elaborados'],
    ['inv-transferir', 'Transferir', 'enviar mercancia almacen'], ['inv-ajustes', 'Ajustes y merma', 'corregir perdida vencido'],
    ['menu', () => T('menu', 'Menú'), 'productos catalogo recetas opciones categorias'], ['insumos', () => T('insumos', 'Insumos'), 'costos materia prima'],
    ['ofertas', 'Ofertas', 'combos promociones'], ['reportes', 'Ganancias', 'reportes utilidad margen cierres de caja'],
    ['gastos', 'Gastos', 'alquiler nomina luz'], ['analitica', 'Tendencias', 'horas pico mas vendidos'],
    ['clientes', 'Clientes', 'fiado credito telefono'], ['pagina', 'Página web', 'tienda en linea pedidos fotos horarios'],
    ['empleados', 'Empleados', 'equipo pin cajero rol'], ['turnos', 'Turnos', 'horas llegada salida'],
    ['ubicaciones', 'Ubicaciones', 'locales mesas almacen'], ['configuracion', 'Configuración', 'ajustes marca logo modulos impuestos itbis licencia respaldo contraseña']
  ];
  const label = l => (typeof l === 'function' ? l() : l);

  let datos = null, cargadoEn = 0;
  async function cargar() {
    if (datos && Date.now() - cargadoEn < 120000) return datos;
    const on = m => !window.Modules || Modules.enabled(m);
    const [prods, sups, clis] = await Promise.all([
      Api.products.list().catch(() => []),
      on('insumos') ? Api.supplies.list().catch(() => []) : [],
      on('clientes') ? Api.customers.list().catch(() => []) : []
    ]);
    datos = { prods: prods || [], sups: sups || [], clis: clis || [] };
    cargadoEn = Date.now();
    return datos;
  }

  /* ── Ventana ── */
  const ov = document.createElement('div');
  ov.className = 'buscar-overlay';
  ov.hidden = true;
  ov.innerHTML = `<div class="buscar-box" role="dialog" aria-modal="true" aria-label="Buscar">
      <div class="buscar-input"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>
        <input type="search" id="buscar-q" placeholder="Buscar pantalla, producto, insumo o cliente…" autocomplete="off" spellcheck="false"><kbd>Esc</kbd></div>
      <div class="buscar-res" id="buscar-res" role="listbox"></div>
    </div>`;
  document.body.appendChild(ov);
  const q = ov.querySelector('#buscar-q');
  const res = ov.querySelector('#buscar-res');
  let resultados = [], sel = 0;

  function buscar() {
    const t = norm(q.value.trim());
    const out = [];
    const pantallas = PANTALLAS.filter(([v]) => !(window.Modules && Modules.viewOff(v)));
    pantallas.forEach(([v, l, k]) => { if (!t || norm(label(l) + ' ' + k).includes(t)) out.push({ g: 'Pantallas', t: label(l), s: '', go: v }); });
    if (t && datos) {
      datos.prods.filter(p => p.active !== false && norm(p.name + ' ' + (p.barcode || '') + ' ' + (p.sku || '')).includes(t)).slice(0, 6)
        .forEach(p => out.push({ g: 'Productos', t: p.name, s: fmt(p.sale_price), go: 'menu', campo: 'menu-search', valor: p.name }));
      datos.sups.filter(x => x.active !== false && norm(x.name).includes(t)).slice(0, 6)
        .forEach(x => out.push({ g: label(() => T('insumos', 'Insumos')), t: x.name, s: x.unit || '', go: 'insumos', campo: 'insumos-search', valor: x.name }));
      datos.clis.filter(c => norm((c.name || '') + ' ' + (c.phone || '')).includes(t)).slice(0, 6)
        .forEach(c => out.push({ g: 'Clientes', t: c.name || c.phone, s: c.phone || '', go: 'clientes', campo: 'clientes-search', valor: c.phone || c.name }));
    }
    resultados = t ? out : out.slice(0, 8);
    sel = 0;
    pintar();
  }
  function pintar() {
    if (!resultados.length) { res.innerHTML = '<p class="buscar-vacio">Nada coincide. Prueba con otra palabra.</p>'; return; }
    let grupo = null;
    res.innerHTML = resultados.map((r, i) => {
      const head = r.g !== grupo ? `<p class="buscar-g">${esc(r.g)}</p>` : '';
      grupo = r.g;
      return `${head}<button type="button" class="buscar-item${i === sel ? ' is-sel' : ''}" role="option" aria-selected="${i === sel}" data-i="${i}"><span>${esc(r.t)}</span><small>${esc(r.s)}</small></button>`;
    }).join('');
  }
  function ir(r) {
    if (!r) return;
    cerrar();
    if (r.campo) { const inp = document.getElementById(r.campo); if (inp) inp.value = r.valor; }
    window.showView(r.go);
    window.scrollTo({ top: 0 });
    if (r.campo) setTimeout(() => { const inp = document.getElementById(r.campo); if (inp) { inp.value = r.valor; inp.dispatchEvent(new Event('input', { bubbles: true })); } }, 700);
  }

  async function abrir() {
    if (app.hidden) return;
    ov.hidden = false;
    q.value = '';
    buscar();
    requestAnimationFrame(() => { ov.classList.add('is-open'); q.focus(); });
    await cargar().catch(() => null);
    if (!ov.hidden) buscar();
  }
  function cerrar() { ov.classList.remove('is-open'); ov.hidden = true; }

  btn.addEventListener('click', abrir);
  q.addEventListener('input', buscar);
  q.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(resultados.length - 1, sel + 1); pintar(); res.querySelector('.is-sel')?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); pintar(); res.querySelector('.is-sel')?.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'Enter') { e.preventDefault(); ir(resultados[sel]); }
  });
  res.addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (b) ir(resultados[Number(b.dataset.i)]); });
  ov.addEventListener('click', e => { if (e.target === ov) cerrar(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !ov.hidden) { cerrar(); return; }
    if (app.hidden || !ov.hidden) return;
    const escribiendo = e.target && e.target.matches && e.target.matches('input, textarea, select, [contenteditable]');
    if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) { e.preventDefault(); abrir(); }
    else if (e.key === '/' && !escribiendo) { e.preventDefault(); abrir(); }
  });
  // Lo cambiado en el sistema se ve en la próxima búsqueda.
  window.addEventListener('view:show', () => { cargadoEn = 0; });
})();
