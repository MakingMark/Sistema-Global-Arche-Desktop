/* ═══ Turnos: llegada y salida de cada empleado (dueño) ═══
   El cierre real es que la persona toque "Salir" (close_type='manual') —
   'reported_next_login' es cuando se le olvidó y lo resolvió al volver a
   entrar; 'auto_timeout' es cuando nadie lo resolvió nunca y el sistema lo
   cerró solo (ver shiftService.js). Ninguno de los dos últimos es "malo" en
   sí — son la señal de que a alguien se le está olvidando seguido tocar
   "Salir", que es justo lo que esta pantalla deja ver. */
(function () {
  'use strict';
  const form = document.getElementById('form-turnos');
  if (!form) return;
  const tbody = document.querySelector('#tabla-turnos tbody');
  const nota = document.getElementById('turnos-nota');
  const LIMIT = 200;

  const CLOSE_LABEL = {
    manual: '<span class="badge badge-sage">Cerrado por el empleado</span>',
    reported_next_login: '<span class="badge badge-warn">Reportado al día siguiente</span>',
    auto_timeout: '<span class="badge badge-voided">Cierre automático</span>'
  };

  // localIsoDate/daysAgo ahora son globales — ver api.js.
  function fmtDuration(startIso, endIso) {
    const mins = Math.round((new Date(endIso) - new Date(startIso)) / 60000);
    if (mins < 0) return '—';
    return `${Math.floor(mins / 60)}h ${mins % 60}min`;
  }

  async function loadFilters() {
    const [locations, employees] = await Promise.all([Api.locations.list(), Api.employees.list()]);
    const locSel = form.elements.location_id;
    const keepLoc = locSel.value;
    locSel.innerHTML = '<option value="">Todas</option>' +
      locations.filter(l => l.active).map(l => `<option value="${l.id}">${UI.escapeHtml(l.name)}</option>`).join('');
    locSel.value = keepLoc;
    const empSel = form.elements.employee_id;
    const keepEmp = empSel.value;
    empSel.innerHTML = '<option value="">Todos</option>' +
      employees.map(e => `<option value="${e.id}">${UI.escapeHtml(e.name)}${e.active ? '' : ' (inactivo)'}</option>`).join('');
    empSel.value = keepEmp;
  }

  function params() {
    const fd = new FormData(form);
    const out = { limit: LIMIT };
    for (const [k, v] of fd.entries()) if (v) out[k] = v;
    return out;
  }

  async function render() {
    let rows;
    try {
      rows = await Api.employees.shifts(params());
    } catch (err) {
      UI.toast(err.message, 'error');
      return;
    }
    tbody.innerHTML = rows.map(s => `
      <tr>
        <td data-th="Empleado">${UI.escapeHtml(s.employee_name)}</td>
        <td data-th="Ubicación">${UI.escapeHtml(s.location_name)}</td>
        <td data-th="Llegada">${fmtDate(s.started_at)}</td>
        <td data-th="Salida">${s.ended_at ? fmtDate(s.ended_at) : '<span class="badge badge-warn">Sigue abierto</span>'}</td>
        <td data-th="Duración">${s.ended_at ? fmtDuration(s.started_at, s.ended_at) : '—'}</td>
        <td data-th="Cierre">${s.close_type ? (CLOSE_LABEL[s.close_type] || s.close_type) : ''}</td>
      </tr>
    `).join('') || '<tr><td colspan="6" class="muted">Sin turnos para este filtro.</td></tr>';
    nota.textContent = rows.length >= LIMIT ? `Se muestran los ${LIMIT} más recientes — acota las fechas para ver el resto.` : '';
  }

  form.addEventListener('submit', e => { e.preventDefault(); render(); });
  document.getElementById('btn-turnos-limpiar').addEventListener('click', () => {
    form.reset();
    form.elements.from.value = daysAgo(14);
    form.elements.to.value = localIsoDate();
    render();
  });

  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'turnos') return;
    await loadFilters();
    if (!form.elements.from.value && !form.elements.to.value) {
      form.elements.from.value = daysAgo(14);
      form.elements.to.value = localIsoDate();
    }
    render();
  });
})();
