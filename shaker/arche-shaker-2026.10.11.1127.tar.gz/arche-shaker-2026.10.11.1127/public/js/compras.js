/* ═══ Compras: proveedores y órdenes de compra ═══ */
(function () {
  'use strict';
  const ordersEl = document.getElementById('compras-ordenes');
  if (!ordersEl) return;
  const vendorsEl = document.getElementById('compras-proveedores');
  const estadoSel = document.getElementById('compras-estado');
  const esc = UI.escapeHtml;
  const STATE = { borrador: ['Borrador', 'badge-muted'], enviada: ['Enviada', 'badge-warn'], recibida: ['Recibida', 'badge-ok'], cancelada: ['Cancelada', 'badge-voided'] };
  let vendors = [], supplies = [];

  async function loadBase() {
    [vendors, supplies] = await Promise.all([Api.vendors.list(), Api.supplies.list()]);
    supplies = supplies.filter(s => s.active !== false);
  }
  const vendorName = id => (vendors.find(v => v.id === id) || {}).name || 'Sin proveedor';

  /* ── Órdenes ── */
  async function renderOrders() {
    const list = await Api.purchaseOrders.list(estadoSel.value);
    ordersEl.innerHTML = '';
    if (!list.length) { ordersEl.innerHTML = '<p class="muted">Todavía no hay órdenes. Crea la primera con «+ Nueva orden».</p>'; return; }
    list.forEach(po => {
      const [label, cls] = STATE[po.status] || [po.status, 'badge-muted'];
      const open = po.status === 'borrador' || po.status === 'enviada';
      const card = document.createElement('div');
      card.className = 'product-card' + (po.status === 'cancelada' ? ' row-voided' : '');
      card.innerHTML = `
        <div class="product-card-header">
          <strong>Orden #${po.id}</strong> <span class="badge ${cls}">${label}</span>
          <div class="muted product-card-subtitle">${esc(po.vendor_name || 'Sin proveedor')} · ${fmtDate(po.created_at)}${po.expected_on ? ' · para el ' + esc(po.expected_on) : ''}</div>
        </div>
        <div class="product-card-stats">
          <div><span class="label">Líneas</span><span class="value">${po.items.length}</span></div>
          <div><span class="label">Total</span><span class="value">${fmt(po.total)}</span></div>
        </div>
        <div class="product-card-actions"></div>`;
      const actions = card.querySelector('.product-card-actions');
      const btn = (text, fn, primary) => { const b = document.createElement('button'); b.className = 'btn btn-sm' + (primary ? ' btn-primary' : ''); b.textContent = text; b.addEventListener('click', fn); actions.appendChild(b); };
      btn(open ? 'Editar' : 'Ver', () => editOrder(po.id));
      if (open) {
        btn('Enviar por WhatsApp', () => sendOrder(po.id));
        btn('Recibir', () => receiveOrder(po.id), true);
        btn('Cancelar', async () => { if (await UI.confirmDialog(`¿Cancelar la orden #${po.id}?`)) { try { await Api.purchaseOrders.cancel(po.id); renderOrders(); } catch (e) { UI.toast(e.message, 'error'); } } });
      }
      ordersEl.appendChild(card);
    });
  }

  async function sendOrder(id) {
    try {
      const po = await Api.purchaseOrders.get(id);
      if (!po.whatsapp_url) { UI.toast('Este proveedor no tiene teléfono: agrégalo en Proveedores', 'error'); return; }
      window.open(po.whatsapp_url, '_blank', 'noopener');
      if (po.status === 'borrador') await Api.purchaseOrders.send(id);
      renderOrders();
    } catch (e) { UI.toast(e.message, 'error'); }
  }

  async function editOrder(id) {
    let po = { id: null, vendor_id: null, expected_on: '', notes: '', items: [], status: 'borrador' };
    if (id) { try { po = await Api.purchaseOrders.get(id); } catch (e) { UI.toast(e.message, 'error'); return; } }
    const closed = po.status === 'recibida' || po.status === 'cancelada';
    let lines = po.items.map(i => ({ supply_id: i.supply_id, quantity: i.quantity, unit_cost: i.unit_cost }));
    const supplyOpts = sel => '<option value="">Elige un insumo…</option>' + supplies.map(s => `<option value="${s.id}" ${s.id === sel ? 'selected' : ''}>${esc(s.name)} (${esc(s.unit)})</option>`).join('');
    const modal = UI.showModal(id ? `Orden #${id}` : 'Nueva orden de compra', `
      <div class="field-grid">
        <label class="f"><span>Proveedor</span><select id="po-vendor" ${closed ? 'disabled' : ''}><option value="">Sin proveedor</option>${vendors.filter(v => v.active || v.id === po.vendor_id).map(v => `<option value="${v.id}" ${v.id === po.vendor_id ? 'selected' : ''}>${esc(v.name)}</option>`).join('')}</select></label>
        <label class="f"><span>Fecha esperada (opcional)</span><input type="date" id="po-date" value="${esc(po.expected_on || '')}" ${closed ? 'disabled' : ''}></label>
      </div>
      <label class="f" style="max-width:none"><span>Nota (opcional)</span><input id="po-notes" maxlength="500" value="${esc(po.notes || '')}" ${closed ? 'disabled' : ''}></label>
      <div style="display:flex;gap:10px;align-items:center;justify-content:space-between;margin:12px 0 6px"><strong>Qué se pide</strong>${closed ? '' : '<button type="button" class="btn btn-sm" id="po-suggest">Sugerir lo que falta</button>'}</div>
      <div id="po-lines"></div>
      ${closed ? '' : '<button type="button" class="btn btn-sm" id="po-add" style="margin-top:8px">+ Insumo</button>'}
      <p class="muted" id="po-total" style="margin:10px 0 0"></p>
      <div class="error" id="po-error" role="alert" hidden></div>
      ${closed ? '' : '<div class="modal-actions" style="margin-top:14px"><button class="btn" id="po-cancel">Cerrar</button><button class="btn btn-primary" id="po-save">Guardar orden</button></div>'}`);
    const el = modal.el;
    const paint = () => {
      el.querySelector('#po-lines').innerHTML = lines.length ? lines.map((l, i) => `
        <div class="po-line" data-i="${i}">
          <label class="f"><span>Insumo</span><select data-f="supply_id" ${closed ? 'disabled' : ''}>${supplyOpts(l.supply_id)}</select></label>
          <label class="f"><span>Cantidad</span><input data-f="quantity" type="number" min="0.001" step="any" value="${l.quantity}" ${closed ? 'disabled' : ''}></label>
          <label class="f"><span>Costo unidad</span><input data-f="unit_cost" type="number" min="0" step="any" value="${l.unit_cost}" ${closed ? 'disabled' : ''}></label>
          ${closed ? '' : '<button type="button" class="btn btn-sm" data-rm aria-label="Quitar">Quitar</button>'}
        </div>`).join('') : '<p class="muted">Agrega los insumos que vas a pedir.</p>';
      const total = lines.reduce((a, l) => a + (Number(l.quantity) || 0) * (Number(l.unit_cost) || 0), 0);
      el.querySelector('#po-total').textContent = lines.length ? `Total estimado: ${fmtDec(total)}` : '';
    };
    paint();
    el.addEventListener('change', e => {
      const row = e.target.closest('.po-line'); if (!row) return;
      const l = lines[Number(row.dataset.i)], f = e.target.dataset.f;
      l[f] = f === 'supply_id' ? Number(e.target.value) || null : e.target.value;
      if (f === 'supply_id' && l.supply_id && !Number(l.unit_cost)) { const s = supplies.find(x => x.id === l.supply_id); if (s) l.unit_cost = Number(s.unit_cost) || 0; }
      paint();
    });
    el.addEventListener('input', e => { const row = e.target.closest('.po-line'); if (row && e.target.dataset.f !== 'supply_id') { lines[Number(row.dataset.i)][e.target.dataset.f] = e.target.value; const total = lines.reduce((a, l) => a + (Number(l.quantity) || 0) * (Number(l.unit_cost) || 0), 0); el.querySelector('#po-total').textContent = `Total estimado: ${fmtDec(total)}`; } });
    el.addEventListener('click', e => { const rm = e.target.closest('[data-rm]'); if (rm) { lines.splice(Number(rm.closest('.po-line').dataset.i), 1); paint(); } });
    if (closed) return;
    el.querySelector('#po-add').addEventListener('click', () => { lines.push({ supply_id: null, quantity: 1, unit_cost: 0 }); paint(); });
    el.querySelector('#po-suggest').addEventListener('click', async () => {
      try {
        const vid = el.querySelector('#po-vendor').value;
        const sug = await Api.purchaseOrders.suggest(vid || null);
        if (!sug.length) { UI.toast(vid ? 'Nada que pedir a este proveedor por ahora' : 'Nada se está acabando por ahora'); return; }
        sug.forEach(s => { if (!lines.some(l => l.supply_id === s.supply_id)) lines.push({ supply_id: s.supply_id, quantity: s.suggested, unit_cost: s.unit_cost }); });
        paint();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
    el.querySelector('#po-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#po-save').addEventListener('click', async ev => {
      const err = el.querySelector('#po-error'); err.hidden = true; ev.currentTarget.disabled = true;
      try {
        await Api.purchaseOrders.save(id, {
          vendor_id: el.querySelector('#po-vendor').value ? Number(el.querySelector('#po-vendor').value) : null,
          expected_on: el.querySelector('#po-date').value || null, notes: el.querySelector('#po-notes').value,
          items: lines.map(l => ({ supply_id: l.supply_id, quantity: Number(l.quantity), unit_cost: Number(l.unit_cost) || 0 }))
        });
        modal.close(); UI.toast('Orden guardada'); renderOrders();
      } catch (e) { err.textContent = e.message; err.hidden = false; ev.currentTarget.disabled = false; }
    });
  }

  async function receiveOrder(id) {
    let po; try { po = await Api.purchaseOrders.get(id); } catch (e) { UI.toast(e.message, 'error'); return; }
    const modal = UI.showModal(`Recibir orden #${id}`, `
      <p class="muted" style="margin-top:0">Anota lo que llegó de verdad (cantidad y costo por unidad). Al confirmar, entra al inventario y el costo se promedia con lo que ya había.</p>
      ${po.items.map(i => `<div class="po-line po-receive" data-item="${i.id}">
        <div><strong>${esc(i.supply_name)}</strong><div class="muted small">pedido: ${fmtNum(i.quantity)} ${esc(i.supply_unit)}</div></div>
        <label class="f"><span>Llegó</span><input data-f="quantity" type="number" min="0" step="any" value="${i.quantity}"></label>
        <label class="f"><span>Costo unidad</span><input data-f="unit_cost" type="number" min="0" step="any" value="${i.unit_cost}"></label></div>`).join('')}
      <div class="error" id="rc-error" role="alert" hidden></div>
      <div class="modal-actions" style="margin-top:14px"><button class="btn" id="rc-cancel">Cancelar</button><button class="btn btn-primary" id="rc-ok">Confirmar recepción</button></div>`);
    const el = modal.el;
    el.querySelector('#rc-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#rc-ok').addEventListener('click', async ev => {
      ev.currentTarget.disabled = true;
      const items = Array.from(el.querySelectorAll('[data-item]')).map(r => ({ item_id: Number(r.dataset.item), quantity: r.querySelector('[data-f="quantity"]').value, unit_cost: r.querySelector('[data-f="unit_cost"]').value }));
      try { await Api.purchaseOrders.receive(id, { items }); modal.close(); UI.toast('Mercancía recibida: ya está en el inventario'); renderOrders(); }
      catch (e) { const err = el.querySelector('#rc-error'); err.textContent = e.message; err.hidden = false; ev.currentTarget.disabled = false; }
    });
  }

  /* ── Proveedores ── */
  function renderVendors() {
    vendorsEl.innerHTML = '';
    if (!vendors.length) { vendorsEl.innerHTML = '<p class="muted">Todavía no hay proveedores.</p>'; return; }
    vendors.forEach(v => {
      const card = document.createElement('div');
      card.className = 'product-card' + (v.active ? '' : ' row-inactive');
      card.innerHTML = `
        <div class="product-card-header"><strong>${esc(v.name)}</strong>${v.active ? '' : ' <span class="badge badge-muted">Inactivo</span>'}
          <div class="muted product-card-subtitle">${esc(v.phone || 'sin teléfono')}${v.rnc ? ' · RNC ' + esc(v.rnc) : ''}${v.email ? ' · ' + esc(v.email) : ''}</div></div>
        <div class="product-card-stats"><div><span class="label">Insumos</span><span class="value">${v.supplies_count}</span></div><div><span class="label">Órdenes</span><span class="value">${v.orders_count}</span></div></div>
        <div class="product-card-actions"></div>`;
      const a = card.querySelector('.product-card-actions');
      const btn = (t, fn) => { const b = document.createElement('button'); b.className = 'btn btn-sm'; b.textContent = t; b.addEventListener('click', fn); a.appendChild(b); };
      btn('Editar', () => editVendor(v));
      btn('Sus insumos', () => vendorSupplies(v));
      btn(v.active ? 'Desactivar' : 'Reactivar', async () => { try { await Api.vendors.update(v.id, { ...v, active: !v.active }); await refreshVendors(); } catch (e) { UI.toast(e.message, 'error'); } });
      vendorsEl.appendChild(card);
    });
  }
  async function refreshVendors() { vendors = await Api.vendors.list(); renderVendors(); }

  function editVendor(v) {
    const modal = UI.showModal(`Editar · ${esc(v.name)}`, `
      <div class="field-grid">
        <label class="f"><span>Nombre</span><input id="ev-name" value="${esc(v.name)}" maxlength="100"></label>
        <label class="f"><span>Teléfono / WhatsApp</span><input id="ev-phone" value="${esc(v.phone || '')}"></label>
        <label class="f"><span>RNC</span><input id="ev-rnc" value="${esc(v.rnc || '')}"></label>
        <label class="f"><span>Correo</span><input id="ev-email" type="email" value="${esc(v.email || '')}"></label>
      </div>
      <label class="f" style="max-width:none"><span>Notas</span><input id="ev-notes" maxlength="500" value="${esc(v.notes || '')}"></label>
      <div class="error" id="ev-error" role="alert" hidden></div>
      <div class="modal-actions" style="margin-top:14px"><button class="btn" id="ev-cancel">Cancelar</button><button class="btn btn-primary" id="ev-ok">Guardar</button></div>`);
    const el = modal.el;
    el.querySelector('#ev-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#ev-ok').addEventListener('click', async () => {
      try {
        await Api.vendors.update(v.id, { name: el.querySelector('#ev-name').value, phone: el.querySelector('#ev-phone').value, rnc: el.querySelector('#ev-rnc').value, email: el.querySelector('#ev-email').value, notes: el.querySelector('#ev-notes').value });
        modal.close(); UI.toast('Proveedor actualizado'); refreshVendors();
      } catch (e) { const err = el.querySelector('#ev-error'); err.textContent = e.message; err.hidden = false; }
    });
  }

  // Qué insumos le compras a este proveedor (para sugerir pedidos).
  function vendorSupplies(v) {
    const modal = UI.showModal(`Insumos de ${esc(v.name)}`, `
      <p class="muted" style="margin-top:0">Marca los insumos que le compras a este proveedor. Así «Sugerir lo que falta» arma el pedido correcto.</p>
      <div class="checklist" style="max-height:50vh;overflow:auto">${supplies.map(s => `<label><input type="checkbox" value="${s.id}" ${s.vendor_id === v.id ? 'checked' : ''}> ${esc(s.name)}${s.vendor_id && s.vendor_id !== v.id ? ` <span class="muted">(hoy: ${esc(vendorName(s.vendor_id))})</span>` : ''}</label>`).join('') || '<p class="muted">Todavía no hay insumos.</p>'}</div>
      <div class="modal-actions" style="margin-top:14px"><button class="btn" id="vs-cancel">Cancelar</button><button class="btn btn-primary" id="vs-ok">Guardar</button></div>`);
    const el = modal.el;
    el.querySelector('#vs-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#vs-ok').addEventListener('click', async () => {
      try {
        for (const s of supplies) {
          const on = el.querySelector(`input[value="${s.id}"]`).checked;
          if (on && s.vendor_id !== v.id) await Api.vendors.setSupplyVendor(s.id, v.id);
          else if (!on && s.vendor_id === v.id) await Api.vendors.setSupplyVendor(s.id, null);
        }
        modal.close(); UI.toast('Guardado'); await loadBase(); renderVendors();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  document.getElementById('form-proveedor').addEventListener('submit', async e => {
    e.preventDefault();
    const err = document.getElementById('proveedor-error'); err.hidden = true;
    const fd = new FormData(e.currentTarget);
    try { await Api.vendors.create({ name: fd.get('name'), phone: fd.get('phone'), rnc: fd.get('rnc'), email: fd.get('email') }); e.currentTarget.reset(); UI.toast('Proveedor agregado'); await refreshVendors(); }
    catch (x) { err.textContent = x.message; err.hidden = false; }
  });
  document.getElementById('compras-nueva').addEventListener('click', () => editOrder(null));
  estadoSel.addEventListener('change', renderOrders);

  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'compras') return;
    try { await loadBase(); renderVendors(); await renderOrders(); } catch (err) { UI.toast(err.message, 'error'); }
  });
})();
