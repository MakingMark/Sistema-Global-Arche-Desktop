/* ═══ Menú → Página web: pedidos, horarios y conexión con la página (dueño) ═══ */
(function () {
  'use strict';
  const saveBtn = document.getElementById('web-save');
  if (!saveBtn) return;
  const esc = UI.escapeHtml;
  const $ = id => document.getElementById(id);
  const DAYS = [[1, 'Lun'], [2, 'Mar'], [3, 'Mié'], [4, 'Jue'], [5, 'Vie'], [6, 'Sáb'], [7, 'Dom']];
  let schedules = [];
  let storeHours = [], zones = [];

  /* ── Horario de la tienda y zonas de delivery ── */
  const hoursRow = (h, i) => `<div class="pw-line pw-line--hours" data-hour="${i}">
    <div class="chips chips-wrap">${DAYS.map(([n, l]) => `<button type="button" class="chip${h.days.includes(n) ? ' active' : ''}" data-day="${n}" aria-pressed="${h.days.includes(n)}">${l}</button>`).join('')}</div>
    <input type="time" value="${esc(h.start)}" data-start aria-label="Abre"><input type="time" value="${esc(h.end)}" data-end aria-label="Cierra">
    <button type="button" class="btn btn-sm" data-del aria-label="Quitar franja">×</button></div>`;
  function renderHours() { $('web-hours-list').innerHTML = storeHours.length ? storeHours.map(hoursRow).join('') : '<p class="muted">Sin franjas: la tienda está siempre abierta.</p>'; }
  function readHours() {
    return Array.from($('web-hours-list').querySelectorAll('[data-hour]')).map(r => ({
      days: Array.from(r.querySelectorAll('[data-day].active')).map(b => Number(b.dataset.day)), start: r.querySelector('[data-start]').value, end: r.querySelector('[data-end]').value }));
  }
  $('web-hours-add').addEventListener('click', () => { storeHours = readHours(); storeHours.push({ days: [1, 2, 3, 4, 5, 6, 7], start: '08:00', end: '22:00' }); renderHours(); });
  $('web-hours-list').addEventListener('click', e => {
    const chip = e.target.closest('[data-day]'); if (chip) { chip.classList.toggle('active'); chip.setAttribute('aria-pressed', chip.classList.contains('active')); return; }
    const del = e.target.closest('[data-del]'); if (del) { storeHours = readHours(); storeHours.splice(Number(del.closest('[data-hour]').dataset.hour), 1); renderHours(); }
  });
  const zoneRow = (z, i) => `<div class="pw-line pw-line--zone" data-zone="${i}"><input placeholder="Zona (ej. Centro)" maxlength="40" value="${esc(z.name)}" data-zname><input type="number" min="0" step="1" placeholder="Costo RD$" value="${z.fee === '' ? '' : Number(z.fee)}" data-zfee><button type="button" class="btn btn-sm" data-zdel aria-label="Quitar zona">×</button></div>`;
  function renderZones() { $('web-zones-list').innerHTML = zones.length ? zones.map(zoneRow).join('') : '<p class="muted">Sin zonas: se usa el costo único de delivery.</p>'; }
  const readZones = () => Array.from($('web-zones-list').querySelectorAll('[data-zone]')).map(r => ({ name: r.querySelector('[data-zname]').value.trim(), fee: r.querySelector('[data-zfee]').value }));
  $('web-zones-add').addEventListener('click', () => { zones = readZones(); zones.push({ name: '', fee: '' }); renderZones(); });
  $('web-zones-list').addEventListener('click', e => { const d = e.target.closest('[data-zdel]'); if (d) { zones = readZones(); zones.splice(Number(d.closest('[data-zone]').dataset.zone), 1); renderZones(); } });

  async function load() {
    const [cfg, locations, sch] = await Promise.all([Api.settings.web(), Api.locations.list(), Api.menu.schedules()]);
    $(cfg.web_orders_enabled ? 'web-mode-direct' : 'web-mode-whatsapp').checked = true;
    $('web-paused').checked = !!cfg.web_orders_paused;
    $('web-location').innerHTML = '<option value="">El primer punto de venta</option>' + locations.filter(l => l.kind === 'carrito' && l.active).map(l => `<option value="${l.id}" ${cfg.web_location_id === l.id ? 'selected' : ''}>${esc(l.name)}</option>`).join('');
    $('web-prep').value = cfg.web_prep_minutes;
    $('web-fee').value = Number(cfg.web_delivery_fee);
    $('web-min').value = Number(cfg.web_min_order);
    $('web-message').value = cfg.web_message || '';
    $('web-whatsapp').value = cfg.web_whatsapp_number || '';
    $('web-origins').value = cfg.web_allowed_origins || '';
    $('web-autosend').checked = !!cfg.web_auto_send;
    $('web-expire').value = cfg.web_expire_minutes;
    $('web-blocked').value = cfg.web_blocked_phones || '';
    $('web-require-pay').checked = !!cfg.web_require_payment_confirmation;
    storeHours = Array.isArray(cfg.web_hours) ? cfg.web_hours : []; renderHours();
    zones = (Array.isArray(cfg.web_delivery_zones) ? cfg.web_delivery_zones : []).map(z => ({ name: z.name, fee: z.fee })); renderZones();
    $('web-notify').checked = !!cfg.web_notify_customers;
    schedules = sch;
    renderSchedules();
    const base = location.origin;
    $('web-snippet').textContent = `// En la página, archivo assets/js/config.js — es la única línea que hay que cambiar:\nwindow.SHAKER_API = "${base}";`;
    $('web-preview').href = '/api/public/menu';
  }

  saveBtn.addEventListener('click', async () => {
    $('web-error').hidden = true;
    try {
      await Api.settings.updateWeb({
        web_orders_enabled: $('web-mode-direct').checked, web_orders_paused: $('web-paused').checked,
        web_location_id: $('web-location').value ? Number($('web-location').value) : null,
        web_prep_minutes: Number($('web-prep').value) || 0, web_delivery_fee: Number($('web-fee').value) || 0, web_min_order: Number($('web-min').value) || 0,
        web_message: $('web-message').value.trim(), web_whatsapp_number: $('web-whatsapp').value.replace(/\D/g, ''),
        web_allowed_origins: $('web-origins').value.trim(),
        web_auto_send: $('web-autosend').checked, web_notify_customers: $('web-notify').checked,
        web_expire_minutes: Number($('web-expire').value) || 0, web_blocked_phones: $('web-blocked').value.trim(), web_require_payment_confirmation: $('web-require-pay').checked,
        web_hours: readHours(), web_delivery_zones: readZones().filter(z => z.name || z.fee !== '').map(z => ({ name: z.name, fee: Number(z.fee) }))
      });
      UI.toast('Configuración de la página guardada');
    } catch (err) { $('web-error').textContent = err.message; $('web-error').hidden = false; }
  });

  function renderSchedules() {
    $('web-horarios').innerHTML = schedules.length ? schedules.map(s => `
      <div class="cat-row${s.active ? '' : ' row-inactive'}">
        <div><strong>${esc(s.name)}</strong> ${s.active ? '' : '<span class="badge badge-muted">Apagado</span>'}
          <div class="muted" style="font-size:.85em">${s.days.length === 7 ? 'Todos los días' : s.days.map(d => DAYS[d - 1][1]).join(', ')} · ${s.start_time} a ${s.end_time} · ${s.category_count} categorías, ${s.product_count} platos</div></div>
        <div class="cat-row-actions"><button class="btn btn-sm" data-edit="${s.id}">${UI.iconLabel('edit', 'Editar')}</button><button class="btn btn-sm" data-del="${s.id}">${UI.iconLabel('trash', 'Quitar')}</button></div>
      </div>`).join('') : '<p class="muted">Todavía no hay horarios. Ej.: Desayuno 6:00 a 11:00, Almuerzo 11:00 a 16:00, Cena 17:00 a 22:00.</p>';
    $('web-horarios').querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => edit(schedules.find(s => s.id === Number(b.dataset.edit)))));
    $('web-horarios').querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
      const s = schedules.find(x => x.id === Number(b.dataset.del));
      if (!(await UI.confirmDialog(`¿Quitar el horario "${s.name}"? Lo que lo usaba queda siempre disponible.`))) return;
      try { await Api.menu.removeSchedule(s.id); UI.toast('Horario quitado'); load(); } catch (err) { UI.toast(err.message, 'error'); }
    }));
  }

  function edit(s) {
    const editing = !!s;
    const modal = UI.showModal(editing ? `Editar · ${esc(s.name)}` : 'Horario nuevo', `
      <label class="f" style="max-width:none"><span>Nombre</span><input id="hs-name" maxlength="60" value="${esc(editing ? s.name : '')}" placeholder="ej. Desayuno"></label>
      <div style="margin:12px 0 6px;font-weight:700;font-size:.85em;color:var(--ink-soft)">Días</div>
      <div class="chips chips-wrap" id="hs-days">${DAYS.map(([n, l]) => `<button type="button" class="chip${!editing || s.days.includes(n) ? ' active' : ''}" data-day="${n}" aria-pressed="${!editing || s.days.includes(n)}">${l}</button>`).join('')}</div>
      <div class="field-grid" style="margin-top:12px">
        <label class="f"><span>Desde</span><input id="hs-start" type="time" value="${editing ? s.start_time : '06:00'}"></label>
        <label class="f"><span>Hasta</span><input id="hs-end" type="time" value="${editing ? s.end_time : '11:00'}"></label>
      </div>
      <p class="muted" style="font-size:.85em">Si “Hasta” es antes que “Desde” (ej. 18:00 a 02:00), la franja cruza la medianoche. Hora de Santo Domingo.</p>
      ${editing ? `<label class="f-check"><input type="checkbox" id="hs-active" ${s.active ? 'checked' : ''}><span>Activo</span></label>` : ''}
      <div class="modal-actions" style="margin-top:16px"><button class="btn" id="hs-cancel">Cancelar</button><button class="btn btn-primary" id="hs-save">Guardar</button></div>`);
    const el = modal.el;
    el.querySelectorAll('[data-day]').forEach(b => b.addEventListener('click', () => { b.classList.toggle('active'); b.setAttribute('aria-pressed', b.classList.contains('active')); }));
    el.querySelector('#hs-cancel').addEventListener('click', () => modal.close());
    el.querySelector('#hs-save').addEventListener('click', async () => {
      const body = {
        name: el.querySelector('#hs-name').value.trim(), days: Array.from(el.querySelectorAll('[data-day].active')).map(b => Number(b.dataset.day)),
        start_time: el.querySelector('#hs-start').value, end_time: el.querySelector('#hs-end').value
      };
      if (editing) body.active = el.querySelector('#hs-active').checked;
      try {
        if (editing) await Api.menu.updateSchedule(s.id, body); else await Api.menu.createSchedule(body);
        modal.close(); UI.toast('Horario guardado'); load();
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  }
  $('btn-horario-nuevo').addEventListener('click', () => edit(null));

  document.querySelector('[data-view="pagina"] [data-subtab="pedidos"]').addEventListener('click', () => load().catch(err => UI.toast(err.message, 'error')));
})();
