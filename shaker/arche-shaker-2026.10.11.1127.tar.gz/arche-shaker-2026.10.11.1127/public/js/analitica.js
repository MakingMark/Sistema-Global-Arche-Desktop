/* ═══ Tendencias (antes Analítica): patrones de las ventas de los PUNTOS DE VENTA (dueño) ═══
   Un período elegido (por defecto, las últimas 4 semanas) comparado contra el
   período anterior de la misma duración, repartido en cuatro pestañas por
   pregunta: Resumen (¿cómo voy?), Cuándo (¿en qué día y hora se vende más?),
   Puntos de venta (¿quién vende más, y qué días?) y Productos (¿qué se vende?).
   Ver server/routes/trends.js (GET /api/reports/trends). */
(function () {
  'use strict';
  const view = document.querySelector('section.view[data-view="analitica"]');
  if (!view) return;

  const chipsEl = document.getElementById('trend-chips');
  const rangeEl = document.getElementById('trend-range');
  const fromInput = document.getElementById('trend-from');
  const toInput = document.getElementById('trend-to');
  const locationSelect = document.getElementById('trend-location');
  const summaryEl = document.getElementById('trend-summary');
  const bodyEl = document.getElementById('trend-body');
  const emptyEl = document.getElementById('analitica-sin-datos');
  const tabs = view.querySelectorAll('[data-ttab]');
  const panels = view.querySelectorAll('[data-tpanel]');

  const DIAS = ['', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  const DIAS_CORTO = ['', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  const esc = UI.escapeHtml;

  let period = '4-weeks';
  let data = null;
  let productsOrder = 'mas';
  let loadSeq = 0;

  /* ── Fechas (siempre componentes LOCALES — nunca toISOString, que en
     Santo Domingo se adelanta un día entre las 8 pm y la medianoche) ── */
  const pad = n => String(n).padStart(2, '0');
  const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const mondayOf = d => addDays(d, -((d.getDay() + 6) % 7));
  function shortDay(s) {
    return parse(s).toLocaleDateString('es-DO', { day: 'numeric', month: 'short' }).replace('.', '');
  }
  function rangeLabel(from, to) {
    return from === to ? shortDay(from) : `${shortDay(from)} – ${shortDay(to)}`;
  }

  // Versión corta para encabezados de fila: "24–30 ago" o "31 ago–6 sept".
  function rangeShort(from, to) {
    const a = parse(from), b = parse(to);
    const mon = d => d.toLocaleDateString('es-DO', { month: 'short' }).replace('.', '');
    return a.getMonth() === b.getMonth() ? `${a.getDate()}–${b.getDate()} ${mon(b)}` : `${a.getDate()} ${mon(a)}–${b.getDate()} ${mon(b)}`;
  }

  function computeRange(kind) {
    const today = new Date();
    if (kind === 'this-week') return { from: iso(mondayOf(today)), to: iso(today), compare: true };
    if (kind === 'last-week') {
      const mon = addDays(mondayOf(today), -7);
      return { from: iso(mon), to: iso(addDays(mon, 6)), compare: true };
    }
    if (kind === '4-weeks') return { from: iso(addDays(today, -27)), to: iso(today), compare: true };
    if (kind === 'this-month') return { from: iso(new Date(today.getFullYear(), today.getMonth(), 1)), to: iso(today), compare: true };
    if (kind === 'last-month') {
      return {
        from: iso(new Date(today.getFullYear(), today.getMonth() - 1, 1)),
        to: iso(new Date(today.getFullYear(), today.getMonth(), 0)), compare: true
      };
    }
    if (kind === 'all') return { from: '2020-01-01', to: iso(today), compare: false };
    const from = fromInput.value, to = toInput.value;
    return from && to && from <= to ? { from, to, compare: true } : null;
  }

  /* ── Formatos ── */
  function fmtK(v) {
    v = Number(v) || 0;
    if (v >= 100000) return Math.round(v / 1000) + 'k';
    if (v >= 1000) return (Math.round(v / 100) / 10).toString().replace('.0', '') + 'k';
    return String(Math.round(v));
  }
  function hourLabel(h) {
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return `${h12} ${h < 12 ? 'a. m.' : 'p. m.'}`;
  }
  // Cambio contra el período anterior — siempre flecha + texto (nunca solo
  // color) para que se entienda igual sin distinguir rojo de verde.
  function deltaChip(cur, prev, label) {
    if (prev == null) return '';
    const title = label ? ` title="${esc(label)}"` : '';
    if (!prev) return cur > 0 ? `<span class="delta is-new"${title}>nuevo</span>` : '';
    const pct = (cur - prev) / prev * 100;
    if (Math.abs(pct) < 0.5) return `<span class="delta"${title}>= igual</span>`;
    const up = pct > 0;
    return `<span class="delta ${up ? 'is-up' : 'is-down'}"${title}>${up ? '▲' : '▼'} ${Math.abs(Math.round(pct))}%</span>`;
  }
  function maxBy(rows, fn) {
    return rows.reduce((best, r) => (best === null || fn(r) > fn(best)) ? r : best, null);
  }
  function minBy(rows, fn) {
    return rows.reduce((worst, r) => (worst === null || fn(r) < fn(worst)) ? r : worst, null);
  }
  // Intensidad 0–1 → un tinte de la marca sobre el fondo del propio tema
  // (semitransparente: se ve igual en claro y en oscuro).
  function heatBg(ratio) {
    if (!(ratio > 0)) return '';
    return `background:color-mix(in srgb, var(--orange) ${Math.round(8 + ratio * 42)}%, transparent)`;
  }

  /* ── Resumen ── */
  function renderKpis() {
    const cur = data.kpis.current, prev = data.kpis.previous;
    const items = [
      { label: 'Ventas', value: fmt(cur.total), delta: deltaChip(cur.total, prev && prev.total, prev && `Antes: ${fmt(prev.total)}`) },
      { label: 'Ganancia', value: fmt(cur.profit), delta: deltaChip(cur.profit, prev && prev.profit, prev && `Antes: ${fmt(prev.profit)}`) },
      { label: 'Facturas', value: fmtNum(cur.sales_count), delta: deltaChip(cur.sales_count, prev && prev.sales_count, prev && `Antes: ${fmtNum(prev.sales_count)}`) },
      { label: 'Ticket promedio', value: fmt(cur.avg_ticket), delta: deltaChip(cur.avg_ticket, prev && prev.avg_ticket, prev && `Antes: ${fmt(prev.avg_ticket)}`) }
    ];
    document.getElementById('trend-kpis').innerHTML = items.map(k => `
      <div class="kpi"><div class="label">${k.label}</div><div class="value">${k.value}</div><div class="kpi-delta">${k.delta || '&nbsp;'}</div></div>
    `).join('');
  }

  // Lista de todos los lunes entre dos fechas (para que una semana sin
  // ventas salga como barra vacía y no desaparezca del gráfico).
  function weeksBetween(from, to) {
    const out = [];
    for (let d = mondayOf(parse(from)); d <= parse(to); d = addDays(d, 7)) out.push(iso(d));
    return out;
  }

  function vbars(items, { colorFn } = {}) {
    const max = Math.max(...items.map(i => i.value), 0);
    return `<div class="vbars" role="list">${items.map(i => {
      const h = max > 0 ? Math.max(i.value / max * 100, i.value > 0 ? 3 : 0) : 0;
      return `
        <div class="vbar" role="listitem" title="${esc(i.title)}" aria-label="${esc(i.title)}">
          <span class="vbar-val">${i.value > 0 ? fmtK(i.value) : ''}</span>
          <span class="vbar-track"><span class="vbar-fill ${colorFn ? colorFn(i) : ''}" style="height:${h}%"></span></span>
          <span class="vbar-label">${i.label}</span>
        </div>`;
    }).join('')}</div>`;
  }

  function renderWeekly() {
    const el = document.getElementById('trend-weekly');
    const noteEl = document.getElementById('trend-weekly-note');
    const totals = {};
    data.weekly.forEach(r => { totals[r.week_start] = (totals[r.week_start] || 0) + r.total; });
    let weeks = weeksBetween(data.period.from, data.period.to);
    const capped = weeks.length > 12;
    if (capped) weeks = weeks.slice(-12);
    const items = weeks.map(w => {
      const d = parse(w);
      const end = addDays(d, 6);
      return {
        value: totals[w] || 0,
        label: `<b>${d.getDate()}</b><small>${d.toLocaleDateString('es-DO', { month: 'short' }).replace('.', '')}</small>`,
        title: `Semana del ${rangeLabel(w, iso(end))}: ${fmt(totals[w] || 0)}`
      };
    });
    const best = maxBy(items, i => i.value);
    el.innerHTML = vbars(items, { colorFn: i => (i === best && i.value > 0) ? 'is-best' : '' });
    const partial = parse(data.period.from).getDay() !== 1 || parse(data.period.to).getDay() !== 0;
    noteEl.textContent = [
      'Cada barra es una semana (lunes a domingo), rotulada con su lunes.',
      partial ? 'La primera y la última pueden estar incompletas, según el período elegido.' : '',
      capped ? 'Se muestran las últimas 12 semanas.' : ''
    ].filter(Boolean).join(' ');
  }

  // Promedio de un punto de venta en un día que abrió, por día de la semana — todos
  // juntos: suma de ventas ÷ suma de "días que abrió" de cada uno.
  function weekdayAverages() {
    const acc = {};
    data.weekdayByLocation.forEach(r => {
      const a = acc[r.weekday] || (acc[r.weekday] = { total: 0, days: 0, count: 0 });
      a.total += r.total; a.days += r.selling_days; a.count += r.sales_count;
    });
    return [1, 2, 3, 4, 5, 6, 7].map(d => ({
      weekday: d, avg: acc[d] && acc[d].days ? acc[d].total / acc[d].days : 0,
      total: acc[d] ? acc[d].total : 0, count: acc[d] ? acc[d].count : 0
    }));
  }

  function renderHighlights(avgs) {
    const cards = [];
    if (data.comparison.length > 1) {
      const top = data.comparison[0];
      cards.push(['Punto de venta que más vendió', esc(top.location_name), fmt(top.total)]);
    }
    const bestDay = maxBy(avgs.filter(a => a.avg > 0), a => a.avg);
    if (bestDay) cards.push(['Mejor día', DIAS[bestDay.weekday], `${fmt(bestDay.avg)} por punto de venta`]);
    const hourTotals = {};
    data.hours.forEach(h => { hourTotals[h.hour] = (hourTotals[h.hour] || 0) + h.sales_count; });
    const bestHour = maxBy(Object.entries(hourTotals).map(([hour, n]) => ({ hour: Number(hour), n })), h => h.n);
    if (bestHour) cards.push(['Hora más fuerte', hourLabel(bestHour.hour), `${fmtNum(bestHour.n)} facturas`]);
    if (data.products.length) cards.push(['Producto más vendido', esc(data.products[0].product_name), `${fmtNum(data.products[0].quantity)} vendidos`]);
    if (data.categories.length) cards.push(['Categoría que más factura', esc(data.categories[0].category_name), fmt(data.categories[0].revenue)]);
    document.getElementById('trend-highlights').innerHTML = cards.map(([label, value, sub]) => `
      <div class="hl"><div class="label">${label}</div><div class="hl-value">${value}</div><div class="muted">${sub}</div></div>
    `).join('') || '<p class="muted">Todavía no hay datos suficientes.</p>';
  }

  const CANALES = { mostrador: 'Mostrador (venta rápida)', mesa: 'Mesas', llevar: 'Para llevar', web: 'Página web / WhatsApp', telefono: 'Teléfono' };
  function renderChannels() {
    document.querySelector('#tabla-trend-canales tbody').innerHTML = (data.channels || []).map(c => `
      <tr><td data-th="Canal">${esc(CANALES[c.channel] || c.channel)}</td><td class="num" data-th="Facturas">${c.sales_count}</td><td class="num" data-th="Ventas">${fmt(c.total)}</td><td class="num" data-th="Ganancia">${fmt(c.profit)}</td></tr>
    `).join('') || '<tr><td colspan="4" class="muted">Sin ventas.</td></tr>';
  }

  function renderPayments() {
    document.querySelector('#tabla-trend-pagos tbody').innerHTML = data.payments.map(p => `
      <tr><td data-th="Método">${esc(p.payment_method)}</td><td class="num" data-th="Facturas">${p.sales_count}</td><td class="num" data-th="Total">${fmt(p.total)}</td></tr>
    `).join('') || '<tr><td colspan="3" class="muted">Sin ventas.</td></tr>';
  }

  /* ── Cuándo ── */
  function renderWeekday(avgs) {
    const withData = avgs.filter(a => a.avg > 0);
    const best = maxBy(withData, a => a.avg);
    const worst = withData.length > 1 ? minBy(withData, a => a.avg) : null;
    document.getElementById('trend-weekday').innerHTML = vbars(avgs.map(a => ({
      value: a.avg,
      label: `<b>${DIAS_CORTO[a.weekday]}</b>`,
      title: `${DIAS[a.weekday]}: ${fmt(a.avg)} por punto de venta y día abierto (${fmtNum(a.count)} facturas en total)`,
      day: a
    })), { colorFn: i => i.day === best ? 'is-best' : (i.day === worst ? 'is-worst' : '') });
  }

  function renderHeat() {
    const el = document.getElementById('trend-heat');
    const noteEl = document.getElementById('trend-heat-note');
    if (!data.hours.length) { el.innerHTML = ''; noteEl.textContent = ''; return; }
    const minH = Math.min(...data.hours.map(h => h.hour));
    const maxH = Math.max(...data.hours.map(h => h.hour));
    const cell = new Map(data.hours.map(h => [`${h.weekday}_${h.hour}`, h]));
    const max = Math.max(...data.hours.map(h => h.sales_count));
    const bestCell = maxBy(data.hours, h => h.sales_count);
    let html = '<table class="heat"><thead><tr><th></th>' + [1, 2, 3, 4, 5, 6, 7].map(d => `<th scope="col">${DIAS_CORTO[d]}</th>`).join('') + '</tr></thead><tbody>';
    for (let h = minH; h <= maxH; h++) {
      html += `<tr><th scope="row">${hourLabel(h)}</th>`;
      for (let d = 1; d <= 7; d++) {
        const c = cell.get(`${d}_${h}`);
        const n = c ? c.sales_count : 0;
        const isBest = c && c === bestCell;
        html += `<td class="${isBest ? 'is-best' : ''}" style="${heatBg(n / max)}" title="${DIAS[d]} ${hourLabel(h)}: ${n} facturas${c ? ' · ' + fmt(c.total) : ''}">${n || ''}</td>`;
      }
      html += '</tr>';
    }
    el.innerHTML = html + '</tbody></table>';
    noteEl.textContent = bestCell
      ? `La franja más fuerte: ${DIAS[bestCell.weekday].toLowerCase()} a las ${hourLabel(bestCell.hour)} (${fmtNum(bestCell.sales_count)} facturas).`
      : '';
  }

  /* ── Carritos ── */
  function renderRank() {
    const rows = data.comparison;
    const max = Math.max(...rows.map(r => r.total), 0);
    const compare = data.period.compare;
    document.getElementById('trend-rank').innerHTML = rows.map((r, idx) => `
      <div class="rank-row">
        <div class="rank-head">
          <span class="rank-pos">${idx + 1}</span>
          <strong class="rank-name">${esc(r.location_name)}</strong>
          <span class="rank-value">${fmt(r.total)}</span>
          ${compare ? deltaChip(r.total, r.prev_total, `Antes: ${fmt(r.prev_total)}`) : ''}
        </div>
        <div class="rank-bar"><span style="width:${max ? Math.max(r.total / max * 100, 2) : 0}%"></span></div>
        <div class="muted rank-meta">${fmtNum(r.sales_count)} facturas · ticket ${fmt(r.avg_ticket)} · ganancia ${fmt(r.profit)}</div>
      </div>
    `).join('') || '<p class="muted">Sin ventas en este período.</p>';
  }

  function matrix(headers, rows, { rowBest = true } = {}) {
    // rows: [{ label, cells: [{value, title}|null] }]. Color: global (mismo
    // máximo para toda la tabla, así se comparan carritos entre sí);
    // negrita/tenue: mejor y peor de CADA fila.
    const all = rows.flatMap(r => r.cells.filter(Boolean).map(c => c.value));
    const gmax = Math.max(...all, 0);
    return `<table class="matrix"><thead><tr><th></th>${headers.map(h => `<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${
      rows.map(r => {
        const vals = r.cells.map(c => c ? c.value : null);
        const present = vals.filter(v => v != null && v > 0);
        const best = present.length ? Math.max(...present) : null;
        const worst = present.length > 1 ? Math.min(...present) : null;
        return `<tr><th scope="row">${r.label}</th>${r.cells.map((c, i) => {
          if (!c) return '<td class="muted" title="No abrió">—</td>';
          const cls = rowBest ? (c.value === best ? 'is-best' : (c.value === worst && worst !== best ? 'is-worst' : '')) : (c.value === best ? 'is-best' : '');
          return `<td class="${cls}" style="${heatBg(gmax ? c.value / gmax : 0)}" title="${esc(c.title)}">${fmtK(c.value)}</td>`;
        }).join('')}</tr>`;
      }).join('')}</tbody></table>`;
  }

  function renderMatrix() {
    const carts = data.comparison;
    const byKey = new Map(data.weekdayByLocation.map(r => [`${r.location_id}_${r.weekday}`, r]));
    const rows = carts.map(c => ({
      label: esc(c.location_name),
      cells: [1, 2, 3, 4, 5, 6, 7].map(d => {
        const r = byKey.get(`${c.location_id}_${d}`);
        if (!r || !r.selling_days) return null;
        const avg = r.total / r.selling_days;
        return { value: avg, title: `${c.location_name} · ${DIAS[d]}: ${fmt(avg)} por día abierto (${r.selling_days} ${r.selling_days === 1 ? 'día' : 'días'}, ${fmtNum(r.sales_count)} facturas)` };
      })
    }));
    document.getElementById('trend-matrix').innerHTML = carts.length ? matrix(DIAS_CORTO.slice(1), rows) : '<p class="muted">Sin ventas en este período.</p>';
    // Frase por carrito: mejor y peor día, para leerlo sin descifrar colores.
    document.getElementById('trend-matrix-notes').innerHTML = carts.map((c, i) => {
      const vals = rows[i].cells.map((cell, idx) => cell ? { day: idx + 1, v: cell.value } : null).filter(Boolean);
      if (!vals.length) return '';
      const best = maxBy(vals, x => x.v);
      const worst = vals.length > 1 ? minBy(vals, x => x.v) : null;
      return `<li><strong>${esc(c.location_name)}:</strong> mejor día, ${DIAS[best.day].toLowerCase()} (${fmt(best.v)})${worst && worst.day !== best.day ? `; el más flojo, ${DIAS[worst.day].toLowerCase()} (${fmt(worst.v)})` : ''}.</li>`;
    }).join('');
  }

  function renderWeeksMatrix() {
    const carts = data.comparison;
    let weeks = weeksBetween(data.period.from, data.period.to);
    if (weeks.length > 12) weeks = weeks.slice(-12);
    const byKey = new Map(data.weekly.map(r => [`${r.week_start}_${r.location_id}`, r.total]));
    const rows = weeks.map(w => ({
      label: rangeShort(w, iso(addDays(parse(w), 6))),
      cells: carts.map(c => {
        const v = byKey.get(`${w}_${c.location_id}`);
        return v ? { value: v, title: `${c.location_name} · semana del ${rangeLabel(w, iso(addDays(parse(w), 6)))}: ${fmt(v)}` } : null;
      })
    }));
    document.getElementById('trend-weeks-matrix').innerHTML = carts.length
      ? matrix(carts.map(c => esc(c.location_name)), rows, { rowBest: false })
      : '<p class="muted">Sin ventas en este período.</p>';
  }

  /* ── Productos ── */
  function rankList(rows, { emptyText, order, tagMost, tagLeast }) {
    if (!rows.length) return `<p class="muted">${emptyText}</p>`;
    const total = rows.reduce((s, r) => s + r.quantity, 0);
    const sorted = [...rows].sort((a, b) => order === 'menos' ? a.quantity - b.quantity : b.quantity - a.quantity);
    const max = Math.max(...rows.map(r => r.quantity));
    const compare = data.period.compare;
    return sorted.map((r, idx) => `
      <div class="rank-row">
        <div class="rank-head">
          <span class="rank-pos">${idx + 1}</span>
          <strong class="rank-name">${esc(r.product_name)}${idx === 0 ? ` <span class="${order === 'menos' ? 'warn-tag' : 'best-tag'}">${order === 'menos' ? tagLeast : tagMost}</span>` : ''}</strong>
          <span class="rank-value">${fmtNum(r.quantity)}</span>
          ${compare ? deltaChip(r.quantity, r.prev_quantity, `Antes: ${fmtNum(r.prev_quantity)}`) : ''}
        </div>
        <div class="rank-bar"><span style="width:${max ? Math.max(r.quantity / max * 100, 2) : 0}%"></span></div>
        <div class="muted rank-meta">${total ? Math.round(r.quantity / total * 100) : 0}% del total · ingreso ${fmt(r.revenue)} · ganancia ${fmt(r.profit)}</div>
      </div>
    `).join('');
  }

  function renderProducts() {
    document.getElementById('trend-productos').innerHTML = rankList(data.products, {
      emptyText: 'Todavía no se vendió ningún producto en este período.', order: productsOrder, tagMost: 'más vendido', tagLeast: 'menos vendido'
    });
    // Las categorías se ordenan por ingreso (no por cantidad): comparar
    // "platos" con "botellas de agua" por unidades no dice nada.
    const catTotal = data.categories.reduce((s, c) => s + c.revenue, 0);
    const catMax = Math.max(...data.categories.map(c => c.revenue), 0);
    document.getElementById('trend-categorias').innerHTML = data.categories.map((c, idx) => `
      <div class="rank-row">
        <div class="rank-head">
          <span class="rank-pos">${idx + 1}</span>
          <strong class="rank-name">${esc(c.category_name)}</strong>
          <span class="rank-value">${fmt(c.revenue)}</span>
        </div>
        <div class="rank-bar"><span style="width:${catMax ? Math.max(c.revenue / catMax * 100, 2) : 0}%"></span></div>
        <div class="muted rank-meta">${catTotal ? Math.round(c.revenue / catTotal * 100) : 0}% del total · ${fmtNum(c.quantity)} vendidos · ganancia ${fmt(c.profit)}</div>
      </div>
    `).join('') || '<p class="muted">Todavía no hay ventas en este período.</p>';
    document.querySelector('#tabla-trend-parejas tbody').innerHTML = data.pairings.map(p => `
      <tr><td data-th="Producto">${esc(p.product_a)}</td><td data-th="Junto con">${esc(p.product_b)}</td><td class="num" data-th="Veces">${p.times}</td></tr>
    `).join('') || '<tr><td colspan="3" class="muted">Todavía no hay ventas con más de un producto.</td></tr>';
    document.querySelector('#tabla-trend-ofertas tbody').innerHTML = data.offers.map(o => `
      <tr><td data-th="Oferta">${esc(o.name)}</td><td class="num" data-th="Veces vendida">${o.times_sold}</td><td class="num" data-th="Ingreso">${fmt(o.revenue)}</td><td class="num" data-th="Ganancia">${fmt(o.profit)}</td></tr>
    `).join('') || '<tr><td colspan="4" class="muted">Todavía no se vendió ninguna oferta.</td></tr>';
  }

  /* ── Carga y orquestación ── */
  function renderAll() {
    const empty = !data.kpis.current.sales_count;
    emptyEl.hidden = !empty;
    bodyEl.hidden = empty;
    const p = data.period;
    summaryEl.textContent = `Ventas de los puntos de venta del ${rangeLabel(p.from, p.to)}` +
      (p.compare ? ` · comparado con ${rangeLabel(p.prev_from, p.prev_to)}` : '') +
      '. Las cifras son netas (sin ITBIS ni propina).';
    if (empty) return;
    const avgs = weekdayAverages();
    renderKpis();
    renderWeekly();
    renderHighlights(avgs);
    renderPayments();
    renderChannels();
    renderWeekday(avgs);
    renderHeat();
    renderRank();
    renderMatrix();
    renderWeeksMatrix();
    renderProducts();
  }

  async function load() {
    const range = computeRange(period);
    if (!range) { UI.toast('Elige las dos fechas del rango (Desde no puede ser posterior a Hasta)', 'error'); return; }
    const seq = ++loadSeq;
    view.setAttribute('aria-busy', 'true');
    try {
      const params = { from: range.from, to: range.to, compare: range.compare ? '1' : '0' };
      if (locationSelect.value) params.location_id = locationSelect.value;
      const trends = await Api.reports.trends(params);
      if (seq !== loadSeq) return; // llegó una respuesta más nueva mientras tanto
      data = trends;
      renderAll();
    } catch (err) {
      UI.toast(err.message, 'error');
    } finally {
      if (seq === loadSeq) view.removeAttribute('aria-busy');
    }
  }

  async function loadLocations() {
    const keep = locationSelect.value;
    const locations = await Api.locations.list();
    // Solo puntos de venta activos (el almacén no vende).
    locationSelect.innerHTML = '<option value="">Todos los puntos de venta</option>' +
      locations.filter(l => l.active && l.kind === 'carrito').map(l => `<option value="${l.id}">${esc(l.name)}</option>`).join('');
    locationSelect.value = keep;
  }

  function showTab(name) {
    tabs.forEach(t => {
      const on = t.dataset.ttab === name;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', String(on));
    });
    panels.forEach(p => { p.hidden = p.dataset.tpanel !== name; });
  }

  tabs.forEach(t => t.addEventListener('click', () => {
    showTab(t.dataset.ttab);
    t.scrollIntoView({ inline: 'center', block: 'nearest' }); // en celular la fila de pestañas se desliza
  }));

  chipsEl.addEventListener('click', e => {
    const chip = e.target.closest('[data-period]');
    if (!chip) return;
    period = chip.dataset.period;
    chipsEl.querySelectorAll('.chip').forEach(c => {
      const on = c === chip;
      c.classList.toggle('active', on);
      c.setAttribute('aria-pressed', String(on));
    });
    rangeEl.hidden = period !== 'custom';
    if (period === 'custom') {
      // Arranca con las últimas 4 semanas ya escritas, para no dejar dos
      // campos vacíos que obliguen a llenarlos antes de ver algo.
      if (!fromInput.value || !toInput.value) {
        const r = computeRange('4-weeks');
        fromInput.value = r.from; toInput.value = r.to;
      }
      fromInput.focus();
      return;
    }
    load();
  });
  document.getElementById('trend-range-apply').addEventListener('click', load);
  locationSelect.addEventListener('change', load);
  function bindProductsOrder() {
    document.getElementById('trend-productos-order').addEventListener('click', e => {
      const btn = e.target.closest('[data-order]');
      if (!btn || !data) return;
      productsOrder = btn.dataset.order;
      document.querySelectorAll('#trend-productos-order .seg').forEach(b => {
        const on = b === btn;
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', String(on));
      });
      renderProducts();
    });
  }

  bindProductsOrder();

  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'analitica') return;
    await loadLocations();
    load();
  });
})();
