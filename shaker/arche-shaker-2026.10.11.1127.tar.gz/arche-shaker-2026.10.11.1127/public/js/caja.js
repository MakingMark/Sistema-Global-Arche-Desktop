/* ═══ Caja del punto de venta: abrir, anotar entradas/salidas y cerrar ═══ */
(function () {
  'use strict';
  const closedCard = document.getElementById('caja-cerrada');
  if (!closedCard) return;
  const esc = UI.escapeHtml;
  const $ = id => document.getElementById(id);
  let session = null;

  const showError = msg => { $('caja-error').textContent = msg || ''; $('caja-error').hidden = !msg; };
  const isPos = () => { const s = Auth.get(); return !!s && s.role === 'cart'; };

  // v3.9: estado de la caja en la barra superior (sin entrar a Caja) y montos
  // rápidos para el fondo inicial (el último usado en este equipo primero).
  const pill = $('ux-caja');
  const FONDO_KEY = 'arche_ultimo_fondo';
  let estadoConocido = false;
  function pintarPill() {
    const on = !window.Modules || Modules.enabled('caja');
    pill.hidden = !on || !isPos() || !estadoConocido;
    if (pill.hidden) return;
    pill.classList.toggle('is-open', !!session);
    pill.innerHTML = session ? '<i></i>Caja abierta' : '<i></i>Caja cerrada';
    pill.title = session ? 'Ver la caja' : 'Abrir la caja';
  }
  pill.addEventListener('click', () => window.showView('pos-caja'));
  function pintarFondos() {
    let ultimo = null; try { ultimo = localStorage.getItem(FONDO_KEY); } catch (_) {}
    const montos = [...new Set([ultimo !== null ? Number(ultimo) : null, 0, 500, 1000, 2000].filter(v => v !== null && !isNaN(v)))].slice(0, 5);
    $('caja-fondo-chips').innerHTML = montos.map(v => `<button type="button" class="cash-chip" data-fondo="${v}">${v === Number(ultimo) && ultimo !== null ? '↺ ' : ''}${fmt(v)}</button>`).join('');
  }
  $('caja-fondo-chips').addEventListener('click', e => {
    const b = e.target.closest('[data-fondo]');
    if (!b) return;
    $('caja-fondo').value = b.dataset.fondo;
    $('caja-fondo-chips').querySelectorAll('.cash-chip').forEach(c => c.classList.toggle('is-active', c === b));
  });

  function render() {
    estadoConocido = true;
    pintarPill();
    if (!session) pintarFondos();
    closedCard.hidden = !!session;
    $('caja-abierta').hidden = !session;
    if (!session) return;
    $('caja-desde').textContent = `· abierta ${fmtDate(session.opened_at)}`;
    $('caja-resumen').innerHTML =
      `<div class="stat"><div class="label">Fondo</div><div class="value">${fmtDec(session.opening_amount)}</div></div>` +
      `<div class="stat"><div class="label">Ventas en efectivo</div><div class="value">${fmtDec(session.cash_sales)}</div></div>` +
      (Number(session.credit_payments) > 0 ? `<div class="stat"><div class="label">Abonos de clientes (efectivo)</div><div class="value">${fmtDec(session.credit_payments)}</div></div>` : '') +
      `<div class="stat"><div class="label">Debería haber</div><div class="value">${fmtDec(session.expected_now)}</div></div>`;
    const other = session.by_method.filter(m => m.method !== 'efectivo');
    $('caja-metodos').textContent = other.length ? 'No pasan por el cajón: ' + other.map(m => `${m.method} ${fmtDec(m.total)} (${m.sales_count})`).join(' · ') : '';
    $('caja-movimientos').innerHTML = session.movements.length ? session.movements.map(m =>
      `<div class="expiry-row"><span><strong>${m.kind === 'entrada' ? '+' : '−'} ${fmtDec(m.amount)}</strong> <span class="muted">· ${esc(m.reason)}</span></span><span class="muted">${fmtDate(m.created_at)}</span></div>`).join('') : '<p class="muted">Sin movimientos.</p>';
    updateDiff();
  }

  function updateDiff() {
    const el = $('caja-diff');
    const raw = $('caja-contado').value;
    if (!session || raw === '') { el.textContent = ''; return; }
    const diff = Math.round((Number(raw) - session.expected_now) * 100) / 100;
    el.textContent = Math.abs(diff) < 0.005 ? '✔ La caja cuadra' : `${diff > 0 ? 'Sobran' : 'Faltan'} ${fmtDec(Math.abs(diff))} — escribe qué pasó en la nota`;
    el.style.color = Math.abs(diff) < 0.005 ? 'var(--sage)' : 'var(--danger)';
  }
  $('caja-contado').addEventListener('input', updateDiff);

  async function load() {
    if (!isPos()) return;
    try { session = await Api.pos.cash(); showError(''); } catch (err) { showError(err.status === undefined ? 'Sin conexión con el servidor — la caja lo necesita.' : err.message); return; }
    render();
  }

  const run = async fn => { try { showError(''); session = await fn(); render(); } catch (err) { showError(err.status === undefined ? 'Sin conexión con el servidor' : err.message); } };

  $('btn-caja-abrir').addEventListener('click', () => {
    const v = $('caja-fondo').value;
    if (v === '') { showError('Escribe el fondo inicial (puede ser 0)'); return; }
    try { localStorage.setItem(FONDO_KEY, String(Number(v))); } catch (_) {}
    run(() => Api.pos.openCash(Number(v))).then(() => { $('caja-fondo').value = ''; UI.toast('Caja abierta'); });
  });
  $('btn-caja-mov').addEventListener('click', () => {
    run(() => Api.pos.cashMovement({ kind: $('caja-mov-tipo').value, amount: Number($('caja-mov-monto').value), reason: $('caja-mov-motivo').value })).then(() => {
      if (!$('caja-error').hidden) return;
      $('caja-mov-monto').value = ''; $('caja-mov-motivo').value = ''; UI.toast('Anotado');
    });
  });
  $('btn-caja-cerrar').addEventListener('click', async () => {
    showError('');
    if ($('caja-contado').value === '') { showError('Cuenta el efectivo y escribe cuánto hay'); return; }
    if (!(await UI.confirmDialog('¿Cerrar la caja? Después hay que abrir una nueva para seguir.'))) return;
    try {
      const closed = await Api.pos.closeCash({ counted_amount: Number($('caja-contado').value), note: $('caja-nota').value.trim() || null });
      UI.toast(Math.abs(closed.difference) < 0.005 ? 'Caja cerrada — cuadró' : `Caja cerrada — diferencia ${fmtDec(closed.difference)}`);
      $('caja-contado').value = ''; $('caja-nota').value = '';
      session = null;
      render();
    } catch (err) { showError(err.status === undefined ? 'Sin conexión con el servidor' : err.message); }
  });

  window.addEventListener('view:show', e => { if (e.detail.view === 'pos-caja') load(); });
  // La píldora se pone al día al entrar a la facturación y cada 5 minutos.
  const cartApp = document.getElementById('cart-app');
  let pillTimer = null;
  const refrescar = () => { if (!cartApp.hidden && isPos() && (!window.Modules || Modules.enabled('caja'))) load(); };
  new MutationObserver(() => { clearInterval(pillTimer); if (!cartApp.hidden) { refrescar(); pillTimer = setInterval(refrescar, 5 * 60000); } })
    .observe(cartApp, { attributes: true, attributeFilter: ['hidden'] });
  if (!cartApp.hidden) { refrescar(); pillTimer = setInterval(refrescar, 5 * 60000); }
})();
