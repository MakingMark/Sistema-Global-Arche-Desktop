/* ═══ Administrativo en 9 entradas (fase 4 de ANALISIS-SISTEMA-COMPLETO.md) ═══
   El menú tenía 20 entradas sueltas. Ahora son 9 y las pantallas relacionadas
   viven detrás de una sola («hub»), con pestañas arriba de la pantalla:
     Inventario  → Existencias · Entradas · Compras · Preparar · Transferir · Ajustes y merma
     Catálogo    → Menú · Insumos · Ofertas
     Reportes    → Ganancias · Gastos · Tendencias
     Equipo y locales → Empleados · Turnos · Ubicaciones
   Ninguna pantalla cambió: solo cómo se llega a ellas. Respeta los módulos
   apagados (una pestaña apagada no sale; un hub sin nada encendido desaparece). */
const Hubs = (function () {
  'use strict';
  const nav = document.getElementById('owner-tabs');
  const T = (k, f) => (window.Vocab ? Vocab.t(k, f) : f);
  const HUBS = {
    panel: [['panel', 'Panel']],
    historial: [['historial', 'Historial']],
    inventario: [['inv-existencias', 'Existencias'], ['inv-entradas', 'Entradas'], ['compras', 'Compras'], ['inv-preparar', 'Preparar'], ['inv-transferir', 'Transferir'], ['inv-ajustes', 'Ajustes y merma']],
    catalogo: [['menu', () => T('menu', 'Menú')], ['insumos', () => T('insumos', 'Insumos')], ['ofertas', 'Ofertas']],
    reportes: [['reportes', 'Ganancias'], ['gastos', 'Gastos'], ['analitica', 'Tendencias']],
    clientes: [['clientes', 'Clientes']],
    pagina: [['pagina', 'Página web']],
    equipo: [['empleados', 'Empleados'], ['turnos', 'Turnos'], ['ubicaciones', 'Ubicaciones']],
    configuracion: [['configuracion', 'Configuración']]
  };
  const label = l => (typeof l === 'function' ? l() : l);
  const on = view => !(window.Modules && Modules.viewOff(view));
  const hubOf = view => Object.keys(HUBS).find(h => HUBS[h].some(([v]) => v === view)) || null;
  const enabledOf = hub => (HUBS[hub] || []).filter(([v]) => on(v));
  const itemOf = hub => nav && nav.querySelector(`.nav-item[data-hub="${hub}"]`);
  const primaryOf = view => { const it = itemOf(hubOf(view)); return it ? it.dataset.view : view; };
  let current = 'panel';

  // Cada entrada del menú lleva a la primera pantalla encendida de su grupo.
  function sync() {
    if (!nav) return;
    nav.querySelectorAll('.nav-item[data-hub]').forEach(it => {
      const ev = enabledOf(it.dataset.hub);
      it.classList.toggle('mod-off', !ev.length);
      if (ev.length && !ev.some(([v]) => v === it.dataset.view)) it.dataset.view = ev[0][0];
    });
    nav.querySelectorAll('.nav-group').forEach(g => {
      const items = Array.from(g.querySelectorAll('.nav-item'));
      g.classList.toggle('mod-off', items.length > 0 && items.every(i => i.classList.contains('mod-off')));
    });
  }

  function markActive(view) {
    const hub = hubOf(view);
    if (!nav || !hub) return;
    nav.querySelectorAll('.nav-item[data-hub]').forEach(it => {
      const act = it.dataset.hub === hub;
      it.classList.toggle('active', act);
      if (act) it.setAttribute('aria-current', 'page'); else it.removeAttribute('aria-current');
    });
  }

  // Pestañas del grupo, arriba de la pantalla (solo si hay más de una encendida).
  function renderTabs(view) {
    document.querySelectorAll('.hub-tabs').forEach(b => b.remove());
    const hub = hubOf(view);
    const ev = hub ? enabledOf(hub) : [];
    if (ev.length < 2) return;
    const section = document.querySelector(`#owner-app .view[data-view="${view}"]`);
    if (!section) return;
    const bar = document.createElement('nav');
    bar.className = 'hub-tabs';
    bar.setAttribute('aria-label', 'Secciones de ' + (itemOf(hub) ? itemOf(hub).textContent.trim() : ''));
    bar.innerHTML = ev.map(([v, l]) => `<button type="button" class="hub-tab${v === view ? ' is-active' : ''}" data-view="${v}"${v === view ? ' aria-current="page"' : ''}>${label(l)}</button>`).join('');
    section.prepend(bar);
    const act = bar.querySelector('.is-active');
    if (act && act.scrollIntoView) act.scrollIntoView({ block: 'nearest', inline: 'center' });
  }

  document.addEventListener('click', e => {
    const b = e.target.closest('.hub-tab');
    if (b && !b.classList.contains('is-active')) window.showView(b.dataset.view);
  });
  window.addEventListener('view:show', e => {
    current = e.detail.view;
    if (!hubOf(current)) return;
    markActive(current);
    renderTabs(current);
  });
  window.addEventListener('modules:changed', () => { sync(); if (hubOf(current)) { markActive(current); renderTabs(current); } });
  window.addEventListener('locale:changed', () => { if (hubOf(current)) renderTabs(current); });
  sync();

  return { hubOf, primaryOf, sync };
})();
window.Hubs = Hubs;
