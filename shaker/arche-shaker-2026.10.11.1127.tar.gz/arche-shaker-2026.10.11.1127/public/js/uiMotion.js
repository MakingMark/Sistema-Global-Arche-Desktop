/* ═══ Interfaz de trabajo v3.1: movimiento y detalles compartidos ═══
   (ANALISIS-INTERFAZ-V3.1.md) Lo usan el administrativo y la facturación:
   - Motion.countUp / countUps: las cifras suben desde 0 (o desde la cifra
     anterior) en vez de aparecer de golpe.
   - Motion.flyTo: un punto que "vuela" del producto tocado al recibo.
   - Motion.bump: un salto corto para avisar que algo cambió (el total).
   - Barra superior: saludo según la hora, fecha, reloj y estado de conexión
     (navigator.onLine + /api/health cada 60 s mientras la app está a la vista).
   - Menú lateral: una pastilla que se desliza hasta la sección activa.
   - Cambio de sección: la vista nueva entra con un fundido corto.
   Con prefers-reduced-motion todo queda quieto: las cifras se ponen directo. */
const Motion = (function () {
  'use strict';
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const easeOut = t => 1 - Math.pow(1 - t, 3);

  /* ── Cifras que suben ── */
  // data-count="1234.5" y data-format="money" | "int". Recuerda la última cifra
  // mostrada en ese elemento para animar solo la diferencia.
  function format(n, kind) {
    if (kind === 'int') return Math.round(n).toLocaleString('es-DO');
    return typeof fmt === 'function' ? fmt(n) : n.toFixed(2);
  }
  function countUp(el, to, kind, ms) {
    const target = Number(to);
    if (!isFinite(target)) return;
    const from = Number(el.dataset.shown || 0);
    el.dataset.shown = String(target);
    if (reduce || from === target) { el.textContent = format(target, kind); return; }
    const dur = ms || Math.min(1100, 450 + Math.log10(Math.abs(target - from) + 1) * 160);
    const t0 = performance.now();
    cancelAnimationFrame(el._countRaf);
    const step = now => {
      const t = Math.min(1, (now - t0) / dur);
      el.textContent = format(from + (target - from) * easeOut(t), kind);
      if (t < 1) el._countRaf = requestAnimationFrame(step);
    };
    el._countRaf = requestAnimationFrame(step);
  }
  function countUps(root) {
    (root || document).querySelectorAll('[data-count]').forEach(el => countUp(el, el.dataset.count, el.dataset.format));
  }

  /* ── Detalles ── */
  function replay(el, cls) { if (!el || reduce) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); }
  const bump = el => replay(el, 'is-bump');

  // Un punto con el color de acento que viaja en arco desde `fromRect` hasta `toEl`.
  function flyTo(fromRect, toEl) {
    if (reduce || !fromRect || !toEl || !toEl.getClientRects().length) return;
    const to = toEl.getBoundingClientRect();
    if (!to.width || to.bottom < 0 || to.top > window.innerHeight) return;
    const dot = document.createElement('span');
    dot.className = 'ux-fly';
    const x0 = fromRect.left + fromRect.width / 2, y0 = fromRect.top + fromRect.height / 2;
    const x1 = to.left + to.width / 2, y1 = to.top + to.height / 2;
    dot.style.left = x0 + 'px'; dot.style.top = y0 + 'px';
    document.body.appendChild(dot);
    const dx = x1 - x0, dy = y1 - y0, lift = Math.min(160, Math.abs(dx) * 0.35 + 40);
    const anim = dot.animate([
      { transform: 'translate(-50%,-50%) scale(1)', opacity: 1 },
      { transform: `translate(calc(-50% + ${dx * 0.5}px), calc(-50% + ${dy * 0.5 - lift}px)) scale(.9)`, opacity: 1, offset: 0.5 },
      { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px)) scale(.35)`, opacity: 0.2 }
    ], { duration: 620, easing: 'cubic-bezier(.45,0,.25,1)' });
    anim.onfinish = () => { dot.remove(); bump(toEl); };
  }

  /* ── Barra superior: saludo, fecha, reloj y conexión ── */
  const $all = sel => Array.from(document.querySelectorAll(sel));
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
  function greeting(h) { return h >= 5 && h < 12 ? 'Buenos días' : h >= 12 && h < 19 ? 'Buenas tardes' : 'Buenas noches'; }
  let clockTimer = null;
  function tick() {
    const d = new Date();
    $all('[data-ux-greeting]').forEach(el => { el.textContent = greeting(d.getHours()); });
    $all('[data-ux-date]').forEach(el => { el.textContent = cap(d.toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long' })); });
    $all('[data-ux-time]').forEach(el => { el.textContent = d.toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit', hour12: true }); });
    clearTimeout(clockTimer);
    clockTimer = setTimeout(tick, 60000 - (Date.now() % 60000) + 50);
  }
  const appVisible = () => !document.hidden && $all('#owner-app, #cart-app').some(a => !a.hidden);
  let healthTimer = null;
  function setStatus(ok, text) {
    $all('[data-ux-status]').forEach(el => { el.classList.toggle('is-off', !ok); el.title = text; });
    $all('[data-ux-status-text]').forEach(el => { el.textContent = text; });
  }
  async function checkHealth() {
    clearTimeout(healthTimer);
    if (!appVisible()) return;
    if (!navigator.onLine) setStatus(false, 'Sin conexión');
    else {
      const ctl = window.AbortController ? new AbortController() : null;
      const to = ctl && setTimeout(() => ctl.abort(), 6000);
      try {
        const r = await fetch('/api/health', { cache: 'no-store', signal: ctl && ctl.signal });
        setStatus(r.ok, r.ok ? 'En línea' : 'Servidor sin respuesta');
      } catch (_) { setStatus(false, 'Sin conexión'); } finally { if (to) clearTimeout(to); }
    }
    healthTimer = setTimeout(checkHealth, 60000);
  }
  window.addEventListener('online', checkHealth);
  window.addEventListener('offline', () => setStatus(false, 'Sin conexión'));
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { tick(); checkHealth(); } });

  // Iniciales del empleado para el avatar de la barra superior.
  function fillInitials() {
    $all('[data-employee-initials]').forEach(el => {
      const src = document.querySelector('[data-employee-name]');
      const parts = String(src ? src.textContent : '').trim().split(/\s+/).filter(Boolean);
      el.textContent = parts.length ? (parts[0][0] + (parts[1] ? parts[1][0] : '')).toUpperCase() : '·';
    });
  }

  /* ── Menú lateral: pastilla deslizante ── */
  function setupGlider(nav) {
    const glider = document.createElement('span');
    glider.className = 'nav-glider';
    glider.setAttribute('aria-hidden', 'true');
    nav.prepend(glider);
    let first = true;
    function place() {
      const active = nav.querySelector('.nav-item.active');
      const ok = active && active.offsetParent !== null && active.getClientRects().length;
      nav.classList.toggle('has-glider', !!ok);
      if (!ok) { first = true; return; }
      const n = nav.getBoundingClientRect(), a = active.getBoundingClientRect();
      if (first || reduce) glider.style.transition = 'none';
      glider.style.borderRadius = getComputedStyle(active).borderRadius;
      glider.style.width = a.width + 'px';
      glider.style.height = a.height + 'px';
      glider.style.transform = `translate(${a.left - n.left + nav.scrollLeft}px, ${a.top - n.top + nav.scrollTop}px)`;
      if (first || reduce) { void glider.offsetWidth; glider.style.transition = ''; }
      first = false;
    }
    window.addEventListener('view:show', () => requestAnimationFrame(place));
    window.addEventListener('resize', place);
    // Grupos que se abren/cierran (menú del dueño en el celular) mueven los ítems.
    new MutationObserver(() => requestAnimationFrame(place)).observe(nav, { subtree: true, attributes: true, attributeFilter: ['aria-expanded', 'hidden', 'class'] });
    if (window.ResizeObserver) new ResizeObserver(place).observe(nav);
    return place;
  }
  const placers = $all('#owner-tabs, #cart-tabs').map(setupGlider);
  const placeAll = () => placers.forEach(p => p());

  /* ── Cambio de sección ── */
  window.addEventListener('view:show', e => {
    const v = document.querySelector(`.view[data-view="${e.detail.view}"]:not([hidden])`);
    replay(v, 'is-entering');
  });

  // Al aparecer el administrativo o la facturación (después del login).
  const onAppShown = () => { if (!appVisible()) return; tick(); fillInitials(); checkHealth(); requestAnimationFrame(placeAll); };
  $all('#owner-app, #cart-app').forEach(app => new MutationObserver(onAppShown).observe(app, { attributes: true, attributeFilter: ['hidden'] }));
  const nameEl = document.querySelector('[data-employee-name]');
  if (nameEl) new MutationObserver(fillInitials).observe(nameEl, { childList: true, characterData: true, subtree: true });
  tick();
  onAppShown();

  return { countUp, countUps, flyTo, bump, replay, reduce };
})();
// Visible también como window.Motion (otros archivos preguntan `window.Motion && …`).
window.Motion = Motion;
