/* ═══ Vocabulario según el tipo de negocio ═══
   Los textos marcados con data-term cambian de nombre (Menú → Catálogo, Insumos →
   Inventario, platos → productos…). Lo que no está en la tabla se queda como está. */
(function () {
  'use strict';
  const TERMS = {
    restaurante: {},
    cafeteria: {},
    tienda: { menu: 'Catálogo', insumos: 'Inventario', plato: 'producto', platos: 'productos', Platos: 'Productos', receta: 'componentes' },
    servicios: { menu: 'Catálogo', insumos: 'Inventario', plato: 'servicio', platos: 'servicios', Platos: 'Servicios', receta: 'componentes' },
    otro: { menu: 'Catálogo', insumos: 'Inventario', plato: 'producto', platos: 'productos', Platos: 'Productos', receta: 'componentes' }
  };
  const table = () => TERMS[AppLocale.activity()] || {};
  // t('platos', 'platos'): el término del negocio, o el texto de siempre.
  const t = (key, fallback) => table()[key] || fallback || key;

  function apply(root) {
    (root || document).querySelectorAll('[data-term]').forEach(el => {
      if (el.dataset.termDefault === undefined) el.dataset.termDefault = el.textContent;
      el.textContent = table()[el.dataset.term] || el.dataset.termDefault;
    });
  }
  window.Vocab = { t, apply };
  window.addEventListener('locale:changed', () => apply(document));
  document.addEventListener('DOMContentLoaded', () => apply(document));
  apply(document);
})();
