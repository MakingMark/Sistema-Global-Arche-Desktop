/* ═══ Cargar recetas e insumos desde Excel/CSV (dueño) ═══ */
(function () {
  'use strict';
  const card = document.getElementById('importar-card');
  if (!card) return;
  const esc = UI.escapeHtml;
  const fileInput = document.getElementById('importar-file');
  let mode = null;

  async function call(path, body) {
    const res = await fetch('/api/import' + path, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, Auth.headers()), body: JSON.stringify(body) });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, data };
  }

  document.getElementById('btn-plantilla-recetas').addEventListener('click', async () => {
    try {
      const res = await fetch('/api/import/recipes-template', { headers: Auth.headers() });
      if (!res.ok) throw new Error('No se pudo generar la plantilla');
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'recetas-plantilla.csv';
      document.body.appendChild(a); a.click(); a.remove();
      UI.toast('Plantilla descargada — completa insumo, cantidad y unidad de cada plato');
    } catch (err) { UI.toast(err.message, 'error'); }
  });
  document.getElementById('btn-importar-recetas').addEventListener('click', () => { mode = 'recipes'; fileInput.click(); });
  document.getElementById('btn-importar-insumos').addEventListener('click', () => { mode = 'supplies'; fileInput.click(); });

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    fileInput.value = '';
    if (!file) return;
    const csv = await file.text();
    const path = mode === 'recipes' ? '/recipes' : '/supplies';
    const preview = await call(path, { csv, dry_run: true });
    const d = preview.data;
    const errs = (d.errors || []).slice(0, 15).map(e => `<li>${esc(e)}</li>`).join('');
    const summary = mode === 'recipes'
      ? `<p><strong>${d.products || 0}</strong> platos con receta nueva.${d.supplies_to_create && d.supplies_to_create.length ? ` Insumos nuevos que se crean (costo RD$0 hasta la primera compra): <strong>${d.supplies_to_create.map(s => esc(s.name)).join(', ')}</strong>.` : ''}</p>`
      : `<p><strong>${d.to_create || 0}</strong> insumos nuevos, <strong>${d.to_update || 0}</strong> existentes (se actualiza su costo) y <strong>${d.with_stock || 0}</strong> con stock inicial (se suma al que ya haya).</p>`;
    const warn = (d.warnings || []).length ? `<p class="muted">Avisos:</p><ul>${d.warnings.slice(0, 8).map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : '';
    const canApply = preview.ok && !(d.errors || []).length && (mode === 'recipes' ? d.products : (d.to_create + d.to_update));
    const modal = UI.showModal('Vista previa', `
      ${errs ? `<p class="error">${esc(d.error || 'Hay errores')}:</p><ul>${errs}</ul>` : summary + warn}
      ${!errs && !canApply ? '<p class="muted">El archivo no trae nada para cargar.</p>' : ''}
      <div class="modal-actions" style="margin-top:14px">
        <button class="btn" id="imp-cancel">${canApply ? 'Cancelar' : 'Cerrar'}</button>
        ${canApply ? '<button class="btn btn-primary" id="imp-apply">Guardar</button>' : ''}
      </div>`);
    modal.el.querySelector('#imp-cancel').addEventListener('click', () => modal.close());
    const apply = modal.el.querySelector('#imp-apply');
    if (apply) apply.addEventListener('click', async () => {
      apply.disabled = true;
      const res = await call(path, { csv });
      if (res.ok && res.data.applied) { modal.close(); UI.toast('Listo — datos cargados'); window.showView('insumos'); }
      else { UI.toast(res.data.error || 'No se pudo guardar', 'error'); apply.disabled = false; }
    });
  });
})();
