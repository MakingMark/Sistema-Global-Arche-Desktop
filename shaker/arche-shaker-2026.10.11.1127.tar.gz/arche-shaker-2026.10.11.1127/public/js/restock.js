/* ═══ Pedir reposición (carrito) ═══ */
(function () {
  'use strict';
  const suppliesBuilder = document.getElementById('restock-supplies');
  if (!suppliesBuilder) return;

  const noteInput = document.getElementById('restock-note');
  const errorEl = document.getElementById('restock-error');
  const mineEl = document.getElementById('restock-mine');
  const esc = UI.escapeHtml;

  let supplies = [];   // lo que este carrito tiene en existencia (Api.pos.stock) — de ahí sale la lista

  function suppliesOptions() { return SupplyPicker.suppliesOptions(supplies, 'supply_id'); }
  function unitTypeOptions(id) { return SupplyPicker.unitTypeOptions(supplies, 'supply_id', id); }

  function addRow() {
    const row = document.createElement('div');
    row.className = 'receta-row';
    row.innerHTML = `
      <select class="supply-select">${suppliesOptions()}</select>
      <input type="number" placeholder="Cantidad" step="1" min="0">
      <select class="unit-type-select"></select>
      <button type="button" class="btn btn-sm">Quitar</button>
    `;
    const supplySelect = row.querySelector('.supply-select');
    const unitTypeSelect = row.querySelector('.unit-type-select');
    unitTypeSelect.innerHTML = unitTypeOptions(supplySelect.value);
    supplySelect.addEventListener('change', () => { unitTypeSelect.innerHTML = unitTypeOptions(supplySelect.value); });
    row.querySelector('button').addEventListener('click', () => row.remove());
    suppliesBuilder.appendChild(row);
  }
  document.getElementById('btn-add-restock-supply').addEventListener('click', addRow);

  function readItems() {
    return Array.from(suppliesBuilder.querySelectorAll('.receta-row')).map(row => {
      const supplyId = Number(row.querySelector('.supply-select').value);
      const qty = Number(row.querySelector('input').value);
      const unitType = row.querySelector('.unit-type-select').value;
      const s = supplies.find(x => x.supply_id === supplyId);
      const size = unitType === 'pack' ? Number(s?.pack_size) : 1;
      const quantity = s && size > 0 ? qty * size : qty;
      return { supply_id: supplyId, quantity };
    }).filter(r => r.supply_id && r.quantity > 0);
  }

  const STATE = { pendiente: ['Pendiente', 'badge-warn'], aprobada: ['Aprobada — llega en un envío', 'badge-ok'], rechazada: ['Rechazada', 'badge-voided'], cancelada: ['Cancelada', 'badge-muted'] };
  async function renderMine() {
    let reqs;
    try { reqs = await Api.pos.restockRequests(); } catch (err) { mineEl.innerHTML = `<p class="muted">${esc(err.message)}</p>`; return; }
    if (!reqs.length) { mineEl.innerHTML = '<p class="muted">Todavía no has pedido nada.</p>'; return; }
    mineEl.innerHTML = reqs.map(r => {
      const [label, cls] = STATE[r.status];
      const items = r.items.map(i => `${fmtNum(i.quantity)} ${esc(i.supply_unit)} de ${esc(i.supply_name)}`).join(', ');
      return `<div class="product-card" data-id="${r.id}">
        <div class="product-card-header"><span class="badge ${cls}">${label}</span>
          <div class="muted product-card-subtitle">${fmtDate(r.created_at)}</div></div>
        <p style="margin:8px 0">${items}</p>
        ${r.status === 'rechazada' && r.reject_reason ? `<p class="muted" style="margin:0 0 8px">Motivo: ${esc(r.reject_reason)}</p>` : ''}
        ${r.status === 'pendiente' ? '<div class="product-card-actions"><button class="btn btn-sm" data-a="cancel">Cancelar</button></div>' : ''}
      </div>`;
    }).join('');
  }
  mineEl.addEventListener('click', async e => {
    const btn = e.target.closest('[data-a="cancel"]');
    if (!btn) return;
    try { await Api.pos.cancelRestockRequest(Number(btn.closest('[data-id]').dataset.id)); UI.toast('Solicitud cancelada'); renderMine(); }
    catch (err) { UI.toast(err.message, 'error'); }
  });

  /* ── Envíos por confirmar (lo que el almacén ya te mandó) ── */
  const transfersEl = document.getElementById('restock-transfers');
  async function renderTransfers() {
    let pending;
    try { pending = await Api.pos.pendingTransfers(); } catch (err) { transfersEl.innerHTML = `<p class="muted">${esc(err.message)}</p>`; return; }
    if (!pending.length) { transfersEl.innerHTML = '<p class="muted">No tienes envíos pendientes de confirmar.</p>'; return; }
    transfersEl.innerHTML = pending.map(t => `
      <div class="product-card" data-transfer="${t.id}">
        <div class="product-card-header"><strong>Envío #${t.id}</strong><div class="muted product-card-subtitle">${fmtDate(t.created_at)}${t.note ? ' · ' + esc(t.note) : ''}</div></div>
        ${t.items.map(i => `<div class="row" style="gap:8px;align-items:center;margin-bottom:6px">
          <span style="flex:1 1 auto">${esc(i.supply_name)} <span class="muted">(mandaron ${fmtNum(i.quantity)} ${esc(i.supply_unit)})</span></span>
          <input type="number" class="confirm-qty" data-supply="${i.supply_id}" min="0" step="any" value="${Number(i.quantity)}" style="max-width:6rem">
        </div>`).join('')}
        <button class="btn btn-primary btn-sm" data-a="confirm">Confirmar recepción</button>
      </div>`).join('');
  }
  transfersEl.addEventListener('click', async e => {
    const btn = e.target.closest('[data-a="confirm"]');
    if (!btn) return;
    const card = btn.closest('[data-transfer]');
    const supplies = Array.from(card.querySelectorAll('.confirm-qty')).map(inp => ({ supply_id: Number(inp.dataset.supply), quantity: Number(inp.value) || 0 }));
    btn.disabled = true;
    try { const r = await Api.pos.confirmTransfer(Number(card.dataset.transfer), { supplies }); UI.toast(r.status === 'confirmada' ? 'Confirmado — ya está en tu inventario' : 'Confirmado con diferencia — el dueño lo va a ver'); renderTransfers(); }
    catch (err) { UI.toast(err.message, 'error'); btn.disabled = false; }
  });

  document.getElementById('btn-restock-send').addEventListener('click', async () => {
    errorEl.hidden = true;
    const items = readItems();
    if (!items.length) { errorEl.textContent = 'Agrega al menos un insumo con cantidad'; errorEl.hidden = false; return; }
    try {
      await Api.pos.requestRestock(items, noteInput.value.trim() || null);
      suppliesBuilder.innerHTML = ''; addRow(); noteInput.value = '';
      UI.toast('Solicitud enviada');
      renderMine();
    } catch (err) { errorEl.textContent = err.message; errorEl.hidden = false; }
  });

  window.addEventListener('view:show', async e => {
    if (e.detail.view !== 'pos-restock') return;
    try { supplies = (await Api.pos.stock()).supplies; } catch (_) { supplies = []; }
    suppliesBuilder.innerHTML = '';
    addRow();
    renderMine();
    renderTransfers();
  });
})();
