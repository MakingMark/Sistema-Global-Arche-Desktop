/* ═══ IndexedDB: cola de ventas sin conexión + última foto conocida del
   catálogo/stock — SOLO para el carrito. Sin librería externa; la API
   nativa de IndexedDB alcanza para lo que hace falta acá (dos "cajones"
   simples, nada de índices compuestos ni consultas complejas). ═══ */
const OfflineDb = (function () {
  'use strict';
  const DB_NAME = 'shaker_offline';
  const DB_VERSION = 1;
  const STORE_SALES = 'pending_sales';
  const STORE_CACHE = 'cache';

  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_SALES)) {
          db.createObjectStore(STORE_SALES, { keyPath: 'client_id' });
        }
        if (!db.objectStoreNames.contains(STORE_CACHE)) {
          db.createObjectStore(STORE_CACHE, { keyPath: 'key' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      // Safari en modo privado (y algún caso raro de disco lleno) puede
      // negar IndexedDB del todo — sin este reject explícito, cada llamado
      // se quedaría esperando una promesa que nunca resuelve ni falla,
      // colgando el flujo de venta en vez de simplemente no tener offline.
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function tx(storeName, mode) {
    const db = await open();
    return db.transaction(storeName, mode).objectStore(storeName);
  }

  // ── Cola de ventas pendientes ──
  async function queueSale(record) {
    const store = await tx(STORE_SALES, 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put(record);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async function getPendingSales() {
    const store = await tx(STORE_SALES, 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result.sort((a, b) => a.createdAt - b.createdAt));
      req.onerror = () => reject(req.error);
    });
  }

  async function removeSale(client_id) {
    const store = await tx(STORE_SALES, 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(client_id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async function updateSale(record) {
    return queueSale(record); // put() sobreescribe por keyPath, sirve para las dos cosas
  }

  // ── Última foto conocida (catálogo, stock) — para poder seguir vendiendo
  // aunque no haya red ni para pedir esos datos de nuevo. ──
  async function cacheSet(key, value) {
    const store = await tx(STORE_CACHE, 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put({ key, value, savedAt: Date.now() });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async function cacheGet(key) {
    const store = await tx(STORE_CACHE, 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ? req.result.value : null);
      req.onerror = () => reject(req.error);
    });
  }

  return { queueSale, getPendingSales, removeSale, updateSale, cacheSet, cacheGet };
})();
