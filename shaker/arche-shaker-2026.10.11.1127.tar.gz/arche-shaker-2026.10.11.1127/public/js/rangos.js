/* ═══ Rangos de fecha de un toque (v3.11) ═══
   Cada filtro de fechas del administrativo (Historial, Ganancias, Gastos,
   Turnos, Pedidos de la página…) ocupaba media pantalla en el celular con dos
   campos de fecha, «Filtrar» y «Limpiar». Esto les agrega arriba:
     Hoy · Ayer · Últimos 7 días · Este mes · Mes pasado · Elegir fechas
   Un toque pone las fechas y filtra (usa el mismo «submit» de cada pantalla, no
   cambia cómo se busca). Las fechas a mano y «Filtrar» solo se ven con «Elegir
   fechas»; los otros filtros (ubicación, estado…) se aplican solos al cambiar.
   El historial de la facturación ya tiene los suyos (pos.js) y no se toca. */
(function () {
  'use strict';
  const iso = d => (typeof localIsoDate === 'function' ? localIsoDate(d) : d.toISOString().slice(0, 10));
  function rango(r) {
    const hoy = new Date(); const d = new Date(hoy); const h = new Date(hoy);
    if (r === 'ayer') { d.setDate(d.getDate() - 1); h.setDate(h.getDate() - 1); }
    else if (r === '7') d.setDate(d.getDate() - 6);
    else if (r === 'mes') d.setDate(1);
    else if (r === 'mesant') { d.setMonth(d.getMonth() - 1, 1); h.setDate(0); }
    return [iso(d), iso(h)];
  }
  const RANGOS = [['hoy', 'Hoy'], ['ayer', 'Ayer'], ['7', 'Últimos 7 días'], ['mes', 'Este mes'], ['mesant', 'Mes pasado'], ['elegir', 'Elegir fechas']];

  document.querySelectorAll('#owner-app form.filtro-fecha').forEach(form => {
    const from = form.querySelector('[name="from"]');
    const to = form.querySelector('[name="to"]');
    if (!from || !to) return;
    const fechas = [from, to].map(i => i.closest('label, .f, .field') || i);
    const botones = Array.from(form.querySelectorAll('button')).filter(b => b.type === 'submit' || /limpiar/i.test(b.id || b.textContent));
    const chips = document.createElement('div');
    chips.className = 'chips rango-chips';
    chips.setAttribute('role', 'tablist');
    chips.setAttribute('aria-label', 'Qué fechas ver');
    chips.innerHTML = RANGOS.map(([k, l]) => `<button type="button" class="chip" role="tab" data-rango="${k}">${l}</button>`).join('');
    form.parentNode.insertBefore(chips, form);
    form.classList.add('rango-form');

    let modo = null, manual = false;   // manual = la persona eligió «Elegir fechas»
    function pintar(k) {
      modo = k;
      chips.querySelectorAll('[data-rango]').forEach(b => { const on = b.dataset.rango === k; b.classList.toggle('active', on); b.setAttribute('aria-selected', String(on)); });
      const manual = k === 'elegir';
      fechas.forEach(el => { el.hidden = !manual; });
      botones.forEach(b => { b.hidden = !manual; });
    }
    // Qué botón corresponde a las fechas que ya tiene el formulario (cada
    // pantalla pone su valor por defecto al abrirse).
    function detectar() {
      if (manual) return;
      if (!from.value && !to.value) { pintar('elegir'); return; }
      const k = RANGOS.find(([r]) => r !== 'elegir' && rango(r)[0] === from.value && rango(r)[1] === to.value);
      pintar(k ? k[0] : 'elegir');
    }
    chips.addEventListener('click', e => {
      const b = e.target.closest('[data-rango]');
      if (!b) return;
      if (b.dataset.rango === 'elegir') { manual = true; pintar('elegir'); from.focus(); return; }
      manual = false;
      [from.value, to.value] = rango(b.dataset.rango);
      pintar(b.dataset.rango);
      form.requestSubmit();
    });
    // Ubicación, estado, categoría…: se aplican al cambiar (sin «Filtrar»).
    form.querySelectorAll('select').forEach(sel => sel.addEventListener('change', () => { if (modo !== 'elegir') form.requestSubmit(); }));
    form.addEventListener('reset', () => setTimeout(() => { manual = false; detectar(); }, 0));
    // Cada pantalla pone sus fechas por defecto al abrirse (a veces después de
    // una carga): se vuelve a mirar un poco después.
    window.addEventListener('view:show', () => { [60, 400].forEach(ms => setTimeout(detectar, ms)); });
    form.addEventListener('submit', () => { if (!manual) setTimeout(detectar, 0); });
    detectar();
  });
})();
