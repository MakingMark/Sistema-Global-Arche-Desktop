/* ═══ Motor de sincronización offline (solo carrito) ═══
   Encola una venta cuando no hay red, la reintenta cuando vuelve la señal
   (con el mismo client_id siempre — el servidor deduplica, ver
   salesService.js), y avisa al resto de la app (banner en pos.js) por
   eventos en vez de acoplarse directo a la UI. */
const OfflineSync = (function () {
  'use strict';
  let syncing = false;
  let pendingCount = 0;
  let failedCount = 0;

  function broadcast() {
    window.dispatchEvent(new CustomEvent('offline:status', {
      detail: { online: navigator.onLine, pending: pendingCount, syncing, failed: failedCount }
    }));
  }

  async function refreshPendingCount() {
    const pending = await OfflineDb.getPendingSales();
    failedCount = pending.filter(p => p.status === 'failed').length;
    pendingCount = pending.length - failedCount;
    broadcast();
    return pending;
  }

  // navigator.onLine solo dice si hay una conexión de red activa (ej. wifi
  // conectado) — no si el servidor de verdad responde (puede haber wifi sin
  // internet real, o internet sin que el servidor esté prendido). Por eso el
  // chequeo real es pegarle a la propia API, no confiar en esa bandera sola.
  async function checkServerReachable() {
    try {
      const res = await fetch('/api/pos/stock', { headers: Auth.headers(), cache: 'no-store' });
      return res.status < 500;
    } catch (_) {
      return false;
    }
  }

  function fmtLocal(n) { return AppLocale.currency() + Math.round(Number(n) || 0).toLocaleString('es-DO'); }
  const round2 = n => Math.round(n * 100) / 100;

  // Precio de UNA unidad de una línea: el precio del menú + lo que suman las
  // opciones elegidas (buscadas en los grupos cacheados del producto).
  function lineOptions(product, optionIds) {
    const out = [];
    for (const id of optionIds || []) {
      for (const g of product.modifier_groups || []) {
        const o = g.options.find(x => x.id === id);
        if (o) out.push(o);
      }
    }
    return out;
  }

  // Arma un recibo de verdad (con nombres, opciones, precios reales e
  // impuestos) usando la última foto cacheada del menú y de la configuración
  // — es lo que permite mostrarle al vendedor un recibo completo aunque el
  // servidor todavía no sepa que esta venta existe.
  async function buildLocalReceipt(payload) {
    const menu = (await OfflineDb.cacheGet('pos_menu')) || { products: [] };
    const offers = (await OfflineDb.cacheGet('pos_offers')) || [];
    const settings = (await OfflineDb.cacheGet('settings')) || {};
    const session = Auth.get();
    let net = 0;
    const lines = [];

    // Una oferta puede combinar varios productos — payload.items trae UNA
    // línea por producto del combo, todas con el mismo offer_id (ver pos.js).
    // No se repite el reparto proporcional exacto del servidor: alcanza con
    // juntarlas en una sola línea al precio del combo (+ extras de opciones),
    // para que el recibo de YA MISMO no muestre un total inflado.
    const offerGroups = new Map();
    payload.items.filter(it => it.offer_id).forEach(it => {
      if (!offerGroups.has(it.offer_id)) offerGroups.set(it.offer_id, []);
      offerGroups.get(it.offer_id).push(it);
    });

    for (const it of payload.items.filter(x => !x.offer_id)) {
      const p = menu.products.find(pr => pr.id === it.product_id);
      const opts = p ? lineOptions(p, it.modifiers) : [];
      const unit = (p ? Number(p.sale_price) : 0) + opts.reduce((s, o) => s + Number(o.price_delta), 0);
      const subtotal = unit * Number(it.quantity);
      net += subtotal;
      lines.push(`${it.quantity} x ${p ? p.name : `Producto #${it.product_id}`} — ${fmtLocal(subtotal)}`);
      opts.forEach(o => lines.push(`   + ${o.name}${Number(o.price_delta) ? ` (${fmtLocal(o.price_delta)})` : ''}`));
      if (it.note) lines.push(`   Nota: ${it.note}`);
    }
    for (const [offerId, group] of offerGroups.entries()) {
      const offer = offers.find(o => o.id === offerId);
      let extras = 0;
      const detail = [];
      group.forEach(it => {
        const p = menu.products.find(pr => pr.id === it.product_id);
        const opts = p ? lineOptions(p, it.modifiers) : [];
        extras += opts.reduce((s, o) => s + Number(o.price_delta), 0) * Number(it.quantity);
        detail.push(`   ${it.quantity} x ${p ? p.name : `Producto #${it.product_id}`}`);
        opts.forEach(o => detail.push(`      + ${o.name}${Number(o.price_delta) ? ` (${fmtLocal(o.price_delta)})` : ''}`));
        if (it.note) detail.push(`      Nota: ${it.note}`);
      });
      let comboPrice;
      let label;
      if (offer) {
        const first = group[0];
        const firstOfferItem = offer.items.find(oi => oi.product_id === first.product_id);
        const n = firstOfferItem ? Number(first.quantity) / Number(firstOfferItem.quantity) : 1;
        comboPrice = Number(offer.price) * n;
        label = n > 1 ? `${n} x ${offer.name}` : offer.name;
      } else {
        // Sin la oferta cacheada no hay forma de saber su precio de combo — se
        // muestra al precio de lista, mejor que $0.
        comboPrice = group.reduce((s, it) => {
          const p = menu.products.find(pr => pr.id === it.product_id);
          return s + (p ? Number(p.sale_price) : 0) * Number(it.quantity);
        }, 0);
        label = 'Combo';
      }
      const subtotal = comboPrice + extras;
      net += subtotal;
      lines.push(`${label} — ${fmtLocal(subtotal)}`, ...detail);
    }

    net = round2(net);
    const itbis = settings.itbis_enabled ? round2(net * Number(settings.itbis_rate) / 100) : 0;
    const tip = settings.tip_enabled ? round2(net * Number(settings.tip_rate) / 100) : 0;
    const fee = Math.max(0, Number(payload.delivery_fee) || 0);
    const total = round2(net + itbis + tip + fee);
    const businessName = settings.business_name || 'Mi negocio';
    const parts = [
      `*${businessName} — Recibo pendiente de sincronizar*`,
      new Date().toLocaleString('es-DO'),
      `Punto: ${(session && session.locationName) || 'Punto de venta'}`
    ];
    if (payload.customer_name) parts.push(`Cliente: ${payload.customer_name}`);
    parts.push('', ...lines, '');
    if (itbis || tip || fee) {
      parts.push(`Subtotal: ${fmtLocal(net)}`);
      if (itbis) parts.push(`ITBIS (${Number(settings.itbis_rate)}%): ${fmtLocal(itbis)}`);
      if (tip) parts.push(`Propina legal (${Number(settings.tip_rate)}%): ${fmtLocal(tip)}`);
      if (fee) parts.push(`Delivery: ${fmtLocal(fee)}`);
    }
    parts.push(`Total: ${fmtLocal(total)}`);
    if (payload.payment_method) parts.push(`Pago: ${payload.payment_method}`);
    if (payload.notes) parts.push(`Notas: ${payload.notes}`);
    parts.push('', '*** SIN CONEXIÓN — se va a confirmar sola apenas vuelva la señal ***');
    return { receipt: parts.join('\n'), total };
  }

  // Descuenta del stock CACHEADO (no del real, ese lo sabe solo el servidor)
  // para que "Mi inventario" y los avisos de "agotado" no sigan mostrando
  // números de antes de la venta mientras se está sin señal — puramente
  // informativo, el servidor vuelve a calcular todo al sincronizar. Usa la
  // receta de cada producto y el insumo de cada opción elegida.
  async function applyOptimisticStock(payload) {
    const stock = await OfflineDb.cacheGet('pos_stock');
    if (!stock) return;
    const menu = (await OfflineDb.cacheGet('pos_menu')) || { products: [] };
    const take = (supplyId, qty) => {
      const row = (stock.supplies || []).find(s => s.supply_id === supplyId);
      if (row) row.stock = Math.max(0, Number(row.stock) - qty);
    };
    for (const it of payload.items) {
      const p = menu.products.find(pr => pr.id === it.product_id);
      if (!p) continue;
      const q = Number(it.quantity);
      (p.supplies || []).forEach(r => take(r.supply_id, Number(r.quantity) * q));
      lineOptions(p, it.modifiers).forEach(o => { if (o.supply_id) take(o.supply_id, Number(o.supply_qty) * q); });
    }
    await OfflineDb.cacheSet('pos_stock', stock);
  }

  // Api.pos.createSale llama acá cuando fetch() falla por falta de red (ver
  // api.js) — arma todo lo necesario para que la venta "funcione" para el
  // vendedor ya mismo, y quede lista para mandarse sola después.
  async function queueSale(payload) {
    const { receipt, total } = await buildLocalReceipt(payload);
    const record = {
      client_id: payload.client_id,
      path: '/pos/sales',
      payload,
      createdAt: Date.now(),
      status: 'pending',
      lastError: null,
      localReceipt: receipt,
      localTotal: total
    };
    await OfflineDb.queueSale(record);
    await applyOptimisticStock(payload);
    await refreshPendingCount();
    // Intento inmediato por si la red en realidad sí está — a veces fetch()
    // falla una vez por un corte de un segundo y ya vuelve.
    trySync();
    return {
      id: null,
      client_id: payload.client_id,
      total,
      receipt,
      offline: true,
      created_at: new Date().toISOString()
    };
  }

  async function trySync() {
    if (syncing) return;
    const pending = await refreshPendingCount();
    if (!pending.length) return;
    if (!(await checkServerReachable())) return;

    syncing = true;
    broadcast();
    try {
      for (const record of pending) {
        // "failed" = el SERVIDOR ya rechazó esto por una razón de negocio real
        // (ej. insuficiente stock al momento de sincronizar) — no es un
        // problema de red, reintentarlo solo iba a fallar de nuevo. Se queda
        // en la cola para que el vendedor/dueño lo vea y decida a mano.
        if (record.status === 'failed') continue;
        try {
          const res = await fetch('/api' + record.path, {
            method: 'POST',
            headers: Object.assign({ 'Content-Type': 'application/json' }, Auth.headers()),
            body: JSON.stringify(record.payload)
          });
          if (res.ok) {
            await OfflineDb.removeSale(record.client_id);
          } else if (res.status >= 500 || res.status === 402) {
            // 402 = la cuenta está en solo lectura (plan vencido): la venta es válida, se queda
            // pendiente y se envía sola cuando se renueve.
            // Error DEL SERVIDOR (se cayó la base, etc.), no un rechazo de
            // negocio de verdad — no dice nada sobre si esta venta es
            // válida o no. Mismo trato que un corte de red: se deja
            // pendiente y se reintenta sola en el próximo pase, en vez de
            // "failed" (que exige que alguien la revise a mano por algo
            // que no tiene que ver con la venta en sí).
            break;
          } else {
            let message = res.statusText;
            try { message = (await res.json()).error || message; } catch (_) {}
            record.status = 'failed';
            record.lastError = message;
            await OfflineDb.updateSale(record);
          }
        } catch (_) {
          // Se cortó la señal a mitad de la sincronización — el resto queda
          // en cola tal cual, se reintenta solo en el próximo pase.
          break;
        }
      }
    } finally {
      syncing = false;
      await refreshPendingCount();
    }
  }

  window.addEventListener('online', trySync);
  window.addEventListener('offline', broadcast);
  // Respaldo del evento 'online' (poco confiable en algunos navegadores/
  // celulares) — un chequeo real cada 20s mientras haya algo pendiente.
  setInterval(trySync, 20000);
  // Al cargar la página (ej. se cerró y reabrió el navegador ya con señal
  // de vuelta) hay que intentar sincronizar YA — 'online' solo dispara en la
  // transición sin-señal→con-señal, no en una carga nueva que ya arranca con
  // señal, así que sin esto una cola pendiente podía quedarse esperando
  // hasta 20s de balde en ese caso.
  trySync();

  return { queueSale, trySync, refreshPendingCount, getPendingCount: () => pendingCount };
})();
