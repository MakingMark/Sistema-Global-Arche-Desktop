/* ═══ Página web: mini CMS (dueño) ═══
   Qué sale · Textos y portada · Fotos. (Pedidos y horarios: menuWeb.js.)
   Servidor: routes/products.js (/:id/web), settings.js (/web-content), media.js. */
(function () {
  'use strict';
  const view = document.querySelector('section.view[data-view="pagina"]');
  if (!view) return;
  const esc = UI.escapeHtml;
  const $ = id => document.getElementById(id);
  const fmt = n => `${AppLocale.currency()}${Number(n).toLocaleString('es-DO', { maximumFractionDigits: 2 })}`;
  const ICON_NAMES = { plate: 'Plato', dumbbell: 'Pesa', trophy: 'Trofeo', scooter: 'Moto', house: 'Casa', avocado: 'Aguacate' };

  /* ───────── Qué sale ───────── */
  let products = [], cats = [], pub = new Map(), siteUrl = '';

  async function loadWhatSale() {
    const [ps, cs, web] = await Promise.all([Api.products.list(), Api.menu.categories(), Api.settings.web()]);
    products = ps.filter(p => p.active); cats = cs.filter(c => c.active);
    siteUrl = web.web_site_url || '';
    const link = $('pw-view-site'); link.hidden = !siteUrl; if (siteUrl) link.href = siteUrl;
    renderConnection(web);
    await Promise.all([refreshPublic(), loadOffers()]);
    renderList();
  }

  /* ── ¿La página está conectada a este sistema? ── */
  function ago(iso) {
    const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 90) return 'hace un momento';
    if (s < 3600) return `hace ${Math.round(s / 60)} min`;
    if (s < 86400) return `hace ${Math.round(s / 3600)} h`;
    return `hace ${Math.round(s / 86400)} días`;
  }
  function renderConnection(web) {
    const el = $('pw-conn'); el.hidden = false;
    const store = `<strong>Tu tienda en línea ya funciona:</strong> <a href="${web.web_store_domain ? 'https://' + esc(web.web_store_domain) : '/tienda'}" target="_blank" rel="noopener">${web.web_store_domain ? esc(web.web_store_domain) : 'ver mi tienda'}</a>. `;
    const at = web.web_last_site_fetch;
    const fresh = at && Date.now() - new Date(at).getTime() < 24 * 3600 * 1000;
    if (fresh) {
      el.className = 'pw-conn is-ok';
      el.innerHTML = `${store}<strong>Página externa conectada.</strong> La última vez que la página pidió sus datos fue ${ago(at)}${web.web_last_site_origin ? ` (${esc(web.web_last_site_origin.replace(/^https?:\/\//, '').replace(/\/.*$/, ''))})` : ''}. Los cambios que hagas aquí se ven en la página en unos segundos.`;
    } else {
      el.className = 'pw-conn is-warn';
      el.innerHTML = `${store}<strong>Tu página externa (si tienes una) todavía no está conectada a este sistema.</strong> ${at ? `La última vez que pidió sus datos fue ${ago(at)}. ` : 'Nunca ha pedido sus datos. '}Mientras no lo esté, lo que cambies aquí <u>no se ve en esa página</u>: ella muestra su menú de respaldo (tu tienda en línea sí lo muestra siempre). Se conecta poniendo la dirección de este sistema en <code>assets/js/config.js</code> de la página (línea <code>SHAKER_API</code>). Detalles en Pedidos y horarios → “Cómo se conecta la página”.`;
    }
  }

  /* ── Ofertas: cuáles salen y, si no, por qué ── */
  let offerStatus = { location: null, offers: [] };
  async function loadOffers() {
    try { offerStatus = await Api.offers.webStatus(); } catch (_) { offerStatus = { location: null, offers: [] }; }
    renderOffers();
  }
  const OFFER_BADGE = { sale: 'badge-sage', no_disponible: 'badge-warn' };
  function renderOffers() {
    const el = $('pw-offers');
    if (!offerStatus.offers.length) { el.innerHTML = ''; return; }
    el.innerHTML = `<div class="card pw-cat"><div class="pw-cat-head"><h2>Ofertas</h2><span class="muted">${offerStatus.offers.filter(o => o.state === 'sale').length} de ${offerStatus.offers.length} salen en la página</span></div>
      ${offerStatus.offers.map(o => `<div class="pw-row" data-oid="${o.id}">
        <div class="pw-name"><strong>${esc(o.name)}</strong><span class="muted">${esc(o.text)}</span></div>
        <span class="badge ${OFFER_BADGE[o.state] || 'badge-muted'} pw-state">${o.state === 'sale' ? 'Sale' : o.state === 'no_disponible' ? 'Agotada ahora' : 'No sale'}</span>
        ${o.can_show ? '<button type="button" class="btn btn-sm btn-primary" data-offer-show>Mostrar en la página</button>' : ''}
        ${o.can_enable_location ? `<button type="button" class="btn btn-sm btn-primary" data-offer-loc>Habilitar en ${esc(offerStatus.location.name)}</button>` : ''}
        <button type="button" class="btn btn-sm" data-offer-edit>Ver en Ofertas</button>
      </div>`).join('')}</div>`;
  }
  $('pw-offers').addEventListener('click', async e => {
    const row = e.target.closest('[data-oid]'); if (!row) return;
    const id = Number(row.dataset.oid);
    try {
      if (e.target.closest('[data-offer-edit]')) { window.showView('ofertas'); return; }
      if (e.target.closest('[data-offer-show]')) { await Api.offers.update(id, { web_visible: true }); UI.toast('La oferta ya se muestra en la página'); }
      if (e.target.closest('[data-offer-loc]')) {
        const all = await Api.offers.list(); const cur = all.find(o => o.id === id);
        await Api.offers.setLocations(id, [...new Set([...(cur ? cur.location_ids : []), offerStatus.location.id])]);
        UI.toast(`Oferta habilitada en ${offerStatus.location.name}`);
      }
      await refreshPublic(); await loadOffers();
    } catch (err) { UI.toast(err.message, 'error'); }
  });
  async function refreshPublic() {
    try {
      const m = await fetch('/api/public/menu', { cache: 'no-store' }).then(r => r.json());
      pub = new Map(m.products.map(p => [p.id, p]));
    } catch (_) { pub = new Map(); }
  }

  function state(p) {
    const cat = cats.find(c => c.id === p.category_id);
    const parent = cat && cat.parent_id ? cats.find(c => c.id === cat.parent_id) : null;
    if (!p.web_visible) return { key: 'oculto', text: 'Oculto', cls: 'badge-muted' };
    if ((cat && !cat.web_visible) || (parent && !parent.web_visible)) return { key: 'oculto', text: 'Categoría oculta', cls: 'badge-muted' };
    if (!p.category_id) return { key: 'oculto', text: 'Sin categoría: no sale', cls: 'badge-warn' };
    const u = pub.get(p.id);
    if (!u) return { key: 'oculto', text: 'No sale', cls: 'badge-muted' };
    if (!u.available) return u.reason === 'Agotado por hoy' ? { key: 'agotado', text: 'Agotado hoy', cls: 'badge-warn' } : { key: 'horario', text: u.reason || 'Fuera de horario', cls: 'badge-warn' };
    return { key: 'visible', text: 'Disponible', cls: 'badge-sage' };
  }
  const soldOutToday = p => !!p.sold_out_on && p.sold_out_on === todayStr();
  function todayStr() { return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santo_Domingo' }).format(new Date()); }

  function rowHtml(p) {
    const st = state(p);
    return `<div class="pw-row${p.web_visible ? '' : ' is-off'}" data-pid="${p.id}" data-state="${st.key}">
      <label class="pw-switch" title="Mostrar en la página"><input type="checkbox" data-vis ${p.web_visible ? 'checked' : ''}><span class="pw-track"></span></label>
      ${p.image_url ? `<img class="pw-thumb" src="${esc(p.image_url)}" alt="" loading="lazy">` : '<span class="pw-thumb pw-thumb--empty"></span>'}
      <div class="pw-name"><strong>${esc(p.name)}</strong> ${p.badge ? `<span class="badge badge-ok">${esc(p.badge)}</span>` : ''}
        <span class="muted">${fmt(p.sale_price)}${p.calories ? ` · ${p.calories} kcal` : ''}${p.protein_g != null && Number(p.protein_g) ? ` · ${Number(p.protein_g)} g prot.` : ''}</span></div>
      <span class="badge ${st.cls} pw-state">${esc(st.text)}</span>
      <label class="pw-soldout" title="Agotado solo por hoy — se quita solo a medianoche"><input type="checkbox" data-sold ${soldOutToday(p) ? 'checked' : ''}><span>Agotado hoy</span></label>
      <button type="button" class="btn btn-sm" data-edit>Editar</button>
    </div>`;
  }

  function renderList() {
    const q = $('pw-search').value.trim().toLowerCase();
    const f = $('pw-filter').value;
    const match = p => (!q || p.name.toLowerCase().includes(q)) && (!f || state(p).key === f);
    const roots = cats.filter(c => !c.parent_id).sort((a, b) => a.sort_order - b.sort_order || a.id - b.id);
    const kidsOf = r => cats.filter(c => c.parent_id === r.id).sort((a, b) => a.sort_order - b.sort_order || a.id - b.id);
    const prodsIn = id => products.filter(p => p.category_id === id && match(p)).sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name));
    let html = '';
    const visibleCount = products.filter(p => state(p).key !== 'oculto').length;
    for (const r of roots) {
      const groups = [{ cat: r, items: prodsIn(r.id), sub: false }, ...kidsOf(r).map(k => ({ cat: k, items: prodsIn(k.id), sub: true }))].filter(g => g.items.length);
      if (!groups.length && (q || f)) continue;
      html += `<div class="card pw-cat" data-cid="${r.id}">
        <div class="pw-cat-head${r.web_visible ? '' : ' is-off'}">
          <label class="pw-switch" title="Mostrar toda la categoría"><input type="checkbox" data-cat-vis="${r.id}" ${r.web_visible ? 'checked' : ''}><span class="pw-track"></span></label>
          <h2>${esc(r.icon || '')} ${esc(r.name)}</h2>
          ${r.web_visible ? '' : '<span class="badge badge-muted">Oculta en la página</span>'}
          <span class="pw-cat-actions"><button type="button" class="btn btn-sm" data-all="1" data-cat="${r.id}">Mostrar todo</button><button type="button" class="btn btn-sm" data-all="0" data-cat="${r.id}">Ocultar todo</button></span>
        </div>`;
      for (const g of groups) {
        if (g.sub) html += `<div class="pw-sub${g.cat.web_visible ? '' : ' is-off'}"><label class="pw-switch"><input type="checkbox" data-cat-vis="${g.cat.id}" ${g.cat.web_visible ? 'checked' : ''}><span class="pw-track"></span></label><h3>${esc(g.cat.name)}</h3></div>`;
        html += g.items.map(rowHtml).join('');
      }
      html += '</div>';
    }
    const orphans = products.filter(p => !p.category_id && match(p));
    if (orphans.length) html += `<div class="card"><h2>Sin categoría</h2>${orphans.map(rowHtml).join('')}</div>`;
    $('pw-list').innerHTML = html || '<div class="card-quiet"><p class="muted" style="margin:0">Ningún plato coincide.</p></div>';
    $('pw-summary').textContent = `${visibleCount} de ${products.length} ${Vocab.t('platos', 'platos')} salen en la página ahora mismo.`;
  }

  const byId = id => products.find(p => p.id === Number(id));
  async function flags(p, data) {
    try {
      const r = await Api.products.webFlags(p.id, data);
      Object.assign(p, r);
      await refreshPublic();
      renderList();
    } catch (err) { UI.toast(err.message, 'error'); renderList(); }
  }
  $('pw-list').addEventListener('change', async e => {
    const row = e.target.closest('[data-pid]');
    if (row && e.target.matches('[data-vis]')) return flags(byId(row.dataset.pid), { web_visible: e.target.checked });
    if (row && e.target.matches('[data-sold]')) return flags(byId(row.dataset.pid), { sold_out_today: e.target.checked });
    if (e.target.matches('[data-cat-vis]')) {
      const c = cats.find(x => x.id === Number(e.target.dataset.catVis));
      try { await Api.menu.updateCategory(c.id, { web_visible: e.target.checked }); c.web_visible = e.target.checked; await refreshPublic(); renderList(); }
      catch (err) { UI.toast(err.message, 'error'); renderList(); }
    }
  });
  $('pw-list').addEventListener('click', async e => {
    const edit = e.target.closest('[data-edit]');
    if (edit) { window.MenuAdmin.editProduct(edit.closest('[data-pid]').dataset.pid).catch(err => UI.toast(err.message, 'error')); return; }
    const all = e.target.closest('[data-all]');
    if (all) {
      const id = Number(all.dataset.cat), on = all.dataset.all === '1';
      const ids = new Set([id, ...cats.filter(c => c.parent_id === id).map(c => c.id)]);
      const items = products.filter(p => ids.has(p.category_id) && p.web_visible !== on);
      if (!items.length) return;
      try { await Promise.all(items.map(p => Api.products.webFlags(p.id, { web_visible: on }).then(r => Object.assign(p, r)))); await refreshPublic(); renderList(); UI.toast(on ? 'Todo a la vista' : 'Todo oculto'); }
      catch (err) { UI.toast(err.message, 'error'); }
    }
  });
  $('pw-search').addEventListener('input', renderList);
  $('pw-filter').addEventListener('change', renderList);

  /* ───────── Textos y portada ───────── */
  const headlineRow = (h = {}) => `<div class="pw-line" data-headline>
    <input placeholder="Tu próxima" maxlength="40" value="${esc(h.before || '')}" aria-label="Inicio del titular">
    <input class="is-accent" placeholder="comida buena" maxlength="30" value="${esc(h.accent || '')}" aria-label="Parte resaltada">
    <input placeholder="está a un toque" maxlength="40" value="${esc(h.after || '')}" aria-label="Final del titular">
    <button type="button" class="btn btn-sm" data-remove aria-label="Quitar titular">×</button></div>`;
  const pillRow = (p = {}) => `<div class="pw-line pw-line--pill" data-pill>
    <select aria-label="Ícono">${Object.entries(ICON_NAMES).map(([k, v]) => `<option value="${k}" ${p.icon === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
    <input placeholder="Suplementos" maxlength="30" value="${esc(p.text || '')}" aria-label="Texto de la etiqueta">
    <button type="button" class="btn btn-sm" data-remove aria-label="Quitar etiqueta">×</button></div>`;
  $('pc-headlines').addEventListener('click', e => { if (e.target.closest('[data-remove]')) e.target.closest('[data-headline]').remove(); });
  $('pc-pills').addEventListener('click', e => { if (e.target.closest('[data-remove]')) e.target.closest('[data-pill]').remove(); });
  $('pc-add-headline').addEventListener('click', () => { if ($('pc-headlines').children.length >= 12) return UI.toast('Máximo 12 titulares', 'error'); $('pc-headlines').insertAdjacentHTML('beforeend', headlineRow()); });
  $('pc-add-pill').addEventListener('click', () => { if ($('pc-pills').children.length >= 4) return UI.toast('Máximo 4 etiquetas', 'error'); $('pc-pills').insertAdjacentHTML('beforeend', pillRow()); });

  async function loadContent() {
    const [c, web] = await Promise.all([Api.settings.webContent(), Api.settings.web()]);
    $('pc-eyebrow').value = c.hero.eyebrow; $('pc-badge').value = c.hero.badge; $('pc-primary').value = c.hero.primary_label;
    $('pc-secondary').value = c.hero.secondary_label; $('pc-intro').value = c.hero.intro; $('pc-secondary-msg').value = c.hero.secondary_message;
    $('pc-headlines').innerHTML = c.hero.headlines.map(headlineRow).join('');
    $('pc-pills').innerHTML = c.hero.pills.map(pillRow).join('');
    $('pc-images').innerHTML = [0, 1, 2].map(i => Fotos.fieldHtml(`pc-img-${i}`, c.hero.images[i] || '', ['Foto grande', 'Foto pequeña 1', 'Foto pequeña 2'][i])).join('');
    Fotos.bind($('pc-images'));
    $('pc-ann-active').checked = c.announcement.active; $('pc-ann-text').value = c.announcement.text;
    $('pc-ann-tone').value = c.announcement.tone; $('pc-ann-until').value = c.announcement.until;
    $('pc-wa').value = web.web_whatsapp_number || ''; $('pc-wa-train').value = c.contact.whatsapp_training; $('pc-ig').value = c.contact.instagram;
    $('pc-address').value = c.footer.address; $('pc-maps').value = c.footer.maps_url; $('pc-footer').value = c.footer.text; $('pc-greeting').value = c.contact.greeting;
    $('pc-layout').value = c.layout || 'auto'; $('pc-seo-title').value = (c.seo || {}).title || ''; $('pc-seo-desc').value = (c.seo || {}).description || ''; $('pc-store-domain').value = web.web_store_domain || '';
    $('pc-cat-title').value = c.sections.categories_title; $('pc-off-title').value = c.sections.offers_title; $('pc-site-url').value = web.web_site_url || '';
  }

  $('pw-content-form').addEventListener('submit', async e => {
    e.preventDefault();
    $('pc-error').hidden = true;
    const content = {
      hero: {
        eyebrow: $('pc-eyebrow').value, intro: $('pc-intro').value, badge: $('pc-badge').value, primary_label: $('pc-primary').value,
        secondary_label: $('pc-secondary').value, secondary_message: $('pc-secondary-msg').value,
        headlines: Array.from($('pc-headlines').querySelectorAll('[data-headline]')).map(r => { const [b, a, f] = r.querySelectorAll('input'); return { before: b.value, accent: a.value, after: f.value }; }),
        pills: Array.from($('pc-pills').querySelectorAll('[data-pill]')).map(r => ({ icon: r.querySelector('select').value, text: r.querySelector('input').value })),
        images: [0, 1, 2].map(i => $(`pc-img-${i}`).value).filter(Boolean)
      },
      contact: { whatsapp_training: $('pc-wa-train').value, instagram: $('pc-ig').value, greeting: $('pc-greeting').value },
      announcement: { active: $('pc-ann-active').checked, text: $('pc-ann-text').value, tone: $('pc-ann-tone').value, until: $('pc-ann-until').value },
      footer: { text: $('pc-footer').value, address: $('pc-address').value, maps_url: $('pc-maps').value },
      sections: { categories_title: $('pc-cat-title').value, offers_title: $('pc-off-title').value },
      layout: $('pc-layout').value, seo: { title: $('pc-seo-title').value, description: $('pc-seo-desc').value }
    };
    const btn = $('pc-save'); btn.disabled = true;
    try {
      await Api.settings.updateWebContent(content);
      await Api.settings.updateWeb({ web_whatsapp_number: $('pc-wa').value.replace(/\D/g, ''), web_site_url: $('pc-site-url').value.trim(), web_store_domain: $('pc-store-domain').value.trim() });
      $('pc-status').textContent = 'Guardado — la página lo muestra en unos segundos.';
      UI.toast('Textos de la página guardados');
    } catch (err) { $('pc-error').textContent = err.message; $('pc-error').hidden = false; }
    finally { btn.disabled = false; }
  });

  /* ───────── Fotos ───────── */
  async function loadPhotos() {
    const list = await Api.media.list();
    $('pf-grid').innerHTML = list.length ? list.map(m => `<div class="photo-cell"><a href="${esc(m.url)}" target="_blank" rel="noopener"><img src="${esc(m.url)}" alt="${esc(m.name)}" loading="lazy"></a>
      <button type="button" class="photo-del" data-del="${m.id}" aria-label="Borrar ${esc(m.name)}">×</button><span class="photo-meta">${esc(m.name)} · ${Math.round(m.size_bytes / 1024)} KB</span></div>`).join('')
      : '<p class="muted">Todavía no has subido fotos. Usa “Subir fotos”.</p>';
  }
  $('pf-file').addEventListener('change', async e => {
    const files = Array.from(e.target.files); e.target.value = '';
    for (let i = 0; i < files.length; i++) {
      $('pf-status').textContent = `Subiendo ${i + 1} de ${files.length}…`;
      try { await Fotos.upload(files[i]); } catch (err) { UI.toast(`${files[i].name}: ${err.message}`, 'error'); }
    }
    $('pf-status').textContent = ''; loadPhotos();
  });
  $('pf-grid').addEventListener('click', async e => {
    const d = e.target.closest('[data-del]'); if (!d) return;
    if (!(await UI.confirmDialog('¿Borrar esta foto? Solo se puede si nada la está usando.'))) return;
    try { await Api.media.remove(d.dataset.del); UI.toast('Foto borrada'); loadPhotos(); } catch (err) { UI.toast(err.message, 'error'); }
  });


  /* ───────── Pedidos recibidos (dueño) ───────── */
  const STATUS = { nuevo: ['Por atender', 'badge-warn'], aceptado: ['Aceptado', 'badge-sage'], rechazado: ['Rechazado', 'badge-muted'], vencido: ['Vencido', 'badge-muted'], cancelado: ['Cancelado', 'badge-muted'] };
  const PAY = { pendiente: 'Transferencia por confirmar', contra_entrega: 'Al recibir', pagado: 'Pagado' };
  const statCard = (label, value, sub) => `<div class="stat"><div class="label">${label}</div><div class="value">${value}</div>${sub ? `<div class="muted" style="font-size:.78rem">${sub}</div>` : ''}</div>`;
  async function loadOrdersList() {
    const fd = new FormData($('pl-form')); const q = {};
    ['status', 'from', 'to'].forEach(k => { if (fd.get(k)) q[k] = fd.get(k); });
    const [st, rows] = await Promise.all([Api.webOrders.stats(q), Api.webOrders.list(q)]);
    $('pl-stats').innerHTML = [
      statCard('Recibidos', st.total),
      statCard('Aceptados', st.accepted, st.accept_rate === null ? '' : `${st.accept_rate}% de los atendidos`),
      statCard('Rechazados', st.rejected), statCard('Vencidos', st.expired), statCard('Cancelados', st.cancelled),
      statCard('Vendido (aceptados)', fmt(st.accepted_value)),
      statCard('Tarda en decidir', st.avg_decide_min === null ? '—' : `${st.avg_decide_min} min`),
      statCard('Tarda en preparar', st.avg_prep_min === null ? '—' : `${st.avg_prep_min} min`)
    ].join('') + (st.top_items.length ? `<div class="stat" style="grid-column:1 / -1;text-align:left"><div class="label">Lo más pedido por la página</div><div>${st.top_items.map(i => `${esc(i.name)} <strong>×${Number(i.quantity)}</strong>`).join(' · ')}</div></div>` : '');
    $('pl-table').querySelector('tbody').innerHTML = rows.map(w => {
      const [label, cls] = STATUS[w.status] || [w.status, 'badge-muted'];
      const extra = w.status === 'rechazado' ? w.reject_reason : w.status === 'cancelado' ? w.cancel_reason : '';
      return `<tr><td data-th="#">${w.id}</td><td data-th="Fecha">${new Date(w.created_at).toLocaleString('es-DO')}</td>
        <td data-th="Cliente"><strong>${esc(w.customer_name)}</strong><div class="muted" style="font-size:.8rem">${esc(w.customer_phone)}</div></td>
        <td data-th="Entrega">${w.fulfillment === 'delivery' ? `Delivery${w.zone ? ' · ' + esc(w.zone) : ''}` : 'Retiro'}</td><td data-th="Pago">${esc(w.payment_method || '')}<div class="muted" style="font-size:.8rem">${esc(PAY[w.payment_status] || '')}</div></td>
        <td class="num" data-th="Total">${fmt(w.net_total + w.delivery_fee)}</td><td data-th="Estado"><span class="badge ${cls}">${esc(label)}</span>${extra ? `<div class="muted" style="font-size:.8rem">${esc(extra)}</div>` : ''}</td></tr>`;
    }).join('') || '<tr><td colspan="7" class="muted">No hay pedidos con ese filtro.</td></tr>';
  }
  $('pl-form').addEventListener('submit', e => { e.preventDefault(); loadOrdersList().catch(err => UI.toast(err.message, 'error')); });

  /* ───────── Carga según la pestaña ───────── */
  const loaders = { 'que-sale': loadWhatSale, contenido: loadContent, fotos: loadPhotos, 'pedidos-lista': loadOrdersList };
  function activate(tab) { if (loaders[tab]) loaders[tab]().catch(err => UI.toast(err.message, 'error')); }
  view.querySelectorAll('[data-subtab]').forEach(b => b.addEventListener('click', () => activate(b.dataset.subtab)));
  // Al guardar un plato desde el modal, se refresca la lista.
  window.addEventListener('menu:loaded', () => { if (!view.hidden && view.querySelector('.subtab.active').dataset.subtab === 'que-sale') loadWhatSale().catch(() => {}); });
  window.addEventListener('view:show', e => {
    if (e.detail.view !== 'pagina') return;
    const active = view.querySelector('.subtab.active');
    activate(active ? active.dataset.subtab : 'que-sale');
  });
})();
