/* ═══ Fotos de la página: subir, elegir y quitar (dueño) ═══
   Las fotos se reducen en el navegador antes de subirlas (no hace falta
   prepararlas). Se usan en la portada, categorías, platos y ofertas. */
(function () {
  'use strict';
  const esc = UI.escapeHtml;
  // Fotos que venían con el sistema: ya no hay (cada negocio sube las suyas).
  const BUNDLED = [];

  // Reduce a 1200 px de ancho máximo y JPEG: una foto de celular de 4 MB queda en ~150 KB.
  function resize(file, maxSide = 1200, quality = 0.82) {
    return new Promise((resolve, reject) => {
      if (!/^image\/(jpeg|png|webp|heic|heif)$/i.test(file.type) && !/\.(jpe?g|png|webp)$/i.test(file.name)) return reject(new Error('Elige una foto JPG, PNG o WEBP'));
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        const k = Math.min(1, maxSide / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
        ctx.drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('No se pudo leer esa foto — prueba con otra (JPG o PNG)')); };
      img.src = url;
    });
  }

  async function upload(file) {
    const data_url = await resize(file);
    return Api.media.upload({ name: file.name.replace(/\.[^.]+$/, ''), data_url });
  }

  // Abre la galería. Devuelve la url elegida, null si eligió "Sin foto", o undefined si cerró.
  function pick(opts = {}) {
    return new Promise(resolve => {
      let done = false;
      const finish = v => { if (done) return; done = true; resolve(v); };
      const modal = UI.showModal('Elegir foto', `
        <div class="photo-toolbar">
          <label class="btn btn-primary btn-sm" style="cursor:pointer">Subir foto nueva<input type="file" accept="image/*" id="ph-file" hidden></label>
          <button type="button" class="btn btn-sm" id="ph-none">Sin foto</button>
          <span class="muted" id="ph-status" role="status"></span>
        </div>
        <h3 class="photo-h">Tus fotos</h3><div class="photo-grid" id="ph-mine"><p class="muted">Cargando…</p></div>
        ${opts.bundled === false || !BUNDLED.length ? '' : `<h3 class="photo-h">Fotos de la página</h3><div class="photo-grid" id="ph-bundled"></div>`}`);
      const el = modal.el;
      const cell = (url, name, del) => `<div class="photo-cell${url === opts.current ? ' is-current' : ''}"><button type="button" class="photo-pick" data-url="${esc(url)}" title="${esc(name)}"><img src="${esc(url)}" alt="${esc(name)}" loading="lazy"></button>${del ? `<button type="button" class="photo-del" data-del="${del}" aria-label="Borrar ${esc(name)}">×</button>` : ''}</div>`;
      async function load() {
        const mine = await Api.media.list().catch(() => []);
        el.querySelector('#ph-mine').innerHTML = mine.length ? mine.map(m => cell(m.url, m.name, m.id)).join('') : '<p class="muted">Todavía no has subido fotos.</p>';
      }
      if (opts.bundled !== false && BUNDLED.length) el.querySelector('#ph-bundled').innerHTML = BUNDLED.map(u => cell(u, u.split('/').pop().replace('.jpg', ''))).join('');
      load();
      el.addEventListener('click', async e => {
        const p = e.target.closest('.photo-pick');
        if (p) { finish(p.dataset.url); modal.close(); return; }
        const d = e.target.closest('.photo-del');
        if (d) {
          if (!(await UI.confirmDialog('¿Borrar esta foto? Solo se puede si nada la está usando.'))) return;
          try { await Api.media.remove(d.dataset.del); load(); } catch (err) { UI.toast(err.message, 'error'); }
        }
      });
      el.querySelector('#ph-none').addEventListener('click', () => { finish(null); modal.close(); });
      el.querySelector('#ph-file').addEventListener('change', async e => {
        const f = e.target.files[0]; if (!f) return;
        const st = el.querySelector('#ph-status'); st.textContent = 'Subiendo…';
        try { const m = await upload(f); finish(m.url); modal.close(); }
        catch (err) { st.textContent = ''; UI.toast(err.message, 'error'); }
      });
      const obs = new MutationObserver(() => { if (!document.body.contains(el)) { obs.disconnect(); finish(undefined); } });
      obs.observe(document.body, { childList: true, subtree: true });
    });
  }

  // Campo de formulario con miniatura + Elegir/Quitar. Se lee con .value del <input id>.
  function fieldHtml(id, url, label) {
    return `<div class="f photo-field" data-photo-field="${id}"><span>${esc(label || 'Foto')}</span>
      <div class="photo-field__row">
        <img class="photo-field__thumb" ${url ? `src="${esc(url)}"` : 'hidden'} alt="">
        <button type="button" class="btn btn-sm" data-photo-pick>${url ? 'Cambiar' : 'Elegir foto'}</button>
        <button type="button" class="btn btn-sm" data-photo-clear ${url ? '' : 'hidden'}>Quitar</button>
      </div><input type="hidden" id="${id}" value="${esc(url || '')}"></div>`;
  }
  function bind(root) {
    root.querySelectorAll('[data-photo-field]').forEach(f => {
      const input = f.querySelector('input[type=hidden]'), thumb = f.querySelector('.photo-field__thumb');
      const btn = f.querySelector('[data-photo-pick]'), clear = f.querySelector('[data-photo-clear]');
      const set = u => {
        input.value = u || ''; thumb.hidden = !u; if (u) thumb.src = u;
        btn.textContent = u ? 'Cambiar' : 'Elegir foto'; clear.hidden = !u;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      };
      btn.addEventListener('click', async () => { const u = await pick({ current: input.value }); if (u !== undefined) set(u); });
      clear.addEventListener('click', () => set(null));
    });
  }

  window.Fotos = { pick, fieldHtml, bind, resize, upload };
})();
