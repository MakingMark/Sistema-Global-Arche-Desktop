/* ═══ Preparar: insumos crudos → insumo preparado ═══
   Dos entradas para lo mismo: el administrativo (Inventario → Preparar, en
   cualquier ubicación) y el punto de venta (Mi inventario → Preparar). */
(function () {
  'use strict';
  const esc = UI.escapeHtml;

  // cfg: { prefix, loadPreps() → [{supply_id, name, unit, stock, batch_yield, track_expiry, inputs:[{supply_id,name,unit,quantity,stock}]}],
  //        produce(data), afterProduce() }
  function mount(cfg) {
    const $ = id => document.getElementById(`${cfg.prefix}-${id}`);
    if (!$('supply')) return null;
    let preps = [];
    let touchedOutput = false;

    const current = () => preps.find(p => String(p.supply_id) === $('supply').value);
    const batches = () => Number($('batches').value) || 0;

    function renderPreview() {
      const p = current();
      const errorEl = $('error');
      errorEl.hidden = true;
      if (!p) { $('preview').innerHTML = '<p class="muted">Todavía no hay insumos preparados. Se crean en Insumos → Editar → “Es un insumo preparado”.</p>'; $('go').disabled = true; return; }
      const n = batches();
      const expected = p.batch_yield * n;
      $('unit').textContent = `(${p.unit}) — esperado ${fmtNum(expected)}`;
      if (!touchedOutput) $('output').value = expected ? String(Math.round(expected * 1000) / 1000) : '';
      $('expiry-wrap').hidden = !p.track_expiry;
      const rows = p.inputs.map(i => {
        const need = i.quantity * n;
        const short = need > i.stock + 1e-9;
        return `<div class="prep-row${short ? ' is-short' : ''}"><span>${esc(i.name)}</span><span>${fmtNum(need)} ${esc(i.unit)} <span class="muted">· hay ${fmtNum(i.stock)}</span>${short ? ' <strong>— no alcanza</strong>' : ''}</span></div>`;
      }).join('');
      const out = Number($('output').value) || 0;
      const yieldPct = expected ? Math.round(out / expected * 1000) / 10 : 0;
      $('preview').innerHTML = `<div class="prep-title">Se gastan:</div>${rows}
        <div class="prep-row prep-total"><span>Rendimiento real</span><span>${out ? `${yieldPct}% de lo esperado` : '—'}</span></div>`;
      $('go').disabled = !n || !out || p.inputs.some(i => i.quantity * n > i.stock + 1e-9);
    }

    async function load() {
      try { preps = await cfg.loadPreps(); } catch (err) { UI.toast(err.status === undefined ? 'Sin conexión con el servidor' : err.message, 'error'); return; }
      const keep = $('supply').value;
      $('supply').innerHTML = preps.map(p => `<option value="${p.supply_id}">${esc(p.name)}</option>`).join('');
      if (keep) $('supply').value = keep;
      touchedOutput = false;
      renderPreview();
    }

    $('supply').addEventListener('change', () => { touchedOutput = false; renderPreview(); });
    $('batches').addEventListener('input', () => { touchedOutput = false; renderPreview(); });
    $('output').addEventListener('input', () => { touchedOutput = true; renderPreview(); });
    if ($('location')) $('location').addEventListener('change', load);

    $('go').addEventListener('click', async () => {
      const p = current();
      if (!p) return;
      const btn = $('go');
      btn.disabled = true;
      $('error').hidden = true;
      try {
        const run = await cfg.produce({
          supply_id: p.supply_id, batches: batches(), output_quantity: Number($('output').value),
          expires_on: (!$('expiry-wrap').hidden && $('expiry').value) || null, note: $('note').value.trim() || null
        });
        UI.toast(`Preparado: ${fmtNum(run.actual_output)} ${run.supply_unit} de ${run.supply_name} (${run.yield_pct}% de lo esperado) · costo ${fmtCost(run.unit_cost)} por ${run.supply_unit}`);
        $('note').value = '';
        touchedOutput = false;
        await load();
        if (cfg.afterProduce) cfg.afterProduce();
      } catch (err) {
        $('error').textContent = err.status === undefined ? 'Sin conexión con el servidor — la preparación necesita conexión.' : err.message;
        $('error').hidden = false;
        renderPreview();
      }
    });
    return { load };
  }

  /* ── Administrativo ── */
  const owner = mount({
    prefix: 'prep',
    async loadPreps() {
      const locId = document.getElementById('prep-location').value;
      const [supplies, stock] = await Promise.all([Api.supplies.list(), locId ? Api.locations.stock(locId) : { supplies: [] }]);
      const stockOf = new Map(stock.supplies.map(s => [s.supply_id, Number(s.stock)]));
      return supplies.filter(s => s.preparation && s.active).map(s => ({
        supply_id: s.id, name: s.name, unit: s.unit, stock: stockOf.get(s.id) || 0, batch_yield: s.preparation.batch_yield, track_expiry: s.track_expiry,
        inputs: s.preparation.inputs.map(i => ({ supply_id: i.supply_id, name: i.name, unit: i.unit, quantity: i.quantity, stock: stockOf.get(i.supply_id) || 0 }))
      }));
    },
    produce: data => Api.supplies.produce(data.supply_id, { ...data, location_id: Number(document.getElementById('prep-location').value) }),
    afterProduce: () => renderHistory()
  });

  async function renderHistory() {
    const el = document.getElementById('prep-history');
    if (!el) return;
    let data;
    try { data = await Api.reports.production({}); } catch (_) { return; }
    el.innerHTML = data.runs.length ? `<div class="table-scroll"><table class="table"><thead><tr><th>Fecha</th><th>Dónde</th><th>Qué</th><th class="num">Tandas</th><th class="num">Salió</th><th class="num">Rendimiento</th><th class="num">Costo/u</th><th>Nota</th></tr></thead><tbody>${
      data.runs.slice(0, 30).map(r => `<tr><td data-th="Fecha">${fmtDate(r.created_at)}</td><td data-th="Dónde">${esc(r.location_name)}</td><td data-th="Qué">${esc(r.supply_name)}</td><td class="num" data-th="Tandas">${fmtNum(r.batches)}</td><td class="num" data-th="Salió">${fmtNum(r.actual_output)} ${esc(r.supply_unit)}</td><td class="num ${r.yield_pct < 85 ? 'low-stock' : ''}" data-th="Rendimiento">${r.yield_pct}%</td><td class="num" data-th="Costo/u">${fmtCost(r.unit_cost)}</td><td data-th="Nota">${esc(r.note || '—')}</td></tr>`).join('')
    }</tbody></table></div>` : '<p class="muted">Todavía no se preparó nada.</p>';
  }

  window.addEventListener('view:show', async e => {
    if (e.detail.view === 'inv-preparar' && owner) {
      const sel = document.getElementById('prep-location');
      const locations = await Api.locations.list();
      const keep = sel.value;
      sel.innerHTML = locations.filter(l => l.active).map(l => `<option value="${l.id}">${esc(l.name)}</option>`).join('');
      if (keep) sel.value = keep;
      owner.load();
      renderHistory();
    }
  });
})();
