/* ═══ Selector de insumo + tipo de unidad (suelta / empaque de compra /
   empaque de reparto) ═══
   Usado por Inventario → Transferir (transferir.js). `idKey` existe porque
   el selector puede recibir insumos con distinta forma de id. */
window.SupplyPicker = (function () {
  'use strict';

  function suppliesOptions(supplies, idKey) {
    return supplies.map(s => `<option value="${s[idKey]}">${UI.escapeHtml(s.name)} (${UI.escapeHtml(s.unit)})</option>`).join('');
  }

  function unitTypeOptions(supplies, idKey, supplyId) {
    const s = supplies.find(x => String(x[idKey]) === String(supplyId));
    let opts = `<option value="unit">${s ? UI.escapeHtml(s.unit) : 'unidad'}</option>`;
    if (s && s.pack_name && s.pack_size) {
      opts += `<option value="pack">${UI.escapeHtml(s.pack_name)} (${fmtNum(s.pack_size)})</option>`;
    }
    // Empaque de reparto — puede ser distinto al de compra (ej. se compra
    // por caja de 1000 pero se transfiere/ajusta por paquete de 50, ver
    // schema.sql) — se ofrece como una opción más, no reemplaza a la otra.
    if (s && s.transfer_pack_name && s.transfer_pack_size) {
      opts += `<option value="transfer_pack">${UI.escapeHtml(s.transfer_pack_name)} (${fmtNum(s.transfer_pack_size)})</option>`;
    }
    return opts;
  }

  return { suppliesOptions, unitTypeOptions };
})();
