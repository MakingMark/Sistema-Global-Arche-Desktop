/* ═══ Configuración → Licencia y plan (fase 3) ═══
   Solo en instalaciones con licencia (PC de un cliente: ARCHE_EDICION=escritorio
   o paquete forzado). Muestra plan, vencimiento y código de la PC, y deja pegar
   una clave nueva sin salir del sistema. En un VPS propio /api/licencia dice
   activa:false y la tarjeta no aparece. */
(function () {
  'use strict';
  const card = document.getElementById('lic-card');
  if (!card) return;
  const $ = id => document.getElementById(id);
  const ARCHE_WHATSAPP = '18099618211';

  async function cargar() {
    let e;
    try { e = await (await fetch('/api/licencia', { cache: 'no-store' })).json(); } catch (_) { return; }
    if (!e || !e.activa) { card.hidden = true; return; }
    card.hidden = false;
    $('lic-plan').textContent = e.planNombre || '—';
    $('lic-vence').textContent = e.vence || '—';
    $('lic-codigo').textContent = e.codigo || '—';
    const badge = $('lic-badge');
    badge.className = 'badge ' + (!e.valida ? 'badge-voided' : e.aviso ? 'badge-warn' : 'badge-ok');
    badge.textContent = !e.valida ? 'Vencida' : e.aviso ? `Vence en ${e.diasRestantes} d` : 'Vigente';
    $('lic-resumen').textContent = e.valida
      ? `${e.negocio || 'Este negocio'} · quedan ${e.diasRestantes} día${e.diasRestantes === 1 ? '' : 's'}`
      : (e.motivo || 'Sin licencia');
    const extra = [];
    if ((e.modulosExtra || []).length) extra.push(`Módulos extra: ${e.modulosExtra.join(', ')}`);
    if (e.limites && e.limites.products) extra.push(`hasta ${e.limites.products} productos`);
    if (e.limites && e.limites.employees) extra.push(`hasta ${e.limites.employees} empleados`);
    $('lic-extra').hidden = !extra.length;
    $('lic-extra').textContent = extra.join(' · ');
    $('lic-wa').href = `https://wa.me/${ARCHE_WHATSAPP}?text=${encodeURIComponent(`Hola, Arche. Quiero renovar la licencia de ${e.negocio || 'mi negocio'}. Código de la PC: ${e.codigo}`)}`;
  }

  $('lic-activar').addEventListener('click', async () => {
    const clave = $('lic-clave').value.trim();
    const msg = $('lic-msg');
    if (!clave) { msg.textContent = 'Pega la clave primero.'; return; }
    $('lic-activar').disabled = true;
    try {
      const r = await fetch('/api/licencia', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ clave }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'No se pudo activar');
      msg.textContent = `Listo: licencia hasta el ${d.vence}. Recargando…`;
      UI.toast('Licencia activada');
      setTimeout(() => location.reload(), 1200);   // el plan nuevo puede cambiar los módulos
    } catch (err) {
      msg.textContent = err.message;
      $('lic-activar').disabled = false;
    }
  });

  window.addEventListener('view:show', e => { if (e.detail.view === 'configuracion') cargar(); });
})();
