/* ═══ Explicaciones al inicio de cada pantalla, cortas en el celular (v3.12) ═══
   Muchas pantallas abren con un párrafo que explica para qué sirven. Es útil
   la primera vez, pero en el celular empuja el contenido real hacia abajo. Ahí
   se muestran 2 líneas y «… más»; un toque lo abre entero (y otro lo cierra). */
(function () {
  'use strict';
  const phone = window.matchMedia('(max-width: 820px)');
  function preparar(p) {
    if (p.dataset.intro) return;
    p.dataset.intro = '1';
    p.classList.add('intro');
    p.setAttribute('role', 'button');
    p.tabIndex = 0;
    p.title = 'Toca para leer todo';
    const toggle = () => p.classList.toggle('is-open');
    p.addEventListener('click', e => { if (phone.matches && !e.target.closest('a, button')) toggle(); });
    p.addEventListener('keydown', e => { if (phone.matches && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); toggle(); } });
  }
  document.querySelectorAll('.view > h1 + p.muted').forEach(preparar);

  // Formularios de «Crear…/Nuevo…» que van ARRIBA de una lista (Empleados,
  // Gastos, Ubicaciones…): en el celular se pliegan en su título, que pasa a
  // ser un botón «+ Crear empleado». Si el formulario es lo único de la
  // pantalla (ej. Entradas), se queda abierto.
  const RX = /^(crear|nuevo|nueva|agregar|añadir|registrar)\b/i;
  document.querySelectorAll('#owner-app .view .card-quiet > h2:first-child, #owner-app .view .card > h2:first-child').forEach(h2 => {
    const card = h2.parentElement;
    if (!RX.test(h2.textContent.trim())) return;
    let sib = card.nextElementSibling, hayLista = false;
    while (sib) { if (sib.matches('.card, .card-quiet, .table-scroll, table, .grid-2, [id$="-list"], [id$="-lista"]')) { hayLista = true; break; } sib = sib.nextElementSibling; }
    if (!hayLista) return;
    card.classList.add('plegable');
    h2.setAttribute('role', 'button');
    h2.tabIndex = 0;
    h2.setAttribute('aria-expanded', 'false');
    const toggle = () => { if (!phone.matches) return; const open = card.classList.toggle('is-open'); h2.setAttribute('aria-expanded', String(open)); };
    h2.addEventListener('click', toggle);
    h2.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
  });
})();
