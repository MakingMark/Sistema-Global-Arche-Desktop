/* ═══ Pestañas dentro de una pantalla (genérico) ═══
   Cualquier `<div class="subtabs" data-subtabs>` con botones `[data-subtab]`
   maneja los paneles `[data-subpanel]` de su misma pantalla. En celular la
   fila de pestañas se desliza de lado (ver .subtabs en app.css). Historial y
   Tendencias tienen su propia lógica (cargan datos al cambiar); estas son
   solo de mostrar/ocultar. Flechas izquierda/derecha cambian de pestaña. */
(function () {
  'use strict';
  document.querySelectorAll('.subtabs[data-subtabs]').forEach(bar => {
    const scope = bar.closest('section.view') || document;
    const buttons = Array.from(bar.querySelectorAll('[data-subtab]'));
    const panels = scope.querySelectorAll('[data-subpanel]');

    function show(name, { focus = false } = {}) {
      buttons.forEach(b => {
        const on = b.dataset.subtab === name;
        b.classList.toggle('active', on);
        b.setAttribute('aria-selected', String(on));
        b.tabIndex = on ? 0 : -1;
        if (on) {
          b.scrollIntoView({ inline: 'center', block: 'nearest' });
          if (focus) b.focus();
        }
      });
      panels.forEach(p => { p.hidden = p.dataset.subpanel !== name; });
      bar.dispatchEvent(new CustomEvent('subtab:show', { bubbles: true, detail: { name } }));
    }

    buttons.forEach((b, i) => {
      b.addEventListener('click', () => show(b.dataset.subtab));
      b.addEventListener('keydown', e => {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
        e.preventDefault();
        const next = buttons[(i + (e.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length];
        show(next.dataset.subtab, { focus: true });
      });
    });
    const initial = buttons.find(b => b.classList.contains('active')) || buttons[0];
    if (initial) show(initial.dataset.subtab);
  });
})();
