/* ═══ Configuración → Tipo de negocio, moneda y medios de pago (dueño) ═══ */
(function () {
  'use strict';
  const card = document.getElementById('negocio-card');
  if (!card) return;
  const $ = id => document.getElementById(id);
  // Módulos recomendados por tipo (mismas combinaciones listas del servidor).
  const PRESET_BY_ACTIVITY = { restaurante: 'restaurante', cafeteria: 'comida_rapida', tienda: 'tienda', servicios: 'servicios', otro: 'restaurante' };

  async function load() {
    const s = await Api.settings.get();
    $('neg-activity').value = s.activity || 'restaurante';
    $('neg-currency').value = s.currency_symbol || 'RD$';
    $('neg-payments').value = (s.payment_methods || []).join(', ');
  }
  $('neg-save').addEventListener('click', async () => {
    $('neg-error').hidden = true;
    try {
      const s = await Api.settings.updateBusiness({
        activity: $('neg-activity').value, currency_symbol: $('neg-currency').value.trim(),
        payment_methods: $('neg-payments').value.split(',').map(x => x.trim()).filter(Boolean)
      });
      AppLocale.set(s);
      $('neg-status').textContent = 'Guardado.';
      UI.toast('Guardado');
    } catch (err) { $('neg-error').textContent = err.message; $('neg-error').hidden = false; }
  });
  $('neg-apply-modules').addEventListener('click', async () => {
    $('neg-error').hidden = true;
    try {
      const r = await Api.settings.modules();
      const p = r.presets.find(x => x.id === PRESET_BY_ACTIVITY[$('neg-activity').value]);
      if (!p) return;
      if (!(await UI.confirmDialog(`¿Aplicar «${p.label}»? Cambia qué partes del sistema se ven (no borra ningún dato).`))) return;
      const patch = Object.fromEntries(r.modules.map(m => [m.id, p.modules[m.id] === undefined ? true : !!p.modules[m.id]]));
      const out = await Api.settings.saveModules(patch);
      Modules.set(Object.fromEntries(out.modules.map(m => [m.id, m.enabled])));
      UI.toast('Módulos actualizados');
    } catch (err) { $('neg-error').textContent = err.message; $('neg-error').hidden = false; }
  });
  window.addEventListener('view:show', e => { if (e.detail.view === 'configuracion') load().catch(() => {}); });
})();
