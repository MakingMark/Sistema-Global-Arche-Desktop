/* ═══ Ofertas: combos de productos MIXTOS a un precio fijo, habilitables
   por punto de venta (dueño) ═══ Cada producto del combo, al venderse, sigue
   costando lo real (receta); solo el PRECIO base se reparte proporcional
   entre las líneas, y las opciones con costo extra se cobran encima — ver
   salesService.js. */
(function () {
  'use strict';
  const form = document.getElementById('form-oferta');
  if (!form) return;
  const recetaBuilder = document.getElementById('oferta-receta-builder');
  const gridEl = document.getElementById('ofertas-grid');

  let vasos = []; // productos activos del menú — cualquiera puede ir en un combo
  let locations = [];
  let offers = [];

  async function loadOptions() {
    const [products, locs] = await Promise.all([Api.products.list(), Api.locations.list()]);
    vasos = products.filter(p => p.active);
    locations = locs.filter(l => l.kind === 'carrito' && l.active);
  }

  function productLabel(p) {
    return `${UI.escapeHtml(p.name)} (${fmt(p.sale_price)})`;
  }

  function productsOptions(selectedId) {
    return vasos.map(p =>
      `<option value="${p.id}" ${String(p.id) === String(selectedId) ? 'selected' : ''}>${productLabel(p)}</option>`
    ).join('');
  }

  function addRecetaRow(container, productId, qty) {
    if (!vasos.length) return;
    const row = document.createElement('div');
    row.className = 'receta-row';
    row.innerHTML = `
      <select>${productsOptions(productId)}</select>
      <input type="number" placeholder="Cantidad" step="1" min="1" value="${qty || 1}">
      <button type="button" class="btn btn-sm">Quitar</button>
    `;
    row.querySelector('button').addEventListener('click', () => row.remove());
    container.appendChild(row);
  }

  function readReceta(container) {
    return Array.from(container.querySelectorAll('.receta-row'))
      .map(row => ({
        product_id: Number(row.querySelector('select').value),
        quantity: Number(row.querySelector('input').value)
      }))
      .filter(r => r.product_id && r.quantity > 0);
  }

  // Qué muestra la página de esta oferta.
  function showWebModal(o) {
    const modal = UI.showModal(`Página web · ${UI.escapeHtml(o.name)}`, `
      <label class="f-check"><input type="checkbox" id="ow-visible" ${o.web_visible ? 'checked' : ''}><span>Mostrar esta oferta en la página de pedidos</span></label>
      <p class="muted" style="font-size:.85em">Solo aparece si además está activa y habilitada en el punto de venta que recibe los pedidos de la página.</p>
      <label class="f" style="max-width:none;margin-top:8px"><span>Etiqueta (ej. “Combo del mes”)</span><input id="ow-label" maxlength="40" value="${UI.escapeHtml(o.label || '')}"></label>
      <label class="f" style="max-width:none;margin-top:8px"><span>Descripción</span><input id="ow-desc" maxlength="200" value="${UI.escapeHtml(o.description || '')}" placeholder="ej. Tu batida favorita con un waffle de avena"></label>
      <div style="margin-top:8px">${Fotos.fieldHtml('ow-image', o.image_url, 'Foto de la oferta')}</div>
      <div class="modal-actions" style="margin-top:16px"><button class="btn" id="ow-cancel">Cancelar</button><button class="btn btn-primary" id="ow-save">Guardar</button></div>`);
    Fotos.bind(modal.el);
    modal.el.querySelector('#ow-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#ow-save').addEventListener('click', async () => {
      try {
        await Api.offers.update(o.id, { web_visible: modal.el.querySelector('#ow-visible').checked, label: modal.el.querySelector('#ow-label').value.trim(), description: modal.el.querySelector('#ow-desc').value.trim(), image_url: modal.el.querySelector('#ow-image').value || null });
        modal.close(); UI.toast('Guardado'); render();
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  }

  document.getElementById('oferta-add-receta-row').addEventListener('click', () => {
    if (!vasos.length) { UI.toast('Todavía no hay ningún producto creado en Menú', 'error'); return; }
    addRecetaRow(recetaBuilder);
  });

  async function showLocationsModal(offer) {
    const body = `
      <p class="muted" style="margin-top:-4px">Marca en qué puntos de venta aparece esta oferta al vender.</p>
      ${locations.length ? locations.map(l => `
        <label class="f-check" style="margin-bottom:8px">
          <input type="checkbox" value="${l.id}" ${offer.location_ids.includes(l.id) ? 'checked' : ''}>
          <span>${UI.escapeHtml(l.name)}</span>
        </label>
      `).join('') : '<p class="muted">Todavía no hay ningún punto de venta activo.</p>'}
      <div class="modal-actions">
        <button class="btn" id="oferta-locs-cancel">Cancelar</button>
        <button class="btn btn-primary" id="oferta-locs-save">Guardar</button>
      </div>
    `;
    const modal = UI.showModal(`Puntos de venta · ${UI.escapeHtml(offer.name)}`, body);
    modal.el.querySelector('#oferta-locs-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#oferta-locs-save').addEventListener('click', async () => {
      const ids = Array.from(modal.el.querySelectorAll('input[type="checkbox"]:checked')).map(i => Number(i.value));
      try {
        await Api.offers.setLocations(offer.id, ids);
        modal.close();
        UI.toast('Puntos de venta actualizados');
        render();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  async function showEditModal(offer) {
    const body = `
      <div class="f" style="margin-bottom:12px"><span>Nombre</span><input id="edit-oferta-name" value="${UI.escapeHtml(offer.name)}"></div>
      <div class="f" style="margin-bottom:12px"><span>Precio del combo (RD$)</span><input type="number" id="edit-oferta-price" step="0.01" min="0" value="${Number(offer.price)}"></div>
      <div style="margin-bottom:8px;font-weight:700;font-size:.9em;color:var(--ink-soft)">Productos del combo</div>
      <div id="edit-oferta-receta" class="receta-builder"></div>
      <button type="button" class="btn btn-sm" id="edit-oferta-add-row" style="margin-top:8px">+ Producto</button>
      <label class="f-check" style="margin-top:16px"><input type="checkbox" id="edit-oferta-active" ${offer.active ? 'checked' : ''}><span>Activa</span></label>
      <div class="modal-actions" style="margin-top:20px">
        <button class="btn" id="edit-oferta-cancel">Cancelar</button>
        <button class="btn btn-primary" id="edit-oferta-save">Guardar</button>
      </div>
    `;
    const modal = UI.showModal(`Editar · ${UI.escapeHtml(offer.name)}`, body);
    const recetaEl = modal.el.querySelector('#edit-oferta-receta');
    offer.items.forEach(it => addRecetaRow(recetaEl, it.product_id, Number(it.quantity)));
    modal.el.querySelector('#edit-oferta-add-row').addEventListener('click', () => addRecetaRow(recetaEl));
    modal.el.querySelector('#edit-oferta-cancel').addEventListener('click', () => modal.close());
    modal.el.querySelector('#edit-oferta-save').addEventListener('click', async () => {
      const name = modal.el.querySelector('#edit-oferta-name').value.trim();
      const price = Number(modal.el.querySelector('#edit-oferta-price').value);
      const active = modal.el.querySelector('#edit-oferta-active').checked;
      const items = readReceta(recetaEl);
      if (!name) { UI.toast('El nombre no puede quedar vacío', 'error'); return; }
      if (!items.length) { UI.toast('El combo necesita al menos un producto', 'error'); return; }
      try {
        await Api.offers.update(offer.id, { name, price, active, items });
        modal.close();
        UI.toast('Oferta actualizada');
        render();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  function renderGrid() {
    gridEl.innerHTML = '';
    if (!offers.length) {
      gridEl.innerHTML = '<p class="muted">Todavía no hay ofertas — crea una arriba.</p>';
      return;
    }
    offers.forEach(o => {
      const normalPrice = o.items.reduce((sum, it) => sum + Number(it.product_sale_price) * Number(it.quantity), 0);
      const savings = normalPrice - Number(o.price);
      const perf = o.performance;
      const locNames = o.location_ids
        .map(id => locations.find(l => l.id === id))
        .filter(Boolean)
        .map(l => l.name);
      const itemsLabel = o.items.map(it => `${Number(it.quantity)} x ${UI.escapeHtml(it.product_name)}`).join(' + ');
      const card = document.createElement('div');
      card.className = 'product-card';
      card.innerHTML = `
        <div class="product-card-header">
          <strong>${UI.escapeHtml(o.name)}</strong>
          <div class="muted product-card-subtitle">
            ${itemsLabel} — ${fmt(o.price)}
            ${savings > 0 ? ` <span class="best-tag">ahorra ${fmt(savings)}</span>` : ''}
            ${!o.active ? ' <span class="tag-neutral">pausada</span>' : ''}
          </div>
          <div class="muted product-card-subtitle">
            ${locNames.length ? `En: ${locNames.map(UI.escapeHtml).join(', ')}` : 'No habilitada en ningún punto de venta todavía'}
            ${o.web_visible ? ' · <span class="badge badge-ok">En la página</span>' : ''}
          </div>
        </div>
        <div class="product-card-stats">
          <div><span class="label">Vendida</span><span class="value">${perf.times_sold} ${perf.times_sold === 1 ? 'vez' : 'veces'}</span></div>
          <div><span class="label">Ingreso</span><span class="value">${fmt(perf.revenue)}</span></div>
          <div><span class="label">Ganancia</span><span class="value">${fmt(perf.profit)}</span></div>
        </div>
        <div class="product-card-actions"></div>
      `;
      const actions = card.querySelector('.product-card-actions');
      const locBtn = document.createElement('button');
      locBtn.className = 'btn btn-sm';
      locBtn.textContent = 'Puntos de venta';
      locBtn.addEventListener('click', () => showLocationsModal(o));
      const editBtn = document.createElement('button');
      editBtn.className = 'btn btn-sm';
      editBtn.innerHTML = UI.iconLabel('edit', 'Editar');
      editBtn.addEventListener('click', () => showEditModal(o));
      const delBtn = document.createElement('button');
      delBtn.className = 'btn btn-sm';
      delBtn.innerHTML = UI.iconLabel('trash', 'Eliminar');
      delBtn.addEventListener('click', async () => {
        const ok = await UI.confirmDialog(`¿Eliminar "${UI.escapeHtml(o.name)}"? Las ventas ya hechas con esta oferta quedan intactas en el historial.`);
        if (!ok) return;
        await Api.offers.remove(o.id);
        UI.toast('Oferta eliminada');
        render();
      });
      const webBtn = document.createElement('button');
      webBtn.className = 'btn btn-sm';
      webBtn.textContent = o.web_visible ? 'Página: sí' : 'Página web';
      webBtn.addEventListener('click', () => showWebModal(o));
      actions.append(locBtn, webBtn, editBtn, delBtn);
      gridEl.appendChild(card);
    });
  }

  async function render() {
    offers = await Api.offers.list();
    renderGrid();
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const items = readReceta(recetaBuilder);
    if (!items.length) { UI.toast('Agrega al menos un producto al combo', 'error'); return; }
    try {
      await Api.offers.create({
        name: fd.get('name'),
        price: Number(fd.get('price')),
        items
      });
      form.reset();
      recetaBuilder.innerHTML = '';
      UI.toast('Oferta creada — ahora elige en qué puntos de venta habilitarla');
      render();
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  window.addEventListener('view:show', async e => {
    if (e.detail.view === 'ofertas') {
      await loadOptions();
      if (!recetaBuilder.children.length) addRecetaRow(recetaBuilder);
      await render();
    }
  });
})();
