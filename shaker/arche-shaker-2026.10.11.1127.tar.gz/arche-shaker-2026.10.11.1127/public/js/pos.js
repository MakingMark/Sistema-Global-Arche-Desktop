/* ═══ App del punto de venta: vender, ver inventario propio, pedir reposición ═══ */
(function () {
  'use strict';
  // "Hoy" con los componentes LOCALES de la fecha (año/mes/día tal como los
  // da el propio reloj del dispositivo) — nunca .toISOString().slice(0,10),
  // que da la fecha en UTC y se adelanta un día entero entre las 8pm y la
  // medianoche en Santo Domingo (UTC-4).
  // localIsoDate ahora es global — ver api.js.

  if (!document.getElementById('pos-product-grid')) return;

  const cartItemsEl = document.getElementById('pos-cart-items');
  const totalEl = document.getElementById('pos-total');
  const btnConfirmar = document.getElementById('btn-confirmar-pos-venta');
  const errorEl = document.getElementById('pos-venta-error');
  const reciboModal = document.getElementById('pos-recibo-modal');
  const reciboTexto = document.getElementById('pos-recibo-texto');
  // Pedido de la página/teléfono/delivery (ver <details id="pos-extra"> en index.html)
  const canalSel = document.getElementById('pos-canal');
  const entregaSel = document.getElementById('pos-entrega');
  const feeWrap = document.getElementById('pos-delivery-wrap');
  const feeInput = document.getElementById('pos-delivery-fee');
  const notaInput = document.getElementById('pos-nota');
  const deliveryRow = document.getElementById('pos-row-delivery');
  // Medios de pago del negocio (Configuración): la lista se rearma cuando llega o cambia.
  const pagoSel = document.getElementById('pos-pago');

  // ── v3.3 (fase 1): forma de pago en botones, vuelto y cliente plegable ──
  // El <select> sigue mandando (lo leen la venta y la cola sin conexión); los
  // botones solo lo cambian. Se recuerda el último pago usado EN ESTE equipo.
  const payButtonsEl = document.getElementById('pos-pay-buttons');
  const efectivoEl = document.getElementById('pos-efectivo');
  const cashChipsEl = document.getElementById('pos-cash-chips');
  const recibidoInput = document.getElementById('pos-recibido');
  const vueltoEl = document.getElementById('pos-vuelto');
  const vueltoLabel = document.getElementById('pos-vuelto-label');
  const vueltoMonto = document.getElementById('pos-vuelto-monto');
  const clienteWrap = document.getElementById('pos-cliente-wrap');
  const toggleClienteBtn = document.getElementById('pos-toggle-cliente');
  const LAST_PAY_KEY = 'arche_ultimo_pago';
  const isCash = m => /efectivo|cash/i.test(m || '');
  const isCredit = m => /fiado|cr[eé]dito/i.test(m || '');
  let recibido = null;   // null = paga exacto
  let lastTotal = 0;

  function renderPayButtons() {
    payButtonsEl.innerHTML = AppLocale.payments().map(m =>
      `<button type="button" class="pay-btn${m === pagoSel.value ? ' is-active' : ''}" role="radio" aria-checked="${m === pagoSel.value}" data-pay="${UI.escapeHtml(m)}">${UI.escapeHtml(m)}</button>`).join('');
  }
  function showCliente(on) {
    clienteWrap.hidden = !on;
    toggleClienteBtn.setAttribute('aria-expanded', String(on));
    toggleClienteBtn.textContent = on ? '− Cliente' : '+ Cliente';
  }
  function setPago(m, remember) {
    pagoSel.value = m;
    if (remember) { try { localStorage.setItem(LAST_PAY_KEY, m); } catch (_) {} }
    renderPayButtons();
    updateCash();
    if (isCredit(m)) showCliente(true);   // el fiado necesita saber a quién
  }
  // Billetes dominicanos: se ofrecen los 3 primeros que alcanzan para el total.
  function cashOptions(total) {
    const bills = [50, 100, 200, 500, 1000, 2000];
    let opts = bills.filter(b => b > total).slice(0, 3);
    if (opts.length < 3) {
      for (let k = Math.ceil((total + 1) / 1000) * 1000; opts.length < 3; k += 1000) if (!opts.includes(k) && k > total) opts.push(k);
    }
    return opts;
  }
  function updateCash() {
    const show = isCash(pagoSel.value) && lastTotal > 0;
    efectivoEl.hidden = !show;
    if (!show) return;
    const opts = cashOptions(lastTotal);
    const otro = recibido !== null && !opts.includes(recibido);
    cashChipsEl.innerHTML =
      `<button type="button" class="cash-chip${recibido === null ? ' is-active' : ''}" data-cash="exacto">Exacto</button>` +
      opts.map(v => `<button type="button" class="cash-chip${recibido === v ? ' is-active' : ''}" data-cash="${v}">${fmt(v)}</button>`).join('') +
      `<button type="button" class="cash-chip${otro || !recibidoInput.hidden ? ' is-active' : ''}" data-cash="otro">Otro</button>`;
    if (recibido === null) { vueltoEl.hidden = true; return; }
    const diff = Math.round((recibido - lastTotal) * 100) / 100;
    vueltoEl.hidden = false;
    vueltoEl.classList.toggle('is-short', diff < 0);
    vueltoLabel.textContent = diff < 0 ? 'Faltan' : 'Vuelto';
    vueltoMonto.textContent = fmt(Math.abs(diff));
    Motion.bump(vueltoMonto);
  }
  payButtonsEl.addEventListener('click', e => {
    const b = e.target.closest('[data-pay]');
    if (b) setPago(b.dataset.pay, true);
  });
  cashChipsEl.addEventListener('click', e => {
    const b = e.target.closest('[data-cash]');
    if (!b) return;
    const v = b.dataset.cash;
    if (v === 'otro') { recibidoInput.hidden = false; recibidoInput.focus(); recibido = Number(recibidoInput.value) > 0 ? Number(recibidoInput.value) : null; }
    else { recibidoInput.hidden = true; recibidoInput.value = ''; recibido = v === 'exacto' ? null : Number(v); }
    updateCash();
  });
  recibidoInput.addEventListener('input', () => {
    recibido = Number(recibidoInput.value) > 0 ? Number(recibidoInput.value) : null;
    updateCash();
  });
  toggleClienteBtn.addEventListener('click', () => showCliente(clienteWrap.hidden));

  const fillPayments = () => {
    const keep = pagoSel.value;
    pagoSel.innerHTML = AppLocale.payments().map(m => `<option>${UI.escapeHtml(m)}</option>`).join('');
    let saved = null; try { saved = localStorage.getItem(LAST_PAY_KEY); } catch (_) {}
    if (keep && AppLocale.payments().includes(keep)) pagoSel.value = keep;
    else if (saved && AppLocale.payments().includes(saved)) pagoSel.value = saved;
    renderPayButtons();
    updateCash();
  };
  fillPayments();
  window.addEventListener('locale:changed', fillPayments);
  const deliveryFee = () => (entregaSel.value === 'delivery' ? Math.max(0, Number(feeInput.value) || 0) : 0);

  // ── Cliente por teléfono (opcional) ──────────────────────────────────
  // El teléfono es el identificador real del cliente (ver customerService.js
  // en el servidor) — si ya existe, el nombre se autocompleta y se bloquea
  // (no se puede pisar desde acá, para que el mismo número nunca termine
  // con dos nombres distintos en la base — pedido explícito del dueño).
  // Solo el número LOCAL (10 dígitos, sin "+1") — mismo criterio que el
  // campo de WhatsApp en Configuración, para no repetir la confusión de
  // tener que escribir el código de país a mano.
  const clientePhoneInput = document.getElementById('pos-cliente-telefono');
  const clienteNombreInput = document.getElementById('pos-cliente');
  const clienteHintEl = document.getElementById('pos-cliente-hint');
  let phoneLookupTimer = null;

  function normalizeLocalPhone(raw) {
    const digits = String(raw || '').replace(/\D/g, '');
    if (!digits) return '';
    return (digits.length === 11 && digits.startsWith('1')) ? digits : `1${digits}`;
  }

  function unlockClienteNombre() {
    clienteNombreInput.readOnly = false;
    clienteHintEl.textContent = '';
  }

  clientePhoneInput.addEventListener('input', () => {
    clearTimeout(phoneLookupTimer);
    const digits = clientePhoneInput.value.replace(/\D/g, '');
    if (digits.length < 10) { unlockClienteNombre(); return; }
    phoneLookupTimer = setTimeout(async () => {
      try {
        const customer = await Api.pos.lookupCustomer(normalizeLocalPhone(clientePhoneInput.value));
        if (customer && customer.name) {
          clienteNombreInput.value = customer.name;
          clienteNombreInput.readOnly = true;
          clienteHintEl.textContent = '· cliente conocido' + (Number(customer.balance) > 0 ? ` · debe ${fmt(customer.balance)}` : '');
        } else {
          unlockClienteNombre();
        }
      } catch (_) { /* sin red o lo que sea — no bloquea armar la venta */ }
    }, 400);
  });

  // Banner de conexión/sincronización — offlineSync.js avisa por evento en
  // vez de que este archivo tenga que conocer sus detalles internos (cola,
  // IndexedDB, etc.), así cualquiera de los dos se puede tocar por separado.
  const offlineBanner = document.getElementById('offline-banner');

  // Una venta "failed" ya no es un problema de red — el servidor la vio y la
  // rechazó de verdad (ej. quedó mal armada, o algo cambió entre que se
  // hizo offline y que se pudo mandar). Reintentarla sola para siempre no
  // sirve de nada; hace falta que alguien la mire y decida. El banner se
  // vuelve tocable para ese caso puntual.
  async function showFailedSalesModal() {
    const pending = await OfflineDb.getPendingSales();
    const failed = pending.filter(p => p.status === 'failed');
    if (!failed.length) return;
    const body = `
      <p class="muted" style="margin-top:-4px">Estas ventas se hicieron sin conexión pero el sistema las rechazó al intentar sincronizarlas de verdad — no se perdieron, pero hay que revisarlas a mano. Si la venta ya no aplica (ej. se corrigió de otra forma), descartala.</p>
      ${failed.map(f => `
        <div class="card-quiet" style="margin-top:10px;padding:12px">
          <strong>${UI.escapeHtml(f.payload.customer_name) || 'Sin nombre de cliente'}</strong>
          <p class="muted" style="margin:4px 0">${fmtDate(new Date(f.createdAt).toISOString())} · ${fmt(f.localTotal)}</p>
          <p style="color:var(--danger);font-weight:700;margin:4px 0">${UI.escapeHtml(f.lastError)}</p>
          <div style="display:flex;gap:8px">
            <button class="btn btn-sm" data-retry="${f.client_id}">Reintentar</button>
            <button class="btn btn-sm" data-discard="${f.client_id}">Descartar</button>
          </div>
        </div>
      `).join('')}
    `;
    const modal = UI.showModal('Ventas sin sincronizar', body);
    modal.el.querySelectorAll('[data-discard]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const ok = await UI.confirmDialog('¿Descartar esta venta? No se va a volver a intentar mandarla.');
        if (!ok) return;
        await OfflineDb.removeSale(btn.dataset.discard);
        UI.toast('Venta descartada');
        modal.close();
        OfflineSync.refreshPendingCount();
      });
    });
    // "Reintentar" — para cuando lo que causó el rechazo ya se resolvió (ej.
    // el dueño mandó más stock, o se corrigió el problema real) y no hace
    // falta perder la venta y tener que cargarla de nuevo a mano. Antes
    // "Descartar" era la única salida para una venta failed, sin importar
    // si el motivo del rechazo seguía vigente o no.
    modal.el.querySelectorAll('[data-retry]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const record = failed.find(f => f.client_id === btn.dataset.retry);
        if (!record) return;
        record.status = 'pending';
        record.lastError = null;
        await OfflineDb.updateSale(record);
        UI.toast('Reintentando…');
        modal.close();
        OfflineSync.trySync();
      });
    });
  }
  offlineBanner.addEventListener('click', () => {
    if (offlineBanner.classList.contains('is-failed')) showFailedSalesModal();
  });

  function renderOfflineBanner({ online, pending, syncing, failed }) {
    if (failed > 0) {
      offlineBanner.hidden = false;
      offlineBanner.className = 'offline-banner is-failed';
      offlineBanner.style.cursor = 'pointer';
      offlineBanner.textContent = `⚠️ ${failed} ${failed === 1 ? 'venta' : 'ventas'} sin sincronizar — tocar para revisar`;
    } else if (!online && !pending) {
      offlineBanner.hidden = false;
      offlineBanner.className = 'offline-banner is-offline';
      offlineBanner.style.cursor = '';
      offlineBanner.textContent = '📵 Sin conexión — puedes seguir vendiendo';
    } else if (syncing) {
      offlineBanner.hidden = false;
      offlineBanner.className = 'offline-banner is-syncing';
      offlineBanner.style.cursor = '';
      offlineBanner.textContent = 'Sincronizando…';
    } else if (pending > 0) {
      offlineBanner.hidden = false;
      offlineBanner.className = 'offline-banner is-pending';
      offlineBanner.style.cursor = '';
      offlineBanner.textContent = `⏳ ${pending} ${pending === 1 ? 'venta' : 'ventas'} sin sincronizar`;
    } else {
      offlineBanner.hidden = true;
    }
  }
  // El dueño reportó en vivo: hace una venta sin señal, la venta SÍ se
  // sincroniza de verdad (se ve bien desde el administrativo), pero el
  // propio carrito sigue mostrando los números de antes — porque
  // renderInventario()/renderHistorial() solo se llaman al ENTRAR a esa
  // pestaña, nunca cuando una sincronización termina en segundo plano
  // mientras el vendedor ya está parado ahí mirando. Si justo está en Mi
  // inventario o Historial cuando termina de sincronizar todo con éxito,
  // se refresca solo.
  let wasSyncing = false;
  window.addEventListener('offline:status', e => {
    renderOfflineBanner(e.detail);
    const { syncing, pending, failed } = e.detail;
    if (wasSyncing && !syncing && pending === 0 && failed === 0) {
      const activeView = document.querySelector('#cart-app .view:not([hidden])');
      const view = activeView && activeView.dataset.view;
      if (view === 'pos-historial') renderHistorial(historialParams());
    }
    wasSyncing = syncing;
  });
  // Estado inicial: offlineSync.js ya corrió su propio refreshPendingCount()
  // antes de que este script termine de cargar (ver orden de <script> en
  // index.html), pero ese primer evento se pierde si este listener todavía
  // no existía — se pide el estado de nuevo acá para no arrancar en blanco.
  OfflineSync.refreshPendingCount();

  const mobileCartBar = document.getElementById('pos-mobile-cart-bar');
  document.getElementById('pos-mobile-cart-cta').insertAdjacentHTML('beforeend', UI.icon('chevronDown'));
  // v3.3: en el celular la barra del total abre la hoja de cobro (el recibo
  // sube desde abajo) en vez de bajar la pantalla hasta él.
  const cobroEl = document.getElementById('pos-cobro');
  const cobroBackdrop = document.getElementById('pos-cobro-backdrop');
  const isPhone = () => window.matchMedia('(max-width: 820px)').matches;
  function openCobro() {
    if (!isPhone()) { btnConfirmar.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
    cobroBackdrop.hidden = false;
    cobroEl.classList.add('is-open');
    document.documentElement.classList.add('cobro-lock');
    requestAnimationFrame(() => cobroBackdrop.classList.add('is-open'));
  }
  function closeCobro() {
    if (!cobroEl.classList.contains('is-open')) return;
    cobroEl.classList.remove('is-open');
    cobroBackdrop.classList.remove('is-open');
    document.documentElement.classList.remove('cobro-lock');
    setTimeout(() => { cobroBackdrop.hidden = true; }, 280);
  }
  mobileCartBar.addEventListener('click', openCobro);
  cobroBackdrop.addEventListener('click', closeCobro);
  document.getElementById('pos-cobro-close').addEventListener('click', closeCobro);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCobro(); });
  // Deslizar la hoja hacia abajo desde su encabezado la cierra.
  (function () {
    const head = cobroEl.querySelector('.cobro-head');
    let y0 = null;
    head.addEventListener('touchstart', e => { if (cobroEl.classList.contains('is-open')) y0 = e.touches[0].clientY; }, { passive: true });
    head.addEventListener('touchmove', e => { if (y0 !== null) cobroEl.style.transform = `translateY(${Math.max(0, e.touches[0].clientY - y0)}px)`; }, { passive: true });
    head.addEventListener('touchend', e => {
      if (y0 === null) return;
      const dy = e.changedTouches[0].clientY - y0; y0 = null; cobroEl.style.transform = '';
      if (dy > 90) closeCobro();
    });
  })();

  /* ── Estado de la venta en armado ── */
  // Líneas normales: { key, product_id, quantity, modifiers: [option_id], note }.
  // Dos líneas con el mismo producto + mismas opciones + misma nota se juntan.
  let cart = [];
  // Ofertas: { offer_id, count, picks: { product_id: { modifiers, note } } }.
  // Cada aplicación de una oferta viaja como UN grupo de líneas con el mismo
  // offer_id (el servidor exige el combo exacto) — por eso las opciones de un
  // producto del combo son las mismas en todas las repeticiones de esa oferta.
  let offerCart = [];
  let offers = [];

  const offersSectionEl = document.getElementById('pos-offers-section');
  const offersListEl = document.getElementById('pos-offers-list');
  const { productById, optionById, optionsDelta, computeAmounts, isWholesale, unitPriceFor } = PosMenu;
  let saleDiscount = null;   // { type, value, reason } — descuento de esta venta
  const settings = () => PosMenu.getSettings();
  const round2 = n => Math.round(n * 100) / 100;
  const lineKey = (productId, modifiers, note) => `${productId}|${[...modifiers].sort((a, b) => a - b).join(',')}|${note || ''}`;

  const menuView = PosMenu.mount({
    tabsEl: document.getElementById('pos-category-tabs'),
    subTabsEl: document.getElementById('pos-subcategory-tabs'),
    gridEl: document.getElementById('pos-product-grid'),
    searchEl: document.getElementById('pos-search'),
    counts: () => {
      const m = new Map();
      cart.forEach(l => m.set(l.product_id, (m.get(l.product_id) || 0) + l.quantity));
      return m;
    },
    onProduct: p => PosMenu.pick(p, ({ modifiers, note, quantity }) => addLine(p.id, modifiers, note, quantity))
  });

  // v3.1: la línea recién tocada se resalta en el recibo y un punto "vuela"
  // desde el producto hasta el total (o hasta la barra del total en el celular).
  let flashKey = null;
  function addLine(productId, modifiers, note, quantity) {
    const key = lineKey(productId, modifiers, note);
    const existing = cart.find(l => l.key === key);
    if (existing) existing.quantity += quantity;
    else cart.push({ key, product_id: productId, quantity, modifiers: [...modifiers], note: note || null });
    flashKey = key;
    renderAll();
    const target = !mobileCartBar.hidden && mobileCartBar.offsetParent !== null ? document.getElementById('pos-mobile-cart-summary') : totalEl;
    Motion.flyTo(menuView.lastRect(), target);
  }

  /* ── Ofertas ── */
  function renderOffers() {
    offersSectionEl.hidden = !offers.length;
    if (!offers.length) return;
    offersListEl.innerHTML = '';
    offers.forEach(o => {
      const entry = offerCart.find(x => x.offer_id === o.id);
      const count = entry ? entry.count : 0;
      const itemsList = o.items.map(it => `<li>${Number(it.quantity)} x ${UI.escapeHtml(it.product_name)}</li>`).join('');
      const normalPrice = o.items.reduce((sum, it) => sum + Number(it.product_sale_price) * Number(it.quantity), 0);
      const savings = normalPrice - Number(o.price);
      const row = document.createElement('div');
      row.className = 'product-row';
      row.innerHTML = `
        <div class="info">
          <strong>${UI.escapeHtml(o.name)}</strong>
          <ul class="offer-items-list">${itemsList}</ul>
          <span class="price">${fmt(o.price)}</span>
          ${savings > 0 ? `<span class="best-tag" style="margin-top:4px;align-self:flex-start">ahorra ${fmt(savings)}</span>` : ''}
        </div>
        <div class="qty-controls"><button data-a="dec">−</button><span>${count}</span><button data-a="inc">+</button></div>
      `;
      row.querySelector('[data-a="inc"]').addEventListener('click', () => addOffer(o));
      row.querySelector('[data-a="dec"]').addEventListener('click', () => {
        if (!entry) return;
        entry.count -= 1;
        if (entry.count <= 0) offerCart = offerCart.filter(x => x !== entry);
        renderAll();
      });
      offersListEl.appendChild(row);
    });
  }

  // Un producto del combo con grupos de opciones pide elegirlas (una sola vez
  // por oferta: las repeticiones del mismo combo llevan las mismas).
  function addOffer(o) {
    const existing = offerCart.find(x => x.offer_id === o.id);
    if (existing) { existing.count += 1; renderAll(); return; }
    const picks = {};
    const queue = o.items.map(it => productById(it.product_id)).filter(p => p && p.modifier_groups.length);
    const next = () => {
      const p = queue.shift();
      if (!p) {
        offerCart.push({ offer_id: o.id, count: 1, picks });
        renderAll();
        return;
      }
      PosMenu.openOptionsSheet(p, {
        title: `${o.name} · ${p.name}`, showQty: false,
        onConfirm: ({ modifiers, note }) => { picks[p.id] = { modifiers, note }; next(); }
      });
    };
    next();
  }

  async function loadOffers() {
    // Api.pos.offers() ya resuelve a [] sola si no hay red y no hay caché —
    // vender sin mostrar ofertas es un degradado aceptable.
    offers = Modules.enabled('ofertas') ? await Api.pos.offers() : [];
    renderOffers();
  }

  /* ── Cuenta (recibo en armado) ── */
  const subtotalRow = document.getElementById('pos-row-subtotal');
  const itbisRow = document.getElementById('pos-row-itbis');
  const tipRow = document.getElementById('pos-row-tip');

  // Los extras de opciones se cobran encima del precio del combo (igual que
  // en salesService.js).
  function offerExtras(o, entry) {
    let extras = 0;
    for (const it of o.items) {
      const p = productById(it.product_id);
      const pick = entry.picks[it.product_id];
      if (p && pick) extras += optionsDelta(p, pick.modifiers) * Number(it.quantity);
    }
    return round2(extras * entry.count);
  }

  // Líneas para el cálculo de importes (mismo reparto del combo que hace el servidor).
  function amountLines() {
    const lines = [];
    for (const l of cart) {
      const p = productById(l.product_id);
      if (p) lines.push({ subtotal: round2((unitPriceFor(p, l.quantity) + optionsDelta(p, l.modifiers)) * l.quantity), rate: p.itbis_rate === undefined ? null : p.itbis_rate });
    }
    for (const e of offerCart) {
      const o = offers.find(x => x.id === e.offer_id);
      if (!o) continue;
      const group = o.items.map(it => {
        const p = productById(it.product_id);
        const qty = Number(it.quantity) * e.count;
        const pick = e.picks[it.product_id];
        return { p, base: p ? Number(p.sale_price) * qty : 0, extras: p && pick ? round2(optionsDelta(p, pick.modifiers) * qty) : 0 };
      });
      const total = round2(Number(o.price) * e.count), normal = group.reduce((a, g) => a + g.base, 0);
      let allocated = 0;
      group.forEach((g, i) => {
        let part;
        if (i === group.length - 1) part = round2(total - allocated);
        else { part = round2(total * (normal > 0 ? g.base / normal : 1 / group.length)); allocated += part; }
        lines.push({ subtotal: round2(part + g.extras), rate: g.p && g.p.itbis_rate !== undefined ? g.p.itbis_rate : null });
      });
    }
    return lines;
  }

  function optionLines(p, ids) {
    return ids.map(id => {
      const f = optionById(p, id);
      if (!f) return '';
      const d = Number(f.option.price_delta);
      return `<div class="cart-item-sub">+ ${UI.escapeHtml(f.option.name)}${d ? ` <span class="muted">(${d > 0 ? '+' : ''}${fmt(d)})</span>` : ''}</div>`;
    }).join('');
  }

  function renderCart() {
    if (!cart.length && !offerCart.length) {
      cartItemsEl.innerHTML = `<div class="ux-empty pos-empty">
        <span class="ux-empty-icon"><svg viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 2.5h10v13l-2-1.2-1.5 1.2L9 14.3l-1.5 1.2L6 14.3l-2 1.2z"/><path d="M6.5 6h5M6.5 9h5"/></svg></span>
        <div><strong>El recibo está vacío</strong><span>Toca un producto para empezar, o busca / escanea su código.</span></div></div>`;
      totalEl.textContent = fmt(0);
      totalEl.dataset.shown = '0';
      btnConfirmar.textContent = 'Confirmar venta';
      btnConfirmar.classList.remove('has-total');
      lastTotal = 0; recibido = null; recibidoInput.value = ''; recibidoInput.hidden = true;
      updateCash();
      closeCobro();
      subtotalRow.hidden = itbisRow.hidden = tipRow.hidden = deliveryRow.hidden = true;
      document.getElementById('pos-row-discount').hidden = true;
      saleDiscount = null; document.getElementById('pos-discount-clear').hidden = true;
      mobileCartBar.hidden = true;
      return;
    }
    let unitCount = 0;
    const offersHtml = offerCart.map((e, i) => {
      const o = offers.find(x => x.id === e.offer_id);
      if (!o) return '';
      unitCount += o.items.reduce((s, it) => s + Number(it.quantity), 0) * e.count;
      const subtotal = Number(o.price) * e.count + offerExtras(o, e);
      const detail = o.items.map(it => {
        const p = productById(it.product_id);
        const pick = e.picks[it.product_id];
        return `<div class="cart-item-sub">${Number(it.quantity) * e.count} x ${UI.escapeHtml(it.product_name)}${p && pick ? optionLines(p, pick.modifiers).replace(/cart-item-sub/g, 'cart-item-sub cart-item-sub-nested') : ''}${pick && pick.note ? `<div class="cart-item-sub cart-item-sub-nested muted">“${UI.escapeHtml(pick.note)}”</div>` : ''}</div>`;
      }).join('');
      return `<div class="cart-line" data-offer="${i}">
        <div class="cart-line-main"><strong>${e.count > 1 ? `${e.count} x ` : ''}${UI.escapeHtml(o.name)}</strong><span>${fmt(subtotal)}</span></div>
        ${detail}
        <div class="cart-line-actions"><button type="button" class="btn btn-sm" data-a="offer-dec">− 1</button><button type="button" class="btn btn-sm" data-a="offer-del">Quitar</button></div>
      </div>`;
    }).join('');
    const linesHtml = cart.map((l, i) => {
      const p = productById(l.product_id);
      if (!p) return '';
      unitCount += l.quantity;
      const wholesale = isWholesale(p, l.quantity);
      const unit = unitPriceFor(p, l.quantity) + optionsDelta(p, l.modifiers);
      return `<div class="cart-line${l.key === flashKey ? ' is-new' : ''}" data-line="${i}">
        <div class="cart-line-main"><strong>${l.quantity} x ${UI.escapeHtml(p.name)}${wholesale ? ' <span class="badge badge-ok">Mayoreo</span>' : ''}</strong><span>${fmt(unit * l.quantity)}</span></div>
        ${wholesale ? `<div class="cart-item-sub muted">${fmt(unitPriceFor(p, l.quantity))} c/u al mayoreo</div>` : (p.wholesale_min_qty && l.quantity < p.wholesale_min_qty ? `<div class="cart-item-sub muted">Agrega ${p.wholesale_min_qty - l.quantity} más para el precio de mayoreo (${fmt(p.wholesale_price)})</div>` : '')}
        ${optionLines(p, l.modifiers)}
        ${l.note ? `<div class="cart-item-sub muted">“${UI.escapeHtml(l.note)}”</div>` : ''}
        <div class="cart-line-actions">
          <div class="qty-controls"><button type="button" data-a="dec" aria-label="Menos">−</button><span>${l.quantity}</span><button type="button" data-a="inc" aria-label="Más">+</button></div>
          <button type="button" class="btn btn-sm" data-a="del">Quitar</button>
        </div>
      </div>`;
    }).join('');
    cartItemsEl.innerHTML = offersHtml + linesHtml;
    flashKey = null;

    const cfg = settings();
    const amt = computeAmounts(amountLines(), saleDiscount);
    const { itbis, tip } = amt;
    const fee = deliveryFee();
    const total = round2(amt.net + itbis + tip + fee);
    const withTaxes = cfg.itbis_enabled || cfg.tip_enabled || fee > 0 || amt.discount > 0;
    document.getElementById('pos-row-discount').hidden = !(amt.discount > 0);
    document.getElementById('pos-discount-label').textContent = `Descuento${saleDiscount ? ` (${saleDiscount.reason})` : ''}`;
    document.getElementById('pos-discount').textContent = '-' + fmt(amt.discount);
    document.getElementById('pos-discount-clear').hidden = !saleDiscount;
    deliveryRow.hidden = !fee;
    document.getElementById('pos-delivery').textContent = fmt(fee);
    subtotalRow.hidden = !withTaxes;
    itbisRow.hidden = !cfg.itbis_enabled;
    tipRow.hidden = !cfg.tip_enabled;
    document.getElementById('pos-subtotal').textContent = fmt(amt.gross);
    document.getElementById('pos-itbis-label').textContent = `ITBIS (${Number(cfg.itbis_rate)}%)`;
    document.getElementById('pos-itbis').textContent = fmt(itbis);
    document.getElementById('pos-tip-label').textContent = `Propina legal (${Number(cfg.tip_rate)}%)`;
    document.getElementById('pos-tip').textContent = fmt(tip);
    Motion.countUp(totalEl, total, 'money', 380);
    btnConfirmar.textContent = `Cobrar ${fmt(total)}`;
    btnConfirmar.classList.add('has-total');
    lastTotal = total;
    updateCash();
    document.getElementById('pos-mobile-cart-summary').textContent =
      `${unitCount} ${unitCount === 1 ? 'artículo' : 'artículos'} · ${fmt(total)}`;
    mobileCartBar.hidden = false;
  }

  cartItemsEl.addEventListener('click', e => {
    const btn = e.target.closest('[data-a]');
    if (!btn) return;
    const lineEl = btn.closest('[data-line]');
    const offerEl = btn.closest('[data-offer]');
    if (lineEl) {
      const l = cart[Number(lineEl.dataset.line)];
      if (!l) return;
      if (btn.dataset.a === 'inc') l.quantity += 1;
      else if (btn.dataset.a === 'dec') l.quantity -= 1;
      else l.quantity = 0;
      if (l.quantity <= 0) cart = cart.filter(x => x !== l);
    } else if (offerEl) {
      const en = offerCart[Number(offerEl.dataset.offer)];
      if (!en) return;
      if (btn.dataset.a === 'offer-dec') en.count -= 1; else en.count = 0;
      if (en.count <= 0) offerCart = offerCart.filter(x => x !== en);
    }
    renderAll();
  });

  function renderAll() { menuView.render(); renderOffers(); renderCart(); }

  async function loadMenu() {
    await PosMenu.load();
    // Si lo que había en la cuenta ya no existe en el menú, se descarta.
    cart = cart.filter(l => productById(l.product_id));
    await loadOffers();
    renderAll();
  }

  btnConfirmar.addEventListener('click', async () => {
    errorEl.hidden = true;
    if (!cart.length && !offerCart.length) return;
    if (isCash(pagoSel.value) && recibido !== null && recibido < lastTotal) {
      errorEl.textContent = `Con ${fmt(recibido)} no alcanza: el total es ${fmt(lastTotal)}. Elige otro monto o «Exacto».`;
      errorEl.hidden = false;
      return;
    }
    const vueltoVenta = isCash(pagoSel.value) && recibido !== null ? { recibido, vuelto: Math.round((recibido - lastTotal) * 100) / 100 } : null;
    const items = cart.map(l => {
      const it = { product_id: l.product_id, quantity: l.quantity };
      if (l.modifiers.length) it.modifiers = l.modifiers;
      if (l.note) it.note = l.note;
      return it;
    });
    // Cada aplicación de una oferta expande TODOS sus productos como líneas
    // propias, todas con el mismo offer_id — el servidor las revalida como
    // grupo y es quien de verdad decide cómo se reparte el precio.
    offerCart.forEach(e => {
      const o = offers.find(x => x.id === e.offer_id);
      if (!o) return;
      o.items.forEach(it => {
        const line = { product_id: it.product_id, quantity: Number(it.quantity) * e.count, offer_id: o.id };
        const pick = e.picks[it.product_id];
        if (pick && pick.modifiers.length) line.modifiers = pick.modifiers;
        if (pick && pick.note) line.note = pick.note;
        items.push(line);
      });
    });
    const textoOriginal = btnConfirmar.textContent;
    try {
      btnConfirmar.disabled = true;
      btnConfirmar.textContent = 'Registrando…';
      const sale = await Api.pos.createSale({
        items,
        customer_name: clienteNombreInput.value || null,
        customer_phone: clientePhoneInput.value ? normalizeLocalPhone(clientePhoneInput.value) : null,
        payment_method: document.getElementById('pos-pago').value,
        channel: canalSel.value,
        delivery_fee: deliveryFee(),
        discount: saleDiscount,
        notes: notaInput.value.trim() || null
      });
      reciboTexto.textContent = sale.receipt;
      // v3.4: mandar el recibo por WhatsApp (al cliente si se escribió su teléfono).
      const telVenta = clientePhoneInput.value ? normalizeLocalPhone(clientePhoneInput.value) : '';
      document.getElementById('btn-wa-pos-recibo').href = `https://wa.me/${telVenta}?text=${encodeURIComponent(sale.receipt || '')}`;
      const vueltoP = document.getElementById('pos-recibo-vuelto');
      vueltoP.hidden = !vueltoVenta;
      if (vueltoVenta) vueltoP.innerHTML = `Recibido ${fmt(vueltoVenta.recibido)} · <strong>Vuelto ${fmt(vueltoVenta.vuelto)}</strong>`;
      reciboModal.hidden = false;
      recibido = null; recibidoInput.value = ''; recibidoInput.hidden = true;
      showCliente(false);
      closeCobro();
      cart = [];
      offerCart = [];
      saleDiscount = null;
      clientePhoneInput.value = '';
      unlockClienteNombre();
      clienteNombreInput.value = '';
      canalSel.value = 'mostrador'; entregaSel.value = 'local'; feeInput.value = ''; feeWrap.hidden = true; notaInput.value = '';
      document.getElementById('pos-zona').innerHTML = '';
      document.getElementById('pos-extra').open = false;
      // El stock cambió: se refresca para que los avisos de "agotado" sean reales.
      PosMenu.refreshStock().then(renderAll);
      renderAll();
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
      // El mensaje aparece DEBAJO del botón, justo donde en celular flota la
      // barra del carrito — se lleva a la vista sí o sí (instantáneo, sin
      // `smooth`: el reflow al mostrarlo cancelaba el scroll suave).
      errorEl.scrollIntoView({ block: 'center' });
    } finally {
      btnConfirmar.disabled = false;
      btnConfirmar.textContent = textoOriginal;
      // Tras una venta el carrito ya quedó vacío: el botón vuelve a "Confirmar venta".
      if (!cart.length && !offerCart.length) renderCart();
    }
  });

  // Delivery: al elegirlo aparece el costo (con el de la página como sugerencia) y el total lo suma.
  entregaSel.addEventListener('change', () => {
    feeWrap.hidden = entregaSel.value !== 'delivery';
    const zonas = Array.isArray((settings() || {}).web_delivery_zones) ? settings().web_delivery_zones : [];
    const zonaSel = document.getElementById('pos-zona');
    zonaSel.hidden = document.getElementById('pos-zona-label').hidden = !(entregaSel.value === 'delivery' && zonas.length);
    if (entregaSel.value === 'delivery' && zonas.length && !zonaSel.options.length) {
      zonaSel.innerHTML = '<option value="">Elige la zona…</option>' + zonas.map(z => `<option value="${z.fee}">${UI.escapeHtml(z.name)} · ${fmt(z.fee)}</option>`).join('');
    }
    if (entregaSel.value === 'delivery' && feeInput.value === '' && !zonas.length) {
      const sug = Number((settings() || {}).web_delivery_fee) || 0;
      if (sug) feeInput.value = sug;
    }
    renderCart();
  });
  document.getElementById('pos-zona').addEventListener('change', e => { if (e.target.value !== '') { feeInput.value = e.target.value; renderCart(); } });
  feeInput.addEventListener('input', renderCart);

  document.getElementById('pos-discount-btn').addEventListener('click', async () => {
    if (!cart.length && !offerCart.length) { UI.toast('Agrega productos primero', 'error'); return; }
    const d = await PosMenu.askDiscount(saleDiscount);
    if (d) { saleDiscount = d; renderCart(); }
  });
  document.getElementById('pos-discount-clear').addEventListener('click', () => { saleDiscount = null; renderCart(); });

  document.getElementById('btn-cerrar-pos-recibo').addEventListener('click', () => { reciboModal.hidden = true; });
  // Imprimir de una vez al confirmar la venta, sin tener que ir a Historial
  // después — el texto ya está en pantalla, no hace falta pedirlo de nuevo.
  document.getElementById('btn-imprimir-pos-recibo').addEventListener('click', () => {
    const win = openReceiptWindow(true);
    fillReceiptWindow(win, reciboTexto.textContent);
  });


  /* ── Mi historial ── */
  const historialTbody = document.querySelector('#tabla-pos-historial tbody');
  const historialFiltro = document.getElementById('form-pos-historial-filtro');
  const historialResumenEl = document.getElementById('pos-historial-resumen');

  function historialParams() {
    const fd = new FormData(historialFiltro);
    const params = {};
    if (fd.get('from')) params.from = fd.get('from');
    if (fd.get('to')) params.to = fd.get('to');
    return params;
  }

  function statCard(label, value) {
    return `<div class="stat"><div class="label">${label}</div><div class="value">${value}</div></div>`;
  }

  // Cuántas facturas hizo, de un vistazo — pedido real pensando en un
  // vendedor en la calle a fin de turno. Cuenta sobre lo que esté filtrado
  // en cada momento (por default, hoy — ver el listener de view:show más
  // abajo); las ventas anuladas no cuentan como facturas activas, pero se
  // muestran aparte para que no parezca que "desaparecieron" de la cuenta.
  //
  // A propósito NO se suma un "Total" acá (aunque cada fila de la tabla sí
  // muestra su propio importe, que el vendedor necesita para operar) —
  // pedido explícito del dueño: no quiere que el empleado vea de un
  // vistazo cuánto dinero pasó por sus manos en total ("se podrían llenar
  // los ojos"). El dueño sí lo ve, en su propio Historial/Reportes.
  function renderHistorialResumen(sales) {
    const completadas = sales.filter(s => s.status !== 'anulada' && !s.return_of);
    const anuladas = sales.filter(s => s.status === 'anulada').length;
    historialResumenEl.innerHTML =
      statCard('Facturas', completadas.length + (anuladas ? ` <span class="muted" style="font-weight:400;font-size:.7em">(+${anuladas} anulada${anuladas === 1 ? '' : 's'})</span>` : ''));
  }

  async function renderHistorial(params) {
    // Igual que en el Historial del dueño: una fila-esqueleto mientras
    // llega la respuesta, en vez de dejar la tabla en blanco durante ese
    // viaje al servidor.
    historialTbody.innerHTML = UI.skeletonRows(4, 5);
    let sales;
    try {
      sales = await Api.pos.sales(params || historialParams());
    } catch (err) {
      // A diferencia de products/stock/offers (que sirven la última foto
      // cacheada sin señal), el Historial no se cachea — pedir la lista
      // completa de ventas offline no tiene el mismo valor que ver el
      // catálogo o el stock para poder seguir vendiendo. Antes esto quedaba
      // como una excepción sin atrapar: la pantalla se quedaba en blanco,
      // sin ningún aviso de qué pasó — encontrado en vivo por el dueño
      // ("cuando quiero cambiar de inventario... ya no me recarga").
      const msg = err.status === undefined
        ? 'Sin conexión — el historial no se puede cargar ahora. Prueba de nuevo cuando vuelva la señal.'
        : 'No se pudo cargar el historial: ' + err.message;
      historialResumenEl.innerHTML = '';
      historialTbody.innerHTML = `<tr><td colspan="5" class="muted">${UI.escapeHtml(msg)}</td></tr>`;
      return;
    }
    renderHistorialResumen(sales);
    if (!sales.length) {
      historialTbody.innerHTML = '<tr><td colspan="5" class="muted">Sin ventas para este filtro.</td></tr>';
      return;
    }
    // v3.4 (fase 2): agrupado por día, con cuántas facturas tuvo cada uno (sin
    // sumar dinero: el dueño no quiere que el empleado vea el total, ver arriba).
    const dayOf = s => new Date(s.created_at).toDateString();
    const hoyKey = new Date().toDateString();
    const ayer = new Date(); ayer.setDate(ayer.getDate() - 1);
    const dayLabel = d => d === hoyKey ? 'Hoy' : d === ayer.toDateString() ? 'Ayer'
      : new Date(d).toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long' }).replace(/^./, c => c.toUpperCase());
    const perDay = new Map();
    sales.forEach(s => { if (s.status !== 'anulada' && !s.return_of) perDay.set(dayOf(s), (perDay.get(dayOf(s)) || 0) + 1); });
    let prevDay = null;
    historialTbody.innerHTML = sales.map((s, idx) => {
      const d = dayOf(s);
      const head = d !== prevDay ? `<tr class="hist-day-row"><td colspan="5"><strong>${dayLabel(d)}</strong><span class="muted"> · ${perDay.get(d) || 0} factura${(perDay.get(d) || 0) === 1 ? '' : 's'}</span></td></tr>` : '';
      prevDay = d;
      return head + `
      <tr data-idx="${idx}" class="${s.status === 'anulada' ? 'row-voided' : ''}">
        <td data-th="#">#${s.id}</td>
        <td data-th="Hora">${new Date(s.created_at).toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit', hour12: true })}</td>
        <td class="num" data-th="Cobrado">${fmt(s.amount_due != null ? s.amount_due : s.total)}</td>
        <td data-th="Estado">${s.status === 'anulada' ? '<span class="badge badge-voided">Anulada</span>' : s.return_of ? `<span class="badge badge-warn">Devolución de #${s.return_of}</span>` : '<span class="badge badge-ok">Completada</span>'}</td>
        <td></td>
      </tr>`;
    }).join('');
    historialTbody.querySelectorAll('tr[data-idx]').forEach(tr => {
      const s = sales[Number(tr.dataset.idx)];
      const actions = tr.lastElementChild;
      if (!actions) return;

      const btnVer = document.createElement('button');
      btnVer.className = 'btn btn-sm';
      // "Ver" abre la factura en su propia ventana, que ya trae su botón
      // "Imprimir" — un botón de Imprimir aparte acá era el mismo destino
      // dos veces, así que se quitó (pedido del dueño, aplicado también
      // acá para consistencia con el Historial del dueño).
      btnVer.innerHTML = UI.iconLabel('eye', 'Ver / imprimir');
      btnVer.addEventListener('click', async () => {
        const win = openReceiptWindow(false);
        // Sin try/catch, un corte de señal (otra vez, el caso más probable
        // en un carrito de la calle) dejaba la ventana nueva trabada en
        // "Cargando…" para siempre, sin explicar nada.
        try {
          const detail = await Api.pos.saleDetail(s.id);
          fillReceiptWindow(win, detail.receipt);
        } catch (err) {
          if (win && !win.closed) fillReceiptWindow(win, `No se pudo cargar la factura: ${err.message}`);
        }
      });
      actions.appendChild(btnVer);

      if (s.status === 'anulada') return;
      if (!s.return_of) {
        const btnDev = document.createElement('button');
        btnDev.className = 'btn btn-sm';
        btnDev.textContent = 'Devolver';
        btnDev.addEventListener('click', () => Devoluciones.open(s.id, { detail: Api.pos.saleDetail, submit: Api.pos.returnItems }, () => renderHistorial()));
        actions.appendChild(btnDev);
      }
      const btn = document.createElement('button');
      btn.className = 'btn btn-sm';
      btn.innerHTML = UI.iconLabel('ban', 'Anular');
      btn.addEventListener('click', async () => {
        const reason = await UI.promptDialog(`¿Anular la venta #${s.id}?`, 'Motivo de la anulación (obligatorio)');
        if (!reason) return;
        try {
          await Api.pos.voidSale(s.id, reason);
          UI.toast('Venta anulada');
          renderHistorial();
        } catch (err) {
          UI.toast(err.message, 'error');
        }
      });
      actions.appendChild(btn);
    });
  }

  // v3.4: Hoy / Ayer / Últimos 7 días de un toque; «Elegir fechas» abre el formulario.
  const histRange = document.getElementById('pos-hist-range');
  const histFechas = document.getElementById('pos-hist-fechas');
  function setRange(r) {
    histRange.querySelectorAll('[data-range]').forEach(b => { const on = b.dataset.range === r; b.classList.toggle('active', on); b.setAttribute('aria-selected', String(on)); });
    histFechas.hidden = r !== 'fechas';
    if (r === 'fechas') return;
    const d = new Date(); const from = new Date();
    if (r === 'ayer') { d.setDate(d.getDate() - 1); from.setDate(from.getDate() - 1); }
    if (r === '7') from.setDate(from.getDate() - 6);
    historialFiltro.querySelector('[name="from"]').value = localIsoDate(from);
    historialFiltro.querySelector('[name="to"]').value = localIsoDate(d);
    renderHistorial(historialParams());
  }
  histRange.addEventListener('click', e => { const b = e.target.closest('[data-range]'); if (b) setRange(b.dataset.range); });

  historialFiltro.addEventListener('submit', e => {
    e.preventDefault();
    renderHistorial(historialParams());
  });
  document.getElementById('btn-pos-historial-limpiar').addEventListener('click', () => {
    historialFiltro.reset();
    renderHistorial({});
  });

  window.addEventListener('view:show', e => {
    if (e.detail.view === 'pos-venta') loadMenu();
    if (e.detail.view === 'pos-historial') {
      // Arranca en "hoy" — es lo que un vendedor casi siempre quiere ver
      // (mismo criterio que ya usa Reportes con "este mes"), sin tener que
      // elegir la fecha a mano cada vez. Si ya había un rango propio puesto
      // (volviendo de otra pantalla), no se pisa.
      const from = historialFiltro.querySelector('[name="from"]');
      const to = historialFiltro.querySelector('[name="to"]');
      if (!from.value && !to.value) {
        // NUNCA new Date().toISOString().slice(0,10) para "hoy": eso da la
        // fecha en UTC, no la del huso horario local — en Santo Domingo
        // (UTC-4), entre las 8pm y la medianoche, el reloj UTC ya marca el
        // día siguiente, así que "hoy" quedaría mañana y el filtro no
        // encontraría ninguna venta de la noche. Encontrado en vivo por el
        // dueño ("pongo hoy a hoy y no aparece nada, pero de ayer a hoy sí").
        from.value = to.value = localIsoDate();
      }
      renderHistorial(historialParams());
    }
  });

  if (!document.getElementById('cart-app').hidden) loadMenu();
})();
