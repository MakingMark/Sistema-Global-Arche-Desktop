/* ═══ Pedidos web (punto de venta): bandeja de lo que piden desde la página ═══ */
(function () {
  'use strict';
  const listEl = document.getElementById('web-lista');
  if (!listEl) return;
  const esc = UI.escapeHtml;
  const navItem = document.getElementById('nav-pos-web');
  const badge = document.getElementById('nav-badge-web');
  let lastCount = null;
  let audioCtx = null;
  let current = [];

  const isPos = () => { const s = Auth.get(); return !!s && s.role === 'cart'; };
  const fmtPhone = p => { const t = String(p).replace(/^1/, ''); return `${t.slice(0, 3)} ${t.slice(3, 6)} ${t.slice(6)}`; };

  function beep() {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      [0, 0.25].forEach(delay => {
        const o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = 'triangle'; o.frequency.value = 660;
        g.gain.setValueAtTime(0.0001, audioCtx.currentTime + delay);
        g.gain.exponentialRampToValueAtTime(0.4, audioCtx.currentTime + delay + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + delay + 0.22);
        o.connect(g); g.connect(audioCtx.destination);
        o.start(audioCtx.currentTime + delay); o.stop(audioCtx.currentTime + delay + 0.25);
      });
    } catch (_) { /* audio bloqueado hasta que alguien toque la pantalla */ }
  }

  function card(w) {
    const lines = (w.items || []).map(l => `<div class="web-line"><strong>${l.quantity} x ${esc(l.name)}</strong>${l.offer_name ? ` <span class="badge badge-ok">${esc(l.offer_name)}</span>` : ''}<span>${fmt(l.unit_price * l.quantity)}</span>
      ${(l.modifiers || []).map(m => `<div class="cart-item-sub">+ ${esc(m.option)}</div>`).join('')}${l.note ? `<div class="cart-item-sub muted">“${esc(l.note)}”</div>` : ''}</div>`).join('');
    const wa = `https://wa.me/${w.customer_phone}`;
    return `<div class="card web-card" data-id="${w.id}">
      <div class="card-header-row"><h2 style="margin:0">#${w.id} · ${esc(w.customer_name)}</h2><span class="muted">${fmtDate(w.created_at)}</span></div>
      <p class="web-meta"><span class="badge ${w.fulfillment === 'delivery' ? 'badge-warn' : 'badge-ok'}">${w.fulfillment === 'delivery' ? 'Delivery' + (w.zone ? ' · ' + esc(w.zone) : '') : 'Retiro'}</span> ${w.payment_status === 'pendiente' ? '<span class="badge badge-warn">Transferencia por confirmar</span> ' : ''}${esc(w.payment_method || '')} · <a href="${wa}" target="_blank" rel="noopener">WhatsApp ${fmtPhone(w.customer_phone)}</a></p>
      ${w.address ? `<p class="web-meta">📍 ${esc(w.address)}</p>` : ''}
      ${w.note ? `<p class="web-meta">📝 ${esc(w.note)}</p>` : ''}
      <div class="web-lines">${lines}</div>
      <div class="web-total"><span>Neto ${fmt(w.net_total)}${w.delivery_fee ? ` + delivery ${fmt(w.delivery_fee)}` : ''}</span></div>
      <div class="cuenta-actions">
        <button type="button" class="btn btn-primary" data-a="accept">Aceptar</button>
        <button type="button" class="btn" data-a="reject">Rechazar</button>
      </div>
    </div>`;
  }

  async function render() {
    let rows;
    try { rows = await Api.pos.webOrders('nuevo'); } catch (err) { listEl.innerHTML = `<p class="muted">${err.status === undefined ? 'Sin conexión con el servidor.' : esc(err.message)}</p>`; return; }
    current = rows;
    listEl.innerHTML = rows.length ? rows.map(card).join('') : '<div class="card-quiet"><p class="muted" style="margin:0">No hay pedidos nuevos. Cuando un cliente pida por la página, aparece acá.</p></div>';
  }

  listEl.addEventListener('click', async e => {
    const btn = e.target.closest('[data-a]');
    const el = btn && btn.closest('[data-id]');
    if (!btn || !el) return;
    const id = Number(el.dataset.id);
    const w = current.find(x => x.id === id);
    btn.disabled = true;
    try {
      if (btn.dataset.a === 'accept') {
        let res;
        try { res = await Api.pos.acceptWebOrder(id); }
        catch (err) {
          // Algo cambió desde que lo pidieron (se agotó, cerró el horario): se avisa y se puede aceptar igual.
          if (!err.data || !err.data.can_force) throw err;
          if (!(await UI.confirmDialog(`${err.message}\n\n¿Aceptarlo igual?`))) { btn.disabled = false; return; }
          res = await Api.pos.acceptWebOrder(id, true);
        }
        UI.toast(`Pedido #${id} aceptado — ya es una comanda`);
        refreshCount();
        // Lo natural es ir a la comanda: mandarla a cocina o corregir algo.
        if (window.openOrderById) window.openOrderById(res.order_id);
      } else {
        const reason = await UI.promptDialog(`¿Rechazar el pedido de ${w ? w.customer_name : '#' + id}?`, 'Motivo (se le muestra al cliente)');
        if (!reason) { btn.disabled = false; return; }
        await Api.pos.rejectWebOrder(id, reason);
        UI.toast('Pedido rechazado');
      }
      render();
    } catch (err) { UI.toast(err.message, 'error'); btn.disabled = false; render(); }
  });

  async function refreshCount() {
    if (!isPos() || document.hidden || document.getElementById('cart-app').hidden) return;
    if (!Modules.enabled('pedidos_directos')) return;
    let c;
    try { c = await Api.pos.webOrdersCount(); } catch (_) { return; }
    navItem.hidden = !c.enabled && !c.count;
    badge.textContent = String(c.count);
    badge.hidden = c.count === 0;
    if (lastCount !== null && c.count > lastCount) { beep(); if (!listEl.closest('.view').hidden) render(); }
    lastCount = c.count;
  }

  setInterval(refreshCount, 8000);
  window.addEventListener('view:show', e => {
    if (!isPos()) return;
    refreshCount();
    if (e.detail.view === 'pos-web') render();
  });
  setTimeout(refreshCount, 1500);
})();
