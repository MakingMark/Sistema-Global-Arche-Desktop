/* ═══ Aviso de la cuenta (solo en modo multi-negocio) ═══
   Prueba por vencer, plan por vencer o cuenta en solo lectura. Con un solo negocio por instalación no aparece. */
(function () {
  'use strict';
  async function show() {
    if (!Auth.get()) return;
    let s;
    try { s = (await (await fetch('/api/settings')).json()).account; } catch (_) { return; }
    if (!s) return;
    let text = null, critical = false;
    if (s.state === 'solo_lectura') {
      critical = true;
      text = s.suspended
        ? 'Tu cuenta está suspendida: puedes ver tu información, pero no registrar ventas ni cambios. Contacta a soporte para reactivarla.'
        : 'Tu cuenta está en modo solo lectura (' + (s.plan === 'prueba' ? 'terminó la prueba gratis' : 'el pago está vencido') + '). Puedes ver y descargar tu información; renueva tu plan para volver a registrar ventas.';
    } else if (s.plan === 'prueba' && s.days_left !== null && s.days_left <= 7) {
      text = s.days_left <= 0 ? 'Tu prueba gratis termina hoy.' : 'Te quedan ' + s.days_left + (s.days_left === 1 ? ' día' : ' días') + ' de prueba gratis.';
    } else if (s.plan !== 'prueba' && s.days_left !== null && s.days_left <= 5) {
      text = 'Tu plan vence ' + (s.days_left <= 0 ? 'hoy' : 'en ' + s.days_left + (s.days_left === 1 ? ' día' : ' días')) + '. Renuévalo para no perder acceso a registrar ventas.';
    }
    if (!text) return;
    const el = document.createElement('div');
    el.className = 'account-banner' + (critical ? ' is-critical' : '');
    el.setAttribute('role', critical ? 'alert' : 'status');
    el.textContent = text;
    if (!critical) {
      const x = document.createElement('button');
      x.type = 'button'; x.textContent = '×'; x.setAttribute('aria-label', 'Cerrar aviso');
      x.addEventListener('click', () => el.remove());
      el.appendChild(x);
    }
    document.body.prepend(el);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', show); else show();
})();
