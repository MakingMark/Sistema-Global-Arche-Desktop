/* ═══ Importes de una venta: descuento, ITBIS por producto y propina (sin DOM) ═══
   El servidor (salesService) y el punto de venta (PosMenu) usan ESTE mismo cálculo,
   así lo que ve el cajero antes de cobrar es exactamente lo que se factura. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TaxCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const round2 = n => Math.round((Number(n) || 0) * 100) / 100;

  // Descuento: { type: 'percent' | 'amount', value }. Nunca pasa del subtotal ni es negativo.
  function discountAmount(gross, discount) {
    if (!discount || !(Number(discount.value) > 0)) return 0;
    const raw = discount.type === 'percent' ? gross * Math.min(100, Number(discount.value)) / 100 : Number(discount.value);
    return Math.min(gross, Math.max(0, round2(raw)));
  }

  // Tasa efectiva de ITBIS de una línea: sin ITBIS en el negocio → 0; sin tasa propia → la general; con tasa propia (0 = exento) → esa.
  function lineRate(line, tax) {
    if (!tax || !tax.itbis_enabled) return 0;
    return line.rate === null || line.rate === undefined || line.rate === '' ? Number(tax.itbis_rate) : Number(line.rate);
  }

  /**
   * lines: [{ subtotal, rate? }]   (rate: null = la general del negocio)
   * discount: { type, value } | null
   * tax: { itbis_enabled, itbis_rate, tip_enabled, tip_rate }
   * → { gross, discount, net, itbis, tip, lines: [{ discount_share, net, rate, itbis }] }
   */
  function compute({ lines, discount, tax }) {
    const gross = round2(lines.reduce((s, l) => s + (Number(l.subtotal) || 0), 0));
    const disc = discountAmount(gross, discount);
    const net = round2(gross - disc);
    // El descuento se reparte entre las líneas en proporción a su valor; la última se lleva el centavo que sobre.
    let left = disc;
    const out = lines.map((l, i) => {
      const share = i === lines.length - 1 ? left : (gross > 0 ? round2(disc * (Number(l.subtotal) || 0) / gross) : 0);
      left = round2(left - share);
      const lnet = round2((Number(l.subtotal) || 0) - share);
      return { discount_share: share, net: lnet, rate: lineRate(l, tax), itbis: 0 };
    });
    // ITBIS: por cada tasa, sobre lo neto de esas líneas (con una sola tasa da lo mismo que antes: neto × tasa).
    const byRate = new Map();
    out.forEach(l => byRate.set(l.rate, round2((byRate.get(l.rate) || 0) + l.net)));
    let itbis = 0;
    for (const [rate, base] of byRate) itbis = round2(itbis + round2(base * rate / 100));
    out.forEach(l => { l.itbis = round2(l.net * l.rate / 100); });
    const tip = tax && tax.tip_enabled ? round2(net * Number(tax.tip_rate) / 100) : 0;
    return { gross, discount: disc, net, itbis, tip, lines: out };
  }

  return { compute, discountAmount, lineRate, round2 };
});
