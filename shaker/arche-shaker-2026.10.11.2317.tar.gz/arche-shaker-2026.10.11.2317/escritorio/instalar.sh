#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Arche Escritorio · Shaker — instalador para Zorin OS / Ubuntu (22.04 o más)
#
# Convierte esta PC en el servidor del sistema:
#   · instala Node, PostgreSQL y el sistema en /opt/arche-shaker
#   · deja el sistema encendiéndose solo al prender la PC (servicio de systemd)
#   · conecta Tailscale para tener una dirección fija para los teléfonos de afuera
#   · respaldo automático todos los días
#   · accesos directos "Shaker" y "Shaker · Conectar teléfono" en el escritorio
#   · la PC deja de suspenderse sola
#
# Uso (desde esta carpeta, con internet):
#   bash instalar.sh                       instalar o actualizar
#   bash instalar.sh --respaldo ARCHIVO    además, carga los datos de un respaldo (.json del sistema)
#   bash instalar.sh --sin-tailscale       sin la dirección de afuera (solo red del local)
#   bash instalar.sh --tailscale-clave tskey-auth-…   conecta Tailscale solo, sin abrir enlaces
#
# Lo normal es NO correrlo a mano sino con el comando de una línea que baja la
# última versión desde GitHub (escritorio/instalar-desde-internet.sh, publicado
# como «instalar» en el repositorio de actualizaciones; ver INSTALAR-EN-PC-CLIENTE.md).
# Ese comando le pasa --manifest y --paquete para verificar la firma de Arche.
#
# Se puede correr las veces que haga falta: si ya está instalado, actualiza el
# programa y conserva los datos, la clave de la base y la configuración.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

NEGOCIO="Shaker"
SLUG="arche-shaker"
PORT=4340
DB_NAME="shaker"
DB_USER="arche"
NODE_VERSION="22.14.0"
# De dónde bajan las actualizaciones (manifest.json + paquete). Viene dentro del
# paquete (escritorio/UPDATE_URL, lo escribe herramientas/empaquetar.js). Vacío = solo por USB.
UPDATE_URL_DEFECTO="$(tr -d '[:space:]' < "$(dirname "${BASH_SOURCE[0]}")/UPDATE_URL" 2>/dev/null || true)"

APP_DIR="/opt/$SLUG"
ENV_DIR="/etc/$SLUG"
ENV_FILE="$ENV_DIR/arche.env"
DATA_DIR="/var/lib/$SLUG"
SERVICE="$SLUG"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"   # carpeta del sistema (la que contiene server/ y public/)

paso() { printf '\n\033[1;34m▶ %s\033[0m\n' "$*"; }
ok()   { printf '  \033[32m✔\033[0m %s\n' "$*"; }
aviso(){ printf '  \033[33m!\033[0m %s\n' "$*"; }
falla(){ printf '\n\033[31m✘ %s\033[0m\n' "$*"; exit 1; }

# ── Comprobaciones ──────────────────────────────────────────────────────────
# Se relanza con permisos de administrador ANTES de leer las opciones, para no perderlas.
[ "$(id -u)" -ne 0 ] && exec sudo -E bash "$0" "$@"
RESPALDO=""
CON_TAILSCALE=1
TS_CLAVE=""
MANIFEST=""; PAQUETE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --respaldo) RESPALDO="$(realpath "$2")"; shift 2 ;;
    --sin-tailscale) CON_TAILSCALE=0; shift ;;
    --tailscale-clave) TS_CLAVE="${2:-}"; shift 2 ;;
    --manifest) MANIFEST="$(realpath "$2")"; shift 2 ;;
    --paquete) PAQUETE="$(realpath "$2")"; shift 2 ;;
    -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    *) echo "Opción desconocida: $1"; exit 1 ;;
  esac
done

USUARIO="${SUDO_USER:-}"
[ -z "$USUARIO" ] || [ "$USUARIO" = "root" ] && falla "Corre el instalador desde tu usuario normal (bash instalar.sh); él pide la clave de administrador solo."
HOME_USUARIO="$(getent passwd "$USUARIO" | cut -d: -f6)"
[ -f "$SRC_DIR/server/index.js" ] && [ -d "$SRC_DIR/public" ] || falla "No encuentro el sistema junto al instalador (falta $SRC_DIR/server)."
command -v apt-get >/dev/null || falla "Este instalador es para Zorin OS / Ubuntu (usa apt)."
[ -n "$RESPALDO" ] && [ ! -f "$RESPALDO" ] && falla "No existe el respaldo $RESPALDO"
case "$(uname -m)" in
  x86_64) NODE_ARCH="x64" ;;
  aarch64|arm64) NODE_ARCH="arm64" ;;
  *) falla "Arquitectura no soportada: $(uname -m)" ;;
esac

echo "Instalando $NEGOCIO en esta PC (usuario: $USUARIO)."

# ── 1. Paquetes del sistema ─────────────────────────────────────────────────
paso "Paquetes (PostgreSQL, curl, rsync)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq postgresql postgresql-contrib curl rsync ca-certificates python3 xdg-utils >/dev/null
systemctl enable --now postgresql >/dev/null
ok "PostgreSQL $(sudo -u postgres psql -tAc 'SHOW server_version' | cut -d' ' -f1) en marcha"

# ── 2. Node.js propio del sistema (no toca el Node de la PC) ────────────────
paso "Node.js $NODE_VERSION"
NODE_DIR="$APP_DIR/node"
if [ ! -x "$NODE_DIR/bin/node" ] || [ "$("$NODE_DIR/bin/node" -v)" != "v$NODE_VERSION" ]; then
  TMP="$(mktemp -d)"
  NAME="node-v$NODE_VERSION-linux-$NODE_ARCH"
  curl -fsSL "https://nodejs.org/dist/v$NODE_VERSION/$NAME.tar.xz" -o "$TMP/node.tar.xz"
  curl -fsSL "https://nodejs.org/dist/v$NODE_VERSION/SHASUMS256.txt" -o "$TMP/SHASUMS256.txt"
  (cd "$TMP" && grep " $NAME.tar.xz\$" SHASUMS256.txt | sed "s/$NAME.tar.xz/node.tar.xz/" | sha256sum -c --quiet) || falla "La descarga de Node no pasó la verificación"
  mkdir -p "$NODE_DIR"
  tar -xJf "$TMP/node.tar.xz" -C "$NODE_DIR" --strip-components=1
  rm -rf "$TMP"
fi
ok "Node $("$NODE_DIR/bin/node" -v)"

# Si vino de internet: el paquete tiene que estar firmado por Arche (ya hay Node para comprobarlo).
if [ -n "$MANIFEST" ] && [ -n "$PAQUETE" ]; then
  "$NODE_DIR/bin/node" "$SRC_DIR/escritorio/verificar-actualizacion.js" "$MANIFEST" "$PAQUETE" >/dev/null \
    || falla "El paquete descargado NO tiene la firma de Arche. No se instala."
  ok "Paquete verificado: firmado por Arche"
fi

# ── 3. Usuario y carpetas ───────────────────────────────────────────────────
paso "Usuario del sistema y carpetas"
id -u arche >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin arche
mkdir -p "$APP_DIR" "$ENV_DIR" "$DATA_DIR/respaldos" "$DATA_DIR/respaldos-diarios" "$DATA_DIR/whatsapp"
ok "$APP_DIR · $DATA_DIR"

# ── 4. Programa ─────────────────────────────────────────────────────────────
paso "Copiando el programa"
systemctl stop "$SERVICE" 2>/dev/null || true
# Cada versión va en su carpeta (versiones/<versión>) y "actual" apunta a la que
# está en uso: así una actualización que falle puede volver a la anterior.
VERSION="$(cat "$SRC_DIR/VERSION" 2>/dev/null || echo "dev-$(date +%Y%m%d%H%M)")"
DEST="$APP_DIR/versiones/$VERSION"
mkdir -p "$DEST"
rsync -a --delete --exclude node_modules --exclude .env --exclude backups --exclude 'server.log' --exclude 'whatsapp-auth*' --exclude test \
  "$SRC_DIR/server/" "$DEST/server/"
rsync -a --delete "$SRC_DIR/public/" "$DEST/public/"
rsync -a --delete --exclude datos "$SRC_DIR/escritorio/" "$DEST/escritorio/"
echo "$VERSION" > "$DEST/VERSION"
chmod +x "$DEST"/escritorio/*.sh
(cd "$DEST/server" && PATH="$NODE_DIR/bin:$PATH" npm ci --omit=dev --no-audit --no-fund --loglevel=error) || falla "No se pudieron instalar las dependencias (¿hay internet?)"
ln -sfn "$DEST" "$APP_DIR/actual"
chown -R arche:arche "$APP_DIR" "$DATA_DIR"
chown -h arche:arche "$APP_DIR/actual"
ok "Versión $VERSION en $APP_DIR"

# ── 5. Base de datos y configuración ────────────────────────────────────────
paso "Base de datos"
if [ -f "$ENV_FILE" ]; then
  DB_PASS="$(sed -n 's#^DATABASE_URL=postgres://[^:]*:\([^@]*\)@.*#\1#p' "$ENV_FILE")"
  PUBLIC_URL="$(sed -n 's/^PUBLIC_URL=//p' "$ENV_FILE")"
  UPDATE_URL="$(sed -n 's/^UPDATE_URL=//p' "$ENV_FILE")"
  [ -n "$UPDATE_URL" ] || UPDATE_URL="$UPDATE_URL_DEFECTO"
  ok "Configuración existente conservada"
else
  DB_PASS="$(python3 -c 'import secrets; print(secrets.token_hex(16))')"
  PUBLIC_URL=""
  UPDATE_URL="$UPDATE_URL_DEFECTO"
fi
if sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1; then
  sudo -u postgres psql -q -c "ALTER ROLE $DB_USER WITH LOGIN PASSWORD '$DB_PASS' CREATEDB" >/dev/null
else
  sudo -u postgres psql -q -c "CREATE ROLE $DB_USER WITH LOGIN PASSWORD '$DB_PASS' CREATEDB" >/dev/null
fi
if ! sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1; then
  sudo -u postgres createdb -O "$DB_USER" "$DB_NAME"
fi
ok "Base \"$DB_NAME\" lista"

escribir_env() {
  umask 027
  cat > "$ENV_FILE" <<EOF
# Arche Escritorio · $NEGOCIO — lo genera instalar.sh (no subir a ningún lado).
DATABASE_URL=postgres://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
PORT=$PORT
BACKUP_DIR=$DATA_DIR/respaldos
WHATSAPP_AUTH_DIR=$DATA_DIR/whatsapp
ARCHE_EDICION=escritorio
ESCRITORIO_NEGOCIO=$NEGOCIO
LICENCIA_DIR=$DATA_DIR
UPDATE_URL=$UPDATE_URL
USUARIO_ESCRITORIO=$USUARIO
PUBLIC_URL=$PUBLIC_URL
EOF
  chown root:arche "$ENV_FILE"
  chmod 640 "$ENV_FILE"
}
escribir_env

# ── 6. Servicio: arranca solo al prender la PC ──────────────────────────────
paso "Servicio de arranque automático"
cat > "/etc/systemd/system/$SERVICE.service" <<EOF
[Unit]
Description=Arche · $NEGOCIO (sistema de facturación)
After=network-online.target postgresql.service
Wants=network-online.target postgresql.service

[Service]
Type=simple
User=arche
WorkingDirectory=$APP_DIR/actual/server
ExecStart=$NODE_DIR/bin/node scripts/run-instance.js $ENV_FILE
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now "$SERVICE" >/dev/null
for i in $(seq 1 30); do curl -fs "http://127.0.0.1:$PORT/api/setup/status" >/dev/null && break; sleep 1; done
curl -fs "http://127.0.0.1:$PORT/api/setup/status" >/dev/null || falla "El sistema no arrancó. Mira: journalctl -u $SERVICE -n 50"
ok "Sistema en marcha en el puerto $PORT"

ESTADO="$(curl -fs "http://127.0.0.1:$PORT/api/setup/status")"
if echo "$ESTADO" | grep -q '"dbState":"schema_missing"\|"dbState":"db_missing"'; then
  curl -fs -X POST -H 'Content-Type: application/json' -d '{}' "http://127.0.0.1:$PORT/api/setup/init-database" >/dev/null || falla "No se pudo crear la estructura de la base"
  systemctl restart "$SERVICE"; sleep 3
  ok "Estructura de la base creada"
fi

# ── 7. Datos de un respaldo (opcional) ──────────────────────────────────────
if [ -n "$RESPALDO" ]; then
  paso "Cargando el respaldo $(basename "$RESPALDO")"
  bash "$APP_DIR/actual/escritorio/restaurar.sh" "$RESPALDO" --sin-confirmar
fi

# ── 8. Respaldo diario ──────────────────────────────────────────────────────
paso "Respaldo automático diario"
cat > "/etc/systemd/system/$SERVICE-respaldo.service" <<EOF
[Unit]
Description=Respaldo diario de Arche · $NEGOCIO
After=postgresql.service

[Service]
Type=oneshot
Environment=USUARIO_ESCRITORIO=$USUARIO
ExecStart=$APP_DIR/actual/escritorio/respaldo.sh
EOF
cat > "/etc/systemd/system/$SERVICE-respaldo.timer" <<EOF
[Unit]
Description=Respaldo diario de Arche · $NEGOCIO (11:30 p. m., o al prender si se lo perdió)

[Timer]
OnCalendar=*-*-* 23:30:00
Persistent=true

[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload
systemctl enable --now "$SERVICE-respaldo.timer" >/dev/null
cat > "/etc/systemd/system/$SERVICE-actualizar.service" <<EOF
[Unit]
Description=Buscar actualizaciones de Arche · $NEGOCIO
After=network-online.target $SERVICE.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$APP_DIR/actual/escritorio/actualizar.sh
EOF
cat > "/etc/systemd/system/$SERVICE-actualizar.timer" <<EOF
[Unit]
Description=Buscar actualizaciones de Arche · $NEGOCIO (al prender y cada 2 horas)

# La PC del negocio no siempre está prendida de madrugada: se revisa a los 3
# minutos de prenderla (antes de que empiecen a vender) y cada 2 horas mientras
# esté encendida. actualizar.sh no instala si hubo ventas en los últimos 15 min.
[Timer]
OnBootSec=3min
OnUnitActiveSec=2h
RandomizedDelaySec=5min

[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload
systemctl enable --now "$SERVICE-actualizar.timer" >/dev/null
ok "Todos los días a las 11:30 p. m. → $HOME_USUARIO/Respaldos $NEGOCIO (y a una memoria USB con la carpeta \"Respaldos-$NEGOCIO\")"

ok "Busca actualizaciones al prender la PC y cada 2 horas (no interrumpe ventas)"

# ── 9. Que la PC no se suspenda ─────────────────────────────────────────────
paso "La PC no se suspende sola"
systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target >/dev/null 2>&1 || true
sudo -u "$USUARIO" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$(id -u "$USUARIO")/bus" \
  gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type 'nothing' 2>/dev/null || true
ok "Suspensión desactivada (la pantalla sí se puede apagar)"

# ── 10. Tailscale: dirección fija para los teléfonos de afuera ──────────────
if [ "$CON_TAILSCALE" = 1 ]; then
  paso "Tailscale (dirección para usar el sistema desde cualquier lugar)"
  if ! command -v tailscale >/dev/null; then
    curl -fsSL https://tailscale.com/install.sh | sh >/dev/null
  fi
  systemctl enable --now tailscaled >/dev/null
  if ! tailscale status >/dev/null 2>&1; then
    if [ -n "$TS_CLAVE" ]; then
      tailscale up --authkey="$TS_CLAVE" --hostname="$(echo "$NEGOCIO" | tr 'A-Z' 'a-z')" || aviso "La llave de Tailscale no sirvió (¿venció?). Corre otra vez sin --tailscale-clave para entrar con el enlace."
    else
      echo
      echo "  Ahora se abre (o aparece abajo) un enlace de Tailscale."
      echo "  Ábrelo, entra con tu cuenta (Google sirve) y autoriza esta PC."
      echo
      tailscale up --hostname="$(echo "$NEGOCIO" | tr 'A-Z' 'a-z')"
    fi
  fi
  echo
  echo "  Activando la dirección pública (Funnel). Si Tailscale muestra un enlace"
  echo "  para habilitar Funnel, ábrelo, acéptalo y vuelve aquí."
  echo
  tailscale funnel --bg "$PORT" || aviso "No se activó Funnel. Cuando lo habilites, corre otra vez: bash instalar.sh"
  DNS="$(tailscale status --json | python3 -c 'import sys,json; print(json.load(sys.stdin)["Self"]["DNSName"].rstrip("."))' 2>/dev/null || true)"
  if [ -n "$DNS" ] && tailscale funnel status 2>/dev/null | grep -q "$DNS"; then
    PUBLIC_URL="https://$DNS"
    escribir_env
    systemctl restart "$SERVICE"
    ok "Dirección pública: $PUBLIC_URL"
  else
    aviso "La dirección pública todavía no está activa."
  fi
fi

# ── 11. Accesos directos ────────────────────────────────────────────────────
paso "Accesos directos"
ESCRITORIO="$(sudo -u "$USUARIO" xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME_USUARIO/Escritorio")"
APPS="$HOME_USUARIO/.local/share/applications"
mkdir -p "$APPS" "$ESCRITORIO"
crear_acceso() { # archivo nombre comentario argumento
  cat > "$APPS/$1" <<EOF
[Desktop Entry]
Type=Application
Name=$2
Comment=$3
Exec=bash $APP_DIR/actual/escritorio/abrir.sh $4
Icon=$APP_DIR/actual/public/icons/icon-512.png
Terminal=false
Categories=Office;
EOF
  cp "$APPS/$1" "$ESCRITORIO/$1"
  chown "$USUARIO:$USUARIO" "$APPS/$1" "$ESCRITORIO/$1"
  chmod +x "$ESCRITORIO/$1"
  sudo -u "$USUARIO" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$(id -u "$USUARIO")/bus" \
    gio set "$ESCRITORIO/$1" metadata::trusted true 2>/dev/null || true
}
crear_acceso "$SLUG.desktop" "$NEGOCIO" "Abrir el sistema de $NEGOCIO" sistema
crear_acceso "$SLUG-conectar.desktop" "$NEGOCIO · Conectar teléfono" "Código QR para abrir el sistema en un teléfono" conectar
ok "En el escritorio y en el menú de aplicaciones"

# ── Listo ───────────────────────────────────────────────────────────────────
IP_LOCAL="$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^(192\.168|10\.|172\.(1[6-9]|2[0-9]|3[01]))\.' | head -1)"
echo
printf '\033[1;32m%s\033[0m\n' "✔ $NEGOCIO quedó instalado en esta PC."
echo "  · En esta PC:            http://localhost:$PORT  (acceso directo \"$NEGOCIO\")"
[ -n "$IP_LOCAL" ] && echo "  · En el Wi-Fi del local:  http://$IP_LOCAL:$PORT"
[ -n "$PUBLIC_URL" ] && echo "  · Desde cualquier lugar:  $PUBLIC_URL"
echo "  · Los teléfonos: abre \"$NEGOCIO · Conectar teléfono\" y escanea el código."
if echo "$(curl -fs "http://127.0.0.1:$PORT/api/setup/status")" | grep -q '"needsSetup":true'; then
  echo "  · Primera vez: pega la LICENCIA en la pantalla que se abre. Después, si traes los datos de"
  echo "    otro equipo, toca «Cargar un respaldo (.json)»; si es un negocio nuevo, llena el asistente."
fi
echo "  · Para dejar fija la IP en el Wi-Fi del local: bash $APP_DIR/actual/escritorio/fijar-ip.sh"
sudo -u "$USUARIO" DISPLAY="${DISPLAY:-:0}" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$(id -u "$USUARIO")/bus" \
  xdg-open "http://localhost:$PORT/" >/dev/null 2>&1 &
