/* ═══ Administrativo en el celular: barra de pestañas + hoja «Más» (v3.2) ═══
   Antes el menú del dueño en el celular era un panel lateral con 4 grupos
   plegados (Inventario, Análisis, Catálogo, Negocio): quedaba medio vacío y
   cada sección costaba dos toques. Ahora sigue el mismo patrón que la
   facturación y que Chicheros: abajo, las 4 secciones de todos los días + «Más»,
   que abre una hoja con TODAS las secciones a la vista, agrupadas.
   Se arma desde el menú de escritorio (#owner-tabs), así respeta solo los
   módulos apagados (Modules.viewOff) y los íconos de siempre. Solo se ve por
   debajo de 820 px (ver app.css, «Administrativo en el celular»). */
(function () {
  'use strict';
  const app = document.getElementById('owner-app');
  const nav = document.getElementById('owner-tabs');
  if (!app || !nav) return;
  const TABS = ['panel', 'historial', 'inv-existencias', 'reportes'];
  const off = view => !!(window.Modules && Modules.viewOff(view));
  const itemFor = view => nav.querySelector(`.nav-item[data-view="${view}"]`);
  const iconOf = item => { const svg = item.querySelector('svg'); return svg ? svg.outerHTML : ''; };
  const labelOf = item => (item.querySelector('.nav-label') || item).textContent.trim();
  const MORE_ICON = '<svg class="nav-icon" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="4" cy="9" r="1.4"/><circle cx="9" cy="9" r="1.4"/><circle cx="14" cy="9" r="1.4"/></svg>';

  /* ── Barra de abajo ── */
  const bar = document.createElement('nav');
  bar.className = 'owner-tabbar';
  bar.setAttribute('aria-label', 'Secciones principales');
  app.appendChild(bar);

  function paintBar() {
    const tabs = TABS.filter(v => itemFor(v) && !off(v));
    bar.innerHTML = tabs.map(v => {
      const it = itemFor(v);
      return `<button type="button" class="owner-tab" data-view="${v}">${iconOf(it)}<span>${labelOf(it)}</span></button>`;
    }).join('') + `<button type="button" class="owner-tab" data-more aria-haspopup="dialog">${MORE_ICON}<span>Más</span></button>`;
    markActive(currentView);
  }

  /* ── Hoja «Más» ── */
  const sheet = document.createElement('div');
  sheet.className = 'owner-more';
  sheet.hidden = true;
  sheet.innerHTML = `
    <div class="owner-more-backdrop" data-close></div>
    <section class="owner-more-panel" role="dialog" aria-modal="true" aria-label="Todas las secciones">
      <div class="owner-more-handle" aria-hidden="true"></div>
      <div class="owner-more-head">
        <div><p class="owner-more-kicker">Administrativo</p><h2 class="owner-more-title"></h2></div>
        <button type="button" class="owner-more-close" data-close aria-label="Cerrar">✕</button>
      </div>
      <div class="owner-more-body"></div>
      <div class="owner-more-foot">
        <a class="btn btn-sm" href="ayuda.html?role=owner" target="shaker-ayuda">Ayuda</a>
        <button type="button" class="btn btn-sm" data-logout>Salir</button>
        <span class="owner-more-arche" role="img" aria-label="Arche"></span>
      </div>
    </section>`;
  document.body.appendChild(sheet);
  const body = sheet.querySelector('.owner-more-body');

  function paintSheet() {
    const name = document.getElementById('brand-name-owner');
    sheet.querySelector('.owner-more-title').textContent = name ? name.textContent.trim() : '';
    body.innerHTML = Array.from(nav.querySelectorAll('.nav-group')).map(g => {
      const lbl = g.querySelector('.nav-group-label');
      const items = Array.from(g.querySelectorAll('.nav-item[data-view]')).filter(it => !off(it.dataset.view));
      if (!items.length) return '';
      return `<div class="owner-more-group">
        <p class="owner-more-label">${lbl ? lbl.childNodes[0].textContent.trim() : 'Día a día'}</p>
        <div class="owner-more-grid">${items.map(it => `<button type="button" class="owner-more-item${it.dataset.view === currentView ? ' is-active' : ''}" data-view="${it.dataset.view}">${iconOf(it)}<span>${labelOf(it)}</span></button>`).join('')}</div>
      </div>`;
    }).join('');
  }

  let lastFocus = null;
  function openSheet() {
    paintSheet();
    lastFocus = document.activeElement;
    sheet.hidden = false;
    requestAnimationFrame(() => sheet.classList.add('is-open'));
    document.documentElement.classList.add('owner-more-lock');
    const first = sheet.querySelector('.owner-more-item');
    if (first) first.focus({ preventScroll: true });
  }
  function closeSheet() {
    if (sheet.hidden) return;
    sheet.classList.remove('is-open');
    document.documentElement.classList.remove('owner-more-lock');
    setTimeout(() => { sheet.hidden = true; }, 260);
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }

  bar.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.hasAttribute('data-more')) { openSheet(); return; }
    window.showView(b.dataset.view);
    window.scrollTo({ top: 0 });
  });
  sheet.addEventListener('click', e => {
    if (e.target.closest('[data-close]')) { closeSheet(); return; }
    const it = e.target.closest('.owner-more-item');
    if (it) { window.showView(it.dataset.view); window.scrollTo({ top: 0 }); closeSheet(); }
    if (e.target.closest('[data-logout]')) closeSheet();
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

  // Deslizar hacia abajo desde el asa o el encabezado cierra la hoja.
  const panel = sheet.querySelector('.owner-more-panel');
  let y0 = null;
  panel.addEventListener('touchstart', e => { if (e.target.closest('.owner-more-handle, .owner-more-head')) y0 = e.touches[0].clientY; }, { passive: true });
  panel.addEventListener('touchmove', e => { if (y0 === null) return; const dy = Math.max(0, e.touches[0].clientY - y0); panel.style.transform = `translateY(${dy}px)`; }, { passive: true });
  panel.addEventListener('touchend', e => {
    if (y0 === null) return;
    const dy = e.changedTouches[0].clientY - y0; y0 = null; panel.style.transform = '';
    if (dy > 80) closeSheet();
  });

  /* ── Pestaña activa ── */
  let currentView = 'panel';
  function markActive(view) {
    const inBar = TABS.includes(view) && bar.querySelector(`[data-view="${view}"]`);
    bar.querySelectorAll('.owner-tab').forEach(b => {
      const on = inBar ? b.dataset.view === view : b.hasAttribute('data-more');
      b.classList.toggle('is-active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
  }
  window.addEventListener('view:show', e => { currentView = e.detail.view; markActive(currentView); });

  // Los módulos llegan después (appSettings.js): se rearma cuando cambian las clases del menú.
  new MutationObserver(() => paintBar()).observe(nav, { subtree: true, attributes: true, attributeFilter: ['class'] });
  paintBar();
})();
