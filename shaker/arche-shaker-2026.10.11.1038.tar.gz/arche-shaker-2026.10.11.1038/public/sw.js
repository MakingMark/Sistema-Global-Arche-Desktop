/* ═══ Service Worker: solo cachea el "cascarón" de la app (HTML/CSS/JS) para
   que un carrito pueda recargar la página aunque no haya señal — NO cachea
   nada de /api/* (eso lo maneja offlineDb.js/api.js, con reglas de negocio
   reales, no una copia ciega de la última respuesta). Sin esto, quedarse sin
   señal justo cuando el navegador necesita recargar (ej. se cerró la
   pestaña, o el celular mató la app en segundo plano) dejaba una pantalla en
   blanco en vez de la app funcionando en modo offline. ═══ */

// Subir este número fuerza a todos los carritos a bajar el cascarón de
// nuevo la próxima vez que haya señal — hacerlo cuando cambie algo real en
// los archivos de esta lista (un js nuevo, un cambio grande de app.css).
const CACHE_NAME = 'app-shell-v13';

const SHELL_FILES = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/css/app.css',
  '/js/brandCore.js',
  '/js/modules.js',
  '/js/vocab.js',
  '/js/negocio.js',
  '/js/modulos.js',
  '/js/brand.js',
  '/js/marca.js',
  '/js/fotos.js',
  '/js/paginaWeb.js',
  '/js/api.js',
  '/js/ui.js',
  '/js/uiMotion.js',
  '/js/subtabs.js',
  '/js/supplyPicker.js',
  '/js/theme.js',
  '/js/appSettings.js',
  '/js/print.js',
  '/js/loginShowcase.js',
  '/js/auth.js',
  '/js/cuenta.js',
  '/js/setup.js',
  '/js/app.js',
  '/js/ownerNav.js',
  '/js/dashboard.js',
  '/js/insumos.js',
  '/js/importar.js',
  '/js/menu.js',
  '/js/menuWeb.js',
  '/js/ubicaciones.js',
  '/js/transferir.js',
  '/js/clientes.js',
  '/js/ofertas.js',
  '/js/whatsappConfig.js',
  '/js/historial.js',
  '/js/historialInventario.js',
  '/js/empleados.js',
  '/js/turnos.js',
  '/js/reportes.js',
  '/js/analitica.js',
  '/js/preparar.js',
  '/js/gastos.js',
  '/js/taxCore.js',
  '/js/devoluciones.js',
  '/js/compras.js',
  '/js/restock.js',
  '/js/posMenu.js',
  '/js/pos.js',
  '/js/mesas.js',
  '/js/caja.js',
  '/js/pedidosWeb.js',
  '/js/licenciaAviso.js',
  '/js/offlineDb.js',
  '/js/offlineSync.js'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(names => Promise.all(names.filter(n => n !== CACHE_NAME).map(n => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // /api/* nunca se sirve desde acá — ni una respuesta vieja de la API
  // pasa por este cache, a propósito (ver comentario de arriba del archivo).
  if (url.pathname.startsWith('/api/')) return;
  if (event.request.method !== 'GET') return;

  // Network-first con reserva en cache: mientras hay señal, siempre se
  // pide la versión real (así un cambio nuevo de la app llega apenas se
  // recarga) — el cache es solo la red de seguridad para cuando la
  // petición de red directamente falla (sin señal).
  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        }
        return response;
      })
      .catch(() => caches.match(event.request).then(cached => cached || caches.match('/index.html')))
  );
});
